/*
Copyright © contributors to CloudNativePG, established as
CloudNativePG a Series of LF Projects, LLC.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

SPDX-License-Identifier: Apache-2.0
*/

package controller

import (
	"context"
	"fmt"
	"maps"
	"reflect"
	"slices"
	"time"

	"github.com/cloudnative-pg/machinery/pkg/log"
	monitoringv1 "github.com/prometheus-operator/prometheus-operator/pkg/apis/monitoring/v1"
	"github.com/sethvargo/go-password/password"
	corev1 "k8s.io/api/core/v1"
	policyv1 "k8s.io/api/policy/v1"
	rbacv1 "k8s.io/api/rbac/v1"
	"k8s.io/apimachinery/pkg/api/equality"
	apierrs "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/discovery"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"

	apiv1 "github.com/cloudnative-pg/cloudnative-pg/api/v1"
	"github.com/cloudnative-pg/cloudnative-pg/internal/configuration"
	"github.com/cloudnative-pg/cloudnative-pg/pkg/certs"
	"github.com/cloudnative-pg/cloudnative-pg/pkg/postgres"
	"github.com/cloudnative-pg/cloudnative-pg/pkg/reconciler/persistentvolumeclaim"
	"github.com/cloudnative-pg/cloudnative-pg/pkg/servicespec"
	"github.com/cloudnative-pg/cloudnative-pg/pkg/specs"
	"github.com/cloudnative-pg/cloudnative-pg/pkg/utils"
	"github.com/cloudnative-pg/cloudnative-pg/pkg/versions"
)

// createPostgresClusterObjects ensures that we have the required global objects
func (r *ClusterReconciler) createPostgresClusterObjects(ctx context.Context, cluster *apiv1.Cluster) error {
	err := r.setupPostgresPKI(ctx, cluster)
	if err != nil {
		return err
	}

	err = r.reconcilePostgresSecrets(ctx, cluster)
	if err != nil {
		return err
	}

	err = r.reconcilePostgresServices(ctx, cluster)
	if err != nil {
		return err
	}

	err = r.reconcilePodDisruptionBudget(ctx, cluster)
	if err != nil {
		return err
	}

	err = r.createOrPatchServiceAccount(ctx, cluster)
	if err != nil {
		return err
	}

	err = r.createOrPatchRole(ctx, cluster)
	if err != nil {
		return err
	}

	err = r.createRoleBinding(ctx, cluster)
	if err != nil {
		return err
	}

	if !cluster.Spec.Monitoring.AreDefaultQueriesDisabled() {
		err = r.createOrPatchDefaultMetrics(ctx, cluster)
		if err != nil {
			return nil
		}
	}

	err = createOrPatchPodMonitor(ctx, r.Client, r.DiscoveryClient, specs.NewClusterPodMonitorManager(cluster))
	if err != nil {
		return err
	}

	err = r.reconcileFailoverQuorumObject(ctx, cluster)
	if err != nil {
		return err
	}

	err = r.reconcilePrimaryLease(ctx, cluster)
	if err != nil {
		return err
	}

	return nil
}

func (r *ClusterReconciler) reconcilePodDisruptionBudget(ctx context.Context, cluster *apiv1.Cluster) error {
	if !cluster.GetEnablePDB() {
		return r.deletePodDisruptionBudgetsIfExist(ctx, cluster)
	}

	primaryPDB := specs.BuildPrimaryPodDisruptionBudget(cluster)
	replicaPDB := specs.BuildReplicasPodDisruptionBudget(cluster)

	if cluster.IsNodeMaintenanceWindowInProgress() && cluster.IsReusePVCEnabled() {
		// The replica PDB should not be enforced if we are inside a maintenance
		// window, and we chose to avoid allocating more storage space.
		replicaPDB = nil

		// If this a single-instance cluster, we need to delete
		// the PodDisruptionBudget for the primary node too
		// otherwise the user won't be able to drain the workloads
		// from the underlying node.
		if cluster.Spec.Instances == 1 {
			primaryPDB = nil
		}
	}

	if err := r.handlePDB(ctx, cluster, primaryPDB, r.deletePrimaryPodDisruptionBudgetIfExists); err != nil {
		return err
	}

	return r.handlePDB(ctx, cluster, replicaPDB, r.deleteReplicasPodDisruptionBudgetIfExists)
}

func (r *ClusterReconciler) handlePDB(
	ctx context.Context,
	cluster *apiv1.Cluster,
	pdb *policyv1.PodDisruptionBudget,
	deleteFunc func(context.Context, *apiv1.Cluster) error,
) error {
	if pdb != nil {
		return r.createOrPatchOwnedPodDisruptionBudget(ctx, cluster, pdb)
	}
	return deleteFunc(ctx, cluster)
}

func (r *ClusterReconciler) reconcilePostgresSecrets(ctx context.Context, cluster *apiv1.Cluster) error {
	err := r.reconcileSuperuserSecret(ctx, cluster)
	if err != nil {
		return err
	}

	err = r.reconcileAppUserSecret(ctx, cluster)
	if err != nil {
		return err
	}

	err = r.reconcilePoolerSecrets(ctx, cluster)
	if err != nil {
		return err
	}

	return nil
}

func (r *ClusterReconciler) reconcileSuperuserSecret(ctx context.Context, cluster *apiv1.Cluster) error {
	// We need to create a secret for the 'postgres' user when superuser
	// access is enabled and the user haven't specified his own
	if cluster.GetEnableSuperuserAccess() &&
		(cluster.Spec.SuperuserSecret == nil || cluster.Spec.SuperuserSecret.Name == "") {
		postgresPassword, err := password.Generate(64, 10, 0, false, true)
		if err != nil {
			return err
		}
		postgresSecret := specs.CreateSecret(
			cluster.GetSuperuserSecretName(),
			cluster.Namespace,
			cluster.GetServiceReadWriteName(),
			"*",
			"postgres",
			postgresPassword,
			utils.UserTypeSuperuser)
		cluster.SetInheritedDataAndOwnership(&postgresSecret.ObjectMeta)

		return createOrPatchClusterCredentialSecret(ctx, r.Client, postgresSecret)
	}

	// If we don't have Superuser enabled we make sure the automatically generated secret doesn't exist
	if !cluster.GetEnableSuperuserAccess() {
		var secret corev1.Secret
		err := r.Get(
			ctx,
			client.ObjectKey{Namespace: cluster.Namespace, Name: cluster.GetSuperuserSecretName()},
			&secret)
		if err != nil {
			if apierrs.IsNotFound(err) || apierrs.IsForbidden(err) {
				return nil
			}
			return err
		}

		if _, owned := IsOwnedByCluster(&secret); owned {
			return r.Delete(ctx, &secret)
		}
	}

	return nil
}

func (r *ClusterReconciler) reconcileAppUserSecret(ctx context.Context, cluster *apiv1.Cluster) error {
	if cluster.ShouldCreateApplicationSecret() {
		appPassword, err := password.Generate(64, 10, 0, false, true)
		if err != nil {
			return err
		}
		appSecret := specs.CreateSecret(
			cluster.GetApplicationSecretName(),
			cluster.Namespace,
			cluster.GetServiceReadWriteName(),
			cluster.GetApplicationDatabaseName(),
			cluster.GetApplicationDatabaseOwner(),
			appPassword,
			utils.UserTypeApp)

		cluster.SetInheritedDataAndOwnership(&appSecret.ObjectMeta)
		return createOrPatchClusterCredentialSecret(ctx, r.Client, appSecret)
	}
	return nil
}

func createOrPatchClusterCredentialSecret(
	ctx context.Context,
	cli client.Client,
	proposed *corev1.Secret,
) error {
	var currentSecret corev1.Secret
	if err := cli.Get(
		ctx,
		client.ObjectKey{Namespace: proposed.Namespace, Name: proposed.Name},
		&currentSecret); apierrs.IsNotFound(err) {
		return cli.Create(ctx, proposed)
	} else if err != nil {
		return err
	}

	// we can patch only secrets that are owned by us
	if _, owned := IsOwnedByCluster(&currentSecret); !owned {
		return nil
	}

	patchedSecret := currentSecret.DeepCopy()
	utils.MergeObjectsMetadata(patchedSecret, proposed)

	// we cannot compare the data due to the password being randomly generated everytime
	if reflect.DeepEqual(patchedSecret.Labels, currentSecret.Labels) &&
		reflect.DeepEqual(patchedSecret.Annotations, currentSecret.Annotations) {
		return nil
	}

	return cli.Patch(ctx, patchedSecret, client.MergeFrom(&currentSecret))
}

func (r *ClusterReconciler) reconcilePoolerSecrets(ctx context.Context, cluster *apiv1.Cluster) error {
	if cluster.Status.PoolerIntegrations == nil {
		return nil
	}

	if len(cluster.Status.PoolerIntegrations.PgBouncerIntegration.Secrets) > 0 {
		var clientCaSecret corev1.Secret

		err := r.Get(ctx, client.ObjectKey{Namespace: cluster.GetNamespace(), Name: cluster.GetClientCASecretName()},
			&clientCaSecret)
		if err != nil {
			return err
		}

		for _, secretName := range cluster.Status.PoolerIntegrations.PgBouncerIntegration.Secrets {
			replicationSecretName := client.ObjectKey{
				Namespace: cluster.GetNamespace(),
				Name:      secretName,
			}
			err = r.ensureLeafCertificate(
				ctx,
				cluster,
				replicationSecretName,
				apiv1.PGBouncerPoolerUserName,
				&clientCaSecret,
				certs.CertTypeClient,
				nil,
				map[string]string{utils.WatchedLabelName: "true"})
			if err != nil {
				return err
			}
		}
	}

	return nil
}

func (r *ClusterReconciler) reconcilePostgresServices(ctx context.Context, cluster *apiv1.Cluster) error {
	anyService := specs.CreateClusterAnyService(*cluster)
	cluster.SetInheritedDataAndOwnership(&anyService.ObjectMeta)

	if err := r.serviceReconciler(ctx, cluster, anyService, configuration.Current.CreateAnyService); err != nil {
		return err
	}

	readService := specs.CreateClusterReadService(*cluster)
	cluster.SetInheritedDataAndOwnership(&readService.ObjectMeta)

	if err := r.serviceReconciler(ctx, cluster, readService, cluster.IsReadServiceEnabled()); err != nil {
		return err
	}

	readOnlyService := specs.CreateClusterReadOnlyService(*cluster)
	cluster.SetInheritedDataAndOwnership(&readOnlyService.ObjectMeta)

	if err := r.serviceReconciler(ctx, cluster, readOnlyService, cluster.IsReadOnlyServiceEnabled()); err != nil {
		return err
	}

	readWriteService := specs.CreateClusterReadWriteService(*cluster)
	cluster.SetInheritedDataAndOwnership(&readWriteService.ObjectMeta)

	if err := r.serviceReconciler(ctx, cluster, readWriteService, cluster.IsReadWriteServiceEnabled()); err != nil {
		return err
	}

	return r.reconcileManagedServices(ctx, cluster)
}

func (r *ClusterReconciler) reconcileManagedServices(ctx context.Context, cluster *apiv1.Cluster) error {
	managedServices, err := specs.BuildManagedServices(*cluster)
	if err != nil {
		return err
	}
	for idx := range managedServices {
		if err := r.serviceReconciler(ctx, cluster, &managedServices[idx], true); err != nil {
			return err
		}
	}

	// we delete the old managed services not appearing anymore in the spec
	var livingServices corev1.ServiceList
	if err := r.List(ctx, &livingServices, client.InNamespace(cluster.Namespace), client.MatchingLabels{
		utils.IsManagedLabelName: "true",
		utils.ClusterLabelName:   cluster.Name,
	}); err != nil {
		return err
	}

	containService := func(expected corev1.Service) func(iterated corev1.Service) bool {
		return func(iterated corev1.Service) bool {
			return iterated.Name == expected.Name
		}
	}

	for idx := range livingServices.Items {
		livingService := livingServices.Items[idx]
		isEnabled := slices.ContainsFunc(managedServices, containService(livingService))
		if isEnabled {
			continue
		}

		// Ensure the service is not present
		if err := r.serviceReconciler(ctx, cluster, &livingService, false); err != nil {
			return err
		}
	}
	return nil
}

func (r *ClusterReconciler) serviceReconciler(
	ctx context.Context,
	cluster *apiv1.Cluster,
	proposed *corev1.Service,
	enabled bool,
) error {
	strategy := apiv1.ServiceUpdateStrategyPatch
	annotationStrategy := apiv1.ServiceUpdateStrategy(proposed.Annotations[utils.UpdateStrategyAnnotation])
	if annotationStrategy == apiv1.ServiceUpdateStrategyReplace {
		strategy = apiv1.ServiceUpdateStrategyReplace
	}

	contextLogger := log.FromContext(ctx).WithValues(
		"serviceName", proposed.Name,
		"updateStrategy", strategy,
	)

	var livingService corev1.Service
	err := r.Get(ctx, types.NamespacedName{Name: proposed.Name, Namespace: proposed.Namespace}, &livingService)
	if apierrs.IsNotFound(err) {
		if !enabled {
			return nil
		}
		contextLogger.Info("creating service")
		servicespec.SetLastApplied(&proposed.ObjectMeta, &proposed.Spec)
		return r.Create(ctx, proposed)
	}
	if err != nil {
		return err
	}

	if owner, _ := IsOwnedByCluster(&livingService); owner != cluster.Name {
		return fmt.Errorf("refusing to reconcile service: %s, not owned by the cluster", livingService.Name)
	}

	if !livingService.DeletionTimestamp.IsZero() {
		contextLogger.Info("waiting for service to be deleted")
		return ErrNextLoop
	}

	if !enabled {
		contextLogger.Info("deleting service, due to not being managed anymore")
		return r.Delete(ctx, &livingService)
	}
	var shouldUpdate bool

	// we ensure we've some space to store the labels and the annotations
	if livingService.Labels == nil {
		livingService.Labels = make(map[string]string)
	}
	if livingService.Annotations == nil {
		livingService.Annotations = make(map[string]string)
	}

	// we preserve existing labels/annotation that could be added by third parties
	if !utils.IsMapSubset(livingService.Labels, proposed.Labels) {
		maps.Copy(livingService.Labels, proposed.Labels)
		shouldUpdate = true
	}

	if !utils.IsMapSubset(livingService.Annotations, proposed.Annotations) {
		maps.Copy(livingService.Annotations, proposed.Annotations)
		shouldUpdate = true
	}

	// Three-way merge: start from living spec, overlay proposed changes,
	// and use last-applied annotation to detect intentional field removals
	patchedSpec := livingService.Spec.DeepCopy()
	if err := servicespec.ApplyProposedChanges(patchedSpec, &proposed.Spec, livingService.Annotations); err != nil {
		return err
	}
	if !reflect.DeepEqual(*patchedSpec, livingService.Spec) {
		livingService.Spec = *patchedSpec
		shouldUpdate = true
	}

	if !shouldUpdate {
		return nil
	}

	if strategy == apiv1.ServiceUpdateStrategyPatch {
		// Store the proposed spec for future three-way merges
		servicespec.SetLastApplied(&livingService.ObjectMeta, &proposed.Spec)
		contextLogger.Info("reconciling service")
		return r.Update(ctx, &livingService)
	}

	contextLogger.Info("deleting the service")
	if err := r.Delete(ctx, &livingService); err != nil {
		return err
	}

	return ErrNextLoop
}

// createOrPatchOwnedPodDisruptionBudget ensures that we have a PDB requiring to remove one node at a time
func (r *ClusterReconciler) createOrPatchOwnedPodDisruptionBudget(
	ctx context.Context,
	cluster *apiv1.Cluster,
	pdb *policyv1.PodDisruptionBudget,
) error {
	if pdb == nil {
		return nil
	}

	var oldPdb policyv1.PodDisruptionBudget

	if err := r.Get(ctx, client.ObjectKey{Name: pdb.Name, Namespace: pdb.Namespace}, &oldPdb); err != nil {
		if !apierrs.IsNotFound(err) {
			return fmt.Errorf("while getting PodDisruptionBudget: %w", err)
		}

		r.Recorder.Event(cluster, "Normal", "CreatingPodDisruptionBudget",
			fmt.Sprintf("Creating PodDisruptionBudget %s", pdb.Name))
		if err = r.Create(ctx, pdb); err != nil {
			return fmt.Errorf("while creating PodDisruptionBudget: %w", err)
		}
		return nil
	}

	patchedPdb := oldPdb.DeepCopy()
	patchedPdb.Spec = pdb.Spec
	utils.MergeObjectsMetadata(patchedPdb, pdb)

	if reflect.DeepEqual(patchedPdb.Spec, oldPdb.Spec) && reflect.DeepEqual(patchedPdb.ObjectMeta, oldPdb.ObjectMeta) {
		// Everything fine, the two pdbs are the same for us
		return nil
	}

	r.Recorder.Event(cluster, "Normal", "UpdatingPodDisruptionBudget",
		fmt.Sprintf("Updating PodDisruptionBudget %s", pdb.Name))

	if err := r.Patch(ctx, patchedPdb, client.MergeFrom(&oldPdb)); err != nil {
		return fmt.Errorf("while patching PodDisruptionBudget: %w", err)
	}

	return nil
}

func (r *ClusterReconciler) deletePodDisruptionBudgetsIfExist(ctx context.Context, cluster *apiv1.Cluster) error {
	if err := r.deletePrimaryPodDisruptionBudgetIfExists(ctx, cluster); err != nil {
		return err
	}

	return r.deleteReplicasPodDisruptionBudgetIfExists(ctx, cluster)
}

func (r *ClusterReconciler) deletePrimaryPodDisruptionBudgetIfExists(
	ctx context.Context,
	cluster *apiv1.Cluster,
) error {
	return r.deletePodDisruptionBudgetIfExists(
		ctx,
		cluster,
		client.ObjectKey{Name: cluster.Name + apiv1.PrimaryPodDisruptionBudgetSuffix, Namespace: cluster.Namespace})
}

func (r *ClusterReconciler) deleteReplicasPodDisruptionBudgetIfExists(
	ctx context.Context,
	cluster *apiv1.Cluster,
) error {
	return r.deletePodDisruptionBudgetIfExists(
		ctx,
		cluster,
		client.ObjectKey{Name: cluster.Name, Namespace: cluster.Namespace},
	)
}

func (r *ClusterReconciler) deletePodDisruptionBudgetIfExists(
	ctx context.Context,
	cluster *apiv1.Cluster,
	key types.NamespacedName,
) error {
	// If we have a PDB, we need to delete it
	var targetPdb policyv1.PodDisruptionBudget
	err := r.Get(ctx, key, &targetPdb)
	if err != nil {
		if !apierrs.IsNotFound(err) {
			return fmt.Errorf("unable to retrieve PodDisruptionBudget: %w", err)
		}
		return nil
	}

	r.Recorder.Event(cluster,
		"Normal",
		"DeletingPodDisruptionBudget",
		"Deleting Pod Disruption Budget "+key.Name)

	err = r.Delete(ctx, &targetPdb)
	if err != nil {
		if !apierrs.IsNotFound(err) {
			return fmt.Errorf("unable to delete PodDisruptionBudget: %w", err)
		}
		return nil
	}
	return nil
}

// createOrPatchServiceAccount creates or synchronizes the ServiceAccount used by the
// cluster with the latest cluster specification
func (r *ClusterReconciler) createOrPatchServiceAccount(ctx context.Context, cluster *apiv1.Cluster) error {
	if cluster.Spec.ServiceAccountName != "" {
		return r.validateExistingServiceAccount(ctx, cluster)
	}

	var sa corev1.ServiceAccount
	if err := r.Get(ctx, client.ObjectKey{Name: cluster.Name, Namespace: cluster.Namespace}, &sa); err != nil {
		if !apierrs.IsNotFound(err) {
			return fmt.Errorf("while getting service account: %w", err)
		}

		r.Recorder.Event(cluster, "Normal", "CreatingServiceAccount", "Creating ServiceAccount")
		return r.createServiceAccount(ctx, cluster)
	}

	generatedPullSecretNames, err := r.generateServiceAccountPullSecretsNames(ctx, cluster)
	if err != nil {
		return fmt.Errorf("while generating pull secret names: %w", err)
	}

	origSa := sa.DeepCopy()
	err = specs.UpdateServiceAccount(generatedPullSecretNames, &sa)
	if err != nil {
		return fmt.Errorf("while generating service account: %w", err)
	}
	// we add the ownerMetadata only when creating the SA
	cluster.SetInheritedData(&sa.ObjectMeta)
	cluster.Spec.ServiceAccountTemplate.MergeMetadata(&sa)

	if specs.IsServiceAccountAligned(
		ctx,
		origSa,
		generatedPullSecretNames,
		sa.ObjectMeta,
	) {
		return nil
	}

	r.Recorder.Event(cluster, "Normal", "UpdatingServiceAccount", "Updating ServiceAccount")
	if err := r.Patch(ctx, &sa, client.MergeFrom(origSa)); err != nil {
		return fmt.Errorf("while patching service account: %w", err)
	}

	return nil
}

// validateExistingServiceAccount checks if the specified ServiceAccount exists
func (r *ClusterReconciler) validateExistingServiceAccount(ctx context.Context, cluster *apiv1.Cluster) error {
	var sa corev1.ServiceAccount
	err := r.Get(ctx, client.ObjectKey{
		Name:      cluster.Spec.ServiceAccountName,
		Namespace: cluster.Namespace,
	}, &sa)
	if err != nil {
		if apierrs.IsNotFound(err) {
			r.Recorder.Eventf(cluster, "Warning", "ServiceAccountNotFound",
				"Specified ServiceAccount %q not found in namespace %q",
				cluster.Spec.ServiceAccountName, cluster.Namespace)
			return fmt.Errorf("serviceAccount %q not found: %w", cluster.Spec.ServiceAccountName, err)
		}
		return fmt.Errorf("while validating existing service account: %w", err)
	}

	return nil
}

// createServiceAccount creates the service account for this PostgreSQL cluster
func (r *ClusterReconciler) createServiceAccount(ctx context.Context, cluster *apiv1.Cluster) error {
	generatedPullSecretNames, err := r.generateServiceAccountPullSecretsNames(ctx, cluster)
	if err != nil {
		return fmt.Errorf("while generating pull secret names: %w", err)
	}

	serviceAccount := &corev1.ServiceAccount{
		ObjectMeta: metav1.ObjectMeta{
			Namespace: cluster.Namespace,
			Name:      cluster.Name,
			Labels: map[string]string{
				utils.KubernetesAppManagedByLabelName: utils.ManagerName,
			},
		},
	}
	err = specs.UpdateServiceAccount(generatedPullSecretNames, serviceAccount)
	if err != nil {
		return fmt.Errorf("while creating new ServiceAccount: %w", err)
	}

	cluster.SetInheritedDataAndOwnership(&serviceAccount.ObjectMeta)
	cluster.Spec.ServiceAccountTemplate.MergeMetadata(serviceAccount)

	err = r.Create(ctx, serviceAccount)
	if err != nil && !apierrs.IsAlreadyExists(err) {
		return err
	}

	return nil
}

// generateServiceAccountPullSecretsNames extracts the list of pull secret names given
// the cluster configuration
func (r *ClusterReconciler) generateServiceAccountPullSecretsNames(
	ctx context.Context, cluster *apiv1.Cluster,
) ([]string, error) {
	pullSecretNames := make([]string, 0, len(cluster.Spec.ImagePullSecrets))

	// Try to copy the secret from the operator
	operatorPullSecret, err := r.copyPullSecretFromOperator(ctx, cluster)
	if err != nil {
		return nil, err
	}

	if operatorPullSecret != "" {
		pullSecretNames = append(pullSecretNames, operatorPullSecret)
	}

	// Append the secrets specified by the user
	for _, secretReference := range cluster.Spec.ImagePullSecrets {
		pullSecretNames = append(pullSecretNames, secretReference.Name)
	}

	return pullSecretNames, nil
}

// copyPullSecretFromOperator will create a secret to download the operator, if the
// operator was downloaded via a Secret.
// It will return the string of the secret name if a secret need to be used to use the operator
func (r *ClusterReconciler) copyPullSecretFromOperator(ctx context.Context, cluster *apiv1.Cluster) (string, error) {
	if configuration.Current.OperatorNamespace == "" {
		// We are not getting started via a k8s deployment. Perhaps we are running in our development environment
		return "", nil
	}

	// Let's find the operator secret
	var operatorSecret corev1.Secret
	if err := r.Get(ctx, client.ObjectKey{
		Name:      configuration.Current.OperatorPullSecretName,
		Namespace: configuration.Current.OperatorNamespace,
	}, &operatorSecret); err != nil {
		if apierrs.IsNotFound(err) {
			// There is no secret like that, probably because we are running in our development environment
			return "", nil
		}
		return "", err
	}

	clusterSecretName := fmt.Sprintf("%s-pull", cluster.Name)

	// Let's create the secret with the required info
	secret := corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Namespace: cluster.Namespace,
			Name:      clusterSecretName,
		},
		Data: operatorSecret.Data,
		Type: operatorSecret.Type,
	}
	cluster.SetInheritedDataAndOwnership(&secret.ObjectMeta)

	// Another sync loop may have already created the service. Let's check that
	if err := r.Create(ctx, &secret); err != nil && !apierrs.IsAlreadyExists(err) {
		return "", err
	}

	return clusterSecretName, nil
}

// createOrPatchRole ensures that the required role for the instance manager exists and
// contains the right rules
func (r *ClusterReconciler) createOrPatchRole(ctx context.Context, cluster *apiv1.Cluster) error {
	originBackup, err := r.getOriginBackup(ctx, cluster)
	if err != nil {
		return err
	}

	// List all the PG roles that will be reconciled by the primary
	// instance of the cluster. CreateRole will create a corev1.Role
	// resource allowing access to all the secrets that are referred
	// by them.
	var roleList apiv1.DatabaseRoleList

	if err := r.List(
		ctx,
		&roleList,
		client.InNamespace(cluster.Namespace),
		client.MatchingFields{
			databaseRoleClusterKey: cluster.Name,
		},
	); err != nil {
		return fmt.Errorf("while listing database roles: %w", err)
	}

	var role rbacv1.Role
	if err := r.Get(ctx, client.ObjectKey{Name: cluster.Name, Namespace: cluster.Namespace}, &role); err != nil {
		if !apierrs.IsNotFound(err) {
			return fmt.Errorf("while getting role: %w", err)
		}

		r.Recorder.Event(cluster, "Normal", "CreatingRole", "Creating Cluster Role")
		return r.createRole(ctx, cluster, originBackup, roleList.Items)
	}

	generatedRole := specs.CreateRole(
		specs.RoleOptions{
			Cluster:      cluster,
			BackupOrigin: originBackup,
			Roles:        roleList.Items,
		},
	)
	if equality.Semantic.DeepEqual(generatedRole.Rules, role.Rules) {
		// Everything fine, the two rules have the same content
		return nil
	}

	r.Recorder.Event(cluster, "Normal", "UpdatingRole", "Updating Cluster Role")

	// The configuration changed, and we need the patch the
	// configMap we have
	patchedRole := role.DeepCopy()
	patchedRole.Rules = generatedRole.Rules
	if err := r.Patch(ctx, patchedRole, client.MergeFrom(&role)); err != nil {
		return fmt.Errorf("while patching role: %w", err)
	}

	return nil
}

// createOrPatchDefaultMetricsConfigmap ensures that the required configmap containing
// default monitoring queries exists and contains the latest queries
func (r *ClusterReconciler) createOrPatchDefaultMetricsConfigmap(ctx context.Context, cluster *apiv1.Cluster) error {
	contextLogger := log.FromContext(ctx)

	// we extract the operator configMap that needs to be cloned in the namespace where the cluster lives
	var sourceConfigmap corev1.ConfigMap
	if err := r.Get(ctx,
		client.ObjectKey{
			Name:      configuration.Current.MonitoringQueriesConfigmap,
			Namespace: configuration.Current.OperatorNamespace,
		}, &sourceConfigmap); err != nil {
		if apierrs.IsNotFound(err) {
			contextLogger.Error(err, "while trying to get default metrics configMap")
			return nil
		}
		return err
	}

	if _, ok := sourceConfigmap.Data[apiv1.DefaultMonitoringKey]; !ok {
		contextLogger.Warning("key not found while checking default metrics configMap", "key",
			apiv1.DefaultMonitoringKey, "configmap_name", sourceConfigmap.Name)
		return nil
	}

	if cluster.Namespace == configuration.Current.OperatorNamespace &&
		configuration.Current.MonitoringQueriesConfigmap == apiv1.DefaultMonitoringConfigMapName {
		contextLogger.Debug(
			"skipping default metrics synchronization. The cluster resides in the same namespace of the operator",
			"clusterNamespace", cluster.Namespace,
			"clusterName", cluster.Name,
		)
		return nil
	}

	// we clone the configmap in the cluster namespace
	var targetConfigMap corev1.ConfigMap
	if err := r.Get(ctx,
		client.ObjectKey{
			Name:      apiv1.DefaultMonitoringConfigMapName,
			Namespace: cluster.Namespace,
		}, &targetConfigMap); err != nil {
		if !apierrs.IsNotFound(err) {
			return err
		}
		// if the configMap does not exist we create it
		newConfigMap := corev1.ConfigMap{
			ObjectMeta: metav1.ObjectMeta{
				Name:      apiv1.DefaultMonitoringConfigMapName,
				Namespace: cluster.Namespace,
				Labels: map[string]string{
					utils.WatchedLabelName:                "true",
					utils.KubernetesAppManagedByLabelName: utils.ManagerName,
				},
			},
			Data: map[string]string{
				apiv1.DefaultMonitoringKey: sourceConfigmap.Data[apiv1.DefaultMonitoringKey],
			},
		}
		utils.SetOperatorVersion(&newConfigMap.ObjectMeta, versions.Version)
		return r.Create(ctx, &newConfigMap)
	}

	// we check that we own the existing configmap
	if _, ok := targetConfigMap.Annotations[utils.OperatorVersionAnnotationName]; !ok {
		contextLogger.Warning("A configmap with the same name as the one the operator would have created for "+
			"default metrics already exists, without the required annotation",
			"configmap", targetConfigMap.Name, "annotation", utils.OperatorVersionAnnotationName)
		return nil
	}

	if reflect.DeepEqual(sourceConfigmap.Data, targetConfigMap.Data) {
		// Everything fine, the two secrets are exactly the same
		return nil
	}

	// The configuration changed, and we need the patch the configMap we have
	patchedConfigMap := targetConfigMap.DeepCopy()
	utils.SetOperatorVersion(&patchedConfigMap.ObjectMeta, versions.Version)
	patchedConfigMap.Data = sourceConfigmap.Data

	if err := r.Patch(ctx, patchedConfigMap, client.MergeFrom(&targetConfigMap)); err != nil {
		return fmt.Errorf("while patching default monitoring queries configmap: %w", err)
	}

	return nil
}

// createOrPatchDefaultMetricsConfigmap ensures that the required secret containing default
// monitoring queries exists and contains the latest queries
func (r *ClusterReconciler) createOrPatchDefaultMetricsSecret(ctx context.Context, cluster *apiv1.Cluster) error {
	contextLogger := log.FromContext(ctx)

	// We extract the operator configMap that needs to be cloned in the namespace where the cluster lives
	var sourceSecret corev1.Secret
	if err := r.Get(ctx,
		client.ObjectKey{
			Name:      configuration.Current.MonitoringQueriesSecret,
			Namespace: configuration.Current.OperatorNamespace,
		}, &sourceSecret); err != nil {
		if apierrs.IsNotFound(err) {
			contextLogger.Error(err, "while trying to get default metrics secret")
			return nil
		}
		return err
	}

	if _, ok := sourceSecret.Data[apiv1.DefaultMonitoringKey]; !ok {
		contextLogger.Warning("key not found while checking default metrics secret", "key",
			apiv1.DefaultMonitoringKey, "secret_name", sourceSecret.Name)
		return nil
	}

	if cluster.Namespace == configuration.Current.OperatorNamespace &&
		configuration.Current.MonitoringQueriesSecret == apiv1.DefaultMonitoringSecretName {
		contextLogger.Debug(
			"skipping default metrics synchronization. The cluster resides in the same namespace of the operator",
			"clusterNamespace", cluster.Namespace,
			"clusterName", cluster.Name,
		)
		return nil
	}

	// We clone the secret in the cluster namespace
	var targetSecret corev1.Secret
	if err := r.Get(ctx,
		client.ObjectKey{
			Name:      apiv1.DefaultMonitoringSecretName,
			Namespace: cluster.Namespace,
		}, &targetSecret); err != nil {
		if !apierrs.IsNotFound(err) {
			return err
		}
		// If the secret does not exist we create it
		newSecret := corev1.Secret{
			ObjectMeta: metav1.ObjectMeta{
				Name:      apiv1.DefaultMonitoringSecretName,
				Namespace: cluster.Namespace,
				Labels: map[string]string{
					utils.WatchedLabelName:                "true",
					utils.KubernetesAppManagedByLabelName: utils.ManagerName,
				},
			},
			Data: map[string][]byte{
				apiv1.DefaultMonitoringKey: sourceSecret.Data[apiv1.DefaultMonitoringKey],
			},
		}
		utils.SetOperatorVersion(&newSecret.ObjectMeta, versions.Version)
		return r.Create(ctx, &newSecret)
	}

	// We check that we own the existing configmap
	if _, ok := targetSecret.Annotations[utils.OperatorVersionAnnotationName]; !ok {
		contextLogger.Warning("A secret with the same name as the one the operator would have created for "+
			"default metrics already exists, without the required annotation",
			"secret", targetSecret.Name, "annotation", utils.OperatorVersionAnnotationName)
		return nil
	}

	if reflect.DeepEqual(sourceSecret.Data, targetSecret.Data) {
		// Everything fine, the two secrets are exactly the same
		return nil
	}

	// The configuration changed, and we need the patch the secret we have
	patchedSecret := targetSecret.DeepCopy()
	utils.SetOperatorVersion(&patchedSecret.ObjectMeta, versions.Version)
	patchedSecret.Data = sourceSecret.Data

	if err := r.Patch(ctx, patchedSecret, client.MergeFrom(&targetSecret)); err != nil {
		return fmt.Errorf("while patching default monitoring queries secret: %w", err)
	}

	return nil
}

func (r *ClusterReconciler) createOrPatchDefaultMetrics(ctx context.Context, cluster *apiv1.Cluster) (err error) {
	if configuration.Current.MonitoringQueriesConfigmap != "" {
		err = r.createOrPatchDefaultMetricsConfigmap(ctx, cluster)
		if err != nil {
			return err
		}
	}
	if configuration.Current.MonitoringQueriesSecret != "" {
		err = r.createOrPatchDefaultMetricsSecret(ctx, cluster)
		if err != nil {
			return err
		}
	}
	return nil
}

type podMonitorManager interface {
	// IsPodMonitorEnabled returns a boolean indicating if the PodMonitor should exists or not
	IsPodMonitorEnabled() bool
	// BuildPodMonitor builds a new PodMonitor object
	BuildPodMonitor() *monitoringv1.PodMonitor
}

// createOrPatchPodMonitor
func createOrPatchPodMonitor(
	ctx context.Context,
	cli client.Client,
	discoveryClient discovery.DiscoveryInterface,
	manager podMonitorManager,
) error {
	contextLogger := log.FromContext(ctx)

	// Checking for the PodMonitor Custom Resource Definition in the Kubernetes cluster
	havePodMonitorCRD, err := utils.PodMonitorExist(discoveryClient)
	if err != nil {
		return err
	}

	if !havePodMonitorCRD {
		if manager.IsPodMonitorEnabled() {
			// If the PodMonitor CRD does not exist, but the cluster has monitoring enabled,
			// the controller cannot do anything until the CRD is installed
			contextLogger.Warning("PodMonitor CRD not present. Cannot create the PodMonitor object")
		}
		return nil
	}

	expectedPodMonitor := manager.BuildPodMonitor()
	// We get the current pod monitor
	podMonitor := &monitoringv1.PodMonitor{}
	if err := cli.Get(
		ctx,
		client.ObjectKeyFromObject(expectedPodMonitor),
		podMonitor,
	); err != nil {
		if !apierrs.IsNotFound(err) {
			return fmt.Errorf("while getting the podmonitor: %w", err)
		}
		podMonitor = nil
	}

	switch {
	// Pod monitor disabled and no pod monitor - nothing to do
	case !manager.IsPodMonitorEnabled() && podMonitor == nil:
		return nil
	// Pod monitor disabled and pod monitor present - delete it
	case !manager.IsPodMonitorEnabled() && podMonitor != nil:
		if _, owned := IsOwnedByCluster(podMonitor); owned {
			contextLogger.Info("Deleting PodMonitor")
			if err := cli.Delete(ctx, podMonitor); err != nil {
				if !apierrs.IsNotFound(err) {
					return err
				}
			}
		}
		return nil
	// Pod monitor enabled and no pod monitor - create it
	case manager.IsPodMonitorEnabled() && podMonitor == nil:
		contextLogger.Debug("Creating PodMonitor")
		return cli.Create(ctx, expectedPodMonitor)
	// Pod monitor enabled and pod monitor present - update it
	default:
		origPodMonitor := podMonitor.DeepCopy()
		podMonitor.Spec = expectedPodMonitor.Spec
		// We don't override the current labels/annotations given that there could be data that isn't managed by us
		utils.MergeObjectsMetadata(podMonitor, expectedPodMonitor)

		// If there's no changes we are done
		if reflect.DeepEqual(origPodMonitor, podMonitor) {
			return nil
		}

		// Patch the PodMonitor, so we always reconcile it with the cluster changes
		contextLogger.Debug("Patching PodMonitor")
		return cli.Patch(ctx, podMonitor, client.MergeFrom(origPodMonitor))
	}
}

// createRole creates the role
func (r *ClusterReconciler) createRole(
	ctx context.Context,
	cluster *apiv1.Cluster,
	backupOrigin *apiv1.Backup,
	roles []apiv1.DatabaseRole,
) error {
	role := specs.CreateRole(
		specs.RoleOptions{
			Cluster:      cluster,
			BackupOrigin: backupOrigin,
			Roles:        roles,
		},
	)
	cluster.SetInheritedDataAndOwnership(&role.ObjectMeta)

	err := r.Create(ctx, &role)
	if err != nil && !apierrs.IsAlreadyExists(err) {
		log.FromContext(ctx).Error(err, "Unable to create the Role", "object", role)
		return err
	}

	return nil
}

// createRoleBinding creates the role binding
func (r *ClusterReconciler) createRoleBinding(ctx context.Context, cluster *apiv1.Cluster) error {
	roleBinding := specs.CreateRoleBinding(cluster.ObjectMeta, cluster.GetServiceAccountName())
	cluster.SetInheritedDataAndOwnership(&roleBinding.ObjectMeta)

	err := r.Create(ctx, &roleBinding)
	if err != nil && !apierrs.IsAlreadyExists(err) {
		log.FromContext(ctx).Error(err, "Unable to create the ServiceAccount", "object", roleBinding)
		return err
	}

	return nil
}

// generateNodeSerial returns the first free node serial number for this cluster.
// A serial is free when no instance currently listed in
// cluster.Status.InstanceNames is using it. With N instances, the first gap in
// [1, N] is free; if there is no gap, all of them are taken and N+1 is free.
func (r *ClusterReconciler) generateNodeSerial(cluster *apiv1.Cluster) int {
	n := len(cluster.Status.InstanceNames)
	for i := 1; i <= n; i++ {
		if !slices.Contains(cluster.Status.InstanceNames, specs.GetInstanceName(cluster.Name, i)) {
			return i
		}
	}

	return n + 1
}

func (r *ClusterReconciler) createPrimaryInstance(
	ctx context.Context,
	cluster *apiv1.Cluster,
) (ctrl.Result, error) {
	contextLogger := log.FromContext(ctx)

	if cluster.IsInitialized() {
		// We are we creating a new blank primary when we had previously generated
		// other nodes, and we don't have any PVC to reuse?
		// This can happen when:
		//
		// 1 - the user deletes all the PVCs and all the Pods in a cluster
		//    (and why would a user do that?)
		// 2 - the cache isn't ready for Pods but is ready for the Cluster,
		//     so we actually don't have the first pod in our managed list,
		//     but it's still in the API Server
		//
		// As far as the first option is concerned, we can just stop
		// healing this cluster as we have nothing to do.
		// For the second option, we can just retry when the next
		// reconciliation loop is started by the informers.
		contextLogger.Info("refusing to create the primary instance because the cluster already initialized")

		if err := r.RegisterPhase(ctx, cluster,
			apiv1.PhaseUnrecoverable,
			"One or more instances were previously created, but no PersistentVolumeClaims (PVCs) exist. "+
				"The cluster is in an unrecoverable state. To resolve this, restore the cluster from a recent backup.",
		); err != nil {
			return ctrl.Result{}, fmt.Errorf("while registering the unrecoverable phase: %w", err)
		}
		return ctrl.Result{}, nil
	}

	// Generate a new node serial
	nodeSerial := r.generateNodeSerial(cluster)
	contextLogger.Debug("allocated node serial", "serial", nodeSerial)

	// Ensure the PVCs for the first node exist, picking the right storage
	// source if we are bootstrapping from a backup or a volume snapshot. This
	// blocks until the source is ready.
	if res, err := r.ensurePrimaryInstancePVCs(ctx, cluster, nodeSerial, nil); !res.IsZero() || err != nil {
		return res, err
	}

	// Record the intended primary in the cluster status *before* the init Job
	// promotes the Pod. reconcileOldPrimary self-demotes a primary whose name
	// does not match Status.TargetPrimary, so TargetPrimary must be set first.
	podName := specs.GetInstanceName(cluster.Name, nodeSerial)
	if err := r.setPrimaryInstance(ctx, cluster, podName); err != nil {
		contextLogger.Error(err, "Unable to set the primary instance name")
		return ctrl.Result{}, err
	}

	if err := r.RegisterPhase(ctx, cluster, apiv1.PhaseFirstPrimary,
		fmt.Sprintf("Creating primary instance %v", podName)); err != nil {
		return ctrl.Result{}, err
	}

	// Creation of the init Job is owned by the unified PVC-state-driven path
	// (ensureInstancesAreCreated): an initializing PVC with no Job gets one
	// created there. We just requeue so that path runs. Gating Job creation
	// here behind a status patch that may lose an optimistic-lock conflict was
	// the source of the first-primary bootstrap deadlock (see #11036).
	return ctrl.Result{RequeueAfter: time.Second}, ErrNextLoop
}

// ensurePrimaryInstancePVCs makes sure the PVCs of the first node exist,
// selecting the proper storage source when bootstrapping from a backup or a
// volume snapshot. A non-zero result means the bootstrap source is not ready
// yet and the caller should requeue.
//
// existingDataSource is the PGDATA PVC's own Spec.DataSource, if the PGDATA
// PVC already exists (a previous attempt got at least that far). When set, it
// must agree with the storage source resolved here: the PGDATA PVC's
// DataSource is fixed at creation time, while the resolution below re-reads
// the current Backup/cluster state, and the two must not be allowed to
// silently diverge (for example a sibling PVC being recreated from a
// different snapshot than the one PGDATA actually holds).
func (r *ClusterReconciler) ensurePrimaryInstancePVCs(
	ctx context.Context,
	cluster *apiv1.Cluster,
	nodeSerial int,
	existingDataSource *corev1.TypedLocalObjectReference,
) (ctrl.Result, error) {
	var recoverySnapshot *persistentvolumeclaim.StorageSource

	// If the cluster is bootstrapping from recovery, it may do so from:
	//  1 - a backup object, which may be done with volume snapshots or object storage
	//  2 - volume snapshots
	// We need to check that whichever alternative is used, the backup/snapshot is completed.
	if cluster.Spec.Bootstrap != nil && cluster.Spec.Bootstrap.Recovery != nil {
		backup, err := r.getOriginBackup(ctx, cluster)
		if err != nil {
			return ctrl.Result{}, err
		}

		if res, err := r.checkReadyForRecovery(ctx, backup, cluster); !res.IsZero() || err != nil {
			return res, err
		}

		recoverySnapshot = persistentvolumeclaim.GetCandidateStorageSourceForPrimary(cluster, backup)
	}

	if err := validateStorageSourceAgreesWithExisting(
		recoverySnapshot, existingDataSource, cluster.Name, nodeSerial,
	); err != nil {
		return ctrl.Result{}, err
	}

	// Create the PVCs from the cluster definition, and if bootstrapping from
	// recoverySnapshot, use that as the source
	if err := persistentvolumeclaim.CreateInstancePVCs(
		ctx,
		r.Client,
		cluster,
		recoverySnapshot,
		nodeSerial,
	); err != nil {
		return ctrl.Result{}, fmt.Errorf("cannot create primary instance PVCs: %w", err)
	}

	return ctrl.Result{}, nil
}

// validateStorageSourceAgreesWithExisting fails cleanly instead of recreating
// a sibling PVC (typically WAL) from a storage source that disagrees with the
// PGDATA PVC already on disk. existingDataSource is nil when the PGDATA PVC
// does not exist yet (fresh bootstrap): there is nothing to compare against,
// and candidate is free to be whatever the current cluster/Backup state
// resolves to.
func validateStorageSourceAgreesWithExisting(
	candidate *persistentvolumeclaim.StorageSource,
	existingDataSource *corev1.TypedLocalObjectReference,
	clusterName string,
	nodeSerial int,
) error {
	if existingDataSource == nil {
		return nil
	}

	var candidateDataSource *corev1.TypedLocalObjectReference
	if candidate != nil {
		candidateDataSource = &candidate.DataSource
	}

	if candidateDataSource != nil && reflect.DeepEqual(*candidateDataSource, *existingDataSource) {
		return nil
	}

	return fmt.Errorf(
		"cannot recreate the missing PVCs of instance %v: the resolved recovery source (%v) "+
			"disagrees with the data source already recorded on its PGDATA PVC (%v)",
		specs.GetInstanceName(clusterName, nodeSerial),
		candidateDataSource,
		existingDataSource,
	)
}

// buildPrimaryBootstrapCommand builds the bootstrap command for the first
// primary instance, selecting the variant (initdb, recovery, pgBaseBackup or
// volume snapshot restore) according to the cluster bootstrap configuration.
// It is invoked from the unified PVC-state-driven path
// (attachInstanceBootstrapInitContainer) when an initializing primary PVC has
// no bootstrap advancing it.
//
// dataSource is the PGDATA PVC's own Spec.DataSource, if any: since the PVC
// already exists by the time this runs, its DataSource is the authoritative
// record of whether it was actually restored from a snapshot. Using it
// instead of recomputing the candidate source from the current Backup object
// keeps the bootstrap variant consistent with what is really on the PVC, even
// if the Backup has changed or been deleted since the PVC was created.
func (r *ClusterReconciler) buildPrimaryBootstrapCommand(
	ctx context.Context,
	cluster *apiv1.Cluster,
	nodeSerial int,
	dataSource *corev1.TypedLocalObjectReference,
) (*specs.InstanceBootstrapCommand, error) {
	isBootstrappingFromRecovery := cluster.Spec.Bootstrap != nil && cluster.Spec.Bootstrap.Recovery != nil
	isBootstrappingFromBaseBackup := cluster.Spec.Bootstrap != nil && cluster.Spec.Bootstrap.PgBaseBackup != nil

	var backup *apiv1.Backup
	if isBootstrappingFromRecovery {
		var err error
		backup, err = r.getOriginBackup(ctx, cluster)
		if err != nil {
			return nil, err
		}
		// getOriginBackup tolerates a missing Backup object by returning nil:
		// fail here rather than building a bootstrap command that points to a
		// recovery source that no longer exists.
		if backup == nil && cluster.Spec.Bootstrap.Recovery.Backup != nil {
			return nil, fmt.Errorf(
				"cannot bootstrap instance %v: the Backup %q it recovers from no longer exists",
				specs.GetInstanceName(cluster.Name, nodeSerial),
				cluster.Spec.Bootstrap.Recovery.Backup.Name,
			)
		}
	}

	switch {
	case isBootstrappingFromRecovery && dataSource != nil:
		metadata, err := persistentvolumeclaim.GetSourceMetadataOrNil(
			ctx,
			r.Client,
			cluster.Namespace,
			*dataSource,
		)
		if err != nil {
			return nil, err
		}
		if metadata == nil {
			return nil, fmt.Errorf(
				"cannot bootstrap instance %v: the data source %q of its PGDATA PVC no longer exists",
				specs.GetInstanceName(cluster.Name, nodeSerial),
				dataSource.Name,
			)
		}
		r.Recorder.Event(cluster, "Normal", "CreatingInstance", "Primary instance (from volumeSnapshots)")
		return specs.BuildPrimaryBootstrapCommandViaRestoreSnapshot(*cluster, metadata), nil

	case isBootstrappingFromRecovery:
		r.Recorder.Event(cluster, "Normal", "CreatingInstance", "Primary instance (from backup)")
		return specs.BuildPrimaryBootstrapCommandViaRecovery(*cluster), nil

	case isBootstrappingFromBaseBackup:
		r.Recorder.Event(cluster, "Normal", "CreatingInstance", "Primary instance (from physical backup)")
		return specs.BuildPrimaryBootstrapCommandViaPgBaseBackup(*cluster), nil

	default:
		r.Recorder.Event(cluster, "Normal", "CreatingInstance", "Primary instance (initdb)")
		return specs.BuildPrimaryBootstrapCommandViaInitdb(*cluster), nil
	}
}

// getOriginBackup gets the backup that is used to bootstrap a new PostgreSQL cluster
func (r *ClusterReconciler) getOriginBackup(ctx context.Context, cluster *apiv1.Cluster) (*apiv1.Backup, error) {
	if cluster.Spec.Bootstrap == nil ||
		cluster.Spec.Bootstrap.Recovery == nil ||
		cluster.Spec.Bootstrap.Recovery.Backup == nil {
		return nil, nil
	}

	var backup apiv1.Backup
	backupObjectKey := client.ObjectKey{
		Namespace: cluster.Namespace,
		Name:      cluster.Spec.Bootstrap.Recovery.Backup.Name,
	}
	err := r.Get(ctx, backupObjectKey, &backup)
	if err != nil {
		if apierrs.IsNotFound(err) {
			r.Recorder.Eventf(cluster, "Warning", "ErrorNoBackup",
				"Backup object \"%v/%v\" is missing",
				backupObjectKey.Namespace, backupObjectKey.Name)

			return nil, nil
		}

		return nil, fmt.Errorf("cannot get the backup object: %w", err)
	}

	return &backup, nil
}

// reconcileMissingInstance creates the next missing instance when the cluster
// has fewer instances than desired and every reported instance is ready.
//
// It returns a non-zero result (or an error) when the caller should stop and
// requeue, and a zero result with no error when there is nothing to do.
func (r *ClusterReconciler) reconcileMissingInstance(
	ctx context.Context,
	cluster *apiv1.Cluster,
	resources *managedResources,
	instancesStatus postgres.PostgresqlStatusList,
) (ctrl.Result, error) {
	if cluster.Status.Instances >= cluster.Spec.Instances ||
		instancesStatus.InstancesReportingStatus() != cluster.Status.Instances {
		return ctrl.Result{}, nil
	}

	newNodeSerial := r.generateNodeSerial(cluster)
	instanceName := specs.GetInstanceName(cluster.Name, newNodeSerial)

	// A serial stops being counted in the status while its PVCs are still
	// terminating, so it can be picked here before the previous instance has
	// been fully torn down. Creating the Job now would bind it to a PVC about
	// to be garbage-collected, leaving the Pod permanently unschedulable while
	// the running-job guard blocks any further reconciliation (see #10985).
	// Wait for the previous PVCs to disappear before recreating the instance.
	if pvcName := persistentvolumeclaim.GetTerminatingInstancePVCName(
		cluster, instanceName, resources.pvcs.Items,
	); pvcName != "" {
		log.FromContext(ctx).Debug(
			"Deferring instance recreation until the previous PVC finishes terminating",
			"instance", instanceName,
			"pvc", pvcName,
		)

		if err := r.RegisterPhase(
			ctx,
			cluster,
			apiv1.PhaseCreatingReplica,
			fmt.Sprintf("Waiting for PVC %q to be removed before recreating instance %q", pvcName, instanceName),
		); err != nil {
			return ctrl.Result{}, err
		}
		return ctrl.Result{RequeueAfter: time.Second}, ErrNextLoop
	}

	return r.joinReplicaInstance(ctx, newNodeSerial, cluster)
}

func (r *ClusterReconciler) joinReplicaInstance(
	ctx context.Context,
	nodeSerial int,
	cluster *apiv1.Cluster,
) (ctrl.Result, error) {
	contextLogger := log.FromContext(ctx)

	var backupList apiv1.BackupList
	if err := r.List(ctx, &backupList,
		client.MatchingFields{clusterNameField: cluster.Name},
		client.InNamespace(cluster.Namespace),
	); err != nil {
		contextLogger.Error(err, "Error while getting backup list, when bootstrapping a new replica")
		return ctrl.Result{}, err
	}

	cmd := specs.BuildReplicaBootstrapCommandViaJoin(*cluster)

	// If we can bootstrap this replica from a pre-existing source, we do it
	storageSource := persistentvolumeclaim.GetCandidateStorageSourceForReplica(ctx, r.Client, cluster, backupList)
	if storageSource != nil {
		cmd = specs.BuildReplicaBootstrapCommandViaRestoreSnapshot(*cluster)
	}

	pod, err := specs.NewInstance(ctx, *cluster, nodeSerial, true)
	if err != nil {
		return ctrl.Result{}, fmt.Errorf("unable to build replica instance: %w", err)
	}
	specs.AddBootstrapInitContainer(pod, *cluster, cmd)

	contextLogger.Info("Creating new Pod",
		"pod", pod.Name,
		"primary", false,
		"storageSource", storageSource,
		"role", string(cmd.Role),
	)

	r.Recorder.Eventf(cluster, "Normal", "CreatingInstance",
		"Creating instance %v-%v", cluster.Name, nodeSerial)

	if err := r.RegisterPhase(ctx, cluster,
		apiv1.PhaseCreatingReplica,
		fmt.Sprintf("Creating replica %v", pod.Name)); err != nil {
		return ctrl.Result{}, err
	}

	if err := ctrl.SetControllerReference(cluster, pod, r.Scheme); err != nil {
		contextLogger.Error(err, "Unable to set the owner reference for joined PostgreSQL node")
		return ctrl.Result{}, err
	}

	utils.InheritAnnotations(&pod.ObjectMeta, cluster.Annotations,
		cluster.GetFixedInheritedAnnotations(), configuration.Current)
	utils.InheritLabels(&pod.ObjectMeta, cluster.Labels,
		cluster.GetFixedInheritedLabels(), configuration.Current)

	// Create the PVCs before the Pod, so the Pod is never observed by the
	// scheduler while its PVCs don't exist yet (which would make it
	// transiently unschedulable).
	if err := persistentvolumeclaim.CreateInstancePVCs(
		ctx,
		r.Client,
		cluster,
		storageSource,
		nodeSerial,
	); err != nil {
		return ctrl.Result{}, fmt.Errorf("cannot create replica instance PVCs: %w", err)
	}

	if err := r.Create(ctx, pod); err != nil {
		if !apierrs.IsAlreadyExists(err) {
			contextLogger.Error(err, "Unable to create Pod", "pod", pod)
			return ctrl.Result{}, err
		}
		contextLogger.Info("Pod already exists, requeuing", "pod", pod.Name)
		return ctrl.Result{RequeueAfter: time.Second}, ErrNextLoop
	}

	return ctrl.Result{RequeueAfter: 30 * time.Second}, ErrNextLoop
}

// attachReplicaBootstrapInitContainer resumes bootstrap of a replica whose
// PVCs exist but are not ready, by attaching a bootstrap init container to
// instanceToCreate. Mirroring buildPrimaryBootstrapCommand, the bootstrap
// variant is decided by the PGDATA PVC's own DataSource, the authoritative
// record of what is really on the volume: recomputing the candidate storage
// source from the live Backup list could disagree with the volume's actual
// content when backups or snapshots changed after the PVCs were created, and
// a snapshot-restore that completes successfully against a volume that was
// never cloned leaves a broken replica behind an apparently successful
// bootstrap.
//
// When part of the PVC group is missing, the snapshot sources the absent
// volumes were meant to be cloned from cannot be reconstructed: recreate the
// missing PVCs empty and rebuild the whole replica through a join, which
// discards any existing content and takes a fresh copy from the primary.
func (r *ClusterReconciler) attachReplicaBootstrapInitContainer(
	ctx context.Context,
	cluster *apiv1.Cluster,
	instanceToCreate *corev1.Pod,
	serial int,
	pgdataDataSource *corev1.TypedLocalObjectReference,
	pvcGroupComplete bool,
) (ctrl.Result, error) {
	if !pvcGroupComplete {
		pgdataDataSource = nil
		if err := persistentvolumeclaim.CreateInstancePVCs(ctx, r.Client, cluster, nil, serial); err != nil {
			return ctrl.Result{}, fmt.Errorf("cannot recreate the missing PVCs of instance %v: %w",
				specs.GetInstanceName(cluster.Name, serial), err)
		}
	}

	cmd := specs.BuildReplicaBootstrapCommandViaJoin(*cluster)
	if pgdataDataSource != nil {
		cmd = specs.BuildReplicaBootstrapCommandViaRestoreSnapshot(*cluster)
	}

	log.FromContext(ctx).Info("Resuming bootstrap for a replica whose PVCs are not ready",
		"instance", instanceToCreate.Name,
		"role", string(cmd.Role),
	)

	r.Recorder.Eventf(cluster, "Normal", "CreatingInstance",
		"Recreating instance %v-%v", cluster.Name, serial)

	if err := r.RegisterPhase(ctx, cluster,
		apiv1.PhaseCreatingReplica,
		fmt.Sprintf("Creating replica %v", instanceToCreate.Name)); err != nil {
		return ctrl.Result{}, err
	}

	specs.AddBootstrapInitContainer(instanceToCreate, *cluster, cmd)

	return ctrl.Result{}, nil
}

// ensureInstancesAreCreated recreates any missing instance
func (r *ClusterReconciler) ensureInstancesAreCreated(
	ctx context.Context,
	cluster *apiv1.Cluster,
	resources *managedResources,
	instancesStatus postgres.PostgresqlStatusList,
) (ctrl.Result, error) {
	contextLogger := log.FromContext(ctx)

	instanceToCreate, err := findInstancePodToCreate(ctx, cluster, instancesStatus, resources.pvcs.Items)
	if err != nil {
		return ctrl.Result{}, err
	}
	if instanceToCreate == nil {
		contextLogger.Trace(
			"haven't found any instance to create",
			"instances", instancesStatus.GetNames(),
			"dangling", cluster.Status.DanglingPVC,
			"unusable", cluster.Status.UnusablePVC,
		)
		return ctrl.Result{}, nil
	}

	// Reattaching an instance whose group of PVCs is incomplete because one of
	// them is still terminating would create a Pod bound to a volume about to be
	// garbage-collected, leaving it unschedulable. Wait for the previous PVC to
	// disappear before reattaching (see #10985).
	if pvcName := persistentvolumeclaim.GetTerminatingInstancePVCName(
		cluster, instanceToCreate.Name, resources.pvcs.Items,
	); pvcName != "" {
		contextLogger.Debug(
			"Deferring instance reattachment until the previous PVC finishes terminating",
			"instance", instanceToCreate.Name,
			"pvc", pvcName,
		)
		return ctrl.Result{RequeueAfter: 1 * time.Second}, ErrNextLoop
	}

	if !cluster.IsNodeMaintenanceWindowInProgress() &&
		instancesStatus.InstancesReportingStatus() != cluster.Status.ReadyInstances {
		// A pod is not ready, let's retry
		contextLogger.Debug("Waiting for node to be ready before attaching PVCs")
		return ctrl.Result{RequeueAfter: 1 * time.Second}, ErrNextLoop
	}

	// The PVC is the managed state; the bootstrap init container on the Pod is
	// just the means to advance it. If any PVC of this instance is not ready
	// yet, attach the init container that will advance it before Postgres
	// starts, otherwise the PVC has no way of ever becoming ready and
	// reconciliation deadlocks (see #11036).
	instancePVCs := persistentvolumeclaim.FilterByPodSpec(resources.pvcs.Items, instanceToCreate.Spec)
	needsBootstrap := slices.ContainsFunc(instancePVCs, func(pvc corev1.PersistentVolumeClaim) bool {
		return pvc.Annotations[utils.PVCStatusAnnotationName] != persistentvolumeclaim.StatusReady
	})
	if needsBootstrap {
		if res, err := r.attachInstanceBootstrapInitContainer(
			ctx, cluster, instanceToCreate, resources,
		); err != nil || !res.IsZero() {
			return res, err
		}
	}

	// If this cluster has been restarted, mark the Pod with the latest restart time
	if clusterRestart, ok := cluster.Annotations[utils.ClusterRestartAnnotationName]; ok {
		if instanceToCreate.Annotations == nil {
			instanceToCreate.Annotations = make(map[string]string)
		}
		instanceToCreate.Annotations[utils.ClusterRestartAnnotationName] = clusterRestart
	}

	contextLogger.Info("Creating new Pod to reattach a PVC",
		"pod", instanceToCreate.Name,
		"pvc", instanceToCreate.Name)

	if err := ctrl.SetControllerReference(cluster, instanceToCreate, r.Scheme); err != nil {
		return ctrl.Result{}, fmt.Errorf("unable to set the owner reference for the Pod: %w", err)
	}

	utils.InheritAnnotations(&instanceToCreate.ObjectMeta, cluster.Annotations,
		cluster.GetFixedInheritedAnnotations(), configuration.Current)
	utils.InheritLabels(&instanceToCreate.ObjectMeta, cluster.Labels,
		cluster.GetFixedInheritedLabels(), configuration.Current)

	if err := r.Create(ctx, instanceToCreate); err != nil {
		if apierrs.IsAlreadyExists(err) {
			// This Pod was already created, maybe the cache is stale.
			// Let's reconcile another time
			contextLogger.Info("Instance already exist, maybe the cache is stale", "instance", instanceToCreate.Name)
			return ctrl.Result{RequeueAfter: 1 * time.Second}, ErrNextLoop
		}

		return ctrl.Result{}, fmt.Errorf("unable to create Pod: %w", err)
	}

	return ctrl.Result{RequeueAfter: 1 * time.Second}, nil
}

// we elect a current instance that doesn't exist for creation
func findInstancePodToCreate(
	ctx context.Context,
	cluster *apiv1.Cluster,
	instancesStatus postgres.PostgresqlStatusList,
	pvcs []corev1.PersistentVolumeClaim,
) (*corev1.Pod, error) {
	instanceThatHavePods := instancesStatus.GetNames()

	var missingInstancePVC *corev1.PersistentVolumeClaim

	iterablePVCs := cluster.Status.DanglingPVC
	// appending unusablePVC ensures that some corner cases are covered. (EX: an instance is deleted manually while
	// new type of PVCs were enabled)
	iterablePVCs = append(iterablePVCs, cluster.Status.UnusablePVC...)
	for _, name := range iterablePVCs {
		idx := slices.IndexFunc(pvcs, func(claim corev1.PersistentVolumeClaim) bool {
			return claim.Name == name
		})
		if idx == -1 {
			return nil, fmt.Errorf("programmatic error, pvc not found")
		}

		serial, err := specs.GetNodeSerial(pvcs[idx].ObjectMeta)
		if err != nil {
			return nil, err
		}

		instanceName := specs.GetInstanceName(cluster.Name, serial)
		if slices.Contains(instanceThatHavePods, instanceName) {
			continue
		}

		// We give the priority to reattaching the primary instance
		if isPrimary := specs.IsPrimary(pvcs[idx].ObjectMeta); isPrimary {
			missingInstancePVC = &pvcs[idx]
			break
		}

		if missingInstancePVC == nil {
			missingInstancePVC = &pvcs[idx]
		}
	}

	if missingInstancePVC != nil {
		serial, err := specs.GetNodeSerial(missingInstancePVC.ObjectMeta)
		if err != nil {
			return nil, err
		}
		return specs.NewInstance(ctx, *cluster, serial, true)
	}

	return nil, nil
}

// attachInstanceBootstrapInitContainer makes sure that an instance whose PVCs
// are not yet ready has a bootstrap init container attached to
// instanceToCreate, advancing them once the Pod is created. It mutates
// instanceToCreate in place; the caller is responsible for actually creating
// the Pod.
//
// This consolidates bootstrap preparation, off the PVC state, for both the
// first primary (originally the fix for the bootstrap deadlock in #11036, now
// carried by this unified path) and a replica whose bootstrap was lost,
// self-healing the #7709 scenario.
func (r *ClusterReconciler) attachInstanceBootstrapInitContainer(
	ctx context.Context,
	cluster *apiv1.Cluster,
	instanceToCreate *corev1.Pod,
	resources *managedResources,
) (ctrl.Result, error) {
	serial, err := specs.GetNodeSerial(instanceToCreate.ObjectMeta)
	if err != nil {
		return ctrl.Result{}, err
	}

	var pgdataDataSource *corev1.TypedLocalObjectReference
	for _, pvc := range persistentvolumeclaim.FilterByPodSpec(resources.pvcs.Items, instanceToCreate.Spec) {
		if pvc.Name == instanceToCreate.Name {
			pgdataDataSource = pvc.Spec.DataSource
		}
	}

	// A previous attempt may have been interrupted between creating the PVCs:
	// detect a PVC group that is missing some of its members. The expected
	// group is derived from the cluster specification, the same source the
	// PVC classifier uses, so that a pod template customized through the
	// podPatch annotation cannot skew the comparison.
	pvcGroupComplete := true
	for _, expectedName := range persistentvolumeclaim.GetExpectedInstancePVCNamesFromCluster(
		cluster, instanceToCreate.Name,
	) {
		if !slices.ContainsFunc(resources.pvcs.Items, func(pvc corev1.PersistentVolumeClaim) bool {
			return pvc.Name == expectedName
		}) {
			pvcGroupComplete = false
			break
		}
	}

	// The first primary is the only instance whose bootstrap is owned by this
	// PVC-driven path. A replica is never created before a primary exists, so
	// while the cluster has no established primary (CurrentPrimary == "") a
	// podless PVC needing bootstrap is the first primary's. This holds even if
	// the status patch that set TargetPrimary in createPrimaryInstance lost an
	// optimistic-lock conflict, which is exactly the deadlock #11036 guards
	// against. Once a primary is running, joinReplicaInstance owns bootstrap
	// for new replicas (it creates the Pod and then the PVCs), so a podless
	// replica PVC without a ready annotation means a previous attempt did not
	// get that far; resume its bootstrap here.
	if cluster.Status.CurrentPrimary != "" && instanceToCreate.Name != cluster.Status.TargetPrimary {
		return r.attachReplicaBootstrapInitContainer(
			ctx, cluster, instanceToCreate, serial, pgdataDataSource, pvcGroupComplete)
	}

	// A previous attempt may have been interrupted while creating the PVC
	// group: recreate any missing PVC, choosing the storage source from the
	// bootstrap configuration, before creating the Pod. When the PGDATA PVC
	// already exists, the resolved source must agree with what PGDATA
	// actually holds, or the sibling PVC would be recreated from a different
	// snapshot than the one already restored.
	if !pvcGroupComplete {
		if res, err := r.ensurePrimaryInstancePVCs(ctx, cluster, serial, pgdataDataSource); !res.IsZero() || err != nil {
			return res, err
		}
	}

	// Set TargetPrimary defensively: if it is not set the instance manager would
	// shut the primary down as soon as it starts (see reconcileOldPrimary).
	if cluster.Status.TargetPrimary != instanceToCreate.Name {
		if err := r.setPrimaryInstance(ctx, cluster, instanceToCreate.Name); err != nil {
			return ctrl.Result{}, fmt.Errorf("unable to set the primary instance name: %w", err)
		}
	}

	cmd, err := r.buildPrimaryBootstrapCommand(ctx, cluster, serial, pgdataDataSource)
	if err != nil {
		return ctrl.Result{}, err
	}

	log.FromContext(ctx).Info("Attaching the bootstrap init container for the primary instance",
		"instance", instanceToCreate.Name,
		"role", string(cmd.Role),
	)

	specs.AddBootstrapInitContainer(instanceToCreate, *cluster, cmd)

	return ctrl.Result{}, nil
}

// checkReadyForRecovery checks if the backup or volumeSnapshots are ready, and
// returns for requeue if not
func (r *ClusterReconciler) checkReadyForRecovery(
	ctx context.Context,
	backup *apiv1.Backup,
	cluster *apiv1.Cluster,
) (ctrl.Result, error) {
	contextLogger := log.FromContext(ctx)

	if cluster.Spec.Bootstrap.Recovery.Backup != nil {
		if backup == nil {
			contextLogger.Info("Missing backup object, can't continue full recovery",
				"backup", cluster.Spec.Bootstrap.Recovery.Backup)
			return ctrl.Result{RequeueAfter: time.Minute}, nil
		}
		if backup.Status.Phase != apiv1.BackupPhaseCompleted {
			contextLogger.Info("The source backup object is not completed, can't continue full recovery",
				"backup", cluster.Spec.Bootstrap.Recovery.Backup,
				"backupPhase", backup.Status.Phase)
			return ctrl.Result{RequeueAfter: time.Minute}, nil
		}
	}

	volumeSnapshotsRecovery := cluster.Spec.Bootstrap.Recovery.VolumeSnapshots
	if volumeSnapshotsRecovery != nil {
		status, err := persistentvolumeclaim.VerifyDataSourceCoherence(
			ctx, r.Client, cluster.Namespace, volumeSnapshotsRecovery)
		if err != nil {
			return ctrl.Result{}, err
		}
		if status.ContainsErrors() {
			contextLogger.Warning(
				"Volume snapshots verification failed, retrying",
				"status", status)
			return ctrl.Result{RequeueAfter: 5 * time.Second}, nil
		}
		if status.ContainsWarnings() {
			contextLogger.Warning("Volume snapshots verification warnings",
				"status", status)
		}
	}
	return ctrl.Result{}, nil
}

/*
Copyright © contributors to CloudNativePG, established as
CloudNativePG a Series of LF Projects, LLC.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

SPDX-License-Identifier: Apache-2.0
*/

package controller

import (
	discoveryv1 "k8s.io/api/discovery/v1"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/predicate"

	"github.com/cloudnative-pg/cloudnative-pg/pkg/utils"
)

// operatorNamespaceServiceEndpointSlicePredicate is a cheap pre-filter that
// drops EndpointSlice events for slices outside the operator namespace and
// those not backing a Service. Slices that pass still need to be matched
// against isPluginService by resolving the owning Service: this predicate is
// only here to keep the workqueue from being woken up by every EndpointSlice
// in the cluster.
func operatorNamespaceServiceEndpointSlicePredicate(operatorNamespace string) predicate.Predicate {
	return predicate.NewPredicateFuncs(func(object client.Object) bool {
		if object.GetNamespace() != operatorNamespace {
			return false
		}
		return object.GetLabels()[discoveryv1.LabelServiceName] != ""
	})
}

func isPluginService(object client.Object, operatorNamespace string) bool {
	if object.GetNamespace() != operatorNamespace {
		// Only consider the services that are in the same
		// namespace where the operator is installed
		return false
	}

	labels := object.GetLabels()
	if _, hasLabel := labels[utils.PluginNameLabelName]; !hasLabel {
		return false
	}

	annotations := object.GetAnnotations()

	if _, hasAnnotation := annotations[utils.PluginClientSecretAnnotationName]; !hasAnnotation {
		return false
	}

	if _, hasAnnotation := annotations[utils.PluginServerSecretAnnotationName]; !hasAnnotation {
		return false
	}

	if _, hasAnnotation := annotations[utils.PluginPortAnnotationName]; !hasAnnotation {
		return false
	}

	return true
}

// isSecretUsedByPluginService returns true when the passed service
// uses the secret with the passed name
func isSecretUsedByPluginService(service client.Object, secretName string) bool {
	annotations := service.GetAnnotations()

	clientSecretName := annotations[utils.PluginClientSecretAnnotationName]
	serverSecretName := annotations[utils.PluginServerSecretAnnotationName]

	return clientSecretName == secretName || serverSecretName == secretName
}

/*
Copyright © contributors to CloudNativePG, established as
CloudNativePG a Series of LF Projects, LLC.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

SPDX-License-Identifier: Apache-2.0
*/

package cache

const (
	// ClusterKey is the key to be used to access the cached cluster
	ClusterKey = "cluster"
	// WALArchiveKey is the key to be used to access the cached envs for wal-archive
	WALArchiveKey = "wal-archive"
	// WALRestoreKey is the key to be used to access the cached envs for wal-restore
	WALRestoreKey = "wal-restore"
	// WALRestoreConfigKey is the key to be used to access the cached recovery
	// source object store configuration. It is populated only by the bootstrap
	// recovery Job, which resolves that store (not derivable from the cluster
	// spec for a recovery.backup reference) and hands it to the wal-restore
	// command via the local webserver cache.
	WALRestoreConfigKey = "wal-restore-config"
)

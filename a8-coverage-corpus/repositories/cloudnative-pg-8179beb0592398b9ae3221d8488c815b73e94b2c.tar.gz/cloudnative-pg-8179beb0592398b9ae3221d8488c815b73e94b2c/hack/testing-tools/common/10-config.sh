#!/usr/bin/env bash
##
## Copyright © contributors to CloudNativePG, established as
## CloudNativePG a Series of LF Projects, LLC.
##
## Licensed under the Apache License, Version 2.0 (the "License");
## you may not use this file except in compliance with the License.
## You may obtain a copy of the License at
##
##     http://www.apache.org/licenses/LICENSE-2.0
##
## Unless required by applicable law or agreed to in writing, software
## distributed under the License is distributed on an "AS IS" BASIS,
## WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
## See the License for the specific language governing permissions and
## limitations under the License.
##
## SPDX-License-Identifier: Apache-2.0
##

# This file defines global, configurable constants and dependency versions.
# Requires: $ROOT_DIR (from 00-paths.sh)

# --- COMMON IMAGE AND VERSION DEFAULTS ---

if [ -z "${K8S_VERSION:-}" ]; then
  echo "ERROR: K8S_VERSION is not set. Source the engine-specific settings.sh first." >&2
  exit 1
fi

# Defines the default cluster name based on the Kubernetes version.
export CLUSTER_NAME=${CLUSTER_NAME:-pg-operator-e2e-${K8S_VERSION//./-}}

# Postgres Image
# Uses awk and tr to ensure clean string extraction, avoiding whitespace/CR issues.
export POSTGRES_IMG=${POSTGRES_IMG:-$(grep 'DefaultImageName.*=' "${ROOT_DIR}/pkg/versions/versions.go" | awk -F '"' '{print $2}' | tr -d '[:space:]')}
export E2E_PRE_ROLLING_UPDATE_IMG=${E2E_PRE_ROLLING_UPDATE_IMG:-${POSTGRES_IMG%.*}}

# PGBouncer Image
export PGBOUNCER_IMG=${PGBOUNCER_IMG:-$(grep 'DefaultPgbouncerImage.*=' "${ROOT_DIR}/pkg/versions/versions.go" | awk -F '"' '{print $2}' | tr -d '[:space:]')}

# RustFS Image
export RUSTFS_IMG=${RUSTFS_IMG:-$(grep 'rustfsImage.*=' "${ROOT_DIR}/tests/utils/objectstore/objectstore.go" | awk -F '"' '{print $2}' | tr -d '[:space:]')}

# AWS CLI Image (S3 client used by the e2e object storage tests)
export AWSCLI_IMG=${AWSCLI_IMG:-$(grep 'awsCliImage.*=' "${ROOT_DIR}/tests/utils/objectstore/objectstore.go" | awk -F '"' '{print $2}' | tr -d '[:space:]')}

# Busybox Image (init container that prepares the object storage volumes)
export BUSYBOX_IMG=${BUSYBOX_IMG:-$(grep 'busyboxImage.*=' "${ROOT_DIR}/tests/utils/objectstore/objectstore.go" | awk -F '"' '{print $2}' | tr -d '[:space:]')}

# Apache Image (Hardcoded stable default)
export APACHE_IMG=${APACHE_IMG:-"httpd"}

# Define the operator source and deployment method.
export OPERATOR=${OPERATOR:-"local"}
export CNPG_DEPLOYMENT_METHOD=${CNPG_DEPLOYMENT_METHOD:-"manifest"}

# Path to the generated operator manifest (mirrors the Makefile default).
export OPERATOR_MANIFEST_PATH="${OPERATOR_MANIFEST_PATH:-${ROOT_DIR}/dist/operator-manifest.yaml}"

# Validate that required images were successfully extracted
if [ -z "${POSTGRES_IMG}" ]; then
  echo "ERROR: Failed to extract POSTGRES_IMG from ${ROOT_DIR}/pkg/versions/versions.go" >&2
  exit 1
fi
if [ -z "${PGBOUNCER_IMG}" ]; then
  echo "ERROR: Failed to extract PGBOUNCER_IMG from ${ROOT_DIR}/pkg/versions/versions.go" >&2
  exit 1
fi
if [ -z "${RUSTFS_IMG}" ]; then
  echo "ERROR: Failed to extract RUSTFS_IMG from ${ROOT_DIR}/tests/utils/objectstore/objectstore.go" >&2
  exit 1
fi
if [ -z "${AWSCLI_IMG}" ]; then
  echo "ERROR: Failed to extract AWSCLI_IMG from ${ROOT_DIR}/tests/utils/objectstore/objectstore.go" >&2
  exit 1
fi
if [ -z "${BUSYBOX_IMG}" ]; then
  echo "ERROR: Failed to extract BUSYBOX_IMG from ${ROOT_DIR}/tests/utils/objectstore/objectstore.go" >&2
  exit 1
fi

# Define the full array of helper images used by load-helper-images
HELPER_IMGS=("$POSTGRES_IMG" "$E2E_PRE_ROLLING_UPDATE_IMG" "$PGBOUNCER_IMG" "$RUSTFS_IMG" "$AWSCLI_IMG" "$BUSYBOX_IMG" "$APACHE_IMG")
export HELPER_IMGS

# Testing the upgrade will require generating a second operator image, `-prime`
export TEST_UPGRADE_TO_V1=${TEST_UPGRADE_TO_V1:-true}

# Feature flags for enabling optional components
export ENABLE_PYROSCOPE=${ENABLE_PYROSCOPE:-}
export ENABLE_CSI_DRIVER=${ENABLE_CSI_DRIVER:-}
export ENABLE_APISERVER_AUDIT=${ENABLE_APISERVER_AUDIT:-}

# plugin-barman-cloud release version. Available options:
#  - "release" (default): the latest published release
#  - "main":              the current snapshot from the main branch
#  - "vX.Y.Z" / "X.Y.Z":  a specific pinned release
export BARMAN_PLUGIN_VERSION=${BARMAN_PLUGIN_VERSION:-"release"}

# --- GENERIC ADD-ON CONSTANTS (Shared CSI/Snapshotter versions for Renovate) ---

# Define default CSI driver version
# renovate: datasource=github-releases depName=kubernetes-csi/csi-driver-host-path
CSI_DRIVER_HOST_PATH_DEFAULT_VERSION="v1.17.1"
# renovate: datasource=github-releases depName=kubernetes-csi/external-snapshotter
EXTERNAL_SNAPSHOTTER_VERSION="v8.6.0"
# renovate: datasource=github-releases depName=kubernetes-csi/external-provisioner
EXTERNAL_PROVISIONER_VERSION="v6.3.0"
# renovate: datasource=github-releases depName=kubernetes-csi/external-resizer
EXTERNAL_RESIZER_VERSION="v2.2.1"
# renovate: datasource=github-releases depName=kubernetes-csi/external-attacher
EXTERNAL_ATTACHER_VERSION="v4.12.0"

# Exporting CSI variables for use in setup scripts
export CSI_DRIVER_HOST_PATH_VERSION=${CSI_DRIVER_HOST_PATH_VERSION:-$CSI_DRIVER_HOST_PATH_DEFAULT_VERSION}
export EXTERNAL_SNAPSHOTTER_VERSION
export EXTERNAL_PROVISIONER_VERSION
export EXTERNAL_RESIZER_VERSION
export EXTERNAL_ATTACHER_VERSION

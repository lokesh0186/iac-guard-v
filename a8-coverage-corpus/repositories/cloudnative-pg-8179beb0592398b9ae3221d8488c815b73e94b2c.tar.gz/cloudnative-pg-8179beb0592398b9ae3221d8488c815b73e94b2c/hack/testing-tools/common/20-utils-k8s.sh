#!/usr/bin/env bash
##
## Copyright © contributors to CloudNativePG, established as
## CloudNativePG a Series of LF Projects, LLC.
##
## Licensed under the Apache License, Version 2.0 (the "License");
## you may not use this file except in compliance with the License.
## You may obtain a copy of the License at
##
##     http://www.apache.org/licenses/LICENSE-2.0
##
## Unless required by applicable law or agreed to in writing, software
## distributed under the License is distributed on an "AS IS" BASIS,
## WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
## See the License for the specific language governing permissions and
## limitations under the License.
##
## SPDX-License-Identifier: Apache-2.0
##

# This file contains functions for interacting with the Kubernetes API using $K8S_CLI.

# _curl_github: like curl, but authenticates with GITHUB_TOKEN when set (avoids
# 403 rate-limiting on unauthenticated downloads from GitHub Actions), without
# ever exposing the token in "set -x" output.
function _curl_github() {
  if [[ "$-" == *x* ]]; then
    trap 'set -x' RETURN
    set +x
  fi
  local auth_header=""
  if [[ -n "${GITHUB_TOKEN:-}" ]]; then
    auth_header="Authorization: Bearer ${GITHUB_TOKEN}"
  fi
  curl -H "${auth_header}" "$@"
}

# _apply_github: fetches a manifest from a raw.githubusercontent.com URL
# (authenticated via _curl_github when GITHUB_TOKEN is set, which is what
# actually avoids the anonymous per-IP rate limit shared by GitHub Actions
# runners) and applies it. The retry is only a fallback for genuine transient
# network errors, not the fix for 429s.
function _apply_github() {
  local url=$1
  _curl_github -fsSL --retry 5 --retry-delay 2 "${url}" | "${K8S_CLI}" apply -f -
}

# wait_for(type, namespace, name, interval, retries)
# Waits until a specified Kubernetes object exists.
function wait_for() {
  local type=$1
  local namespace=$2
  local name=$3
  local interval=$4
  local retries=$5

  ITER=0
  while ! ${K8S_CLI} get -n "$namespace" "$type" "$name" && [ "$ITER" -lt "$retries" ]; do
    ITER=$((ITER + 1))
    echo "$name $type doesn't exist yet. Waiting $interval seconds ($ITER of $retries)."
    sleep "$interval"
  done
  # Returns non-zero if the object was not found within retries
  [[ $ITER -lt $retries ]]
}

# retry N command
# Retries a command up to a specific number of times with exponential backoff.
function retry {
  local retries=$1
  shift

  local count=0
  until "$@"; do
    local exit=$?
    local wait=$((2 ** count))
    count=$((count + 1))
    if [ "$count" -lt "$retries" ]; then
      echo "Retry $count/$retries exited $exit, retrying in $wait seconds..." >&2
      sleep "$wait"
    else
      echo "Retry $count/$retries exited $exit, no more retries left." >&2
      return "$exit"
    fi
  done
  return 0
}

# version_gte: returns 0 (true) if version >= threshold
function version_gte() {
  local threshold=$1
  local version=$2
  [[ "$(printf '%s\n' "$threshold" "$version" | sort -V | head -n1)" == "$threshold" ]]
}

# wait_for_all_nodes: waits until every expected node has registered with the
# API server. The expected count is derived from $NODES, mirroring the
# create_cluster_kind/create_cluster_k3d formula: worker/agent nodes join the
# control plane asynchronously, so `kind create cluster` / `k3d cluster
# create` returning is no guarantee that every Node object exists yet. Callers
# that need to operate on the complete node set (e.g.
# label_failure_domain_topology) must call this first.
function wait_for_all_nodes() {
    # shellcheck disable=SC2153 # NODES is set by the caller (kind/k3d setup.sh) before sourcing this file
    local expected_nodes=$(( NODES > 1 ? NODES + 1 : 1 ))

    local iter=0
    while [[ "$(${K8S_CLI} get nodes --no-headers 2>/dev/null | wc -l | tr -d ' ')" -lt "${expected_nodes}" ]]; do
        if [[ $iter -ge 120 ]]; then
            # this runs on every cluster creation, so it must not be the reason
            # a test run never starts: the tests needing every node say so
            echo "WARNING: timed out waiting for ${expected_nodes} nodes to register, continuing" >&2
            break
        fi
        sleep 1
        ((++iter))
    done
}

# label_failure_domain_topology: labels every node with
# topology.kubernetes.io/region (fixed to "cnpg") and topology.kubernetes.io/zone
# (az-<N>, where N is the trailing number in the node's name -- e.g.
# "...-worker3" becomes az-3 -- and defaults to 1 for a node name with no
# trailing number, such as the control-plane or the first worker), so that
# CloudNativePG's failure domain-aware synchronous replication
# (nodeFailureDomainKeys/podFailureDomainKeys) has real, node-distinct
# topology labels to read on a local kind/k3d cluster -- neither engine sets
# these by default. Only sets a label when it isn't already present, so a
# node that genuinely carries real topology labels (e.g. a non-local engine)
# is left untouched. Assumes every node is already registered; call
# wait_for_all_nodes first.
function label_failure_domain_topology() {
    local region="cnpg"

    local node
    while IFS= read -r node; do
        local seq=1
        if [[ "${node}" =~ ([0-9]+)$ ]]; then
            seq="${BASH_REMATCH[1]}"
        fi
        local zone="az-${seq}"

        if [[ -z "$(${K8S_CLI} get node "${node}" -o jsonpath='{.metadata.labels.topology\.kubernetes\.io/region}')" ]]; then
            ${K8S_CLI} label node "${node}" "topology.kubernetes.io/region=${region}"
        fi
        if [[ -z "$(${K8S_CLI} get node "${node}" -o jsonpath='{.metadata.labels.topology\.kubernetes\.io/zone}')" ]]; then
            ${K8S_CLI} label node "${node}" "topology.kubernetes.io/zone=${zone}"
        fi
    # A trailing newline after every name (rather than joining with spaces
    # and translating) matters here: `while read` silently drops the last
    # line of input when it isn't newline-terminated, which would otherwise
    # skip the last node returned by the list -- deterministically, not just
    # under a registration race.
    done < <(${K8S_CLI} get nodes -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}')
}

# get_default_storage_class detects the default K8s storage class
function get_default_storage_class() {
    ${K8S_CLI} get storageclass -o json | jq -r 'first(.items[] | select (.metadata.annotations["storageclass.kubernetes.io/is-default-class"] == "true") | .metadata.name)'
}

# get_default_snapshot_class detects the snapshot class for a given storage class
function get_default_snapshot_class() {
    local STORAGE_CLASS=${1:-${1:?STORAGE_CLASS is required}}
    ${K8S_CLI} get storageclass "$STORAGE_CLASS" -o json | jq -r '.metadata.annotations["storage.kubernetes.io/default-snapshot-class"]'
}

function deploy_prometheus_crds() {
  # Requires helm to be installed and $K8S_CLI (kubectl/oc) to be functional.
  # shellcheck disable=SC2154
  echo -e "${bright}Starting deployment of Prometheus CRDs...${reset}"

  # 1. Add Prometheus Community Helm Repository
  retry 3 helm repo add prometheus-community https://prometheus-community.github.io/helm-charts

  # 2. Install only the CRDs required by the Prometheus operator
  # We install into kube-system as that namespace is standard and always exists.
  retry 3 helm -n kube-system upgrade --install prometheus-operator-crds prometheus-community/prometheus-operator-crds

  echo -e "${bright}Prometheus CRDs deployed.${reset}"
}

function deploy_pyroscope() {
  # Requires helm to be installed and available in the environment.

  echo -e "${bright}Deploying Pyroscope and enabling pprof profiling on the operator...${reset}"

  # 1. Add Pyroscope Helm Repository
  retry 3 helm repo add pyroscope-io https://grafana.github.io/helm-charts

  # 2. Define Pyroscope configuration values and install via Helm
  local values_file="${TEMP_DIR}/pyroscope_values.yaml"
  cat >"${values_file}" <<-EOF
pyroscopeConfigs:
  log-level: "debug"
EOF
  retry 3 helm upgrade --install --create-namespace -n pyroscope pyroscope pyroscope-io/pyroscope -f "${values_file}"

  # 3. Create patch file to enable operator profiling annotations
  # These annotations tell Pyroscope's agent what ports and profiles to scrape.
  local annotations="${TEMP_DIR}/pyroscope_annotations.yaml"
  cat >"${annotations}" <<- EOF
spec:
    template:
      metadata:
          annotations:
            profiles.grafana.com/memory.scrape: "true"
            profiles.grafana.com/memory.port: "6060"
            profiles.grafana.com/cpu.scrape: "true"
            profiles.grafana.com/cpu.port: "6060"
            profiles.grafana.com/goroutine.scrape: "true"
            profiles.grafana.com/goroutine.port: "6060"
EOF

  # Patch the operator deployment to enable profiling ports/scrapes
  "${K8S_CLI}" -n cnpg-system patch deployment cnpg-controller-manager --patch-file "${annotations}"

  # 4. Patch the operator's ConfigMap to inherit these new annotations
  # This ensures PostgreSQL clusters managed by the operator also inherit the profiling settings.
  local configMaps="${TEMP_DIR}/cnpg_configmap_config.yaml"
  cat >"${configMaps}" <<-EOF
data:
  INHERITED_ANNOTATIONS: "profiles.grafana.com/*"
EOF

  # Find the name of the ConfigMap currently referenced by the operator deployment
  local configMapName
  configMapName=$("${K8S_CLI}" -n cnpg-system get deployments.apps cnpg-controller-manager -o jsonpath='{.spec.template.spec.containers[0].envFrom[0].configMapRef.name}')

  # Patch the ConfigMap
  "${K8S_CLI}" -n cnpg-system patch configmap "${configMapName}" --patch-file "${configMaps}"

  echo -e "${bright}Pyroscope deployment successful and operator patched to expose profiling data.${reset}"
}

# print_operator_image: prints the operator image reference (as set on the
# controller-manager Deployment's first container) when the deployment exists.
function print_operator_image() {
    local image
    image=$(${K8S_CLI} get deployment cnpg-controller-manager -n cnpg-system \
        --ignore-not-found \
        -o jsonpath='{.spec.template.spec.containers[0].image}')
    if [[ -n "${image}" ]]; then
        printf '%bOperator image: %s%b\n' "${bright}" "${image}" "${reset}"
    fi
}

# reset_operator_namespace: deletes the cnpg-system namespace and any
# cluster-scoped resources left by a previous operator installation, then waits
# for finalization so the next apply doesn't race a terminating namespace.
# Plugin services are deleted first because deploy_operator_from_manifest can
# target an arbitrary released operator version, and every version released so
# far still puts a cnpg.io/cleanupPlugin finalizer on the plugin Service; that
# finalizer only got removed on unreleased main/branch tips (#10940), so
# deleting cnpg-system wholesale can still wedge the namespace against a
# released operator. 1.30 is the newest release branch and still predates the
# fix, so this is safe to drop once 1.30 reaches EOL.
# Cluster-scoped resources (webhooks, ClusterRoles, ClusterRoleBindings) must be
# removed explicitly because they survive namespace deletion and would block Helm
# from adopting them (missing ownership labels).
function reset_operator_namespace() {
    # Must run before "helm uninstall": that would tear down a helm-deployed
    # operator first, leaving nothing to clear the finalizer below.
    ${K8S_CLI} delete services -n cnpg-system -l cnpg.io/pluginName \
        --ignore-not-found --wait=true --timeout=60s 2>/dev/null || true

    if command -v helm &>/dev/null && helm status cnpg -n cnpg-system &>/dev/null; then
        helm uninstall cnpg -n cnpg-system --wait
    fi

    ${K8S_CLI} delete ns cnpg-system --ignore-not-found --wait=false
    ${K8S_CLI} wait --for=delete ns/cnpg-system --timeout=60s

    ${K8S_CLI} get mutatingwebhookconfigurations -o name | { grep '/cnpg-' || true; } | xargs -r "${K8S_CLI}" delete
    ${K8S_CLI} get validatingwebhookconfigurations -o name | { grep '/cnpg-' || true; } | xargs -r "${K8S_CLI}" delete
    ${K8S_CLI} get clusterroles -o name | { grep '/cnpg-' || true; } | xargs -r "${K8S_CLI}" delete
    ${K8S_CLI} get clusterrolebindings -o name | { grep '/cnpg-' || true; } | xargs -r "${K8S_CLI}" delete
}

# wait_operator_ready: waits for the operator deployment rollout to finish and
# prints a completion banner. Accepts an optional deployment name.
# When installed via manifest or the cnpg plugin the deployment is called
# cnpg-controller-manager; when installed via Helm it is called
# cnpg-cloudnative-pg. See:
# https://cloudnative-pg.io/docs/1.29/installation_upgrade#using-the-helm-chart
function wait_operator_ready() {
    local deploy_name="${1:-cnpg-controller-manager}"
    ${K8S_CLI} -n cnpg-system rollout status deploy/"${deploy_name}" --timeout=5m
    printf '%bOperator deployment complete.%b\n' "${bright}" "${reset}"
    print_operator_image
}

# deploy_operator_from_manifest <operator>
# Deploys the operator by applying its manifest. The <operator> argument is
# interpreted either as a semver version (e.g. 1.28.1 or v1.28.1, with optional
# prerelease suffix), in which case the published release manifest from the main
# repository is used, or as a branch name (e.g. main, release-1.28), in which
# case the snapshot manifest from the cloudnative-pg/artifacts repository is
# used.
function deploy_operator_from_manifest() {
    local operator="${1:?operator is required}"
    local mode
    local manifest_url

    if [[ "${operator}" =~ ^v?[0-9]+\.[0-9]+\.[0-9]+(-[A-Za-z0-9.-]+)?$ ]]; then
        local version="${operator#v}"
        mode="version"
        manifest_url="https://github.com/cloudnative-pg/cloudnative-pg/releases/download/v${version}/cnpg-${version}.yaml"
    elif [[ "${operator}" =~ ^v?[0-9] ]]; then
        # Looks version-like but isn't valid semver -- refuse rather than silently
        # fall through to branch mode and produce a misleading "not found" error.
        printf '%bError: %s is not a valid operator version (expected e.g. 1.28.1 or v1.28.1)%b\n' \
            "${bright}" "${operator}" "${reset}" >&2
        exit 1
    elif [[ "${operator}" =~ ^[A-Za-z0-9][A-Za-z0-9._/-]*$ ]] && [[ "${operator}" != *..* ]]; then
        mode="branch"
        manifest_url="https://raw.githubusercontent.com/cloudnative-pg/artifacts/${operator}/manifests/operator-manifest.yaml"
    else
        printf '%bError: %s is not a valid operator value%b\n' \
            "${bright}" "${operator}" "${reset}" >&2
        printf '%bExpected a semver (e.g. 1.28.1) or a branch name (e.g. main, release-1.28).%b\n' \
            "${bright}" "${reset}" >&2
        exit 1
    fi

    local manifest_file="${TEMP_DIR}/cnpg-operator-manifest.yaml"
    if ! _curl_github -fsSL --retry 5 --retry-delay 2 -o "${manifest_file}" "${manifest_url}"; then
        printf '%bError: Manifest not found at %s%b\n' "${bright}" "${manifest_url}" "${reset}" >&2
        printf '%bInterpreted %s as a %s.%b\n' "${bright}" "${operator}" "${mode}" "${reset}" >&2
        exit 1
    fi

    printf '%bDeploying operator from %s%b\n' "${bright}" "${operator}" "${reset}"
    reset_operator_namespace
    # --server-side avoids the last-applied-configuration annotation exceeding
    # the 262144 byte limit on large CRDs; --force-conflicts lets us adopt
    # existing field ownership when re-deploying or switching operator version.
    ${K8S_CLI} apply --server-side --force-conflicts -f "${manifest_file}"
    wait_operator_ready
}

# deploy_csi_host_path: Deploys the host path CSI driver and snapshotter components.
function deploy_csi_host_path() {
  # shellcheck disable=SC2154
  echo -e "${bright}Deploying CSI Host Path Driver...${reset}"

  # Base URL for CSI repository manifests
  local CSI_BASE_URL=https://raw.githubusercontent.com/kubernetes-csi

  # --- 1. Install External Snapshotter CRDs and Controller (Versions sourced from 10-config.sh) ---

  ## Apply CRDs
  _apply_github "${CSI_BASE_URL}/external-snapshotter/${EXTERNAL_SNAPSHOTTER_VERSION}/client/config/crd/snapshot.storage.k8s.io_volumesnapshotclasses.yaml"
  _apply_github "${CSI_BASE_URL}/external-snapshotter/${EXTERNAL_SNAPSHOTTER_VERSION}/client/config/crd/snapshot.storage.k8s.io_volumesnapshotcontents.yaml"
  _apply_github "${CSI_BASE_URL}/external-snapshotter/${EXTERNAL_SNAPSHOTTER_VERSION}/client/config/crd/snapshot.storage.k8s.io_volumesnapshots.yaml"

  ## Apply RBAC and Controller
  _apply_github "${CSI_BASE_URL}/external-snapshotter/${EXTERNAL_SNAPSHOTTER_VERSION}/deploy/kubernetes/snapshot-controller/rbac-snapshot-controller.yaml"
  _apply_github "${CSI_BASE_URL}/external-snapshotter/${EXTERNAL_SNAPSHOTTER_VERSION}/deploy/kubernetes/snapshot-controller/setup-snapshot-controller.yaml"
  _apply_github "${CSI_BASE_URL}/external-snapshotter/${EXTERNAL_SNAPSHOTTER_VERSION}/deploy/kubernetes/csi-snapshotter/rbac-csi-snapshotter.yaml"

  # --- 2. Install External Sidecar Components ---

  ## Install external provisioner
  _apply_github "${CSI_BASE_URL}/external-provisioner/${EXTERNAL_PROVISIONER_VERSION}/deploy/kubernetes/rbac.yaml"

  ## Install external attacher
  _apply_github "${CSI_BASE_URL}/external-attacher/${EXTERNAL_ATTACHER_VERSION}/deploy/kubernetes/rbac.yaml"

  ## Install external resizer
  _apply_github "${CSI_BASE_URL}/external-resizer/${EXTERNAL_RESIZER_VERSION}/deploy/kubernetes/rbac.yaml"

  # --- 3. Install Driver and Plugin ---

  ## Create a temporary file for the modified plugin deployment. This updates the image tag.
  local plugin_file="${TEMP_DIR}/csi-hostpath-plugin.yaml"
  _curl_github -fsSL --retry 5 --retry-delay 2 "${CSI_BASE_URL}/csi-driver-host-path/${CSI_DRIVER_HOST_PATH_VERSION}/deploy/kubernetes-1.30/hostpath/csi-hostpath-plugin.yaml" |
    sed "s|registry.k8s.io/sig-storage/hostpathplugin:.*|registry.k8s.io/sig-storage/hostpathplugin:${CSI_DRIVER_HOST_PATH_VERSION}|g" > "${plugin_file}"

  # Apply driver info and plugin deployment
  _apply_github "${CSI_BASE_URL}/csi-driver-host-path/${CSI_DRIVER_HOST_PATH_VERSION}/deploy/kubernetes-1.30/hostpath/csi-hostpath-driverinfo.yaml"
  "${K8S_CLI}" apply -f "${plugin_file}"
  rm "${plugin_file}"

  # --- 4. Configure Storage Classes ---

  ## Create VolumeSnapshotClass
  _apply_github "${CSI_BASE_URL}/csi-driver-host-path/${CSI_DRIVER_HOST_PATH_VERSION}/deploy/kubernetes-1.30/hostpath/csi-hostpath-snapshotclass.yaml"

  ## Patch VolumeSnapshotClass to allow snapshots of running PostgreSQL instances
  ## by ignoring read failures during snapshot creation
  "${K8S_CLI}" patch volumesnapshotclass csi-hostpath-snapclass -p '{"parameters":{"ignoreFailedRead":"true"}}' --type merge

  ## Create StorageClass
  _apply_github "${CSI_BASE_URL}/csi-driver-host-path/${CSI_DRIVER_HOST_PATH_VERSION}/examples/csi-storageclass.yaml"

  ## Annotate the StorageClass to set the default snapshot class
  "${K8S_CLI}" annotate storageclass csi-hostpath-sc storage.kubernetes.io/default-snapshot-class=csi-hostpath-snapclass

  # Wait for CSI plugin to be ready
  echo -e "${bright}CSI driver plugin deployment has started. Waiting for the CSI plugin to be ready...${reset}"
  local ITER=0
  while true; do
    if [[ $ITER -ge 300 ]]; then
      echo -e "${bright}Timeout: The CSI plugin did not become ready within the expected time.${reset}"
      exit 1
    fi
    local NUM_SPEC
    local NUM_STATUS
    NUM_SPEC=$("${K8S_CLI}" get statefulset csi-hostpathplugin -o jsonpath='{.spec.replicas}' 2>/dev/null || echo "")
    NUM_STATUS=$("${K8S_CLI}" get statefulset csi-hostpathplugin -o jsonpath='{.status.availableReplicas}' 2>/dev/null || echo "")
    if [[ -n "$NUM_SPEC" && "$NUM_SPEC" == "$NUM_STATUS" ]]; then
      echo -e "${bright}Success: The CSI plugin is deployed and ready.${reset}"
      break
    fi
    sleep 1
    ((++ITER))
  done
}

# deploy_fluentd: Pulls the FluentD image and deploys the DaemonSet.
function deploy_fluentd() {
  local FLUENTD_IMAGE=fluent/fluentd-kubernetes-daemonset:v1.14.3-debian-forward-1.0
  # shellcheck disable=SC2154
  local FLUENTD_LOCAL_IMAGE="${registry_name}:5000/fluentd-kubernetes-daemonset:local"

  echo -e "${bright}Starting FluentD deployment...${reset}"
  docker pull "${FLUENTD_IMAGE}"
  docker tag "${FLUENTD_IMAGE}" "${FLUENTD_LOCAL_IMAGE}"
  # shellcheck disable=SC2153
  "load_image_${CLUSTER_ENGINE}" "${CLUSTER_NAME}" "${FLUENTD_LOCAL_IMAGE}"

  "${K8S_CLI}" apply -f "${E2E_DIR}/local-fluentd.yaml"

  # Wait for FluentD to be ready
  echo -e "${bright}Waiting for FluentD to become ready...${reset}"
  local ITER=0
  local NODE
  NODE=$("${K8S_CLI}" get nodes --no-headers | wc -l | tr -d " ")
  while true; do
    if [[ $ITER -ge 300 ]]; then
      echo -e "${bright}Time out waiting for FluentD readiness${reset}"
      exit 1
    fi
    local NUM_READY
    NUM_READY=$("${K8S_CLI}" get ds fluentd -n kube-system -o jsonpath='{.status.numberReady}' 2>/dev/null || echo "")
    if [[ -n "$NUM_READY" && "$NUM_READY" == "$NODE" ]]; then
      echo -e "${bright}FluentD is Ready${reset}"
      break
    fi
    sleep 1
    ((++ITER))
  done
}

# deploy_operator_from_source: applies the pre-generated operator manifest.
# Requires generate_operator_manifest (via setup-cluster.sh) to have been
# called first.
function deploy_operator_from_source() {
    # shellcheck disable=SC2154
    echo -e "${bright}Deploying CNPG operator from ${OPERATOR_MANIFEST_PATH}${reset}"
    ${K8S_CLI} apply --server-side --force-conflicts -f "${OPERATOR_MANIFEST_PATH}"
    wait_operator_ready
}

# deploy_operator_with_helm: installs the operator from the published CNPG Helm
# chart, overriding the chart's default image with the locally-built one so the
# same binary under test is used. Only supported with OPERATOR=local.
#
# CRDs are applied from the local source tree (config/helm) so they always
# match the locally-built operator binary under test. The chart's built-in CRD
# management is disabled via --set crds.create=false.
function deploy_operator_with_helm() {
    if ! command -v helm &>/dev/null; then
        echo "ERROR: 'helm' not found in PATH. Install Helm before running with CNPG_DEPLOYMENT_METHOD=helm." >&2
        exit 1
    fi

    echo -e "${bright}Deploying CNPG operator via Helm chart...${reset}"

    # Apply CRDs from the local source tree to ensure they match the operator binary under test.
    ${K8S_CLI} apply --server-side -k "${ROOT_DIR}/config/helm"

    helm repo add cnpg https://cloudnative-pg.github.io/charts
    helm repo update cnpg

    local -a helm_args=(
        --namespace cnpg-system
        --create-namespace
        --set crds.create=false
        --set config.create=false
        --set "additionalArgs[0]=--secret-name=cnpg-controller-manager-config"
    )

    if ${K8S_CLI} get secret cnpg-pull-secret -n cnpg-system >/dev/null 2>&1; then
        helm_args+=(--set "imagePullSecrets[0].name=cnpg-pull-secret")
    fi

    if [[ -n "${CNPG_CHART_VERSION:-}" ]]; then
        helm_args+=(--version "${CNPG_CHART_VERSION}")
    fi

    # shellcheck disable=SC2153
    if [[ "${OPERATOR}" == "local" ]]; then
        local helm_image_tag="${CONTROLLER_IMG##*:}"
        if [[ -n "${CONTROLLER_IMG_DIGEST:-}" ]]; then
            helm_image_tag="${helm_image_tag}@${CONTROLLER_IMG_DIGEST}"
        fi
        helm_args+=(
            --set "image.repository=${CONTROLLER_IMG%:*}"
            --set "image.tag=${helm_image_tag}"
            --set "additionalEnv[0].name=POSTGRES_IMAGE_NAME"
            --set "additionalEnv[0].value=${POSTGRES_IMG}"
            --set "additionalEnv[1].name=PGBOUNCER_IMAGE_NAME"
            --set "additionalEnv[1].value=${PGBOUNCER_IMG}"
        )
    fi

    helm upgrade --install cnpg cnpg/cloudnative-pg "${helm_args[@]}"
    # When installed via Helm the deployment is called cnpg-cloudnative-pg, not
    # cnpg-controller-manager. See:
    # https://cloudnative-pg.io/docs/current/installation_upgrade#using-the-helm-chart
    wait_operator_ready "cnpg-cloudnative-pg"
}

# ensure_cert_manager: installs cert-manager (idempotently) and waits for it to
# become ready. plugin-barman-cloud requires cert-manager because its manifest
# creates the Issuer/Certificate resources used for the operator<->plugin mTLS.
function ensure_cert_manager() {
    # Split so renovate's regex (needs a bare "X_VERSION=", not "local X_VERSION=") still matches.
    local CERT_MANAGER_DEFAULT_VERSION
    # renovate: datasource=github-releases depName=cert-manager/cert-manager
    CERT_MANAGER_DEFAULT_VERSION="v1.21.0"
    local cert_manager_version="${CERT_MANAGER_VERSION:-${CERT_MANAGER_DEFAULT_VERSION}}"

    # shellcheck disable=SC2154
    if ${K8S_CLI} get deployment cert-manager -n cert-manager >/dev/null 2>&1; then
        echo -e "${bright}cert-manager already present, skipping install.${reset}"
    else
        echo -e "${bright}Installing cert-manager ${cert_manager_version}...${reset}"
        # Download once, then retry only the apply, as deploy_operator_from_manifest does.
        local manifest_file="${TEMP_DIR:-/tmp}/cert-manager-manifest.yaml"
        if ! _curl_github -fsSL --retry 5 --retry-delay 2 -o "${manifest_file}" \
            "https://github.com/cert-manager/cert-manager/releases/download/${cert_manager_version}/cert-manager.yaml"; then
            printf '%bError: could not download the cert-manager %s manifest%b\n' \
                "${bright}" "${cert_manager_version}" "${reset}" >&2
            return 1
        fi
        retry 5 "${K8S_CLI}" apply --server-side --force-conflicts -f "${manifest_file}"
    fi
    ${K8S_CLI} wait --for=condition=Available --timeout=300s -n cert-manager \
        deployment/cert-manager deployment/cert-manager-webhook deployment/cert-manager-cainjector
}

# install_barman_cloud_plugin: installs plugin-barman-cloud into cnpg-system.
# The version is selected via the BARMAN_PLUGIN_VERSION environment variable:
#   - "release" (default): the latest published release
#   - "main":              the current snapshot from the main branch
#   - "vX.Y.Z" / "X.Y.Z":  a specific pinned release
#   - "pr-<number>":       a plugin-barman-cloud pull request. Installs the
#                          testing images its CI publishes for the PR (tagged
#                          "pr-<number>"), with the manifest taken from the
#                          PR's head ref.
#   - "<branch>":          a same-repo plugin-barman-cloud branch. Installs the
#                          testing images its CI publishes for the branch. The
#                          manifest checked into the branch still points at the
#                          "main" testing images, so both the operator
#                          Deployment image and the sidecar image are repointed
#                          at the branch's testing images (tag = branch name
#                          with every "/" replaced by "-", mirroring the plugin
#                          Taskfile).
# Requires the operator to be installed first. Exports
# BARMAN_PLUGIN_VERSION_RESOLVED with the concrete version that was deployed
# (read back from the running deployment image) so the test suite can log it.
function install_barman_cloud_plugin() {
    # shellcheck disable=SC2154
    local selector="${BARMAN_PLUGIN_VERSION:-release}"
    local repo="cloudnative-pg/plugin-barman-cloud"
    local manifest_url
    local operator_namespace="cnpg-system"
    # Non-empty only in branch mode; holds the derived testing image tag.
    local branch_tag=""

    case "${selector}" in
        release)
            manifest_url="https://github.com/${repo}/releases/latest/download/manifest.yaml"
            ;;
        main)
            manifest_url="https://raw.githubusercontent.com/${repo}/refs/heads/main/manifest.yaml"
            ;;
        *)
            # A pinned version, validated with the same anchored pattern used by
            # deploy_operator_from_manifest so a malformed value fails fast with a
            # clear message instead of a confusing 404.
            if [[ "${selector}" =~ ^v?[0-9]+\.[0-9]+\.[0-9]+(-[A-Za-z0-9.-]+)?$ ]]; then
                manifest_url="https://github.com/${repo}/releases/download/v${selector#v}/manifest.yaml"
            elif [[ "${selector}" =~ ^pr-[0-9]+$ ]]; then
                # A plugin-barman-cloud pull request: its CI publishes the
                # testing images under the "pr-<number>" tag (the pull_request
                # ref name is "<number>/merge", not the branch name), and the
                # matching manifest is served from the PR's head ref.
                manifest_url="https://raw.githubusercontent.com/${repo}/refs/pull/${selector#pr-}/head/manifest.yaml"
                branch_tag="${selector}"
            elif [[ "${selector}" =~ ^[A-Za-z0-9][A-Za-z0-9._/-]*$ && "${selector}" != *".."* ]]; then
                # Anything else is treated as a plugin-barman-cloud branch name,
                # validated with a conservative charset so a malformed value
                # fails fast instead of building a bogus raw URL. A nonexistent
                # branch still fails later with the "manifest not found" error.
                # ".." is rejected outright: curl normalizes "../" in the URL
                # path by default, so a crafted selector could otherwise escape
                # the pinned "${repo}" and reach an arbitrary repo/branch.
                manifest_url="https://raw.githubusercontent.com/${repo}/refs/heads/${selector}/manifest.yaml"
                branch_tag="${selector//\//-}"
            else
                printf '%bError: invalid BARMAN_PLUGIN_VERSION "%s" (expected "release", "main", a version like v0.12.0, pr-<number> for a pull request, or a branch name)%b\n' \
                    "${bright}" "${selector}" "${reset}" >&2
                return 1
            fi
            ;;
    esac

    ensure_cert_manager

    echo -e "${bright}Installing plugin-barman-cloud (${selector}) from ${manifest_url}${reset}"
    # Download once, then retry only the apply, as deploy_operator_from_manifest
    # does. The retry absorbs the cert-manager webhook readiness race: the
    # plugin manifest creates cert-manager Issuer/Certificate resources.
    local manifest_file="${TEMP_DIR:-/tmp}/plugin-barman-cloud-manifest.yaml"
    if ! _curl_github -fsSL --retry 5 --retry-delay 2 -o "${manifest_file}" "${manifest_url}"; then
        printf '%bError: manifest not found at %s%b\n' "${bright}" "${manifest_url}" "${reset}" >&2
        return 1
    fi

    # Force every namespaced object onto the namespace this script installs
    # the operator into, rather than trusting whatever the release manifest
    # happens to hardcode: the two are not guaranteed to match.
    local kustomize_dir
    kustomize_dir="$(mktemp -d)"
    cp "${manifest_file}" "${kustomize_dir}/manifest.yaml"
    cat > "${kustomize_dir}/kustomization.yaml" <<EOF
resources:
- manifest.yaml
namespace: ${operator_namespace}
EOF
    # In branch mode the checked-in manifest still references the "main" testing
    # images, so repoint both at the branch's testing images. The Deployment
    # image is handled by the images transformer; the sidecar image is delivered
    # to the operator through the SIDECAR_IMAGE env var, which the manifest wires
    # up via a secretKeyRef into a content-hashed Secret. Patching the env var
    # with a literal value (and dropping the valueFrom) overrides that
    # indirection directly, so the hashed Secret name never has to be known.
    if [[ -n "${branch_tag}" ]]; then
        local plugin_image="ghcr.io/cloudnative-pg/plugin-barman-cloud-testing"
        local sidecar_image="ghcr.io/cloudnative-pg/plugin-barman-cloud-sidecar-testing"
        cat >> "${kustomize_dir}/kustomization.yaml" <<EOF
images:
- name: ${plugin_image}
  newTag: ${branch_tag}
patches:
- target:
    kind: Deployment
    name: barman-cloud
  patch: |-
    apiVersion: apps/v1
    kind: Deployment
    metadata:
      name: barman-cloud
    spec:
      template:
        spec:
          containers:
          - name: barman-cloud
            env:
            - name: SIDECAR_IMAGE
              value: ${sidecar_image}:${branch_tag}
              valueFrom: null
EOF
    fi
    "${K8S_CLI}" kustomize "${kustomize_dir}" > "${manifest_file}"
    rm -rf "${kustomize_dir}"

    # The images transformer above is a silent no-op if plugin_image no longer
    # matches what the manifest actually references, so check the rewrite
    # landed instead of installing a manifest that's still pinned to "main".
    if [[ -n "${branch_tag}" ]] && ! grep -qF "${plugin_image}:${branch_tag}" "${manifest_file}"; then
        printf '%bError: expected image %s:%s not found in the generated manifest; the plugin-barman-cloud image name may have changed%b\n' \
            "${bright}" "${plugin_image}" "${branch_tag}" "${reset}" >&2
        return 1
    fi

    retry 5 "${K8S_CLI}" apply --server-side --force-conflicts -f "${manifest_file}"

    ${K8S_CLI} -n "${operator_namespace}" rollout status deploy/barman-cloud --timeout=5m

    local image
    image=$(${K8S_CLI} get deployment barman-cloud -n "${operator_namespace}" \
        -o jsonpath='{.spec.template.spec.containers[0].image}')
    export BARMAN_PLUGIN_VERSION_RESOLVED="${image##*:}"
    printf '%bplugin-barman-cloud installed: selector=%s resolved=%s (image %s)%b\n' \
        "${bright}" "${selector}" "${BARMAN_PLUGIN_VERSION_RESOLVED}" "${image}" "${reset}"
}

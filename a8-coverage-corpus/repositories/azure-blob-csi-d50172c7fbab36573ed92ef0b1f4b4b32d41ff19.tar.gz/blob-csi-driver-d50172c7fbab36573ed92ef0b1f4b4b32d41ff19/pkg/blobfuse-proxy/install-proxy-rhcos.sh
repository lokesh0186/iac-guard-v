#!/bin/sh

# Copyright 2019 The Kubernetes Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

set -xe

if [ -z "${CUSTOM_BIN_PATH:-}" ] ; then
  case "${DISTRIBUTION}" in
    "cos")
      BIN_PATH="/home/kubernetes/bin" ;;
    "gardenlinux" | "flatcar")
      BIN_PATH="/var/bin"
      mkdir -p /host${BIN_PATH} ;;
    "azurecontainerlinux")
      BIN_PATH="/opt/blobcsi/bin"
      mkdir -p /host${BIN_PATH} ;;
    "rhcos")
      # On RHCOS, /usr/local is a symlink to /var/usrlocal. The chart
      # rewrites BOTH the hostPath and the in-container mountPath to
      # /var/usrlocal to avoid crun's RESOLVE_NO_SYMLINKS check, so the
      # write path inside this init container must also be
      # /host/var/usrlocal/bin. On the host, /var/usrlocal/bin is the
      # same real directory as /usr/local/bin via the OSTree symlink,
      # so the systemd unit still resolves the binary correctly.
      BIN_PATH=${BIN_PATH:-/var/usrlocal/bin}
      mkdir -p /host${BIN_PATH} ;;
    *)
      BIN_PATH=${BIN_PATH:-/usr/local/bin} ;;
  esac
else
  BIN_PATH="/${CUSTOM_BIN_PATH#/}"
fi
echo "set BIN_PATH to ${BIN_PATH}"

#copy blobfuse2 binary to BIN_PATH/blobfuse2
updateBlobfuse2="true"
if [ "$DISTRIBUTION" = "azurecontainerlinux" ]; then
  echo "skip blobfuse2 install for Azure Container Linux (pre-installed)"
  updateBlobfuse2="false"
elif [ "${INSTALL_BLOBFUSE}" = "true" ] || [ "${INSTALL_BLOBFUSE2}" = "true" ]
then
  if [ -f "/host${BIN_PATH}/blobfuse2" ];then
    if [ "$DISTRIBUTION" = "flatcar" ] ; then
      # Flatcar uses a custom binary name and provides a wrapper script library loader, see below
      old=$(sha256sum /host${BIN_PATH}/blobfuse2.bin | awk '{print $1}')
    else
      old=$(sha256sum /host${BIN_PATH}/blobfuse2 | awk '{print $1}')
    fi
    new=$(sha256sum /usr/bin/blobfuse2 | awk '{print $1}')
    if [ "$old" = "$new" ];then
      updateBlobfuse2="false"
      echo "no need to update blobfuse2 since no change"
    fi
  fi
else
  echo "no need to install blobfuse2"
  updateBlobfuse2="false"
fi
if [ "$updateBlobfuse2" = "true" ];then
  echo "copy blobfuse2...."
  if [ "$DISTRIBUTION" = "flatcar" ] ; then
    # No libfuse.so.* on Flatcar so we ship the container's and provide a wrapper script
    find /usr/ -name 'libfuse.so.*' -exec cp '{}' /host${BIN_PATH} \;
    cp /usr/bin/blobfuse2 /host${BIN_PATH}/blobfuse2.bin --force
    {
      echo '#!/usr/bin/bash'
      echo "LD_LIBRARY_PATH='${BIN_PATH}' exec ${BIN_PATH}/blobfuse2.bin \"\${@}\""
    } >/host${BIN_PATH}/blobfuse2
    chmod 755 /host${BIN_PATH}/blobfuse2.bin
  else
    cp /usr/bin/blobfuse2 /host${BIN_PATH}/blobfuse2 --force
  fi
  # Copy libfuse3.so.3 to the host ONLY when the host does not already have
  # a copy. Distributions like RHCOS 9.x and RHEL 9.x provide a libfuse3
  # built against their native glibc (2.34). Overwriting it with the
  # container's copy (built on Debian Bookworm / glibc 2.38) causes
  # "GLIBC_2.38 not found" errors when blobfuse2 runs on the host.
  #
  # We never replace or remove an existing /host/usr/lib64/libfuse3.so.3:
  # even if it looks identical to the container's copy, we cannot safely
  # prove where it came from, and `rm` cannot restore the OS's original
  # file. Nodes that were affected by a previous driver version installer
  # (which unconditionally overwrote libfuse3.so.3) must be repaired
  # out-of-band by reinstalling the host's fuse3 package or by an OSTree
  # rollback — not by this init container.
  _container_fuse3=""
  if [ -f "/usr/lib/libfuse3.so.3" ]; then
    _container_fuse3="/usr/lib/libfuse3.so.3"
  elif [ -f "/usr/lib64/libfuse3.so.3" ]; then
    _container_fuse3="/usr/lib64/libfuse3.so.3"
  fi

  if [ ! -d "/host/usr/lib64/" ]; then
    echo "skip copying libfuse3.so.3: /host/usr/lib64/ does not exist"
  elif [ ! -f "/host/usr/lib64/libfuse3.so.3" ]; then
    # Host has no libfuse3 at all — install ours.
    if [ -n "$_container_fuse3" ]; then
      echo "copy libfuse3.so.3 to /host/usr/lib64/ (host copy not present)"
      cp "${_container_fuse3}"* /host/usr/lib64/
    fi
  else
    echo "skip copying libfuse3.so.3: host already has /usr/lib64/libfuse3.so.3"
  fi
  chmod 755 /host${BIN_PATH}/blobfuse2
fi

if [ "${INSTALL_BLOBFUSE_PROXY}" = "true" ];then
  # install blobfuse-proxy
  updateBlobfuseProxy="true"
  if [ -f "/host${BIN_PATH}/blobfuse-proxy" ];then
    old=$(sha256sum /host${BIN_PATH}/blobfuse-proxy | awk '{print $1}')
    new=$(sha256sum /blobfuse-proxy/blobfuse-proxy | awk '{print $1}')
    if [ "$old" = "$new" ];then
      updateBlobfuseProxy="false"
      echo "no need to update blobfuse-proxy"
    fi
  fi
  if [ "$updateBlobfuseProxy" = "true" ];then
    echo "copy blobfuse-proxy...."
    rm -rf /host/${KUBELET_PATH}/plugins/blob.csi.azure.com/blobfuse-proxy.sock
    cp /blobfuse-proxy/blobfuse-proxy /host${BIN_PATH}/blobfuse-proxy --force
    chmod 755 /host${BIN_PATH}/blobfuse-proxy
  fi

  updateService="true"
  echo "change from /usr/bin/blobfuse-proxy to ${BIN_PATH}/blobfuse-proxy in blobfuse-proxy.service"
  sed -i "s|/usr/bin/blobfuse-proxy|${BIN_PATH}/blobfuse-proxy|g" /blobfuse-proxy/blobfuse-proxy.service
  if [ "${BIN_PATH}" != "/usr/local/bin" ]; then
    echo "add \"Environment=PATH=${BIN_PATH}:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin\" in blobfuse-proxy.service."
    sed -i "/^\\[Service\\]/a Environment=\"PATH=${BIN_PATH}:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin\"" /blobfuse-proxy/blobfuse-proxy.service
  fi
  if [ -f "/host/etc/systemd/system/blobfuse-proxy.service" ];then
    old=$(sha256sum /host/etc/systemd/system/blobfuse-proxy.service | awk '{print $1}')
    new=$(sha256sum /blobfuse-proxy/blobfuse-proxy.service | awk '{print $1}')
    if [ "$old" = "$new" ];then
        updateService="false"
        echo "no need to update blobfuse-proxy.service"
    fi
  fi
  if [ "$updateService" = "true" ];then
    echo "copy blobfuse-proxy.service...."
    mkdir -p /host/etc/systemd/system/
    cp /blobfuse-proxy/blobfuse-proxy.service /host/etc/systemd/system/blobfuse-proxy.service
  fi

  $HOST_CMD systemctl daemon-reload
  $HOST_CMD systemctl enable blobfuse-proxy.service
  if [ "$updateBlobfuseProxy" = "true" ] || [ "$updateService" = "true" ];then
    echo "restart blobfuse-proxy...."
    $HOST_CMD systemctl restart blobfuse-proxy.service
  else
    echo "start blobfuse-proxy...."
    $HOST_CMD systemctl start blobfuse-proxy.service
  fi
fi

# ONLYOFFICE DocSpace for Kubernetes
The following guide covers the installation process of the ‘ONLYOFFICE DocSpace’ into a Kubernetes cluster or OpenShift cluster.

## Contents
- [Requirements](#requirements)
- [Deploy prerequisites](#deploy-prerequisites)
  * [1. Add Helm repositories](#1-add-helm-repositories)
  * [2. Install NFS Provisioner](#2-install-nfs-provisioner)
  * [3. Install MySQL](#3-install-mysql)
  * [4. Install RabbitMQ](#4-install-rabbitmq)
  * [5. Install Redis](#5-install-redis)
  * [6. Install OpenSearch](#6-install-opensearch)
  * [7. Install ONLYOFFICE Docs](#7-install-onlyoffice-docs)
  * [8. Make changes to the configuration files (optional)](#8-make-changes-to-the-configuration-files-optional)
    + [8.1 Create a Secret containing a json file](#81-create-a-secret-containing-a-json-file)
    + [8.2 Specify parameters when installing ONLYOFFICE DocSpace](#82-specify-parameters-when-installing-onlyoffice-docspace)
- [Deploy ONLYOFFICE DocSpace](#deploy-onlyoffice-docspace)
  * [1. Add a license](#1-add-a-license)
  * [2. Install ONLYOFFICE DocSpace](#2-install-onlyoffice-docspace)
  * [3. Uninstall ONLYOFFICE DocSpace](#3-uninstall-onlyoffice-docspace)
  * [4. Upgrade ONLYOFFICE DocSpace](#4-upgrade-onlyoffice-docspace)
- [Parameters](#parameters)
  * [Common parameters](#common-parameters)
  * [ONLYOFFICE DocSpace Application parameters](#onlyoffice-docspace-application-parameters)
  * [ONLYOFFICE DocSpace Router Application additional parameters](#onlyoffice-docspace-router-application-additional-parameters)
  * [ONLYOFFICE DocSpace Socket Application additional parameters](#onlyoffice-docspace-socket-application-additional-parameters)
  * [ONLYOFFICE DocSpace Ssoauth Application additional parameters](#onlyoffice-docspace-ssoauth-application-additional-parameters)
  * [ONLYOFFICE DocSpace Proxy Frontend Application additional parameters](#onlyoffice-docspace-proxy-frontend-application-additional-parameters)
  * [ONLYOFFICE Docs parameters](#onlyoffice-docs-parameters)
  * [ONLYOFFICE DocSpace Ingress parameters](#onlyoffice-docspace-ingress-parameters)
  * [ONLYOFFICE DocSpace Jobs parameters](#onlyoffice-docspace-jobs-parameters)
  * [ONLYOFFICE DocSpace Elasticsearch parameters](#onlyoffice-docspace-opensearch-parameters)
  * [ONLYOFFICE DocSpace Test parameters](#onlyoffice-docspace-test-parameters)
- [Configuration and installation details](#configuration-and-installation-details)
  * [1. Expose ONLYOFFICE DocSpace](#1-expose-onlyoffice-docspace)
    + [1.1 Expose ONLYOFFICE DocSpace via Service (HTTP Only)](#11-expose-onlyoffice-docspace-via-service-http-only)
    + [1.2 Expose ONLYOFFICE DocSpace via Ingress](#12-expose-onlyoffice-docspace-via-ingress)
    + [1.2.1 Installing F5 NGINX Ingress Controller](#121-installing-f5-nginx-ingress-controller)
    + [1.2.2 Expose ONLYOFFICE DocSpace via HTTP](#122-expose-onlyoffice-docspace-via-http)
    + [1.2.3 Expose ONLYOFFICE DocSpace via HTTPS](#123-expose-onlyoffice-docspace-via-https)
    + [1.2.4 Expose ONLYOFFICE DocSpace via HTTPS using the Let's Encrypt certificate](#124-expose-onlyoffice-docspace-via-https-using-the-lets-encrypt-certificate)
  * [2. Transition from ElasticSearch to OpenSearch](#2-transition-from-elasticsearch-to-opensearch)
  * [3. Scale ONLYOFFICE DocSpace (optional)](#3-scale-onlyoffice-docspace-optional)
    + [3.1 Horizontal Pod Autoscaling](#31-horizontal-pod-autoscaling)
    + [3.2 Manual scaling](#32-manual-scaling)
  * [4. Encryption Key Management for Identity](#4-encryption-key-management-for-identity)
  * [5. Configuring Domain Name for Email Notifications](#5-configuring-domain-name-for-email-notifications)
- [ONLYOFFICE DocSpace installation test (optional)](#onlyoffice-docspace-installation-test-optional)

## Requirements

  - Kubernetes version no lower than 1.19+ or OpenShift version no lower than 3.11+
  - A minimum of two hosts is required for the Kubernetes cluster
  - Resources for the cluster hosts: 8 CPU \ 16 GB RAM min
  - Kubectl is installed on the cluster management host. Read more on the installation of kubectl [here](https://kubernetes.io/docs/tasks/tools/install-kubectl/)
  - Helm v3.15+ is installed on the cluster management host. Read more on the installation of Helm [here](https://helm.sh/docs/intro/install/)
  - If you use OpenShift, you can use both `oc` and `kubectl` to manage deploy.
  - If the installation of components external to ‘ONLYOFFICE DocSpace’ is performed from Helm Chart in an OpenShift cluster, then it is recommended to install them from a user who has the `cluster-admin` role, in order to avoid possible problems with access rights. See [this](https://docs.openshift.com/container-platform/4.7/authentication/using-rbac.html) guide to add the necessary roles to the user.

## Deploy prerequisites

Note: It may be required to apply `SecurityContextConstraints` policy when installing into OpenShift cluster, which adds permission to run containers from a user whose `ID = 1000` and `ID = 1001`.

To do this, run the following commands:

```
$ oc apply -f https://raw.githubusercontent.com/ONLYOFFICE/Kubernetes-DocSpace/main/sources/scc/helm-components.yaml
$ oc adm policy add-scc-to-group scc-helm-components system:authenticated
```

### 1. Add Helm repositories

```bash
$ helm repo add bitnami https://charts.bitnami.com/bitnami
$ helm repo add nfs-server-provisioner https://kubernetes-sigs.github.io/nfs-ganesha-server-and-external-provisioner
$ helm repo add onlyoffice https://download.onlyoffice.com/charts/stable
$ helm repo update
```

### 2. Install NFS Provisioner

Note: When installing NFS Server Provisioner, Storage Classes - `NFS` is created. When installing to an OpenShift cluster, the user must have a role that allows you to create Storage Classes in the cluster. Read more [here](https://docs.openshift.com/container-platform/4.7/storage/dynamic-provisioning.html).

```bash
$ helm install nfs-server nfs-server-provisioner/nfs-server-provisioner \
  --set persistence.enabled=true \
  --set "storageClass.mountOptions={noac,vers=4.1,retrans=2,timeo=30}" \
  --set persistence.storageClass=PERSISTENT_STORAGE_CLASS \
  --set persistence.size=PERSISTENT_SIZE
```

- `PERSISTENT_STORAGE_CLASS` is a Persistent Storage Class available in your Kubernetes cluster.

- `PERSISTENT_SIZE` is the total size of all Persistent Storages for the nfs Persistent Storage Class. Must be at least the sum of the values of the `persistence` and `opensearch.persistence.size` parameters if `persistence.storageClass=nfs` and `opensearch.persistence.storageClass=nfs`. You can express the size as a plain integer with one of these suffixes: `T`, `G`, `M`, `Ti`, `Gi`, `Mi`. For example: `19Gi`.

See more details about installing NFS Server Provisioner via Helm [here](https://github.com/kubernetes-sigs/nfs-ganesha-server-and-external-provisioner/tree/master/charts/nfs-server-provisioner).

*The PersistentVolume type to be used for PVC placement must support Access Mode [ReadWriteMany](https://kubernetes.io/docs/concepts/storage/persistent-volumes/#access-modes).*

*Also, PersistentVolume must have as the owner the user from whom the ONLYOFFICE DocSpace will be started. By default it is `onlyoffice` (104:107).*

### 3. Install MySQL

To install MySQL to your cluster, run the following command:

```bash
$ helm install mysql -f https://raw.githubusercontent.com/ONLYOFFICE/Kubernetes-DocSpace/main/sources/mysql_values.yaml --version 14.0.3 bitnami/mysql \
  --set auth.database=docspace \
  --set auth.username=onlyoffice_user \
  --set primary.persistence.storageClass=PERSISTENT_STORAGE_CLASS \
  --set primary.persistence.size=PERSISTENT_SIZE \
  --set primary.resourcesPreset=none \
  --set image.repository=bitnamilegacy/mysql \
  --set global.security.allowInsecureImages=true \
  --set image.tag=9.4.0-debian-12-r1 \
  --set metrics.enabled=false \
  --set primary.livenessProbe.timeoutSeconds=10 \
  --set primary.readinessProbe.timeoutSeconds=10 \
  --set primary.livenessProbe.periodSeconds=20 \
  --set primary.readinessProbe.periodSeconds=20
```

Here `PERSISTENT_SIZE` is a size for the Database persistent volume. For example: `8Gi`.

Note: Set the `metrics.enabled=true` to enable exposing Database metrics to be gathered by Prometheus. Also add the following parameters: `metrics.image.repository=bitnamilegacy/mysqld-exporter` and `metrics.image.tag=0.17.2-debian-12-r16`.

See more details about installing MySQL via Helm [here](https://github.com/bitnami/charts/tree/main/bitnami/mysql).

### 4. Install RabbitMQ

To install RabbitMQ to your cluster, run the following command:

```bash
$ helm install rabbitmq --version 16.0.14 bitnami/rabbitmq \
  --set persistence.storageClass=PERSISTENT_STORAGE_CLASS \
  --set resourcesPreset=none \
  --set image.repository=bitnamilegacy/rabbitmq \
  --set image.tag=4.1.3-debian-12-r1 \
  --set global.security.allowInsecureImages=true \
  --set metrics.enabled=false
```

Note: Set the `metrics.enabled=true` to enable exposing RabbitMQ metrics to be gathered by Prometheus.

See more details about installing RabbitMQ via Helm [here](https://github.com/bitnami/charts/tree/main/bitnami/rabbitmq#rabbitmq).

### 5. Install Redis

To install Redis to your cluster, run the following command:

```bash
$ helm install redis --version 22.0.7 bitnami/redis \
  --set architecture=standalone \
  --set master.persistence.storageClass=PERSISTENT_STORAGE_CLASS \
  --set master.resourcesPreset=none \
  --set global.security.allowInsecureImages=true \
  --set image.repository=bitnamilegacy/redis \
  --set image.tag=8.2.1-debian-12-r0 \
  --set metrics.enabled=false
```

Note: Set the `metrics.enabled=true` to enable exposing Redis metrics to be gathered by Prometheus. Also add the following parameters: `metrics.image.repository=bitnamilegacy/redis-exporter` and `metrics.image.tag=1.76.0-debian-12-r0`.

See more details about installing Redis via Helm [here](https://github.com/bitnami/charts/tree/main/bitnami/redis).

### 6. Install OpenSearch

To install OpenSearch to your cluster, set the `opensearch.enabled=true` parameter when installing ONLYOFFICE DocSpace.

If you want to connect ONLYOFFICE DocSpace with an external OpenSearch instance, you need to specify the corresponding values in `connections.elkScheme`, `connections.elkHost`, `connections.elkPort`, `connections.elkThreads` parameters and define `opensearch.enabled` parameter as `false`.

### 7. Install ONLYOFFICE Docs

NOTE: By default, an installation made specifically for Kubernetes is used. This is added as a [Helm Subchart](https://helm.sh/docs/chart_template_guide/subcharts_and_globals/). See more details about installing ONLYOFFICE Docs in Kubernetes via Helm [here](https://github.com/ONLYOFFICE/Kubernetes-Docs). Depending on the type of your DocSpace license, set the value in the `global.installationType` parameter. Possible values are `DEVELOPER` - Developer Edition or `ENTERPRISE` - Enterprise Edition. By default - `ENTERPRISE`. According to the specified value, Docs with the same solution type will be installed.

if you plan to use the already installed Onlyoffice Docs and it is deployed in the same cluster as ONLYOFFICE DocSpace is planned to be deployed, then specify the name of the service in the `connections.documentServerHost` parameter and set `false` in the `docs.enabled` parameter.
Also, specify the Namespace if the Docs is deployed in a different Namespace than ONLYOFFICE DocSpace is planned, for example, `documentserver.ds:8888`.
Also, in the `connections.appUrlPortal` parameter, specify the router service name of the ONLYOFFICE DocSpace and the Namespace in which ONLYOFFICE DocSpace will be deployed, for example, `http://router.default:8092`.

If Kubernetes-Docs is deployed externally, relative to the cluster in which ONLYOFFICE DocSpace is planned to be deployed, then you need to specify the [external Docs address](https://github.com/ONLYOFFICE/Kubernetes-Docs?tab=readme-ov-file#53-expose-onlyoffice-docs) in the `connections.documentServerUrlExternal` parameter in the `http(s)://<documentserver-address>/` format and set `docs.enabled` to `false` and in the `connections.appUrlPortal` parameter, specify the [external address of the ONLYOFFICE DocSpace](https://github.com/ONLYOFFICE/Kubernetes-DocSpace/tree/main?tab=readme-ov-file#1-expose-onlyoffice-docspace), for example, `https://docspace.example.com`.

Also, when using Kubernetes-Docs, installed not as a subchart, specify the DocSpace JWT parameters the same as in Docs in `jwt.secret`, `jwt.header`, etc.

### 8. Make changes to the configuration files (optional)

#### 8.1 Create a Secret containing a json file

To create a Secret containing configuration files for overriding default values and additional configuration files for ONLYOFFICE DocSpace, you need to run the following command:

```bash
$ kubectl create secret generic docspace-custom-config \
  --from-file=./appsettings.test.json \
  --from-file=./notify.test.json
```

Note: Any name can be used instead of `docspace-custom-config`.

Note: The example above shows two configuration files. You can use as many as you want, as well as only one file.

Note: When using the `test` suffix in the file name, set the `connections.envExtension` parameter to `test`.

#### 8.2 Specify parameters when installing ONLYOFFICE DocSpace

When installing ONLYOFFICE DocSpace, specify the `extraConf.secretName=docspace-custom-config` and `extraConf.filename={appsettings.test.json,notify.test.json}` parameters.

Note: If you need to add a configuration file after the ONLYOFFICE DocSpace is already installed, you need to execute step [8.1](#81-create-a-secret-containing-a-json-file)
and then run the `helm upgrade [RELEASE_NAME] onlyoffice/docspace --set extraConf.secretName=docspace-custom-config --set "extraConf.filename={appsettings.test.json,notify.test.json}" --no-hooks` command or
`helm upgrade [RELEASE_NAME] -f ./values.yaml onlyoffice/docspace --no-hooks` if the parameters are specified in the `values.yaml` file.

## Deploy ONLYOFFICE DocSpace

Note: It may be required to apply `SecurityContextConstraints` policy when installing into OpenShift cluster, which adds permission to run containers from a user whose `ID = 104`.

To do this, run the following commands:

```
$ oc apply -f https://raw.githubusercontent.com/ONLYOFFICE/Kubernetes-DocSpace/main/sources/scc/docspace-components.yaml
$ oc adm policy add-scc-to-group scc-docspace-components system:authenticated
```

Also, you must set the `podSecurityContext.enabled` parameter to `true`:

```
$ helm install [RELEASE_NAME] onlyoffice/docspace --set podSecurityContext.enabled=true
```

### 1. Add a license

If you have a valid ONLYOFFICE DocSpace license, set the `global.installationType` parameter to `ENTERPRISE` and install ONLYOFFICE Docspace

```bash
$ helm install [RELEASE_NAME] -f values.yaml onlyoffice/docspace --set global.installationType=ENTERPRISE
```

At the wizard page during the first login please add your license using the corresponding field.

### 2. Install ONLYOFFICE DocSpace

Note: In the `connections.appKnownNetworks` parameter, specify the address ranges of the Kubernetes cluster networks, as well as the networks in which the proxies that you are using in front of DocSpace services, from which the forwarded headers for ONLYOFFICE DocSpace services will be received. Default value - `10.0.0.0/8,172.16.0.0/12,192.168.0.0/16`

To install ONLYOFFICE DocSpace to your cluster, run the following command:

```bash
$ helm install [RELEASE_NAME] -f values.yaml onlyoffice/docspace
```

The command deploys ONLYOFFICE DocSpace on the Kubernetes cluster in the default configuration. The [Parameters] section lists the parameters that can be configured during installation.

_See [helm install](https://helm.sh/docs/helm/helm_install/) for command documentation._

### 3. Uninstall ONLYOFFICE DocSpace

To uninstall/delete the `docspace` deployment:

```bash
$ helm uninstall [RELEASE_NAME]
```

The `helm uninstall` command removes all the Kubernetes components associated with the chart and deletes the release.

_See [helm uninstall](https://helm.sh/docs/helm/helm_uninstall/) for command documentation._

### 4. Upgrade ONLYOFFICE DocSpace

Note: If you have Elasticsearch installed, please read [this section](#2-transition-from-elasticsearch-to-opensearch).

Note: When upgrading to version `3.0.0` from an earlier version, set the parameters `docs.upgrade.job.enabled` and `docs.clearCache.job.enabled` to `false`. When installing version `3.0.0` or upgrading from version `3.0.0` to a later version, these parameters should be set to `true`. Additionally, when upgrading to version `3.0.0` from an earlier version, set the parameter `upgrade.job.docsInitDB.enabled` to `true`. However, when installing version `3.0.0` or upgrading from version "3.0.0" to a later version, this parameter should be set to `false`.

It's necessary to set the parameters for updating. For example,

```bash
$ helm upgrade [RELEASE_NAME] onlyoffice/docspace \
  --set images.tag=[tag]
```

  > **Note**: also need to specify the parameters that were specified during installation

Or modify the `values.yaml` file and run the command:

  ```bash
  $ helm upgrade [RELEASE_NAME] -f values.yaml onlyoffice/docspace
  ```

Running the `helm upgrade` command runs a hook that cleans up the directory with libraries and then fills with new ones. This is needed when updating the version of ONLYOFFICE DocSpace. The default hook execution time is 300s.
The execution time can be changed using `--timeout [time]`, for example:

```bash
$ helm upgrade [RELEASE_NAME] -f values.yaml onlyoffice/docspace --timeout 15m
```

If you want to update any parameter other than the version of the ONLYOFFICE DocSpace, then run the `helm upgrade` command without `hooks`, for example:

```bash
$ helm upgrade [RELEASE_NAME] onlyoffice/docspace --set jwt.enabled=false --no-hooks
```

_See [helm upgrade](https://helm.sh/docs/helm/helm_upgrade/) for command documentation._

To rollback updates, run the following command:

```bash
$ helm rollback [RELEASE_NAME]
```

_See [helm rollback](https://helm.sh/docs/helm/helm_rollback/) for command documentation._

## Parameters

### Common parameters

| Parameter                                              | Description                                                                                                                 | Default                       |
|--------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------|-------------------------------|
| `global.installationType`                              | Defines solution type for DocSpace and Docs. Possible values are `DEVELOPER` or `ENTERPRISE`                                | `ENTERPRISE`                  |
| `connections.envExtension`                             | Defines whether an environment will be used                                                                                 | `""`                          |
| `connections.installationType`                         | Deprecated. Use `global.installationType` instead. The parameter is evaluated as a template and is equal to `global.installationType` | {{ .Values.global.installationType }} |
| `connections.migrationType`                            | Defines migration type                                                                                                      | `STANDALONE`                  |
| `connections.mysqlDatabaseMigration`                   | Enables database migration                                                                                                  | `false`                       |
| `connections.mysqlHost`                                | The IP address or the name of the Database host                                                                             | `mysql`                       |
| `connections.mysqlPort`                                | Database server port number                                                                                                 | `3306`                        |
| `connections.mysqlDatabase`                            | Name of the Database the application will be connected with. The database must already exist                                | `docspace`                    |
| `connections.mysqlUser`                                | Database user                                                                                                               | `onlyoffice_user`             |
| `connections.mysqlPassword`                            | Database user password. If set to, it takes priority over the `connections.mysqlExistingSecret`                             | `""`                          |
| `connections.mysqlExistingSecret`                      | Name of existing secret to use for Database passwords. Must contain the key specified in `connections.mysqlSecretKeyPassword` | `mysql`                     |
| `connections.mysqlSecretKeyPassword`                   | The name of the key that contains the Database user password. If you set a password in `connections.mysqlPassword`, a secret will be automatically created, the key name of which will be the value set here | `mysql-password` |
| `connections.redisHost`                                | The IP address or the name of the Redis host. If Redis is deployed inside a k8s cluster, then you need to specify the [FQDN](https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#services) name of the service | `redis-master.default.svc.cluster.local` |
| `connections.redisPort`                                | The Redis server port number                                                                                                | `6379`                        |
| `connections.redisUser`                                | The Redis [user](https://redis.io/docs/management/security/acl/) name                                                       | `default`                     |
| `connections.redisDB`                                  | Number of the redis logical database to be [selected](https://redis.io/commands/select/)                                                                     | `0`                           |
| `connections.redisExistingSecret`                      | Name of existing secret to use for Redis password. Must contain the key specified in `connections.redisSecretKeyName`       | `redis`                       |
| `connections.redisSecretKeyName`                       | The name of the key that contains the Redis user password. If you set a password in `connections.redisPassword`, a secret will be automatically created, the key name of which will be the value set here | `redis-password` |
| `connections.redisPassword`                            | The password set for the Redis account. If set to, it takes priority over the `connections.redisExistingSecret`             | `""`                          |
| `connections.redisNoPass`                              | Defines whether to use a Redis auth without a password. If the connection to Redis server does not require a password, set the value to `true` | `false`    |
| `connections.brokerHost`                               | The IP address or the name of the Broker host                                                                               | `rabbitmq`                    |
| `connections.brokerPort`                               | The port for the connection to Broker host                                                                                  | `5672`                        |
| `connections.brokerVhost`                              | The virtual host for the connection to Broker host                                                                          | `/`                           |
| `connections.brokerUser`                               | The username for the Broker account                                                                                         | `guest`                       |
| `connections.brokerProto`                              | The protocol for the connection to Broker host                                                                              | `amqp`                        |
| `connections.brokerUri`                                | A string containing the necessary connection parameters to Broker. If set to, it takes priority                             | `""`                          |
| `connections.brokerExistingSecret`                     | The name of existing secret to use for Broker password. Must contain the key specified in `connections.brokerSecretKeyName` | `rabbitmq`                    |
| `connections.brokerSecretKeyName`                      | The name of the key that contains the Broker user password. If you set a password in `connections.brokerPassword`, a secret will be automatically created, the key name of which will be the value set here | `rabbitmq-password` |
| `connections.brokerPassword`                           | Broker user password. If set to, it takes priority over the `connections.brokerExistingSecret`                              | `""`                          |
| `connections.elkScheme`                                | The protocol for the connection to Opensearch                                                                               | `http`                        |
| `connections.elkHost`                                  | The IP address or the name of the Opensearch host                                                                           | `opensearch`                  |
| `connections.elkPort`                                  | The port for the connection to Opensearch                                                                                   | `9200`                        |
| `connections.elkThreads`                               | Number of threads in Opensearch                                                                                             | `1`                           |
| `connections.apiHost`                                  | The name of the ONLYOFFICE DocSpace Api service                                                                             | `api`                         |
| `connections.apiSystemHost`                            | The name of the ONLYOFFICE DocSpace Api System service                                                                      | `api-system`                  |
| `connections.notifyHost`                               | The name of the ONLYOFFICE DocSpace Notify service                                                                          | `notify`                      |
| `connections.studioNotifyHost`                         | The name of the ONLYOFFICE DocSpace Studio Notify service                                                                   | `studio-notify`               |
| `connections.socketHost`                               | The name of the ONLYOFFICE DocSpace Socket service                                                                          | `socket`                      |
| `connections.peopleServerHost`                         | The name of the ONLYOFFICE DocSpace People Server service                                                                   | `people-server`               |
| `connections.filesHost`                                | The name of the ONLYOFFICE DocSpace Files service                                                                           | `files`                       |
| `connections.filesWorkerHost`                        | The name of the ONLYOFFICE DocSpace Files Worker service                                                                  | `files-worker`              |
| `connections.studioHost`                               | The name of the ONLYOFFICE DocSpace Studio service                                                                          | `studio`                      |
| `connections.backupHost`                               | The name of the ONLYOFFICE DocSpace Backup service                                                                          | `backup`                      |
| `connections.ssoauthHost`                              | The name of the ONLYOFFICE DocSpace SSO service                                                                             | `ssoauth`                     |
| `connections.clearEventsHost`                          | The name of the ONLYOFFICE DocSpace Clear Events service                                                                    | `clear-events`                |
| `connections.doceditorHost`                            | The name of the ONLYOFFICE DocSpace Doceditor service                                                                       | `doceditor`                   |
| `connections.backupWorkerHost`                | The name of the ONLYOFFICE DocSpace Backup Worker service                                                         | `backup-worker`     |
| `connections.loginHost`                                | The name of the ONLYOFFICE DocSpace Login service                                                                           | `login`                       |
| `connections.healthchecksHost`                         | The name of the ONLYOFFICE DocSpace Healthchecks service                                                                    | `healthchecks`                |
| `connections.identityApiHost`                          | The name of the ONLYOFFICE DocSpace Identity API service                                                                    | `identity-api`                |
| `connections.identityAuthorizationHost`                | The name of the ONLYOFFICE DocSpace Identity service                                                                        | `identity-authorization`                |
| `connections.sdkHost`                                  | The name of the DocSpace SDK service                                                                                        | `sdk`                         |
| `connections.telegramHost`                               | The name of the ONLYOFFICE DocSpace Telegram service                                                                          | `telegram`                      |
| `connections.aiHost`                                   | The name of the ONLYOFFICE DocSpace AI service                                                                             | `ai`                           |
| `connections.aiWorkerHost`                            | The name of the ONLYOFFICE DocSpace AI Worker service                                                                     | `ai-worker`                          |
| `connections.aiMCPHost`                                | The name of the ONLYOFFICE DocSpace AI MCP service                                                                     | `ai-mcp`                      |
| `connections.documentServerHost`                       | The name of the Document Server service. Used when installing a local Document Server (by default `docs.enabled=true`)      | `document-server`             |
| `connections.documentServerUrlExternal`                | The address of the external Document Server. If set, the local Document Server will not be installed                        | `""`                          |
| `connections.appUrlPortal`                             | URL for ONLYOFFICE DocSpace requests. By default, the name of the routing (Router) service and the port on which it accepts requests are used | `http://router:8092`   |
| `connections.appCoreBaseDomain`                        | The base domain on which the ONLYOFFICE DocSpace will be available                                                          | `localhost`                   |
| `connections.appCoreMachinekey.secretKey`              | The secret key used in the ONLYOFFICE DocSpace                                                                              | `your_core_machinekey`        |
| `connections.appCoreMachinekey.existingSecret`         | The name of an existing secret containing Core Machine Key. Must contain the `APP_CORE_MACHINEKEY` key. If not specified, a secret will be created with the value set in `connections.appCoreMachinekey.secretKey` | `""` |
| `connections.countWorkerConnections`                   | Defines the nginx config [worker_connections](https://nginx.org/en/docs/ngx_core_module.html#worker_connections) directive for routing (Router) service | `1024` |
| `connections.nginxSnvsubstTemplateSuffix`              | A suffix of template files for rendering nginx configs in routing (Router) service                                          | `.template`                   |
| `connections.oauthOrigin`                              | The address of the OAUTH2 server                                                                                            | `""`                          |
| `connections.appKnownNetworks`                         | Defines the address ranges of known networks to accept forwarded headers from for ONLYOFFICE DocSpace services. In particular, the networks in which the proxies that you are using in front of DocSpace services are located should be indicated here. Provide IP ranges using CIDR notation | `10.0.0.0/8,172.16.0.0/12,192.168.0.0/16` |
| `connections.hostAliases`                              | Adds [additional entries](https://kubernetes.io/docs/tasks/network/customize-hosts-file-for-pods/) to the hosts file in containers                          | `[]` |
| `connections.oauthRedirectURL`                         | Address of the oauth authorization server                                                                                   | `https://service.onlyoffice.com/oauth2.aspx` |
| `namespaceOverride`                                    | The name of the namespace in which ONLYOFFICE DocSpace will be deployed. If not set, the name will be taken from `.Release.Namespace`  | `""`                          |
| `commonLabels`                                         | Defines labels that will be additionally added to all the deployed resources. You can also use `tpl` as the value for the key | `{}`                        |
| `commonAnnotations`                                    | Defines annotations that will be additionally added to all the deployed resources. You can also use `tpl` as the value for the key. Some resources may override the values specified here with their own | `{}` |
| `podAnnotations`                                       | Map of annotations to add to the ONLYOFFICE DocSpace pods. Each Docspace application can override the values specified here with its own | `rollme: "{{ randAlphaNum 5 \| quote }}"` |
| `serviceAccount.create`                                | Enable ServiceAccount creation                                                                                              | `false`                       |
| `serviceAccount.name`                                  | Name of the ServiceAccount to be used. If not set and `serviceAccount.create` is `true` the name will be taken from `.Release.Name` or `serviceAccount.create` is `false` the name will be "default" | `""` |
| `serviceAccount.annotations`                           | Map of annotations to add to the ServiceAccount                                                                             | `{}`                          |
| `serviceAccount.automountServiceAccountToken`          | Enable auto mount of ServiceAccountToken on the serviceAccount created. Used only if `serviceAccount.create` is `true`      | `true`                        |
| `podSecurityContext.enabled`                           | Enable security context for the pods. If set to true, `podSecurityContext` is enabled for all resources describing the podTemplate. Individual values for `docs` and `elasticsearch` | `false`                |
| `podSecurityContext.fsGroup`                           | Defines the Group ID to which the owner and permissions for all files in volumes are changed when mounted in the ONLYOFFICE DocSpace application Pods | `107`          |
| `containerSecurityContext.enabled`                     | Enable security context for containers in ONLYOFFICE DocSpace application pods. Individual values for `docs` and `opensearch` | `false`                       |
| `nodeSelector`                                         | Node labels for ONLYOFFICE DocSpace application pods assignment. Each ONLYOFFICE Docspace application can override the values specified here with its own | `{}`                  |
| `tolerations`                                          | Tolerations for ONLYOFFICE DocSpace application pods assignment. Each ONLYOFFICE Docspace application can override the values specified here with its own | `[]`                  |
| `imagePullSecrets`                                     | Container image registry secret name                                                                                        | `""`                          |
| `images.registry`                                      | Global image registry for all DocSpace applications.                                                                        | `""`                          |
| `images.tag`                                           | Global image tag for all DocSpace applications. Does not apply to the Document Server, Elasticsearch and Proxy Frontend     | `3.7.2`                       |
| `replicas`                                             | Global replica value for all DocSpace applications. Does not apply to the Document Server and Elasticsearch                 | `2`                           |
| `jwt.enabled`                                          | Specifies the enabling the JSON Web Token validation by the DocSpace                                                        | `true`                        |
| `jwt.secret`                                           | Defines the secret key to validate the JSON Web Token in the request to the DocSpace                                        | `jwt_secret`                  |
| `jwt.header`                                           | Defines the http header that will be used to send the JSON Web Token                                                        | `AuthorizationJwt`            |
| `jwt.inBody`                                           | Specifies the enabling the token validation in the request body to the ONLYOFFICE DocSpace                                  | `false`                       |
| `jwt.existingSecret`                                   | The name of an existing secret containing variables for jwt. If not specified, a secret named `jwt` will be created         | `""`                          |
| `extraConf.secretName`                                 | The name of the Secret containing the json files that override the default values and additional configuration files        | `""`                          |
| `extraConf.filename`                                   | The name of the json files that contains custom values and name additional configuration files. Must be the same as the `key` name in `extraConf.secretName`. May contain multiple values | `appsettings.test.json` |
| `log.level`                                            | Defines the type and severity of a logged event                                                                             | `Warning`                     |
| `debug.enabled`                                        | Enable debug                                                                                                                | `false`                       |
| `initContainers.checkDB.image.registry`                | check-db initContainer image registry. Takes priority over `images.registry`                                                | `""`                          |
| `initContainers.checkDB.image.repository`              | check-db initContainer image repository                                                                                     | `onlyoffice/docs-utils`       |
| `initContainers.checkDB.image.tag`                     | check-db initContainer image tag. If set to, it takes priority over the `images.tag`                                        | `9.4.1-1`                     |
| `initContainers.checkDB.image.pullPolicy`              | check-db initContainer image pull policy                                                                                    | `IfNotPresent`                |
| `initContainers.checkDB.resources.requests.memory`     | The requested Memory for the check-db initContainer                                                                         | `256Mi`                       |
| `initContainers.checkDB.resources.requests.cpu`        | The requested CPU for the check-db initContainer                                                                            | `100m`                        |
| `initContainers.checkDB.resources.limits.memory`       | The Memory limits for the check-db initContainer                                                                            | `1Gi`                         |
| `initContainers.checkDB.resources.limits.cpu`          | The CPU limits for the check-db initContainer                                                                               | `1000m`                       |
| `initContainers.custom`                                | Defines custom containers that run before ONLYOFFICE DocSpace containers in a Pods. For example, a container that changes the owner of the PersistentVolume. For the `Docs`, `Router`, `Opensearch` and `Proxy Frontend` services, the corresponding individual parameters are used | `[]` |
| `persistence.storageClass`                             | PVC Storage Class for ONLYOFFICE DocSpace data volume                                                                                  | `nfs`                         |
| `persistence.docspaceData.existingClaim`               | The name of the existing PVC for storing files common to all services. If not specified, a PVC named "docspace-data" will be created | `""`                 |
| `persistence.docspaceData.annotations`                 | Defines annotations that will be additionally added to common files PVC. If set to, it takes priority over the `commonAnnotations` | `{}`                   |
| `persistence.docspaceData.size`                        | PVC Storage Request for common files volume                                                                                 | `8Gi`                         |
| `persistence.routerLog.existingClaim`                  | The name of the existing PVC for storing Nginx logs of the Router service. If not specified, a PVC named "router-log" will be created | `""`                |
| `persistence.routerLog.annotations`                    | Defines annotations that will be additionally added to Nginx logs PVC. If set to, it takes priority over the `commonAnnotations` | `{}`                     |
| `persistence.routerLog.size`                           | PVC Storage Request for Nginx logs volume                                                                                   | `5Gi`                         |
| `podAntiAffinity.type`                                 | Types of Pod antiaffinity. Allowed values: `preferred` or `required`                                                        | `preferred`                   |
| `podAntiAffinity.topologyKey`                          | Node label key to match                                                                                                     | `kubernetes.io/hostname`      |
| `podAntiAffinity.weight`                               | Priority when selecting node. It is in the range from 1 to 100. Used only when `podAntiAffinity.type=preferred`             |`100`                          |

### ONLYOFFICE DocSpace Application* parameters

| Parameter                                                 | Description                                                                                                     | Default                                   |
|-----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|-------------------------------------------|
| `Application.enabled`                                     | Enables Application installation. Individual values for `identity.authorization` and `identity.api`                                                                                | `true`                                    |
| `Application.kind`                                        | The controller used for deploy. Possible values are `Deployment` (default) or `StatefulSet`. Not used in `docs`, `opensearch` and `ai-mcp` | `Deployment`             |
| `Application.annotations`                                 | Defines annotations that will be additionally added to Application deploy. If set to, it takes priority over the `commonAnnotations` | `{}`                 |
| `Application.replicaCount`                                | Number of "Application" replicas to deploy. Not used in `docs`,`opensearch` and `aiMCP`. If the `Application.autoscaling.enabled` parameter is enabled, it is ignored                                 | `2`                                       |
| `Application.updateStrategy.type`                         | "Application" update strategy type                                                                              | `RollingUpdate`                           |
| `Application.updateStrategy.rollingUpdate.maxUnavailable` | Maximum number of "Application" Pods unavailable during the update process                                      | `25%`                                     |
| `Application.updateStrategy.rollingUpdate.maxSurge`       | Maximum number of "Application" Pods created over the desired number of Pods                                    | `25%`                                     |
| `Application.podManagementPolicy`                         | The Application Pods scaling operations policy. Used if `Application.kind` is set to `StatefulSet`. Not used in `docs`, `opensearch` and `ai-mcp` | `OrderedReady`    |
| `Application.podAnnotations`                              | Map of annotations to add to the "Application" pods. If set to, it takes priority over the `podAnnotations`     | `{}`                                      |
| `Application.podSecurityContext.enabled`                  | Enable security context for the "Application" pods. If set to, it takes priority over the `podSecurityContext`  | `false`                                   |
| `Application.customPodAntiAffinity`                       | Prohibiting the scheduling of Api System Pods relative to other Pods containing the specified labels on the same node | `{}`                                |
| `Application.podAffinity`                                 | Defines [Pod affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#inter-pod-affinity-and-anti-affinity) rules for "Application" Pods scheduling by nodes relative to other Pods | `{}` |
| `Application.nodeAffinity`                                | Defines [Node affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity) rules for "Application" Pods scheduling by nodes | `{}` |
| `Application.nodeSelector`                                | Node labels for Api System pods assignment. If set to, it takes priority over the `nodeSelector`                | `{}`                                      |
| `Application.tolerations`                                 | Tolerations for Api System pods assignment. If set to, it takes priority over the `tolerations`                 | `[]`                                      |
| `Application.autoscaling.enabled`                         | Enable "Application" deployment autoscaling                                                                                                                                       | `false`                                                                                   |
| `Application.autoscaling.annotations`                     | Defines annotations that will be additionally added to "Application" deployment HPA. If set to, it takes priority over the `commonAnnotations`                                    | `{}`                                                                                      |
| `Application.autoscaling.minReplicas`                     | "Application" deployment autoscaling minimum number of replicas                                                                                                                   | `2`                                                                                       |
| `Application.autoscaling.maxReplicas`                     | "Application" deployment autoscaling maximum number of replicas                                                                                                                   | `4`                                                                                       |
| `Application.autoscaling.targetCPU.enabled`               | Enable autoscaling of "Application" deployment by CPU usage percentage                                                                                                            | `true`                                                                                    |
| `Application.autoscaling.targetCPU.utilizationPercentage` | "Application" deployment autoscaling target CPU percentage                                                                                                                        | `70`                                                                                      |
| `Application.autoscaling.targetMemory.enabled`            | Enable autoscaling of "Application" deployment by memory usage percentage                                                                                                         | `false`                                                                                   |
| `Application.autoscaling.targetMemory.utilizationPercentage` | "Application" deployment autoscaling target memory percentage                                                                                                                     | `70`                                                                                      |
| `Application.autoscaling.customMetricsType`               | Custom, additional or external autoscaling metrics for the "Application" deployment                                                                                               | `[]`                                                                                      |
| `Application.autoscaling.behavior`                        | Configuring "Application" deployment scaling behavior policies for the `scaleDown` and `scaleUp` fields                                                                           | `{}`                                                                                      |
| `Application.image.registry`                              | "Application" container image registry. Takes priority over `images.registry`                                   | `""`                                      |
| `Application.image.repository`                            | "Application" container image repository. Individual values for `proxyFrontend`, `docs` and `opensearch`        | `onlyoffice/docspace-Application`         |
| `Application.image.tag`                                   | "Application" container image tag. If set to, it takes priority over the `images.tag`. Individual values for `proxyFrontend`, `docs` and `opensearch` | `""` |
| `Application.image.pullPolicy`                            | "Application" container image pull policy                                                                       | `IfNotPresent`                            |
| `Application.containerSecurityContext.enabled`            | Enable security context for containers in "Application" pods. If set to, it takes priority over the `containerSecurityContext` | `false`                    |
| `Application.lifecycleHooks`                              | Defines the Backup [container lifecycle hooks](https://kubernetes.io/docs/concepts/containers/container-lifecycle-hooks). It is used to trigger events to run at certain points in a container's lifecycle | `{}` |
| `Application.containerPorts.app`                          | "Application" container port. Not used in `router`, `proxyFrontend`, `identity.authorization`, `identity.api` and `aiMCP`                                            | `5050`                                    |
| `Application.startupProbe.enabled`                        | Enable startupProbe for "Application" container                                                                 | `true`                                    |
| `Application.readinessProbe.enabled`                      | Enable readinessProbe for "Application" container                                                               | `true`                                    |
| `Application.livenessProbe.enabled`                       | Enable livenessProbe for "Application" container                                                                | `true`                                    |
| `Application.resources.requests`                          | The requested resources for the "Application" container                                                         | `memory, cpu`                             |
| `Application.resources.limits`                            | The resources limits for the "Application" container                                                            | `memory, cpu`                             |
| `Application.extraEnvVars`                                | An array with extra env variables for the "Application" container                                               | `[]`                                      |
| `Application.extraVolumes`                                | An array with extra volumes for the "Application" Pod                                                           | `[]`                                      |
| `Application.extraVolumeMounts`                           | An array with extra volume mounts for the "Application" container                                               | `[]`                                      |

* Application* Note: Since all available Applications have some identical parameters, a description for each of them has not been added to the table, but combined into one.
Instead of `Application`, the parameter name should have the following values: `files`, `peopleServer`, `router`, `healthchecks`, `apiSystem`, `api`, `backup`, `backupWorker`, 
`clearEvents`, `doceditor`, `filesWorker`, `login`, `notify`, `socket`, `ssoauth`, `studio`, `studioNotify`, `proxyFrontend`, `docs`,  `opensearch`, `identity.authorization`, `identity.api`, `sdk`, `telegram`, `ai`, `aiWorker` and `aiMCP`.

### ONLYOFFICE DocSpace Router Application additional parameters

| Parameter                                                | Description                                                                                                     | Default              |
|----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|----------------------|
| `router.initContainers`                                  | Defines containers that run before Router container in the Router pod                                           | `[]`                 |
| `router.containerPorts.external`                         | Router container port                                                                                           | `8092`               |
| `router.extraEnvVars`                                    | An array with extra env variables for the Router container                                                      | `[]`                 |
| `router.extraConf.customInitScripts.configMap`           | The name of the ConfigMap containing custom initialization scripts                                              | `""`                 |
| `router.extraConf.customInitScripts.fileName`            | The names of scripts containing custom initialization scripts. Must be the same as the `key` names in `router.extraConf.customInitScripts.configMap`. May contain multiple values | `60-custom-init-scripts.sh` |
| `router.extraConf.templates.configMap`                   | The name of the ConfigMap containing configuration file templates containing environment variables. The values of these variables will be substituted when the container is started | `""` |
| `router.extraConf.templates.fileName`                    | The names of the configuration file templates containing environment variables. Must be the same as the `key` names in `router.extraConf.templates.configMap`. May contain multiple values | `10.example.conf.template` |
| `router.extraConf.confd.configMap`                       | The name of the ConfigMap containing additional custom configuration files. These files will be map in the `/etc/nginx/conf.d/` directory of the container | `""` |
| `router.extraConf.confd.fileName`                        | The names of the configuration files containing custom configuration files. Must be the same as the `key` names in `router.extraConf.confd.configMap`. May contain multiple values | `example.conf` |
| `router.service.existing`                                | The name of an existing service for Router. If not set, a service named `router` will be created                | `""`                 |
| `router.service.annotations`                             | Map of annotations to add to the Router service                                                                 | `{}`                 |
| `router.service.port.external`                           | Router service port                                                                                             | `8092`               |
| `router.service.type`                                    | Router service type                                                                                             | `ClusterIP`          |
| `router.service.sessionAffinity`                         | [Session Affinity](https://kubernetes.io/docs/reference/networking/virtual-ips/#session-affinity) for Router service. If not set, `None` will be set as the default value | `""` |
| `router.service.sessionAffinityConfig`                   | [Configuration](https://kubernetes.io/docs/reference/networking/virtual-ips/#session-stickiness-timeout) for Router service Session Affinity. Used if the `router.service.sessionAffinity` is set | `{}` |
| `router.service.externalTrafficPolicy`                   | Enable preservation of the client source IP. There are two [available options](https://kubernetes.io/docs/tasks/access-application-cluster/create-external-load-balancer/#preserving-the-client-source-ip): `Cluster` (default) and `Local`. Not [supported](https://kubernetes.io/docs/tutorials/services/source-ip/) for service type - `ClusterIP` | `""` |
| `router.resolver.dns`                                    | [Configures](https://github.com/openresty/openresty/#resolvconf-parsing) name server used to resolve names of upstream servers into addresses. If set to, it takes priority over the `router.resolver.local` | `""` |
| `router.resolver.local`                                  | Allows you to use the DNS configuration of the container. If set to `on`, the standard path "/etc/resolv.conf" will be used. You can specify an arbitrary path | `on` |

### ONLYOFFICE DocSpace Socket Application additional parameters

| Parameter                                                | Description                                                                                                     | Default              |
|----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|----------------------|
| `socket.containerPorts.socket`                           | Socket additional container port                                                                                | `9899`               |

### ONLYOFFICE DocSpace Ssoauth Application additional parameters

| Parameter                                                | Description                                                                                                     | Default              |
|----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|----------------------|
| `ssoauth.containerPorts.sso`                             | Ssoauth additional container port                                                                               | `9834`               |

### ONLYOFFICE DocSpace Identity Authorization and Identity API Applications common parameters

| Parameter                                                | Description                                                                                                     | Default              |
|----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|----------------------|
| `identity.enabled`                             | Enables Identity appications: `identity.authorization`, `identity.api`                                                                                 | `false`               |
| `identity.serviceAccount.create`               | Enable Identity ServiceAccount creation. The `Role` and the `RoleBinding` required to build a cluster from identity replicas will be applied. If disabled, the common `serviceAccount` will be used | `false` |
| `identity.env.springProfilesActive`            | Defines the environment variable to override/pick Spring profile. Default is `dev`                                                                       | `dev`              |
| `identity.env.multicast.enabled`               | Defines whether multicast discovery will be used                                                                          | `false`              |
| `identity.env.kubernetes.enabled`              | Defines whether k8s service discovery will be used                                                                        | `true`               |
| `identity.env.region            `              | Defines the deployment region. Use "local" for local deployment or specify a region (e.g., "eu", "us") for regional queues| `local`               |
| `identity.env.grpcClientAddress.authorization` | Defines the gRPC client registration addresses. These addresses are used to connect to the corresponding services. `authorization` specifies the gRPC address for the Identity Authorization service  | `static://identity-authorization:9999`    |
| `identity.env.grpcClientAddress.registration`  | Specifies the gRPC address for the Identity API service                                                                   | `static://identity-api:8888`               |
| `identity.secret.existingSecret`               | Name of the existing secret file that must contain the variable SPRING_APPLICATION_ENCRYPTION_SECRET. If not specified, a new secret will be automatically generated. | `""`               |
| `identity.secret.springEncryptionValue`        | The secret key used for encrypting sensitive data such as client_secret, access_token, and refresh_token                  | `true`               |
| `identity.secret.generate`                     | If `true`, a new secret will be automatically generated. If you experience OAuth2 access issues, set this to `false`        | `true`               |

### ONLYOFFICE DocSpace Identity Authorization Application additional parameters

| Parameter                                                | Description                                                                                                     | Default              |
|----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|----------------------|
| `identity.authorization.containerPorts.authorization`                             | Identity additional container port                                                                               | `8080`               |

### ONLYOFFICE DocSpace Identity API Application additional parameters

| Parameter                                                | Description                                                                                                     | Default              |
|----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|----------------------|
| `identity.api.containerPorts.api`                             | Identity API additional container port                                                                               | `9090`               |

### ONLYOFFICE DocSpace AI MCP Server Application additional parameters

| Parameter                                                | Description                                                                                                     | Default              |
|----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|----------------------|
| `aiMCP.containerPorts.app`                               | AI MCP container port                                                                                           | `5158`                  |

### ONLYOFFICE DocSpace Proxy Frontend Application additional parameters

| Parameter                                                | Description                                                                                                     | Default              |
|----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|----------------------|
| `proxyFrontend.enabled`                                  | Enables Proxy Frontend installation                                                                             | `false`              |
| `proxyFrontend.initContainers`                           | Defines containers that run before Proxy Frontend container in the Proxy Frontend pod                           | `[]`                 |
| `proxyFrontend.image.registry`                           | Proxy Frontend container image registry. Takes priority over `images.registry`                                  | `""`                 |
| `proxyFrontend.image.repository`                         | Proxy Frontend container image repository                                                                       | `nginx`              |
| `proxyFrontend.image.tag`                                | Proxy Frontend container image tag                                                                              | `latest`             |
| `proxyFrontend.containerPorts.http`                      | Proxy Frontend HTTP container port                                                                              | `80`                 |
| `proxyFrontend.containerPorts.https`                     | Proxy Frontend HTTPS container port                                                                             | `443`                |
| `proxyFrontend.extraConf.customConfd.configMap`          | The name of the ConfigMap containing additional custom configuration files. These files will be map in the `/etc/nginx/conf.d/` directory of the container | `""` |
| `proxyFrontend.extraConf.customConfd.fileName`           | The names of the configuration files containing additional custom configuration files. Must be the same as the `key` names in `proxyFrontend.extraConf.customConfd.configMap`. May contain multiple values | `example.conf` |
| `proxyFrontend.hostname`                                 | The hostname (domainname) by which the ONLYOFFICE DocSpace will be available                                    | `""`                 |
| `proxyFrontend.tls.secretName`                           | The name of the TLS secret containing the certificate and its associated key                                    | `tls`                |
| `proxyFrontend.tls.mountPath`                            | The path where the certificate and key will be mounted                                                          | `/etc/nginx/ssl`     |
| `proxyFrontend.tls.crtName`                              | Name of the key containing the certificate                                                                      | `cert.crt`           |
| `proxyFrontend.tls.keyName`                              | Name of the key containing the key                                                                              | `cert.key`           |
| `proxyFrontend.service.existing`                         | The name of an existing service for Proxy Frontend. If not set, a service named `proxy-frontend` will be created | `""`                |
| `proxyFrontend.service.annotations`                      | Map of annotations to add to the Proxy Frontend service                                                         | `{}`                 |
| `proxyFrontend.service.type`                             | Proxy Frontend service type                                                                                     | `LoadBalancer`       |
| `proxyFrontend.service.sessionAffinity`                  | [Session Affinity](https://kubernetes.io/docs/reference/networking/virtual-ips/#session-affinity) for Proxy Frontend. service. If not set, `None` will be set as the default value | `""` |
| `proxyFrontend.service.sessionAffinityConfig`            | [Configuration](https://kubernetes.io/docs/reference/networking/virtual-ips/#session-stickiness-timeout) for Proxy Frontend service Session Affinity. Used if the `proxyFrontend.service.sessionAffinity` is set | `{}` |
| `proxyFrontend.service.externalTrafficPolicy`            | Enable preservation of the client source IP. There are two [available options](https://kubernetes.io/docs/tasks/access-application-cluster/create-external-load-balancer/#preserving-the-client-source-ip): `Cluster` (default) and `Local`. Not [supported](https://kubernetes.io/docs/tutorials/services/source-ip/) for service type - `ClusterIP` | `""` |

### ONLYOFFICE Docs parameters

| Parameter                                                | Description                                                                                                     | Default              |
|----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|----------------------|
| `docs.enabled`                                           | Enables Onlyoffice Docs subchart installation. Set to `false` if you plan to use the already installed Onlyoffice Docs or install DocSpace without it | `true`                |
| `docs.images.registry`                                   | Global image registry for Onlyoffice Docs containers.                                                           | `""`                     |
| `docs.images.tag`                                        | Global image tag for Onlyoffice Docs containers.                                                                | `""`                     |
| `docs.connections.dbType`                                | The Database type. By default, the same Database connection is used as for DocSpace                             | `mysql`                  |
| `docs.connections.dbHost`                                | The IP address or the name of the Database host                                                                 | `mysql`                  |
| `docs.connections.dbUser`                                | Database user                                                                                                   | `onlyoffice_user`        |
| `docs.connections.dbPort`                                | Database server port number                                                                                     | `3306`                   |
| `docs.connections.dbName`                                | Name of the Database database the application will be connected with. The database must already exist           | `docspace`               |
| `docs.connections.dbExistingSecret`                      | Name of existing secret to use for Database password. Must contain the key specified in `docs.connections.dbSecretKeyName` | `mysql`       |
| `docs.connections.dbSecretKeyName`                       | The name of the key that contains the Database user password. If you set a password in `docs.connections.dbPassword`, a secret will be automatically created, the key name of which will be the value set here | `mysql-password` |
| `docs.connections.dbPassword`                            | Database user password. If set to, it takes priority over the `docs.connections.dbExistingSecret`               | `""`                     |
| `docs.connections.redisHost`                             | The IP address or the name of the Redis host. By default, the same Redis connection is used as for DocSpace, except for `docs.connections.redisDBNum` | `redis-master` |
| `docs.connections.redisPort`                             | The Redis server port number                                                                                    | `6379`                   |
| `docs.connections.redisUser`                             | The Redis [user](https://redis.io/docs/management/security/acl/) name                                           | `default`                |
| `docs.connections.redisDBNum`                            | Number of the Redis logical [database](https://redis.io/commands/select/) to be selected                        | `1`                      |
| `docs.connections.redisExistingSecret`                   | Name of existing secret to use for Redis password. Must contain the key specified in `docs.connections.redisSecretKeyName` | `redis`       |
| `docs.connections.redisSecretKeyName`                    | The name of the key that contains the Redis user password. If you set a password in `docs.connections.redisPassword`, a secret will be automatically created, the key name of which will be the value set here | `redis-password` |
| `docs.connections.redisPassword`                         | The password set for the Redis account. If set to, it takes priority over the `docs.connections.redisExistingSecret` | `""`                |
| `docs.connections.redisNoPass`                           | Defines whether to use a Redis auth without a password. If the connection to Redis server does not require a password, set the value to `true` | `false` |
| `docs.connections.amqpType`                              | Defines the AMQP server type. By default, the same RabbitMQ connection is used as for DocSpace                  | `rabbitmq`               |
| `docs.connections.amqpHost`                              | The IP address or the name of the AMQP server                                                                   | `rabbitmq`               |
| `docs.connections.amqpPort`                              | The port for the connection to AMQP server                                                                      | `5672`                   |
| `docs.connections.amqpVhost`                             | The virtual host for the connection to AMQP server                                                              | `/`                      |
| `docs.connections.amqpUser`                              | The username for the AMQP server account                                                                        | `user`                   |
| `docs.connections.amqpProto`                             | The protocol for the connection to AMQP server                                                                  | `amqp`                   |
| `docs.connections.amqpExistingSecret`                    | The name of existing secret to use for AMQP server password. Must contain the key specified in `docs.connections.amqpSecretKeyName` | `rabbitmq` |
| `docs.connections.amqpSecretKeyName`                     | The name of the key that contains the AMQP server user password. If you set a password in `docs.connections.amqpPassword`, a secret will be automatically created, the key name of which will be the value set here | `rabbitmq-password` |
| `docs.connections.amqpPassword`                          | AMQP server user password. If set to, it takes priority over the `docs.connections.amqpExistingSecret`          | `""`                     |
| `docs.service.port`                                      | ONLYOFFICE Docs service port                                                                                    | `80`                     |
| `docs.license.existingClaim`                             | Name of the existing PVC in which the license is stored. Must contain the file `license.lic`. By default, a PVC is connected, in which a license is added when using DocSpace Enterprise | `docspace-data` |
| `docs.jwt.existingSecret`                                | The name of an existing secret containing variables for jwt. By default, the jwt secret is used, which will be created with values from the jwt DocSpace | `docspace-jwt` |
| `docs.upgrade.job.enabled`                               | Enable the execution of job Docs pre-upgrade before upgrading. Set to `false` when upgrading to version `3.0.0` from earlier. When installing `3.0.0` and also when upgrading from version `3.0.0` to a later one, it should be set to `true` | `true` |
| `docs.clearCache.job.enabled`                            | Enable the execution of job Docs Clear Cache after upgrading. Set to `false` when upgrading to version `3.0.0` from earlier. When installing `3.0.0` and also when upgrading from version `3.0.0` to a later one, it should be set to `true` | `true` |

### ONLYOFFICE DocSpace Ingress parameters

| Parameter                                                | Description                                                                                                     | Default                                                                                   |
|----------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------|
| `ingress.enabled`                                        | Enable the creation of an ingress for the ONLYOFFICE DocSpace                                                   | `false`                                                                                   |
| `ingress.annotations`                                    | Map of annotations to add to the Ingress                                                                        | `nginx.org/client-max-body-size: 100m` |
| `ingress.ingressClassName`                               | Used to reference the IngressClass that should be used to implement this Ingress                                | `nginx`                                                                                   |
| `ingress.controllerName`                                 | Ingress controller type. Affects which controller-specific annotations are applied. Supported values: `nginx-ingress` (F5 NGINX, `nginx.org/` annotations), `ingress-nginx` (Kubernetes community, `nginx.ingress.kubernetes.io/` annotations) | `nginx-ingress` |
| `ingress.tls.enabled`                                    | Enable TLS for the ONLYOFFICE DocSpace                                                                          | `false`                                                                                   |
| `ingress.tls.secretName`                                 | Secret name for TLS to mount into the Ingress                                                                   | `tls`                                                                                     |
| `ingress.pathType                                        | Specifies the path type for the ONLYOFFICE DocSpace ingress resource. Allowed values: `Exact`, `Prefix` or `ImplementationSpecific` | `ImplementationSpecific`                                              |
| `ingress.host`                                           | Ingress hostname for the ONLYOFFICE DocSpace                                                                    | `""`                                                                                      |
| `ingress.tenants`                                        | Ingress hostnames if you need to use more than one name. For example, for multitenancy. If set to, it takes priority over the `ingress.host`. If `ingress.tls.enabled` is set to `true`, it is assumed that the certificate for all specified domains is kept secret by `ingress.tls.secretName` | `[]` |
| `ingress.letsencrypt.enabled`                            | Enabling certificate request creation in Let's Encrypt. Used if `ingress.enabled` is set to `true`              | `false`                                                                                   |
| `ingress.letsencrypt.clusterIssuerName`                  | ClusterIssuer Name                                                                                              | `letsencrypt-prod`                                                                        |
| `ingress.letsencrypt.email`                              | Your email address used for ACME registration                                                                   | `""`                                                                                      |
| `ingress.letsencrypt.server`                             | The address of the Let's Encrypt server to which requests for certificates will be sent                         | `https://acme-v02.api.letsencrypt.org/directory`                                          |
| `ingress.letsencrypt.secretName`                         | Name of a secret used to store the ACME account private key                                                     | `letsencrypt-prod-private-key`                                                            |

### ONLYOFFICE DocSpace Jobs parameters

| Parameter                                                       | Description                                                                                                                                                                                                | Default                                         |
|-----------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------|
| `install.job.enabled`                                           | Enable the execution of job pre-install before installing ONLYOFFICE DocSpace                                                                                                                              | `true`                                          |
| `install.job.annotations`                                       | Defines annotations that will be additionally added to Install Job. If set to, it takes priority over the `commonAnnotations`                                                                              | `{}`                                            |
| `install.job.podAnnotations`                                    | Map of annotations to add to the Install Job Pod. If set to, it takes priority over the `podAnnotations`                                                                                                   | `{}`                                            |
| `install.job.podSecurityContext.enabled`                        | Enable security context for the Install Job pod                                                                                                                                                            | `false`                                         |
| `install.job.customPodAntiAffinity`                             | Prohibiting the scheduling of Install Job Pod relative to other Pods containing the specified labels on the same node                                                                                      | `{}`                                            |
| `install.job.podAffinity`                                       | Defines [Pod affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#inter-pod-affinity-and-anti-affinity) rules for Install Job Pod scheduling by nodes relative to other Pods | `{}`                                            |
| `install.job.nodeAffinity`                                      | Defines [Node affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity) rules for Install Job Pod scheduling by nodes                                              | `{}`                                            |
| `install.job.nodeSelector`                                      | Node labels for Install Job pod assignment. If set to, it takes priority over the `nodeSelector`                                                                                                           | `{}`                                            |
| `install.job.tolerations`                                       | Tolerations for Install Job pod assignment. If set to, it takes priority over the `tolerations`                                                                                                            | `[]`                                            |
| `install.job.containerSecurityContext.enabled`                  | Enable security context for containers in Install Job pod                                                                                                                                                  | `false`                                         |
| `install.job.initContainers.migrationRunner.enabled`            | Enable database initialization                                                                                                                                                                             | `true`                                          |
| `install.job.initContainers.migrationRunner.image.registry`     | Migration Runner container image registry. Takes priority over `images.registry`                                                                                                                           | `""`                                            |
| `install.job.initContainers.migrationRunner.image.repository`   | Job by pre-install Migration Runner container image repository                                                                                                                                             | `onlyoffice/docspace-migration-runner`          |
| `install.job.initContainers.migrationRunner.image.tag`          | Job by pre-install Migration Runner container image tag. If set to, it takes priority over the `images.tag`                                                                                                | `""`                                            |
| `install.job.initContainers.migrationRunner.image.pullPolicy`   | Job by pre-install Migration Runner container image pull policy                                                                                                                                            | `IfNotPresent`                                  |
| `install.job.initContainers.migrationRunner.resources.requests` | The requested resources for the Job pre-install Migration Runner container                                                                                                                                 | `memory, cpu`                                   |
| `install.job.initContainers.migrationRunner.resources.limits`   | The resources limits for the Job pre-install Migration Runner container                                                                                                                                    | `memory, cpu`                                   |
| `upgrade.job.enabled`                                           | Enable the execution of job pre-upgrade before upgrading ONLYOFFICE DocSpace                                                                                                                               | `true`                                          |
| `upgrade.job.annotations`                                       | Defines annotations that will be additionally added to Upgrade Job. If set to, it takes priority over the `commonAnnotations`                                                                              | `{}`                                            |
| `upgrade.job.podAnnotations`                                    | Map of annotations to add to the Upgrade Job Pod. If set to, it takes priority over the `podAnnotations`                                                                                                   | `{}`                                            |
| `upgrade.job.podSecurityContext.enabled`                        | Enable security context for the Upgrade Job pod                                                                                                                                                            | `false`                                         |
| `upgrade.job.customPodAntiAffinity`                             | Prohibiting the scheduling of Upgrade Job Pod relative to other Pods containing the specified labels on the same node                                                                                      | `{}`                                            |
| `upgrade.job.podAffinity`                                       | Defines [Pod affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#inter-pod-affinity-and-anti-affinity) rules for Upgrade Job Pod scheduling by nodes relative to other Pods | `{}`                                            |
| `upgrade.job.nodeAffinity`                                      | Defines [Node affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity) rules for Upgrade Job Pod scheduling by nodes                                              | `{}`                                            |
| `upgrade.job.nodeSelector`                                      | Node labels for Upgrade Job pod assignment. If set to, it takes priority over the `nodeSelector`                                                                                                           | `{}`                                            |
| `upgrade.job.tolerations`                                       | Tolerations for Upgrade Job pod assignment. If set to, it takes priority over the `tolerations`                                                                                                            | `[]`                                            |
| `upgrade.job.containerSecurityContext.enabled`                  | Enable security context for containers in Upgrade Job pod                                                                                                                                                  | `false`                                         |
| `upgrade.job.initContainers.migrationRunner.enabled`            | Enable database update                                                                                                                                                                                     | `true`                                          |
| `upgrade.job.initContainers.migrationRunner.image.registry`     | Migration Runner container image registry. Takes priority over `images.registry`                                                                                                                           | `""`                                            |
| `upgrade.job.initContainers.migrationRunner.image.repository`   | Job by pre-upgrade Migration Runner container image repository                                                                                                                                             | `onlyoffice/docspace-migration-runner`          |
| `upgrade.job.initContainers.migrationRunner.image.tag`          | Job by pre-upgrade Migration Runner container image tag. If set to, it takes priority over the `images.tag`                                                                                                | `""`                                            |
| `upgrade.job.initContainers.migrationRunner.image.pullPolicy`   | Job by pre-upgrade Migration Runner container image pull policy                                                                                                                                            | `IfNotPresent`                                  |
| `upgrade.job.initContainers.migrationRunner.resources.requests` | The requested resources for the Job pre-upgrade Migration Runner container                                                                                                                                 | `memory, cpu`                                   |
| `upgrade.job.initContainers.migrationRunner.resources.limits`   | The resources limits for the Job pre-upgrade Migration Runner container                                                                                                                                    | `memory, cpu`                                   |
| `upgrade.job.initContainers.rootless.enabled`                      | Enable the rootless initContainer to change file ownership                                                                  | `true`                        |
| `upgrade.job.initContainers.rootless.image.registry`            | rootless initContainer image registry. Takes priority over `images.registry`                                                   | `""`                          |
| `upgrade.job.initContainers.rootless.image.repository`             | rootless initContainer image repository                                                                                     | `onlyoffice/docs-utils`       |
| `upgrade.job.initContainers.rootless.image.tag`                    | rootless initContainer image tag. If set to, it takes priority over the `images.tag`                                        | `9.4.1-1`                     |
| `upgrade.job.initContainers.rootless.image.pullPolicy`             | rootless initContainer image pull policy                                                                                    | `IfNotPresent`                |
| `upgrade.job.initContainers.rootless.resources.requests.memory`    | The requested Memory for the rootless initContainer                                                                         | `256Mi`                       |
| `upgrade.job.initContainers.rootless.resources.requests.cpu`       | The requested CPU for the rootless initContainer                                                                            | `100m`                        |
| `upgrade.job.initContainers.rootless.resources.limits.memory`      | The Memory limits for the rootless initContainer                                                                            | `1Gi`                         |
| `upgrade.job.initContainers.rootless.containerSecurityContext.enabled`                  | Enable security context for the rootless initContainer                                                 | `true`                        |
| `upgrade.job.initContainers.rootless.containerSecurityContext.runAsUser`                | User ID for the DocSpace rootless initContainer. When performing a clean install of 3.0+ images or upgrading from version 3.0+ to a later version, you can specify uid=104  | `0`                           |
| `upgrade.job.initContainers.rootless.containerSecurityContext.runAsGroup`               | Group ID for the DocSpace rootless initContainer. When performing a clean install of 3.0+ images or upgrading from version 3.0+ to a later version, you can specify gid=107 | `0`                           |
| `upgrade.job.initContainers.rootless.containerSecurityContext.allowPrivilegeEscalation` | Controls whether a process can gain more privileges than its parent process                            | `false`                       |
| `upgrade.job.initContainers.rootless.containerSecurityContext.seLinuxOptions`           | Defines SELinux labels for the DocSpace rootless initContainer                                         | `{}`                          |
| `upgrade.job.initContainers.rootless.containerSecurityContext.seccompProfile`           | Defines the Seccomp profile for the DocSpace rootless initContainer                                    | `type: RuntimeDefault`        |
| `upgrade.job.initContainers.rootless.containerSecurityContext.capabilities`             | Defines the privileges granted to the process                                                          | `drop: ["ALL"]`               |
| `upgrade.job.docsInitDB.enabled`                                | Enable the Init DB for Docs container to create tables required for Docs to work. Set to `true` when upgrading to version `3.0.0` from earlier. When installing `3.0.0` and also when upgrading from version `3.0.0` to a later one, it should be set to `false` | `false` |
| `elasticsearchClearIndexes.job.enabled`                         | Enable the execution of job elasticsearchClearIndexes before upgrading DocSpace. If you are using Opensearch or an external Elasticsearch, you can set it to `false`                                       | `true`                                          |
| `elasticsearchClearIndexes.job.annotations`                     | Defines annotations that will be additionally added to elasticsearchClearIndexes Job. If set to, it takes priority over the `commonAnnotations`                                                            | `{}`                                            |
| `elasticsearchClearIndexes.job.podAnnotations`                  | Map of annotations to add to the elasticsearchClearIndexes Job Pod. If set to, it takes priority over the `podAnnotations`                                                                                 | `{}`                                            |
| `elasticsearchClearIndexes.job.podSecurityContext.enabled`      | Enable security context for the elasticsearchClearIndexes Job pod                                                                                                                                          | `false`                                         |
| `elasticsearchClearIndexes.job.customPodAntiAffinity`           | Prohibiting the scheduling of elasticsearchClearIndexes Job Pod relative to other Pods containing the specified labels on the same node                                                                    | `{}`                                            |
| `elasticsearchClearIndexes.job.podAffinity`                     | Defines [Pod affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#inter-pod-affinity-and-anti-affinity) rules for elasticsearchClearIndexes Job Pod scheduling by nodes relative to other Pods | `{}`                          |
| `elasticsearchClearIndexes.job.nodeAffinity`                    | Defines [Node affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity) rules for elasticsearchClearIndexes Job Pod scheduling by nodes                            | `{}`                                            |
| `elasticsearchClearIndexes.job.nodeSelector`                    | Node labels for elasticsearchClearIndexes Job pod assignment. If set to, it takes priority over the `nodeSelector`                                                                                         | `{}`                                            |
| `elasticsearchClearIndexes.job.tolerations`                     | Tolerations for elasticsearchClearIndexes Job pod assignment. If set to, it takes priority over the `tolerations`                                                                                          | `[]`                                            |
| `elasticsearchClearIndexes.job.containerSecurityContext.enabled`| Enable security context for containers in elasticsearchClearIndexes Job pod                                                                                                                                | `false`                                         |
| `elasticsearchClearIndexes.job.resources.requests`              | The requested resources for the Job elasticsearchClearIndexes container                                                                                                                                    | `memory, cpu`                                   |
| `elasticsearchClearIndexes.job.resources.limits`                | The resources limits for the Job elasticsearchClearIndexes container                                                                                                                                       | `memory, cpu`                                   |
| `singlePortalDomain.job.enabled`                                | Enable the execution of job singlePortalDomain before upgrading and installing DocSpace                                                                                                                    | `false`                                         |
| `singlePortalDomain.job.env.appCoreServerRoot`                  | Configures APP_CORE_SERVER_ROOT; automatically set to "https://*/" if ingress.tls.enabled is true                                                                                                          | `""`                                            |
| `singlePortalDomain.job.env.domain`                             | Configures domain name; overridden by ingress.host if present                                                                                                                                              | `""`                                            |
| `singlePortalDomain.job.image.registry`                         | singlePortalDomain container image registry. Takes priority over `images.registry`                                                                                                                         | `""`                                            |
| `singlePortalDomain.job.image.repository`                       | singlePortalDomain container image repository                                                                                                                                                              | `"onlyoffice/docs-utils"`                       |
| `singlePortalDomain.job.image.tag`                              | singlePortalDomain container image tag. If set to, it takes priority over the `images.tag`                                                                                                                 | `"9.4.1-1"`                                     |
| `singlePortalDomain.job.image.pullPolicy`                       | singlePortalDomain container image pull policy                                                                                                                                                             | `"IfNotPresent"`                                |
| `singlePortalDomain.job.annotations`                            | Defines annotations that will be additionally added to singlePortalDomain Job. If set to, it takes priority over the `commonAnnotations`                                                                   | `{}`                                            |
| `singlePortalDomain.job.podAnnotations`                         | Map of annotations to add to the singlePortalDomain Job Pod                                                                                                                                                | `{}`                                            |
| `singlePortalDomain.job.podSecurityContext.enabled`             | Enable security context for the singlePortalDomain Job pod                                                                                                                                                 | `{}`                                            |
| `singlePortalDomain.job.customPodAntiAffinity`                  | Prohibiting the scheduling of singlePortalDomain Job Pod relative to other Pods containing the specified labels on the same node                                                                           | `{}`                                            |
| `singlePortalDomain.job.podAffinity`                            | Defines [Pod affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#inter-pod-affinity-and-anti-affinity) rules for singlePortalDomain Job Pod scheduling by nodes relative to other Pods | `{}`                                 |
| `singlePortalDomain.job.nodeAffinity`                           | Defines [Node affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity) rules for singlePortalDomain Job Pod scheduling by nodes                                   | `{}`                                            |
| `singlePortalDomain.job.nodeSelector`                           | Node labels for singlePortalDomain Job pod assignment. If set to, it takes priority over the `nodeSelector`                                                                                                | `{}`                                            |
| `singlePortalDomain.job.tolerations`                            | Tolerations for singlePortalDomain Job pod assignment. If set to, it takes priority over the `tolerations`                                                                                                 | `[]`                                            |
| `singlePortalDomain.job.containerSecurityContext.enabled`       | Enable security context for containers in singlePortalDomain Job pod                                                                                                                                       | `false`                                         |
| `singlePortalDomain.job.resources.requests`                     | The requested resources for the singlePortalDomain Job container                                                                                                                                           | `memory, cpu`                                   |
| `singlePortalDomain.job.resources.limits`                       | The resources limits for the singlePortalDomain Job container                                                                                                                                              | `memory, cpu`                                   |
### ONLYOFFICE DocSpace Opensearch parameters

| Parameter                                             | Description                                                                                                  | Default                                                        |
|-------------------------------------------------------|--------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------|
| `opensearch.enabled`                                  | Enables Opensearch installation                                                                              | `true`                                                         |
| `opensearch.initContainers.changeVolumeOwner.securityContext.enabled`   | Enable security context for Opensearch change-volume-owner initContainer container in pod                    | `false`                                                        |
| `opensearch.initContainers.changeVolumeOwner.resources.requests`        | The requested resources for the Opensearch change-volume-owner initContainer                                 | `memory, cpu`                                                  |
| `opensearch.initContainers.changeVolumeOwner.resources.limits`          | The resources limits for the Opensearch change-volume-owner initContainer                                    | `memory, cpu`                                                  |
| `opensearch.initContainers.custom`                    | Custom Opensearch initContainers parameters. Additional containers that run before Elasticsearch container in a Pod | `[]`                                                    |
| `opensearch.image.registry`                           | Opensearch container image registry. Takes priority over `images.registry`                                   | `""`                                                           |
| `opensearch.image.repository`                         | Opensearch container image repository                                                                        | `onlyoffice/opensearch`                                        |
| `opensearch.image.tag`                                | Opensearch container image tag                                                                               | `7.16.3`                                                       |
| `opensearch.persistence.annotations`                  | Defines annotations that will be additionally added to Opensearch PVC. If set to, it takes priority over the `commonAnnotations` | `{}`                                       |
| `opensearch.persistence.storageClass`                 | PVC Storage Class for Opensearch volume                                                                      | `"nfs"`                                                        |
| `opensearch.persistence.accessModes`                  | Opensearch Persistent Volume access modes                                                                    | `ReadWriteOnce`                                                |
| `opensearch.persistence.size`                         | PVC Storage Request for Opensearch volume                                                                    | `30Gi`                                                         |
| `opensearch.env.discoveryType`                        | Determines the cluster discovery type. Set to "single-node" for a single-node cluster                        | `single-node                                                   |
| `opensearch.env.disableSecurityPlugin`                | disables the security plugin                                                                                 | `true`                                                         |
| `opensearch.env.disableInstallDemoConfig`             | disables the installation of demo configuration                                                              | `true`                                                         |
| `opensearch.env.bootstrapMemoryLock`                  | determines whether JVM should lock memory                                                                    | `true`                                                         |
| `opensearch.env.ESJAVAOPTS`                           | defines JVM options                                                                                          | `-Xms2g -Xmx2g -Dlog4j2.formatMsgNoLookups=true`               |
| `opensearch.env.indicesFieldDataCacheSize`            | sets the size of the index field data cache                                                                  | `30%`                                                          |
| `opensearch.env.indicesMemoryIndexBufferSize`         | sets the size of the in-memory index buffer                                                                  | `30%`                                                          |

### ONLYOFFICE DocSpace Test parameters

| Parameter                                                | Description                                                                                                                                                                            | Default                          |
|----------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------|
| `tests.enabled`                                          | Enable the resources creation necessary for ONLYOFFICE DocSpace launch testing and connected dependencies availability testing. These resources will be used when running the `helm test` command | `true`                |
| `tests.annotations`                                      | Defines annotations that will be additionally added to Test Pod. If set to, it takes priority over the `commonAnnotations`                                                             | `{}`                             |
| `tests.podSecurityContext.enabled`                       | Enable security context for the Test pod                                                                                                                                               | `false`                          |
| `tests.customPodAntiAffinity`                            | Prohibiting the scheduling of Test Pod relative to other Pods containing the specified labels on the same node                                                                         | `{}`                             |
| `tests.podAffinity`                                      | Defines [Pod affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#inter-pod-affinity-and-anti-affinity) rules for Test Pod scheduling by nodes relative to other Pods | `{}`                |
| `tests.nodeAffinity`                                     | Defines [Node affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/#node-affinity) rules for Test Pod scheduling by nodes                                 | `{}`                             |
| `tests.nodeSelector`                                     | Node labels for Test pod assignment. If set to, it takes priority over the `nodeSelector`                                                                                              | `{}`                             |
| `tests.tolerations`                                      | Tolerations for Test pod assignment. If set to, it takes priority over the `tolerations`                                                                                               | `[]`                             |
| `tests.image.registry`                                   | Test container image registry. Takes priority over `images.registry`                                                                                                                   | `""`                             |
| `tests.image.repository`                                 | Test container image name                                                                                                                                                              | `onlyoffice/docs-utils`          |
| `tests.image.tag`                                        | Test container image tag                                                                                                                                                               | `9.4.1-1`                        |
| `tests.image.pullPolicy`                                 | Test container image pull policy                                                                                                                                                       | `IfNotPresent`                   |
| `tests.containerSecurityContext.enabled`                 | Enable security context for the Test container                                                                                                                                         | `false`                          |
| `tests.resources.requests`                               | The requested resources for the Test container                                                                                                                                         | `memory: "256Mi"`, `cpu: "200m"` |
| `tests.resources.limits`                                 | The resources limits for the Test container                                                                                                                                            | `memory: "1Gi"`, `cpu: "1000m"`  |

## Configuration and installation details

### 1. Expose ONLYOFFICE DocSpace

#### 1.1 Expose ONLYOFFICE DocSpace via Service (HTTP Only)

*You should skip step[#1.1] if you are going to expose ONLYOFFICE DocSpace via HTTPS*

This type of exposure has the least overheads of performance, it creates a loadbalancer to get access to ONLYOFFICE DocSpace.
Use this type of exposure if you use external TLS termination, and don't have another WEB application in the k8s cluster.

To expose ONLYOFFICE DocSpace via service, set the `router.service.type` parameter to `LoadBalancer`:

```bash
$ helm install [RELEASE_NAME] onlyoffice/docspace --set router.service.type=LoadBalancer,router.service.port.external=8092

```

Run the following command to get the `router` service IP:

```bash
$ kubectl get service router -o jsonpath="{.status.loadBalancer.ingress[*].ip}"
```

After that, ONLYOFFICE DocSpace will be available at `http://DOCSPACE-SERVICE-IP/`.

If the service IP is empty, try getting the `router` service hostname:

```bash
$ kubectl get service router -o jsonpath="{.status.loadBalancer.ingress[*].hostname}"
```

In this case, ONLYOFFICE DocSpace will be available at `http://DOCSPACE-SERVICE-HOSTNAME/`.


#### 1.2 Expose ONLYOFFICE DocSpace via Ingress

#### 1.2.1 Installing F5 NGINX Ingress Controller

To install the F5 NGINX Ingress Controller to your cluster using the OCI registry, run the following command:

```bash
$ helm install nginx-ingress oci://ghcr.io/nginx/charts/nginx-ingress --version 2.5.1 --set controller.setAsDefault=true --set controller.replicaCount=2
```

See more detail about installing F5 NGINX Ingress via Helm [here](https://docs.nginx.com/nginx-ingress-controller/install/helm/open-source/).

Note: The chart also supports the community `ingress-nginx` controller. To use it, set `ingress.controllerName=ingress-nginx`.

#### 1.2.2 Expose ONLYOFFICE DocSpace via HTTP

*You should skip step[2.1.2] if you are going to expose ONLYOFFICE DocSpace via HTTPS*

This type of exposure has more overheads of performance compared with exposure via service, it also creates a loadbalancer to get access to ONLYOFFICE DocSpace.
Use this type if you use external TLS termination and when you have several WEB applications in the k8s cluster. You can use the one set of ingress instances and the one loadbalancer for those. It can optimize the entry point performance and reduce your cluster payments, cause providers can charge a fee for each loadbalancer.

To expose ONLYOFFICE DocSpace via ingress HTTP, set the `ingress.enabled` and the `ingress.host` parameters to true:

```bash
$ helm install [RELEASE_NAME] onlyoffice/docspace --set ingress.enabled=true --set ingress.host=example.com

```

Run the following command to get the `docspace` ingress IP:

```bash
$ kubectl get ingress docspace -o jsonpath="{.status.loadBalancer.ingress[*].ip}"
```

If the ingress IP is empty, try getting the `docspace` ingress hostname:

```bash
$ kubectl get ingress docspace -o jsonpath="{.status.loadBalancer.ingress[*].hostname}"
```

In this case, ONLYOFFICE DocSpace will be available at `http://DOCSPACE-INGRESS-HOSTNAME/`.

#### 1.2.3 Expose ONLYOFFICE DocSpace via HTTPS

This type of exposure allows you to enable internal TLS termination for ONLYOFFICE DocSpace.

Create the `tls` secret with an ssl certificate inside.

Put the ssl certificate and the private key into the `tls.crt` and `tls.key` files and then run:

```bash
$ kubectl create secret tls tls \
  --cert=./tls.crt \
  --key=./tls.key
```

```bash
$ helm install [RELEASE_NAME] onlyoffice/docspace --set ingress.enabled=true,ingress.tls.enabled=true,ingress.tls.secretName=tls,ingress.host=example.com

```

The `ingress.host` field is required. 

Run the following command to get the `docspace` ingress IP:

```bash
$ kubectl get ingress docspace -o jsonpath="{.status.loadBalancer.ingress[*].ip}"
```

If the ingress IP is empty, try getting the `docspace` ingress hostname:

```bash
$ kubectl get ingress docspace -o jsonpath="{.status.loadBalancer.ingress[*].hostname}"
```

Associate the `docspace` ingress IP or hostname with your domain name through your DNS provider.

After that, ONLYOFFICE DocSpace will be available at `https://your-domain-name/`.

#### 1.2.4 Expose ONLYOFFICE DocSpace via HTTPS using the Let's Encrypt certificate

- Add Helm repositories:
  ```bash
  $ helm repo add jetstack https://charts.jetstack.io
  $ helm repo update
  ```
- Installing cert-manager
  ```bash
  $ helm install cert-manager --version v1.20.2 jetstack/cert-manager \
    --namespace cert-manager \
    --create-namespace \
    --set crds.enabled=true \
    --set crds.keep=false
  ```
Next, perform the installation or upgrade by setting the `ingress.enabled`, `ingress.tls.enabled` and `ingress.letsencrypt.enabled` parameters to `true`. Also set your own values in the parameters `ingress.letsencrypt.email`, `ingress.host` or `ingress.tenants`(for example, `--set "ingress.tenants={tenant1.example.com,tenant2.example.com}"`) if you want to use multiple domain names.

Note: If you are changing the `ingress.path`, `ingress.host`, or `ingress.tenants` values after ONLYOFFICE DocSpace is already installed with `ingress.letsencrypt.enabled=true`, run the upgrade with `--server-side=true` and `--force-conflicts` to avoid field ownership conflicts:

```bash
$ helm upgrade [RELEASE_NAME] onlyoffice/docspace --server-side=true --force-conflicts -f values.yaml
```

This is only required when using Let's Encrypt (`ingress.letsencrypt.enabled=true`). If you use your own certificate that is already installed in the cluster and do not enable Let's Encrypt, these flags are not needed during upgrade.

### 2. Transition from ElasticSearch to OpenSearch

In ONLYOFFICE DocSpace appVersion 2.5.0, ElasticSearch is being replaced with OpenSearch, which will require reindexing, taking some time.

For proper reindexing before updating ONLYOFFICE DocSpace to version 2.5.0, execute the following command:
- If `file-services` is deployed as a StatefulSet:

  ```bash
  kubectl scale statefulset files-worker --replicas=0
  ```
- Otherwise, if deployed as a Deployment:

  ```bash
  kubectl scale deployment files-worker --replicas=0
  ```
Then proceed with the ONLYOFFICE DocSpace update.

NOTE: If you have an external Elasticsearch installed, please follow these steps before updating:

1. Reduce the replica count of `files-worker` to 0, as described above.
2. In the configmap and job files named `elasticsearch-clear-indexes.yaml`, replace the values in `spec.template.spec.containers.env[(name=="MYSQL_PASSWORD")].value` and, if necessary, in `spec.template.spec.containers.env[(name=="MYSQL_USER")].value` with your own values.
3. Apply these files `elasticsearch-clear-indexes.yaml`:

  ```bash
  kubectl apply -f https://raw.githubusercontent.com/ONLYOFFICE/Kubernetes-DocSpace/main/sources/elasticsearch-clear-indexes.yaml
  ```
After successfully executing the Pod `elasticsearch-clear-indexes` that created the Job, delete this Job with the following command:

  ``` bash
  kubectl delete -f https://raw.githubusercontent.com/ONLYOFFICE/Kubernetes-DocSpace/main/sources/elasticsearch-clear-indexes.yaml
  ```
### 3. Scale ONLYOFFICE DocSpace (optional)

*This step is optional. You can skip step [3](#3-scale-onlyoffice-docspace-optional) entirely if you want to use default deployment settings.*

*The term Application will be used to refer to application deployments. You can find more details and the full list of Applications [here](#onlyoffice-docspace-application-parameters), with the exception of `opensearch`.*

#### 3.1 Horizontal Pod Autoscaling

You can enable Autoscaling so that the number of replicas of *Application* deployments is calculated automatically based on the values and type of metrics.

For resource metrics, API metrics.k8s.io must be registered, which is generally provided by [metrics-server](https://github.com/kubernetes-sigs/metrics-server). It can be launched as a cluster add-on.

To use the target utilization value (`target.type==Utilization`), it is necessary that the values for `resources.requests` are specified in the deployment.

For more information about Horizontal Pod Autoscaling, see [here](https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/).

To enable HPA for the *Application* deployment, specify the `APPLICATION.autoscaling.enabled=true` parameter. 
In this case, the `APPLICATION.replicaCount` parameter is ignored and the number of replicas is controlled by HPA.

With the `autoscaling.enabled` parameter enabled, by default Autoscaling will adjust the number of replicas based on the average percentage of CPU Utilization.
For other configurable Autoscaling parameters, see the [ONLYOFFICE DocSpace Application parameters](#onlyoffice-docspace-application-parameters) table.

#### 3.2 Manual scaling

The *Application* deployment consists of 2 pods by default.

To scale the specific *Application* deployment individually, use the following command:

```bash
$ kubectl scale -n default deployment APPLICATION --replicas=POD_COUNT
```

where `POD_COUNT` is a number of the `APPLICATION` pods.

### 4. Encryption Key Management for Identity

Starting from **chart version 3.2.0**, the encryption key used by the Identity service (`SPRING_APPLICATION_ENCRYPTION_SECRET`) is now created automatically and stored in a Kubernetes Secret.

#### Upgrading from earlier versions

If you are upgrading from a version older than 3.2.0, and you have already created applications or configured OAuth2 integrations, we recommend disabling automatic key generation to preserve compatibility with existing data:

```bash
$ helm upgrade [RELEASE_NAME] onlyoffice/docspace --set identity.secret.generate=false
```

This setting ensures consistent encryption behavior during the upgrade.

> **Note:** If you experience issues with authentication or access after the upgrade, try setting `generate: "false"` and re-deploying the chart.

#### For new installations

No additional configuration is required. A secure key will be generated automatically:

```bash
$ helm install [RELEASE_NAME] onlyoffice/docspace --set identity.secret.generate=true
```
#### Manual configuration

Manual configuration of the encryption key is also supported if needed:

- To use an existing Kubernetes Secret:

```bash
$ helm install [RELEASE_NAME] onlyoffice/docspace --set identity.secret.existingSecret=secret-file
```

The specified Secret must contain the key `SPRING_APPLICATION_ENCRYPTION_SECRET`.

- To explicitly set the secret value:

```bash
$ helm install [RELEASE_NAME] onlyoffice/docspace --set identity.secret.springEncryptionValue=secret-value
```
#### Parameter priority

When multiple encryption-related settings are defined, the following order of precedence applies:

1. `existingSecret`  
2. `springEncryptionValue`  
3. `generate`  
> **Note:** It is recommended to configure only one method to avoid conflicts and ensure predictable behavior.

### 5. Configuring Domain Name for Email Notifications

The **single-portal-domain** job allows single-portal (non-multitenant) DocSpace installations to correctly display the domain name in **emails and notifications**.  
Without it, such installations use `localhost` as the sender domain in notification links.

When the job runs, it updates the database so that all notification links use the proper domain and protocol (HTTP or HTTPS).  
The domain and protocol are taken automatically from **Ingress** settings, but if an external Ingress is used, they can be set manually in `values.yaml`.

#### Upgrading from earlier versions

If you previously installed DocSpace without a public domain or switched to HTTPS later, enable this job before the next upgrade:

```bash
helm upgrade [RELEASE_NAME] onlyoffice/docspace   --set singlePortalDomain.job.enabled=true   --set ingress.host=docspace.example.com
```

> **Note:** The domain name and HTTPS/HTTP scheme will be applied from your current Ingress configuration.

If your Ingress is external or not managed by the chart, specify domain and protocol manually:

```bash
helm upgrade [RELEASE_NAME] onlyoffice/docspace   --set singlePortalDomain.job.enabled=true   --set singlePortalDomain.job.env.domain=docspace.example.com   --set singlePortalDomain.job.env.appCoreServerRoot=https://*/
```

#### For new installations

If you install DocSpace with `ingress.host` configured (and optionally `ingress.tls.enabled=true`), the job is not required.  
Notification links will automatically use your public domain and protocol.

#### Parameters

- `singlePortalDomain.job.env.domain` — defines the portal domain; used when `ingress.host` is not set.  
- `singlePortalDomain.job.env.appCoreServerRoot` — defines the protocol prefix (`http://*/` or `https://*/`); if TLS is enabled, the chart automatically uses `https://*/`.

## ONLYOFFICE DocSpace installation test (optional)

You can test ONLYOFFICE DocSpace services availability and access to connected dependencies by running the following command:

```bash
$ helm test [RELEASE_NAME] -n <NAMESPACE>
```

The output should have the following line:

```bash
Phase: Succeeded
```

To view the log of the Pod running as a result of the `helm test` command, run the following command:

```bash
$ kubectl logs -f test-docspace -n <NAMESPACE>
```

The ONLYOFFICE DocSpace services availability check is considered a priority, so if it fails with an error, the test is considered to be failed.

After this, you can delete the `test-docspace` Pod by running the following command:

```bash
$ kubectl delete pod test-docspace -n <NAMESPACE>
```

Note: This testing is for informational purposes only and cannot guarantee 100% availability results.
It may be that even though all checks are completed successfully, an error occurs in the application.
In this case, more detailed information can be found in the application logs.


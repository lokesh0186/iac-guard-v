# Istio

## Table of Contents

|API channel|Implementation version|Mode|Report|
|-----------|----------------------|----|------|
|x|[1.30.0](https://github.com/istio/istio/releases/tag/1.30.0-alpha.2)|x|[1.30.0 report](./1.30.0-default-report.yaml)|

## Reproduce

Istio conformance tests can be reproduced by running `prow/integ-suite-kind.sh test.integration.pilot.kube` from within the [Istio repo](https://github.com/istio/istio).

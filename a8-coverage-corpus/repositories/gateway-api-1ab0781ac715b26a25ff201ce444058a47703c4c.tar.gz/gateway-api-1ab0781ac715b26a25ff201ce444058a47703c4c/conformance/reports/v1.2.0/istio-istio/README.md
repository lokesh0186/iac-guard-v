# Istio

## Table of Contents

|API channel|Implementation version|Mode|Report|
|-----------|----------------------|----|------|
|x|[1.24](https://github.com/istio/istio/releases/tag/1.24.0)|x|[v1.24 report](./experimental-1.24-default-report.yaml)|

## Reproduce

Istio conformance tests can be reproduced by running `prow/integ-suite-kind.sh test.integration.pilot.kube` from within the [Istio repo](https://github.com/istio/istio).
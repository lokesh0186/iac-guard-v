package unit_tests

import (
	"testing"

	"github.com/neo4j/helm-charts/internal/model"
	"github.com/stretchr/testify/assert"
	appsv1 "k8s.io/api/apps/v1"
	v1 "k8s.io/api/core/v1"
)

func TestNeo4jNameWithLoadBalancerSelector(t *testing.T) {
	t.Parallel()

	core1 := model.NewReleaseName("foo")
	args := append(useEnterprise, useDataModeAndAcceptLicense...)
	coreOneManifest, err := model.HelmTemplateForRelease(t, core1, model.HelmChart, args, useNeo4jClusterName...)
	if !assert.NoError(t, err) {
		return
	}

	service := coreOneManifest.OfTypeWithName(&v1.Service{}, "neo4j-cluster-lb-neo4j").(*v1.Service)
	selector := service.Spec.Selector

	checkCoreManifestHasPodMatchingSelector(t, coreOneManifest, selector)

	assert.Contains(t, selector, "app")
	assert.Equal(t, selector["app"], "neo4j-cluster")
}

func checkCoreManifestHasPodMatchingSelector(t *testing.T, manifest *model.K8sResources, selector map[string]string) {
	for _, sts := range manifest.OfType(&appsv1.StatefulSet{}) {
		podLabels := sts.(*appsv1.StatefulSet).Spec.Template.Labels
		for key, expectedValue := range selector {
			assert.Contains(t, podLabels, key)
			assert.Equal(t, expectedValue, podLabels[key])
		}
	}
}

// TestNeo4jInternalPorts checks if the internals services for cluster core contains the expected ports
func TestNeo4jInternalPorts(t *testing.T) {
	t.Parallel()

	expectedPorts := map[int32]int32{
		6362: 6362,
		7687: 7687,
		7474: 7474,
		7688: 7688,
		6000: 6000,
		5000: 5000,
		7000: 7000,
	}

	neo4j := model.NewReleaseName("foo")
	desiredFeatures := [][]string{
		useEnterprise,
		useDataModeAndAcceptLicense,
		useNeo4jClusterName,
		enableCluster,
	}
	var args []string
	for _, a := range desiredFeatures {
		args = append(args, a...)
	}
	neo4jManifest, err := model.HelmTemplateForRelease(t, neo4j, model.HelmChart, args)
	if !assert.NoError(t, err) {
		return
	}

	internalService := neo4jManifest.OfTypeWithName(&v1.Service{}, neo4j.InternalServiceName()).(*v1.Service)
	assert.Equal(t, internalService.Spec.Type, v1.ServiceTypeClusterIP)

	checkPortsMatchExpected(t, expectedPorts, internalService)
}

// TestNeo4jPanicOnShutDownConfig checks whether the server.panic.shutdown_on_panic attribute is set to the default value true or not
func TestNeo4jPanicOnShutDownConfig(t *testing.T) {
	t.Parallel()

	neo4j := model.NewReleaseName("foo")
	desiredFeatures := [][]string{
		useEnterprise,
		useDataModeAndAcceptLicense,
		useNeo4jClusterName,
		enableCluster,
	}
	var args []string
	for _, a := range desiredFeatures {
		args = append(args, a...)
	}
	neo4jManifest, err := model.HelmTemplateForRelease(t, neo4j, model.HelmChart, args)
	if !assert.NoError(t, err) {
		return
	}

	defaultConfigMap := neo4jManifest.OfTypeWithName(&v1.ConfigMap{}, neo4j.DefaultConfigMapName()).(*v1.ConfigMap)
	assert.Contains(t, defaultConfigMap.Data, "server.panic.shutdown_on_panic")
	assert.Contains(t, defaultConfigMap.Data["server.panic.shutdown_on_panic"], "true")
}

func TestPluginsVolumeSetsPluginsDirectory(t *testing.T) {
	t.Parallel()

	args := append([]string{}, useDataModeAndAcceptLicense...)
	args = append(args, useNeo4jClusterName...)
	args = append(args,
		"--set", "volumes.plugins.mode=share",
		"--set", "volumes.plugins.share.name=data",
	)

	manifest, err := model.HelmTemplate(t, model.HelmChart, args)
	if !assert.NoError(t, err) {
		return
	}

	defaultConfigMap := manifest.OfTypeWithName(
		&v1.ConfigMap{},
		model.DefaultHelmTemplateReleaseName.DefaultConfigMapName(),
	).(*v1.ConfigMap)
	assert.Equal(t, "/plugins", defaultConfigMap.Data["server.directories.plugins"])
}

func TestPluginsDirectoryIsNotSetWithoutPluginsVolume(t *testing.T) {
	t.Parallel()

	args := append([]string{}, useDataModeAndAcceptLicense...)
	args = append(args, useNeo4jClusterName...)

	manifest, err := model.HelmTemplate(t, model.HelmChart, args)
	if !assert.NoError(t, err) {
		return
	}

	defaultConfigMap := manifest.OfTypeWithName(
		&v1.ConfigMap{},
		model.DefaultHelmTemplateReleaseName.DefaultConfigMapName(),
	).(*v1.ConfigMap)
	assert.NotContains(t, defaultConfigMap.Data, "server.directories.plugins")
}

// TestNeo4jServerAndUserLogsConfig checks whether the server and user logs are set in the respective conf files.
func TestNeo4jServerAndUserLogsConfig(t *testing.T) {
	t.Parallel()
	serverLogsXml := []string{"--set", "logging.serverLogsXml=\"unit test case to test it\""}
	userLogsXml := []string{"--set", "logging.userLogsXml=\"unit test case to test it\""}
	neo4j := model.NewReleaseName("foo")
	desiredFeatures := [][]string{
		useEnterprise,
		useDataModeAndAcceptLicense,
		useNeo4jClusterName,
		enableCluster,
		serverLogsXml,
		userLogsXml,
	}
	var args []string
	for _, a := range desiredFeatures {
		args = append(args, a...)
	}

	neo4jManifest, err := model.HelmTemplateForRelease(t, neo4j, model.HelmChart, useDataModeAndAcceptLicense, args...)
	if !assert.NoError(t, err) {
		return
	}

	defaultConfigMap := neo4jManifest.OfTypeWithName(&v1.ConfigMap{}, neo4j.DefaultConfigMapName()).(*v1.ConfigMap)
	userLogsConfigMap := neo4jManifest.OfTypeWithName(&v1.ConfigMap{}, neo4j.UserLogsConfigMapName()).(*v1.ConfigMap)
	serverLogsConfigMap := neo4jManifest.OfTypeWithName(&v1.ConfigMap{}, neo4j.ServerLogsConfigMapName()).(*v1.ConfigMap)
	assert.NotNil(t, userLogsConfigMap, " userLogs Config Map cannot be null")
	assert.NotNil(t, serverLogsConfigMap, " serverLogs Config Map cannot be null")
	assert.Contains(t, defaultConfigMap.Data, "server.logs.user.config")
	assert.Contains(t, defaultConfigMap.Data, "server.logs.config")
	assert.Contains(t, defaultConfigMap.Data["server.logs.user.config"], "/config/user-logs.xml/user-logs.xml")
	assert.Contains(t, defaultConfigMap.Data["server.logs.config"], "/config/server-logs.xml/server-logs.xml")
	assert.Contains(t, serverLogsConfigMap.Data["server-logs.xml"], "unit test case to test it")
	assert.Contains(t, userLogsConfigMap.Data["user-logs.xml"], "unit test case to test it")
}

// TestSeparatedImageFields checks if the image is correctly constructed using separated fields
func TestSeparatedImageFields(t *testing.T) {
	t.Parallel()

	release := model.NewReleaseName("test-separated")

	args := append(useDataModeAndAcceptLicense, useNeo4jClusterName...)
	args = append(args, []string{
		"--set", "image.registry=myregistry.com",
		"--set", "image.repository=neo4j-custom",
		"--set", "neo4j.edition=enterprise",
	}...)

	manifests, err := model.HelmTemplateForRelease(t, release, model.HelmChart, args)
	if !assert.NoError(t, err) {
		return
	}

	stsList := manifests.OfType(&appsv1.StatefulSet{})
	assert.Len(t, stsList, 1)

	sts := stsList[0].(*appsv1.StatefulSet)
	container := sts.Spec.Template.Spec.Containers[0]

	assert.Contains(t, container.Image, "myregistry.com/neo4j-custom:")
	assert.Contains(t, container.Image, "-enterprise")
}

// TestFailBothCustomAndSeparated checks if validation fails when both customImage and separated fields are set
func TestFailBothCustomAndSeparated(t *testing.T) {
	t.Parallel()

	release := model.NewReleaseName("test-fail-both")

	args := append(useDataModeAndAcceptLicense, useNeo4jClusterName...)
	args = append(args, []string{
		"--set", "image.customImage=custom/image:tag",
		"--set", "image.registry=myregistry.com",
	}...)

	_, err := model.HelmTemplateForRelease(t, release, model.HelmChart, args)
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "Cannot use both image.customImage and separated image fields")
}

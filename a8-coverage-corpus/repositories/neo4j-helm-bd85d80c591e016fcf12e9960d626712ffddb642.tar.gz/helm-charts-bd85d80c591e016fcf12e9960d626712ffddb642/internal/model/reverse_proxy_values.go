package model

type Neo4jReverseProxyValues struct {
	NameOverride      string                   `yaml:"nameOverride,omitempty"`
	FullnameOverride  string                   `yaml:"fullnameOverride,omitempty"`
	ReverseProxy      ReverseProxy             `yaml:"reverseProxy,omitempty"`
	ExtraEnvVars      []map[string]interface{} `yaml:"extraEnvVars,omitempty"`
	ExtraVolumes      []map[string]interface{} `yaml:"extraVolumes,omitempty"`
	ExtraVolumeMounts []map[string]interface{} `yaml:"extraVolumeMounts,omitempty"`
}

type ReverseProxy struct {
	Image            string                `yaml:"image,omitempty"`
	ImagePullSecrets []string              `yaml:"imagePullSecrets,omitempty"`
	ServiceName      string                `yaml:"serviceName,omitempty"`
	Namespace        string                `yaml:"namespace,omitempty"`
	Domain           string                `yaml:"domain,omitempty"`
	Service          ReverseProxyService   `yaml:"service,omitempty"`
	Ingress          Ingress               `yaml:"ingress,omitempty"`
	PodLabels        map[string]string     `yaml:"podLabels,omitempty"`
	NodeSelector     map[string]string     `yaml:"nodeSelector,omitempty"`
	Tolerations      []Toleration          `yaml:"tolerations,omitempty"`
	Resources        ReverseProxyResources `yaml:"resources,omitempty"`
}

type ReverseProxyService struct {
	Annotations map[string]string `yaml:"annotations,omitempty"`
}

type ReverseProxyResources struct {
	Requests ReverseProxyResourceValues `yaml:"requests,omitempty"`
	Limits   ReverseProxyResourceValues `yaml:"limits,omitempty"`
}

type ReverseProxyResourceValues struct {
	CPU    string `yaml:"cpu,omitempty"`
	Memory string `yaml:"memory,omitempty"`
}

type Ingress struct {
	Enabled     bool              `yaml:"enabled"`
	Annotations map[string]string `yaml:"annotations,omitempty"`
	TLS         TLS               `yaml:"tls,omitempty"`
	Host        string            `yaml:"host,omitempty"`
}

type TLS struct {
	Enabled bool     `yaml:"enabled"`
	Config  []Config `yaml:"config,omitempty"`
}

type Config struct {
	Hosts      []string `yaml:"hosts,omitempty"`
	SecretName string   `yaml:"secretName,omitempty"`
}

package integration_tests

import (
	"bufio"
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"fmt"
	"io"
	"log"
	"math"
	"math/big"
	"os"
	"os/exec"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/aws/aws-sdk-go-v2/service/s3/types"
	. "github.com/neo4j/helm-charts/internal/helpers"
	"github.com/neo4j/helm-charts/internal/integration_tests/gcloud"
	"github.com/neo4j/helm-charts/internal/model"
	"github.com/neo4j/helm-charts/internal/testutil/poll"
	"github.com/neo4j/helm-charts/internal/testutil/timeouts"
	"github.com/stretchr/testify/assert"
	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	restclient "k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
)

type SubTest struct {
	name string
	test func(*testing.T)
}

func CheckError(err error) {
	if err != nil {
		log.Panic(err)
	}
}

var (
	Clientset                   *kubernetes.Clientset
	Config                      *restclient.Config
	gcpServiceAccountNamePrefix = "gcp-sa"
	k8sServiceAccountNamePrefix = "k8s-sa"
	// Roles granted by createGCPServiceAccount at the project level;
	// deleteGCPServiceAccount revokes the same set so the project policy
	// doesn't accumulate `deleted:serviceAccount:...` ghost members
	// (which eventually poison add-iam-policy-binding calls for unrelated
	// SAs).
	gcpServiceAccountProjectRoles = []string{
		"roles/storage.admin",
		"roles/artifactregistry.repoAdmin",
	}
	mutex sync.Mutex
)

func init() {
	//os.Setenv("KUBECONFIG", ".kube/config")
	// gets kubeconfig from env variable
	Config, err := clientcmd.BuildConfigFromFlags("", os.Getenv("KUBECONFIG"))
	CheckError(err)
	Clientset, err = kubernetes.NewForConfig(Config)
	CheckError(err)
}

func publicKey(priv interface{}) interface{} {
	switch k := priv.(type) {
	case *rsa.PrivateKey:
		return &k.PublicKey
	case *ecdsa.PrivateKey:
		return &k.PublicKey
	default:
		return nil
	}
}

func pemBlockForKey(priv interface{}) *pem.Block {
	switch k := priv.(type) {
	case *rsa.PrivateKey:
		return &pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(k)}
	case *ecdsa.PrivateKey:
		b, err := x509.MarshalECPrivateKey(k)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Unable to marshal ECDSA private key: %v", err)
			os.Exit(2)
		}
		return &pem.Block{Type: "EC PRIVATE KEY", Bytes: b}
	default:
		return nil
	}
}

func generateCerts(tempDir string) {
	priv, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		log.Fatal(err)
	}
	template, err := buildCert(rand.Reader, priv, time.Now(), big.NewInt(1))
	if err != nil {
		log.Fatal(err)
	}

	derBytes, err := x509.CreateCertificate(rand.Reader, template, template, publicKey(priv), priv)
	if err != nil {
		log.Fatalf("Failed to create certificate: %s", err)
	}
	out := &bytes.Buffer{}
	pem.Encode(out, &pem.Block{Type: "CERTIFICATE", Bytes: derBytes})

	f, err := os.Create(tempDir + "/public.crt")

	if err != nil {
		log.Fatal(err)
	}

	_, err = f.WriteString(out.String())
	f.Close()

	if err != nil {
		log.Fatal(err)
	}
	out.Reset()
	pem.Encode(out, pemBlockForKey(priv))
	f, err = os.Create(tempDir + "/private.key")
	if err != nil {
		log.Fatal(err)
	}

	_, err = f.WriteString(out.String())
	f.Close()

	if err != nil {
		log.Fatal(err)
	}
}

func buildCert(random io.Reader, private *ecdsa.PrivateKey, validFrom time.Time, serialNumber *big.Int) (*x509.Certificate, error) {

	template := x509.Certificate{}

	template.Subject = pkix.Name{
		CommonName: string("localhost"),
	}
	template.DNSNames = []string{"localhost", "localhost:7473", "localhost:7687"}
	template.NotBefore = validFrom
	template.NotAfter = validFrom.Add(100 * time.Hour)
	template.KeyUsage = x509.KeyUsageCertSign
	template.IsCA = true
	template.BasicConstraintsValid = true

	template.SerialNumber = serialNumber

	derBytes, err := x509.CreateCertificate(
		random, &template, &template, &private.PublicKey, private)
	if err != nil {
		return nil, fmt.Errorf("Failed to create certificate: %v", err)
	}
	return x509.ParseCertificate(derBytes)
}

func createAwsCredFile(dirName string, accessKey string, secretKey string) (string, error) {
	fileContent := `
[default]
region = us-east-1
`
	fileContent = fileContent + fmt.Sprintf("aws_access_key_id = %s\naws_secret_access_key = %s", accessKey, secretKey)
	filePath := fmt.Sprintf("%s/awscredentials", dirName)
	err := os.WriteFile(filePath, []byte(fileContent), 0666)
	if err != nil {
		return "", err
	}
	return filePath, nil
}

func createAzureCredFile(dirName string) (string, error) {
	fileContent := fmt.Sprintf("AZURE_STORAGE_ACCOUNT=%s\nAZURE_STORAGE_KEY=%s\nAZURE_CLIENT_ID=%s\nAZURE_CLIENT_SECRET=%s\nAZURE_TENANT_ID=%s",
		os.Getenv("AZURE_STORAGE_ACCOUNT"),
		os.Getenv("AZURE_STORAGE_KEY"),
		os.Getenv("AZURE_CLIENT_ID"),
		os.Getenv("AZURE_CLIENT_SECRET"),
		os.Getenv("AZURE_TENANT_ID"))
	filePath := fmt.Sprintf("%s/azurecredentials", dirName)
	err := os.WriteFile(filePath, []byte(fileContent), 0666)
	if err != nil {
		return "", err
	}
	return filePath, nil
}

func createGCPCredFile(dirName string) (string, error) {
	filePath := fmt.Sprintf("%s/gcpcredentials", dirName)
	err := os.WriteFile(filePath, []byte(os.Getenv("GCP_SERVICE_ACCOUNT_CRED")), 0666)
	if err != nil {
		return "", err
	}
	return filePath, nil
}

func kCreateSecret(namespace model.Namespace) ([][]string, Closeable, error) {
	tempDir, err := os.MkdirTemp("", string(namespace))
	closeable := func() error { return os.RemoveAll(tempDir) }
	if err != nil {
		return nil, closeable, err
	}
	generateCerts(tempDir)
	awsCredFileName, err := createAwsCredFile(tempDir, os.Getenv("AWS_ACCESS_KEY_ID"), os.Getenv("AWS_SECRET_ACCESS_KEY"))
	if err != nil {
		return nil, closeable, err
	}
	azureCredFileName, err := createAzureCredFile(tempDir)
	if err != nil {
		return nil, closeable, err
	}
	gcpCredFileName, err := createGCPCredFile(tempDir)
	if err != nil {
		return nil, closeable, err
	}
	return [][]string{
		{"create", "secret", "-n", string(namespace), "generic", model.DefaultAuthSecretName, fmt.Sprintf("--from-literal=NEO4J_AUTH=neo4j/%s", model.DefaultPassword)},
		{"create", "secret", "-n", string(namespace), "generic", "bolt-cert", fmt.Sprintf("--from-file=%s/public.crt", tempDir)},
		{"create", "secret", "-n", string(namespace), "generic", "https-cert", fmt.Sprintf("--from-file=%s/public.crt", tempDir)},
		{"create", "secret", "-n", string(namespace), "generic", "bolt-key", fmt.Sprintf("--from-file=%s/private.key", tempDir)},
		{"create", "secret", "-n", string(namespace), "generic", "https-key", fmt.Sprintf("--from-file=%s/private.key", tempDir)},
		{"create", "secret", "-n", string(namespace), "generic", "bloom-license", fmt.Sprintf("--from-literal=bloom.license=%s", os.Getenv("BLOOM_LICENSE"))},
		{"create", "secret", "-n", string(namespace), "generic", "ldapsecret", "--from-literal=LDAP_PASS=demo123"},
		{"create", "secret", "-n", string(namespace), "generic", "awscred", fmt.Sprintf("--from-file=credentials=%s", awsCredFileName)},
		{"create", "secret", "-n", string(namespace), "generic", "azurecred", fmt.Sprintf("--from-file=credentials=%s", azureCredFileName)},
		{"create", "secret", "-n", string(namespace), "generic", "gcpcred", fmt.Sprintf("--from-file=credentials=%s", gcpCredFileName)},
		{"create", "secret", "-n", string(namespace), "tls", "ingress-secret", fmt.Sprintf("--key=%s/%s", tempDir, "private.key"), fmt.Sprintf("--cert=%s/%s", tempDir, "public.crt")},
	}, closeable, err
}

func helmCleanupCommands(releaseName model.ReleaseName) [][]string {
	return [][]string{
		{"uninstall", releaseName.String(), "--wait", "--timeout", "2m", "--namespace", string(releaseName.Namespace())},
	}
}

func kCleanupCommands(namespace model.Namespace) [][]string {
	return [][]string{{"delete", "namespace", string(namespace), "--ignore-not-found", "--force", "--grace-period=0"}}
}

var portOffset int32 = 0

func proxyBolt(t *testing.T, releaseName model.ReleaseName, connectToPod bool) (int32, Closeable, error) {
	localHttpPort := 9000 + atomic.AddInt32(&portOffset, 1)
	localBoltPort := 9100 + atomic.AddInt32(&portOffset, 1)

	program := "kubectl"

	args := []string{"--namespace", string(releaseName.Namespace()), "port-forward", fmt.Sprintf("pod/%s", releaseName.PodName()), fmt.Sprintf("%d:7474", localHttpPort), fmt.Sprintf("%d:7687", localBoltPort)}
	if !connectToPod {
		args = []string{"--namespace", string(releaseName.Namespace()), "port-forward", fmt.Sprintf("service/%s-lb-neo4j", model.DefaultNeo4jName), fmt.Sprintf("%d:7474", localHttpPort), fmt.Sprintf("%d:7687", localBoltPort)}
	}

	t.Logf("running: %s %s\n", program, args)
	cmd := exec.Command(program, args...)
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return localBoltPort, nil, err
	}
	// Use the same pipe for standard error
	cmd.Stderr = cmd.Stdout

	// Make a new channel which will be used to signal that we are ready
	started := make(chan struct{})

	// Create a scanner which scans in a line-by-line fashion
	scanner := bufio.NewScanner(stdout)

	// Use the scanner to scan the output line by line and log it
	// It's running in a goroutine so that it doesn't block
	go func() {
		var once sync.Once
		notifyStarted := func() { started <- struct{}{} }

		// We're all done, unblock the channel
		defer func() {
			once.Do(notifyStarted)
		}()

		// Read line by line and process it until we see that Forwarding has begun
		for scanner.Scan() {
			line := scanner.Text()
			t.Log("PortForward:", line)
			if strings.HasPrefix(line, "Forwarding from") {
				once.Do(notifyStarted)
			}
		}
		scannerErr := scanner.Err()
		if scannerErr != nil {
			t.Logf("Scanner logged error %s - this is usually expected when the proxy is terminated", scannerErr)
		}
	}()

	// Start the command and check for errors
	err = cmd.Start()
	if err == nil {
		// Wait for output to indicate we actually started forwarding
		<-started
		if cmd.ProcessState != nil && cmd.ProcessState.Exited() {
			err = fmt.Errorf("port forward process exited unexpectedly")
		}
	}

	return localBoltPort, func() error {
		var cmdErr = cmd.Process.Kill()
		if cmdErr != nil {
			t.Log("failed to kill process: ", cmdErr)
		}
		stdout.Close()
		return cmdErr
	}, err
}

func proxyMinioTenant(namespace string, tenantName string) (int, Closeable, error) {

	time.Sleep(1 * time.Minute)
	localPort := 9000
	program := "kubectl"
	args := []string{"--namespace", namespace, "port-forward", fmt.Sprintf("svc/%s-hl", tenantName), fmt.Sprintf("%d:9000", localPort)}

	log.Printf("running: %s %s\n", program, args)
	cmd := exec.Command(program, args...)
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return localPort, nil, err
	}
	// Use the same pipe for standard error
	cmd.Stderr = cmd.Stdout

	// Make a new channel which will be used to signal that we are ready
	started := make(chan struct{})

	// Create a scanner which scans in a line-by-line fashion
	scanner := bufio.NewScanner(stdout)

	// Use the scanner to scan the output line by line and log it
	// It's running in a goroutine so that it doesn't block
	go func() {
		var once sync.Once
		notifyStarted := func() { started <- struct{}{} }

		// We're all done, unblock the channel
		defer func() {
			once.Do(notifyStarted)
		}()

		// Read line by line and process it until we see that Forwarding has begun
		for scanner.Scan() {
			line := scanner.Text()
			log.Printf("PortForward:%s", line)
			if strings.HasPrefix(line, "Forwarding from") {
				once.Do(notifyStarted)
			}
		}
		scannerErr := scanner.Err()
		if scannerErr != nil {
			log.Printf("Scanner logged error %s - this is usually expected when the proxy is terminated", scannerErr)
		}
	}()

	// Start the command and check for errors
	err = cmd.Start()
	if err == nil {
		// Wait for output to indicate we actually started forwarding
		<-started
		if cmd.ProcessState != nil && cmd.ProcessState.Exited() {
			err = fmt.Errorf("port forward process exited unexpectedly")
		}
	}

	return localPort, func() error {
		var cmdErr = cmd.Process.Kill()
		if cmdErr != nil {
			log.Printf("failed to kill process: %v", cmdErr)
		}
		stdout.Close()
		return cmdErr
	}, err
}

func runAll(t *testing.T, bin string, commands [][]string, failFast bool) error {
	var combinedErrors error
	for _, command := range commands {
		err := run(t, bin, command...)
		if err != nil {
			if failFast {
				return err
			} else {
				combinedErrors = CombineErrors(combinedErrors, fmt.Errorf("error: '%s' running %s %s", err, bin, command))
			}
		}
	}
	return combinedErrors
}

func createNamespace(t *testing.T, releaseName model.ReleaseName) (Closeable, error) {
	namespace := string(releaseName.Namespace())

	// Try to delete the namespace if it exists
	_ = run(t, "kubectl", "delete", "ns", namespace, "--ignore-not-found=true")

	// Wait for the namespace to be fully deleted
	maxRetries := 30
	for i := 0; i < maxRetries; i++ {
		err := run(t, "kubectl", "get", "ns", namespace)
		if err != nil {
			// Namespace doesn't exist, we can proceed
			break
		}
		t.Logf("Waiting for namespace %s to be deleted... (%d/%d)", namespace, i+1, maxRetries)
		time.Sleep(5 * time.Second)
		if i == maxRetries-1 {
			return func() error {
				return runAll(t, "kubectl", kCleanupCommands(releaseName.Namespace()), false)
			}, fmt.Errorf("timed out waiting for namespace %s to be deleted", namespace)
		}
	}

	err := run(t, "kubectl", "create", "ns", namespace)
	return func() error {
		return runAll(t, "kubectl", kCleanupCommands(releaseName.Namespace()), false)
	}, err
}

// createPriorityClass create priority class to test the priorityClassName feature
func createPriorityClass(t *testing.T, releaseName model.ReleaseName) (Closeable, error) {
	//kubectl create priorityclass high-priority-<namespace> --value=1000 --description="high priority -n <namespace>"
	priorityClassName := model.PriorityClassName(string(releaseName.Namespace()))
	err := run(t, "kubectl", "create", "priorityclass", priorityClassName, "--value=1000", "--description=\"high priority\"", "-n", string(releaseName.Namespace()))
	return func() error {
		return runAll(t, "kubectl",
			[][]string{{"delete", "priorityClass", priorityClassName, "--force", "--grace-period=0"}},
			false)
	}, err
}

func run(t *testing.T, command string, args ...string) error {
	t.Logf("running: %s %s\n", command, args)

	// Add timeout context to prevent commands from hanging indefinitely
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
	defer cancel()

	cmd := exec.CommandContext(ctx, command, args...)
	out, err := cmd.CombinedOutput()

	// Handle timeout errors
	if ctx.Err() == context.DeadlineExceeded {
		t.Logf("Command timed out after 10 minutes: %s %s", command, args)
		return fmt.Errorf("command timed out after 10 minutes: %s %v", command, args)
	}

	if out != nil {
		t.Logf("output: %s\n", out)
	}
	return err
}

func runWithRetry(t *testing.T, maxRetries int, command string, args ...string) error {
	var err error
	for i := 0; i < maxRetries; i++ {
		err = run(t, command, args...)
		if err == nil {
			return nil
		}
		if i < maxRetries-1 {
			delay := time.Duration(1<<uint(i)) * 5 * time.Second
			t.Logf("Command failed (attempt %d/%d), retrying in %v: %s %v: %v", i+1, maxRetries, delay, command, args, err)
			time.Sleep(delay)
		}
	}
	return fmt.Errorf("command failed after %d attempts: %s %v: %w", maxRetries, command, args, err)
}

func kubectlLogs(t *testing.T, podName string, namespace string) (string, error) {
	return poll.UntilValue(context.Background(), t, poll.Opts{
		Interval:      10 * time.Second,
		Timeout:       25 * time.Second, // 3 attempts at 10s interval matches historical budget
		Description:   fmt.Sprintf("kubectl logs for pod %s in %s", podName, namespace),
		RetryableErrs: func(error) bool { return true },
	}, func(context.Context) (string, bool, error) {
		out, err := exec.Command("kubectl", "logs", podName, "--namespace", namespace).CombinedOutput()
		if err != nil {
			return "", false, err
		}
		return string(out), true, nil
	})
}

func waitForPodsTerminated(t *testing.T, namespace string, timeout time.Duration) {
	err := poll.Until(context.Background(), t, poll.Opts{
		Interval:      5 * time.Second,
		Timeout:       timeout,
		Description:   fmt.Sprintf("all pods in namespace %s to terminate", namespace),
		RetryableErrs: func(error) bool { return true }, // list-pods failures are transient
	}, func(ctx context.Context) (bool, error) {
		pods, err := Clientset.CoreV1().Pods(namespace).List(ctx, metav1.ListOptions{})
		if err != nil {
			return false, err
		}
		return len(pods.Items) == 0, nil
	})
	if err != nil {
		t.Logf("%v; force-deleting remaining pods", err)
		// Pods are still Terminating (finalizers, detaching disks, preStop hooks) — force-remove them
		// so downstream `helm uninstall --wait` doesn't block indefinitely.
		_ = run(t, "kubectl", "delete", "pod", "--all", "--namespace", namespace, "--force", "--grace-period=0", "--ignore-not-found")
	}
}

// waitForBackupPodCompletion polls until a pod matching podNameSubstring appears in the namespace
// and its logs contain successMessage. Returns the pod name and full log output.
// Periodically logs the pod's actual output for diagnostics.
func waitForBackupPodCompletion(t *testing.T, namespace, podNameSubstring, successMessage string, timeout time.Duration) (string, string, error) {
	var (
		lastLogOutput string
		lastPodName   string
		pollCount     int
	)
	type result struct {
		podName string
		logs    string
	}
	got, err := poll.UntilValue(context.Background(), t, poll.Opts{
		Interval:      30 * time.Second,
		Timeout:       timeout,
		Description:   fmt.Sprintf("backup pod matching %q to log %q", podNameSubstring, successMessage),
		RetryableErrs: func(error) bool { return true },
	}, func(ctx context.Context) (result, bool, error) {
		pods, err := Clientset.CoreV1().Pods(namespace).List(ctx, metav1.ListOptions{})
		if err != nil {
			return result{}, false, fmt.Errorf("list pods: %w", err)
		}
		for _, pod := range pods.Items {
			if !strings.Contains(pod.Name, podNameSubstring) {
				continue
			}
			lastPodName = pod.Name
			t.Logf("Found backup pod: %s (status: %s)", pod.Name, pod.Status.Phase)
			logs, logsErr := kubectlLogs(t, pod.Name, namespace)
			if logsErr != nil {
				return result{}, false, fmt.Errorf("kubectl logs: %w", logsErr)
			}
			lastLogOutput = logs
			if strings.Contains(logs, successMessage) {
				return result{podName: pod.Name, logs: logs}, true, nil
			}
			// Log pod output every 4th poll (~2 min) for diagnostics.
			if pollCount%4 == 0 {
				preview := logs
				if len(preview) > 500 {
					preview = preview[:500] + "..."
				}
				t.Logf("Backup pod %q not yet completed. Current logs:\n%s", podNameSubstring, preview)
			}
			pollCount++
			return result{}, false, nil
		}
		t.Logf("Backup pod matching %q not yet created, waiting...", podNameSubstring)
		pollCount++
		return result{}, false, nil
	})
	if err != nil {
		if lastPodName != "" {
			t.Logf("TIMEOUT: Backup pod %q did not complete. Final pod logs:\n%s", lastPodName, lastLogOutput)
		}
		return "", "", err
	}
	return got.podName, got.logs, nil
}

// waitForPodByName polls until a pod matching podNameSubstring appears in the namespace.
// Use this when only pod spec checks (env vars, mounts) are needed, not log assertions.
func waitForPodByName(t *testing.T, namespace, podNameSubstring string, timeout time.Duration) (v1.Pod, error) {
	return poll.UntilValue(context.Background(), t, poll.Opts{
		Interval:      30 * time.Second,
		Timeout:       timeout,
		Description:   fmt.Sprintf("pod matching %q to appear in %s", podNameSubstring, namespace),
		RetryableErrs: func(error) bool { return true },
	}, func(ctx context.Context) (v1.Pod, bool, error) {
		pods, err := Clientset.CoreV1().Pods(namespace).List(ctx, metav1.ListOptions{})
		if err != nil {
			return v1.Pod{}, false, err
		}
		for _, pod := range pods.Items {
			if strings.Contains(pod.Name, podNameSubstring) {
				return pod, true, nil
			}
		}
		return v1.Pod{}, false, nil
	})
}

func AsCloseable(closeables []Closeable) Closeable {
	return func() error {
		var combinedErrors error
		if closeables != nil {
			for _, closeable := range closeables {
				innerErr := closeable()
				if innerErr != nil {
					combinedErrors = CombineErrors(combinedErrors, innerErr)
				}
			}
		}
		return combinedErrors
	}
}

func InstallNeo4jInGcloud(t *testing.T, zone gcloud.Zone, project gcloud.Project, releaseName model.ReleaseName, chart model.Neo4jHelmChartBuilder, extraHelmInstallArgs ...string) (Closeable, error) {

	var closeables []Closeable
	addCloseable := func(closeable Closeable) {
		closeables = append([]Closeable{closeable}, closeables...)
	}

	completed := false
	// This is here to ensure that closeables are closed if there is a panic
	defer func() (err error) {
		if !completed {
			err = AsCloseable(closeables)()
			t.Log(err)
		}
		return err
	}()

	cleanupGcloud, diskName, err := gcloud.InstallGcloud(t, zone, project, releaseName)
	if err != nil {
		return AsCloseable(closeables), err
	}
	_, pvErr := createPersistentVolume(diskName, zone, project, releaseName)
	if pvErr != nil {
		return AsCloseable(closeables), pvErr
	}
	addCloseable(cleanupGcloud)
	// delete the statefulset like this otherwise the pods will hang around for their termination grace period
	addCloseable(func() error {
		return runAll(t, "kubectl", [][]string{
			{"delete", "statefulset", releaseName.String(), "--namespace", string(releaseName.Namespace()), "--grace-period=0", "--force", "--ignore-not-found"},
			{"delete", "pod", releaseName.PodName(), "--namespace", string(releaseName.Namespace()), "--grace-period=0", "--wait", "--timeout=120s", "--ignore-not-found"},
			{"delete", "pvc", fmt.Sprintf("%s-pvc", releaseName.String()), "--grace-period=0", "--wait", "--timeout=120s", "--ignore-not-found"},
			{"delete", "pv", fmt.Sprintf("%s-pv", releaseName.String()), "--grace-period=0", "--wait", "--timeout=10s", "--ignore-not-found"},
		}, false)
	})
	addCloseable(func() error { return runAll(t, "helm", helmCleanupCommands(releaseName), false) })

	err = run(t, "helm", model.BaseHelmCommand("install", releaseName, chart, model.Neo4jEdition, extraHelmInstallArgs...)...)

	if err != nil {
		return AsCloseable(closeables), err
	}

	completed = true
	return AsCloseable(closeables), err
}

func createPersistentVolume(name *model.PersistentDiskName, zone gcloud.Zone, project gcloud.Project, release model.ReleaseName) (*v1.PersistentVolumeClaim, error) {
	pv := &v1.PersistentVolume{
		ObjectMeta: metav1.ObjectMeta{
			Name:      fmt.Sprintf("%s-pv", release.String()),
			Namespace: string(release.Namespace()),
		},
		Spec: v1.PersistentVolumeSpec{
			Capacity: v1.ResourceList{
				v1.ResourceStorage: *resource.NewQuantity(10*1024*1024*1024, resource.BinarySI),
			},
			PersistentVolumeSource: v1.PersistentVolumeSource{
				CSI: &v1.CSIPersistentVolumeSource{
					Driver:       "pd.csi.storage.gke.io",
					VolumeHandle: fmt.Sprintf("projects/%s/zones/%s/disks/%s", project, zone, string(*name)),
					FSType:       "ext4",
				},
			},
			AccessModes:                   []v1.PersistentVolumeAccessMode{v1.ReadWriteOnce},
			PersistentVolumeReclaimPolicy: v1.PersistentVolumeReclaimDelete,
			ClaimRef: &v1.ObjectReference{
				Kind:       "PersistentVolumeClaim",
				Namespace:  string(release.Namespace()),
				Name:       fmt.Sprintf("%s-pvc", release.String()),
				APIVersion: "v1",
			},

			StorageClassName: "",
		},
	}
	pvc := &v1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      fmt.Sprintf("%s-pvc", release.String()),
			Namespace: string(release.Namespace()),
		},
		Spec: v1.PersistentVolumeClaimSpec{
			AccessModes: pv.Spec.AccessModes,
			Resources: v1.VolumeResourceRequirements{
				Requests: pv.Spec.Capacity,
			},
			VolumeName:       pv.Name,
			StorageClassName: &pv.Spec.StorageClassName,
		},
	}
	_, err := Clientset.CoreV1().PersistentVolumes().Create(context.TODO(), pv, metav1.CreateOptions{})
	if err != nil {
		return nil, err
	}
	return Clientset.CoreV1().PersistentVolumeClaims(string(release.Namespace())).Create(context.TODO(), pvc, metav1.CreateOptions{})
}

func prepareK8s(t *testing.T, releaseName model.ReleaseName) (Closeable, error) {
	var closeables []Closeable

	addCloseable := func(closeable Closeable) {
		closeables = append([]Closeable{closeable}, closeables...)
	}

	cleanupNamespace, err := createNamespace(t, releaseName)
	addCloseable(cleanupNamespace)
	if err != nil {
		return AsCloseable(closeables), err
	}

	createSecretCommands, cleanupCertificates, err := kCreateSecret(releaseName.Namespace())
	addCloseable(cleanupCertificates)
	if err != nil {
		return AsCloseable(closeables), err
	}

	err = runAll(t, "kubectl", createSecretCommands, true)
	if err != nil {
		return AsCloseable(closeables), err
	}

	return AsCloseable(closeables), nil
}

func runSubTests(t *testing.T, subTests []SubTest) {
	t.Cleanup(func() { t.Logf("Finished running all tests in '%s'", t.Name()) })

	for _, test := range subTests {

		t.Run(test.name, func(t *testing.T) {
			t.Logf("Started running subtest '%s'", t.Name())
			t.Cleanup(func() { t.Logf("Finished running subtest '%s'", t.Name()) })
			test.test(t)
		})
	}
}

func installNeo4j(t *testing.T, releaseName model.ReleaseName, chart model.Neo4jHelmChartBuilder, extraHelmInstallArgs ...string) (Closeable, error) {
	err := waitForClusterConnection(t)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to cluster: %v", err)
	}

	closeables := []Closeable{}
	addCloseable := func(closeable Closeable) {
		closeables = append([]Closeable{closeable}, closeables...)
	}

	closeable, err := prepareK8s(t, releaseName)
	addCloseable(closeable)
	if err != nil {
		return AsCloseable(closeables), err
	}

	closeable, err = InstallNeo4jInGcloud(t, gcloud.CurrentZone(), gcloud.CurrentProject(), releaseName, chart, extraHelmInstallArgs...)
	addCloseable(closeable)
	if err != nil {
		return AsCloseable(closeables), err
	}

	err = run(t, "kubectl", "--namespace", string(releaseName.Namespace()), "rollout", "status", "--watch", "--timeout=120s", "statefulset/"+releaseName.String())
	return AsCloseable(closeables), err
}

func TestBackupLogStreamingIntegration(t *testing.T, releaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}

	backupReleaseName := model.NewReleaseName("standalone-backup-logs-" + TestNamespace(t))
	namespace := string(releaseName.Namespace())

	t.Cleanup(func() {
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	// Install backup chart without cloud provider to use local volume
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", releaseName.String()),
		DatabaseNamespace:        namespace,
		Database:                 "neo4j,system",
		CloudProvider:            "",
		Verbose:                  true,
		Type:                     "FULL",
		KeepBackupFiles:          true,
	}
	helmValues.Neo4J.JobSchedule = "* * * * *"

	_, err := helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	if err != nil {
		return fmt.Errorf("helm install failed: %v", err)
	}

	// Poll for backup job completion
	t.Log("Waiting for backup log streaming job to complete")

	deadline := time.Now().Add(8 * time.Minute)
	var backupPodFound bool

	for time.Now().Before(deadline) {
		pods, listErr := Clientset.CoreV1().Pods(namespace).List(context.Background(), metav1.ListOptions{})
		if listErr != nil {
			t.Logf("Error retrieving pod list: %v", listErr)
			time.Sleep(30 * time.Second)
			continue
		}

		for _, pod := range pods.Items {
			if strings.Contains(pod.Name, "standalone-backup-logs") {
				backupPodFound = true
				t.Logf("Found backup log streaming pod: %s (status: %s)", pod.Name, pod.Status.Phase)

				logOutput, logsErr := kubectlLogs(t, pod.Name, namespace)
				if logsErr != nil {
					time.Sleep(30 * time.Second)
					continue
				}

				if !strings.Contains(logOutput, "Backup completed successfully") {
					t.Log("Backup not yet completed, waiting...")
					time.Sleep(30 * time.Second)
					continue
				}

				t.Logf("Backup log streaming pod logs:\n%s", logOutput)
				t.Log("Backup log streaming completed successfully!")
				return nil
			}
		}

		if !backupPodFound {
			t.Log("Backup log streaming pod not yet created, waiting...")
		}
		time.Sleep(30 * time.Second)
	}

	if !backupPodFound {
		return fmt.Errorf("no backup pod found after polling")
	}
	return fmt.Errorf("backup did not complete within timeout")
}

func TestBackupCompressIntegration(t *testing.T, releaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}

	backupReleaseName := model.NewReleaseName("standalone-backup-compress-" + TestNamespace(t))
	namespace := string(releaseName.Namespace())

	t.Cleanup(func() {
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	// Install backup chart with compress option enabled
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", releaseName.String()),
		DatabaseNamespace:        namespace,
		Database:                 "neo4j,system",
		CloudProvider:            "",
		Verbose:                  true,
		Type:                     "FULL",
		KeepBackupFiles:          true,
		Compress:                 true,
	}
	helmValues.Neo4J.JobSchedule = "* * * * *"

	_, err := helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	if err != nil {
		return fmt.Errorf("helm install failed: %v", err)
	}

	_, logOutput, pollErr := waitForBackupPodCompletion(t, namespace, "standalone-backup-compress", "Backup completed successfully", 8*time.Minute)
	if pollErr != nil {
		return pollErr
	}

	if !strings.Contains(logOutput, "--compress=true") {
		return fmt.Errorf("expected log entry '--compress=true' not found in logs:\n%s", logOutput)
	}

	return nil
}

// TestAggregateBackupWithWildcard tests aggregate backup functionality with wildcard database selector
func TestAggregateBackupWithWildcard(t *testing.T, standaloneReleaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}

	namespace := string(standaloneReleaseName.Namespace())

	// Step 1: Create initial backups for multiple databases (neo4j and system)
	t.Log("Step 1: Creating initial backups for neo4j and system databases")
	initialBackupReleaseName := model.NewReleaseName("wildcard-initial-backup-" + TestNamespace(t))

	t.Cleanup(func() {
		_ = runAll(t, "helm", [][]string{
			{"uninstall", initialBackupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	// Use cloud storage so all backup jobs can share the same backup files
	bucketName := model.BucketName
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	initialHelmValues := model.DefaultNeo4jBackupValues
	initialHelmValues.Backup = model.Backup{
		BucketName:               bucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", standaloneReleaseName.String()),
		DatabaseNamespace:        namespace,
		Database:                 "neo4j,system", // Backup both databases
		CloudProvider:            "gcp",
		SecretName:               "gcpcred",
		SecretKeyName:            "credentials",
		KeepBackupFiles:          true,
		Type:                     "FULL",
		Verbose:                  true,
	}
	initialHelmValues.ConsistencyCheck.Enable = false

	t.Logf("Installing initial backup chart to create backups for neo4j and system")
	_, err := helmClient.Install(t, initialBackupReleaseName.String(), namespace, initialHelmValues)
	if err != nil {
		return fmt.Errorf("failed to install initial backup helm chart: %v", err)
	}

	_, _, initialPollErr := waitForBackupPodCompletion(t, namespace, "wildcard-initial-backup", "Cloud backup completed successfully", 8*time.Minute)
	if initialPollErr != nil {
		return fmt.Errorf("initial backup did not complete: %v", initialPollErr)
	}

	// Uninstall FULL backup CronJob to prevent interference with the aggregate step
	t.Log("Uninstalling FULL backup CronJob before proceeding to aggregate")
	_ = runAll(t, "helm", [][]string{
		{"uninstall", initialBackupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
	}, false)

	// Step 2: Run aggregate backup with wildcard
	t.Log("Step 2: Running aggregate backup with wildcard")
	aggregateBackupReleaseName := model.NewReleaseName("wildcard-aggregate-backup-" + TestNamespace(t))

	t.Cleanup(func() {
		_ = runAll(t, "helm", [][]string{
			{"uninstall", aggregateBackupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	aggregateHelmValues := model.DefaultNeo4jBackupValues
	aggregateHelmValues.Backup = model.Backup{
		BucketName:               bucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", standaloneReleaseName.String()),
		DatabaseNamespace:        namespace,
		Database:                 "*",
		CloudProvider:            "gcp",
		SecretName:               "gcpcred",
		SecretKeyName:            "credentials",
		KeepBackupFiles:          true,
		Verbose:                  true,
		AggregateBackup: model.AggregateBackup{
			Enabled:          true,
			Database:         "*",
			FromPath:         "",
			KeepOldBackup:    false,
			ParallelRecovery: false,
			Verbose:          true,
		},
	}
	aggregateHelmValues.ConsistencyCheck.Enable = false

	t.Logf("Installing aggregate backup chart with wildcard database selector")
	_, err = helmClient.Install(t, aggregateBackupReleaseName.String(), namespace, aggregateHelmValues)
	if err != nil {
		return fmt.Errorf("failed to install aggregate backup helm chart: %v", err)
	}

	// Step 3: Poll for aggregate backup completion and verify logs
	t.Log("Step 3: Waiting for aggregate backup with wildcard to complete")

	deadline := time.Now().Add(8 * time.Minute)
	var aggregateBackupPodFound bool

	for time.Now().Before(deadline) {
		pods, err := Clientset.CoreV1().Pods(namespace).List(context.Background(), metav1.ListOptions{})
		if err != nil {
			t.Logf("Error retrieving pod list: %v", err)
			time.Sleep(30 * time.Second)
			continue
		}

		for _, pod := range pods.Items {
			if strings.Contains(pod.Name, "wildcard-aggregate-backup") {
				aggregateBackupPodFound = true
				t.Logf("Found aggregate backup pod: %s (status: %s)", pod.Name, pod.Status.Phase)

				logOutput, logsErr := kubectlLogs(t, pod.Name, namespace)
				if logsErr != nil {
					time.Sleep(30 * time.Second)
					continue
				}

				if !strings.Contains(logOutput, "Aggregate backup completed successfully") {
					t.Log("Aggregate backup not yet completed, waiting...")
					time.Sleep(30 * time.Second)
					continue
				}

				t.Logf("Aggregate backup pod logs:\n%s", logOutput)

				expectedLogEntries := []string{
					"Wildcard '*' detected",
					"passing to neo4j-admin for native wildcard handling",
					"Aggregate backup completed successfully",
				}

				for _, expectedLog := range expectedLogEntries {
					if !strings.Contains(logOutput, expectedLog) {
						return fmt.Errorf("expected log entry '%s' not found in aggregate backup logs:\n%s", expectedLog, logOutput)
					}
				}

				t.Log("Aggregate backup with wildcard completed successfully!")
				goto aggregateDone
			}
		}

		if !aggregateBackupPodFound {
			t.Log("Aggregate backup pod not yet created, waiting...")
		}
		time.Sleep(30 * time.Second)
	}

	if !aggregateBackupPodFound {
		return fmt.Errorf("no aggregate backup pod found after polling")
	}
	return fmt.Errorf("aggregate backup did not complete within timeout")

aggregateDone:

	return nil
}

func k8sTests(name model.ReleaseName, chart model.Neo4jHelmChartBuilder) ([]SubTest, error) {
	expectedConfiguration, err := (&model.Neo4jConfiguration{}).PopulateFromFile(Neo4jConfFile)
	if err != nil {
		return nil, err
	}
	log.Printf("%v", expectedConfiguration)
	return []SubTest{
		{name: "Check Neo4j Logs For Any Errors", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, checkNeo4jLogsForAnyErrors(t, name), "Neo4j Logs check should succeed")
		}},
		{name: "Check Neo4j Configuration", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, checkNeo4jConfiguration(t, name, expectedConfiguration), "Neo4j Config check should succeed")
		}},
		{name: "Check Bloom Version", test: func(t *testing.T) { assert.NoError(t, checkBloomVersion(t, name), "Retrieve a valid BLOOM version") }},
		{name: "Create Node", test: func(t *testing.T) { assert.NoError(t, createNode(t, name), "Create Node should succeed") }},
		{name: "Delete Resources", test: func(t *testing.T) { assert.NoError(t, ResourcesCleanup(t, name), "Cleanup Resources should succeed") }},
		{name: "Reinstall Resources", test: func(t *testing.T) {
			assert.NoError(t, ResourcesReinstall(t, name, chart), "Reinstall Resources should succeed")
		}},
		{name: "Count Nodes", test: func(t *testing.T) { assert.NoError(t, checkNodeCount(t, name), "Count Nodes should succeed") }},
		{name: "Check Probes", test: func(t *testing.T) { assert.NoError(t, CheckProbes(t, name), "Probes Matching should succeed") }},
		{name: "Check Service Annotations", test: func(t *testing.T) {
			assert.NoError(t, CheckServiceAnnotations(t, name, chart), "Services should have annotations")
		}},
		{name: "Check RunAsNonRoot", test: func(t *testing.T) { assert.NoError(t, RunAsNonRoot(t, name), "RunAsNonRoot check should succeed") }},
		{name: "Exec in Pod", test: func(t *testing.T) { assert.NoError(t, CheckExecInPod(t, name), "Exec in Pod should succeed") }},
		{name: "Install Backup Helm Chart For GCP With Inconsistencies", test: func(t *testing.T) {
			assert.NoError(t, InstallNeo4jBackupGCPHelmChartWithInconsistencies(t, name), "Backup to GCP should succeed along with upload of inconsistencies report")
		}},
		{name: "Install Backup Helm Chart For GCP With Workload Identity", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, InstallNeo4jBackupGCPHelmChartWithWorkloadIdentity(t, name), "Backup to GCP with workload identity should succeed")
		}},
		{name: "Install Backup Helm Chart For AWS", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, InstallNeo4jBackupAWSHelmChart(t, name), "Backup to AWS should succeed")
		}},
		{name: "Install Backup Helm Chart For Azure", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, InstallNeo4jBackupAzureHelmChart(t, name), "Backup to Azure should succeed")
		}},
		{name: "Install Backup Helm Chart For GCP", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, InstallNeo4jBackupGCPHelmChart(t, name), "Backup to GCP should succeed")
		}},
		{name: "Install Reverse Proxy Helm Chart", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, InstallReverseProxyHelmChart(t, name), "Reverse Proxy installation with ingress should succeed")
		}},
		{name: "Install Backup With File Cleanup", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, InstallNeo4jBackupWithFileCleanup(t, name), "Backup with file cleanup should succeed")
		}},
		{name: "Check Backup Log Streaming", test: func(t *testing.T) {
			assert.NoError(t, TestBackupLogStreamingIntegration(t, name), "Backup log streaming should work correctly")
		}},
		{name: "Check Backup Compression", test: func(t *testing.T) {
			assert.NoError(t, TestBackupCompressIntegration(t, name), "Backup compression should work correctly")
		}},
		{name: "Test Aggregate Backup With Wildcard", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, TestAggregateBackupWithWildcard(t, name), "Aggregate backup with wildcard should work correctly")
		}},
	}, nil
}

func waitForServiceAccountCreation(projectID, serviceAccountEmail string, maxRetries int) error {
	for i := 0; i < maxRetries; i++ {
		cmd := exec.Command("gcloud", "iam", "service-accounts", "describe",
			serviceAccountEmail,
			"--project", projectID)

		if err := cmd.Run(); err == nil {
			return nil
		}

		time.Sleep(time.Duration(math.Pow(2, float64(i))) * time.Second)
	}
	return fmt.Errorf("service account %s was not created after %d retries",
		serviceAccountEmail, maxRetries)
}

// runGcloudCommandWithRetry executes gcloud commands with retry logic for concurrent policy changes errors
func runGcloudCommandWithRetry(cmd *exec.Cmd, maxRetries int, description string) ([]byte, []byte, error) {
	for attempt := 0; attempt < maxRetries; attempt++ {
		stdout, stderr, err := RunCommand(cmd)

		if err == nil {
			return stdout, stderr, nil
		}

		// Check if this is the specific concurrent policy changes error
		stderrStr := string(stderr)
		if strings.Contains(stderrStr, "There were concurrent policy changes") &&
			strings.Contains(stderrStr, "Please retry the whole read-modify-write with exponential backoff") {

			if attempt < maxRetries-1 { // Don't sleep on the last attempt
				backoffDuration := time.Duration(math.Pow(2, float64(attempt))) * time.Second
				log.Printf("Concurrent policy changes detected for %s, retrying in %v (attempt %d/%d)",
					description, backoffDuration, attempt+1, maxRetries)
				time.Sleep(backoffDuration)
				continue
			}
		}

		// If it's not the concurrent policy error or we've exhausted retries, return the error
		return stdout, stderr, err
	}

	return nil, nil, fmt.Errorf("failed after %d retries for %s", maxRetries, description)
}

func InstallNeo4jBackupAWSHelmChart(t *testing.T, standaloneReleaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}
	backupReleaseName := model.NewReleaseName("standalone-backup-aws-" + TestNamespace(t))
	backupBucketName := fmt.Sprintf("helm-charts-%s", TestNamespace(t))
	namespace := string(standaloneReleaseName.Namespace())

	t.Logf("Using namespace: %s for AWS backup test", namespace)

	// Use defer to ensure bucket cleanup happens even if function panics or returns early
	bucketCreated := false
	defer func() {
		if bucketCreated {
			if err := deleteAWSBucket(os.Getenv("AWS_ACCESS_KEY_ID"), os.Getenv("AWS_SECRET_ACCESS_KEY"), "us-east-1", backupBucketName); err != nil {
				t.Logf("WARNING: Failed to delete AWS bucket %s during cleanup: %v", backupBucketName, err)
			} else {
				t.Logf("Successfully deleted AWS bucket %s", backupBucketName)
			}
		}
	}()

	t.Cleanup(func() {
		_ = runAll(t, "kubectl", [][]string{
			{"delete", "secret", "awscred", "--namespace", namespace, "--ignore-not-found"},
		}, false)
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
		if bucketCreated {
			if err := deleteAWSBucket(os.Getenv("AWS_ACCESS_KEY_ID"), os.Getenv("AWS_SECRET_ACCESS_KEY"), "us-east-1", backupBucketName); err != nil {
				t.Logf("WARNING: Failed to delete AWS bucket %s during test cleanup: %v", backupBucketName, err)
			}
		}
	})

	_, err := Clientset.CoreV1().Secrets(namespace).Get(context.TODO(), "awscred", metav1.GetOptions{})
	if err == nil {
		t.Logf("Found existing secret 'awscred' in namespace %s, deleting it", namespace)
		err = Clientset.CoreV1().Secrets(namespace).Delete(context.TODO(), "awscred", metav1.DeleteOptions{})
		if err != nil {
			return fmt.Errorf("failed to delete existing AWS credentials secret: %v", err)
		}
	}

	secretKey := &v1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "awscred",
			Namespace: namespace,
		},
		Data: map[string][]byte{
			"credentials": []byte(fmt.Sprintf("[default]\naws_access_key_id=%s\naws_secret_access_key=%s",
				os.Getenv("AWS_ACCESS_KEY_ID"),
				os.Getenv("AWS_SECRET_ACCESS_KEY"))),
		},
		Type: "Opaque",
	}

	_, err = Clientset.CoreV1().Secrets(namespace).Create(context.TODO(), secretKey, metav1.CreateOptions{})
	if err != nil {
		return fmt.Errorf("failed to create AWS credentials secret: %v", err)
	}

	_, err = Clientset.CoreV1().Secrets(namespace).Get(context.TODO(), "awscred", metav1.GetOptions{})
	if err != nil {
		return fmt.Errorf("failed to verify AWS credentials secret exists: %v", err)
	}

	t.Logf("Successfully created and verified secret 'awscred' in namespace %s", namespace)

	err = createAWSBucket(os.Getenv("AWS_ACCESS_KEY_ID"), os.Getenv("AWS_SECRET_ACCESS_KEY"), "us-east-1", backupBucketName)
	if err != nil {
		return fmt.Errorf("failed to create AWS bucket: %v", err)
	}
	bucketCreated = true
	t.Logf("Successfully created AWS bucket %s", backupBucketName)

	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		BucketName:               backupBucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", standaloneReleaseName.String()),
		DatabaseNamespace:        namespace,
		Database:                 "neo4j,system",
		CloudProvider:            "aws",
		SecretName:               "awscred",
		SecretKeyName:            "credentials",
		Verbose:                  true,
		KeepBackupFiles:          true,
		Type:                     "FULL",
		S3ForcePathStyle:         true,
		S3Region:                 "us-east-1",
		S3SignatureVersion:       "4",
	}
	helmValues.ConsistencyCheck.Database = "neo4j"

	t.Logf("Installing helm chart in namespace %s with secret 'awscred'", namespace)
	_, err = helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	if err != nil {
		secret, getErr := Clientset.CoreV1().Secrets(namespace).Get(context.TODO(), "awscred", metav1.GetOptions{})
		if getErr != nil {
			t.Logf("Debug: Failed to get secret after helm error: %v", getErr)
		} else {
			t.Logf("Debug: Secret exists with keys: %v", secret.Data)
		}
		return fmt.Errorf("helm install failed: %v", err)
	}

	return nil
}

func InstallNeo4jBackupAzureHelmChart(t *testing.T, standaloneReleaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}
	backupReleaseName := model.NewReleaseName("standalone-backup-azure-" + TestNamespace(t))
	namespace := string(standaloneReleaseName.Namespace())

	t.Log("Starting Azure backup test")

	t.Cleanup(func() {
		t.Log("Running cleanup for Azure backup test")
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	bucketName := model.BucketName
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		BucketName:               bucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", standaloneReleaseName.String()),
		DatabaseNamespace:        string(standaloneReleaseName.Namespace()),
		Database:                 "neo4j,system",
		CloudProvider:            "azure",
		SecretName:               "azurecred",
		SecretKeyName:            "credentials",
		Verbose:                  true,
		Type:                     "FULL",
	}
	// Disable consistency checks for cloud storage backups
	helmValues.ConsistencyCheck.Enable = false
	helmValues.ConsistencyCheck.Database = ""

	t.Logf("Installing Azure backup helm chart with values: %+v", helmValues)
	_, err := helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	if err != nil {
		t.Logf("Failed to install Azure backup helm chart: %v", err)
		return err
	}

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), backupReleaseName.String(), metav1.GetOptions{})
	if err != nil {
		t.Logf("Failed to get Azure backup cronjob: %v", err)
		return fmt.Errorf("cannot retrieve azure backup cronjob: %v", err)
	}
	if cronjob.Spec.Schedule != helmValues.Neo4J.JobSchedule {
		t.Logf("Azure cronjob schedule mismatch. Got %s, want %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule)
		return fmt.Errorf("azure cronjob schedule %s not matching with the schedule defined in values.yaml %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule)
	}

	t.Log("Waiting for Azure backup job to complete")
	_, logOutput, pollErr := waitForBackupPodCompletion(t, namespace, "standalone-backup-azure", "Cloud backup completed successfully", 8*time.Minute)
	if pollErr != nil {
		return pollErr
	}

	// Check for connectivity and initialization logs
	requiredLogs := []string{
		"Connectivity established with Database",
		"Printing backup flags",
		"--include-metadata=all",
		"--type=FULL",
		"neo4j system",
		"Backup completed successfully",
	}
	for _, requiredLog := range requiredLogs {
		if !strings.Contains(logOutput, requiredLog) {
			t.Logf("Required log entry not found in Azure backup: %s", requiredLog)
			return fmt.Errorf("required log entry not found in Azure backup: %s", requiredLog)
		}
	}

	t.Log("Azure backup test completed successfully")
	return nil
}

func InstallNeo4jBackupGCPHelmChart(t *testing.T, standaloneReleaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}
	backupReleaseName := model.NewReleaseName("standalone-backup-gcp-" + TestNamespace(t))
	namespace := string(standaloneReleaseName.Namespace())

	t.Log("Starting GCP backup test")

	t.Cleanup(func() {
		t.Log("Running cleanup for GCP backup test")
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	bucketName := model.BucketName
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		BucketName:               bucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", standaloneReleaseName.String()),
		DatabaseNamespace:        string(standaloneReleaseName.Namespace()),
		Database:                 "neo4j,system",
		CloudProvider:            "gcp",
		SecretName:               "gcpcred",
		SecretKeyName:            "credentials",
		Verbose:                  true,
		Type:                     "FULL",
		KeepBackupFiles:          true,
	}
	// Explicitly disable consistency checks for cloud storage backups to avoid timeouts
	// This follows the same pattern used for AWS cloud backups
	helmValues.ConsistencyCheck.Enable = false
	helmValues.ConsistencyCheck.Database = ""

	t.Logf("Installing GCP backup helm chart with values: %+v", helmValues)
	_, err := helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	if err != nil {
		t.Logf("Failed to install GCP backup helm chart: %v", err)
		return err
	}

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), backupReleaseName.String(), metav1.GetOptions{})
	if err != nil {
		t.Logf("Failed to get GCP backup cronjob: %v", err)
		return fmt.Errorf("cannot retrieve gcp backup cronjob: %v", err)
	}
	if cronjob.Spec.Schedule != helmValues.Neo4J.JobSchedule {
		t.Logf("GCP cronjob schedule mismatch. Got %s, want %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule)
		return fmt.Errorf("gcp cronjob schedule %s not matching with the schedule defined in values.yaml %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule)
	}

	_, logOutput, pollErr := waitForBackupPodCompletion(t, namespace, "standalone-backup-gcp", "Cloud backup completed successfully", 8*time.Minute)
	if pollErr != nil {
		return pollErr
	}

	requiredLogs := []string{
		"Connectivity established with Database",
		"Printing backup flags",
		"--include-metadata=all",
		"--type=FULL",
		"neo4j system",
		"Backup completed successfully",
	}
	for _, requiredLog := range requiredLogs {
		if !strings.Contains(logOutput, requiredLog) {
			return fmt.Errorf("required log entry not found in GCP backup: %s", requiredLog)
		}
	}

	t.Log("GCP backup test completed successfully")
	return nil
}

func InstallNeo4jBackupGCPHelmChartWithInconsistencies(t *testing.T, standaloneReleaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}

	t.Log("Starting backup test with inconsistencies")
	err := introduceInconsistency(t, standaloneReleaseName)
	if err != nil {
		t.Logf("Failed to introduce inconsistency: %v", err)
		return err
	}

	// First run local backup with consistency check
	err = installNeo4jBackupLocalWithConsistencyCheck(t, standaloneReleaseName)
	if err != nil {
		t.Logf("Local backup with consistency check failed: %v", err)
		return err
	}

	// Then run GCP cloud backup without consistency check
	err = installNeo4jBackupGCPCloudStorage(t, standaloneReleaseName)
	if err != nil {
		t.Logf("GCP cloud backup failed: %v", err)
		return err
	}

	t.Log("Reverting inconsistency")
	err = revertInconsistency(standaloneReleaseName)
	if err != nil {
		t.Logf("Failed to revert inconsistency: %v", err)
		return fmt.Errorf("error seen while reverting inconsistency: %v", err)
	}

	t.Log("Backup test completed successfully")
	return nil
}

// installNeo4jBackupLocalWithConsistencyCheck performs local backup with consistency check
func installNeo4jBackupLocalWithConsistencyCheck(t *testing.T, standaloneReleaseName model.ReleaseName) error {
	backupReleaseName := model.NewReleaseName("standalone-backup-local-incon-" + TestNamespace(t))
	namespace := string(standaloneReleaseName.Namespace())

	t.Cleanup(func() {
		t.Log("Running cleanup for local backup test")
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", standaloneReleaseName.String()),
		DatabaseNamespace:        namespace,
		Database:                 "neo4j,system",
		CloudProvider:            "", // Local backup
		Verbose:                  true,
		Type:                     "FULL",
		KeepBackupFiles:          true,
	}

	// Enable consistency check for local backup
	helmValues.ConsistencyCheck.Enable = true
	helmValues.ConsistencyCheck.Database = "neo4j"

	t.Logf("Installing local backup helm chart with values: %+v", helmValues)
	_, err := helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	if err != nil {
		t.Logf("Failed to install local backup helm chart: %v", err)
		return err
	}

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), backupReleaseName.String(), metav1.GetOptions{})
	if err != nil {
		t.Logf("Failed to get local backup cronjob: %v", err)
		return fmt.Errorf("cannot retrieve local backup cronjob: %v", err)
	}

	if cronjob.Spec.Schedule != helmValues.Neo4J.JobSchedule {
		t.Logf("Local backup cronjob schedule mismatch. Got %s, want %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule)
		return fmt.Errorf("local backup cronjob schedule %s not matching with the schedule defined in values.yaml %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule)
	}

	// Poll for backup completion with consistency check - reasonable timeout for local backup
	deadline := time.Now().Add(10 * time.Minute)
	var found bool
	var logOutput string

	for !time.Now().After(deadline) {
		pods, err := Clientset.CoreV1().Pods(namespace).List(context.Background(), metav1.ListOptions{})
		if err != nil {
			t.Logf("Error retrieving pod list: %v", err)
			time.Sleep(30 * time.Second)
			continue
		}

		found = false
		for _, pod := range pods.Items {
			if strings.Contains(pod.Name, "standalone-backup-local-incon") {
				found = true
				t.Logf("Found local backup pod: %s", pod.Name)
				t.Logf("Pod status: %s", pod.Status.Phase)

				var logsErr error
				logOutput, logsErr = kubectlLogs(t, pod.Name, namespace)
				if logsErr != nil {
					time.Sleep(30 * time.Second)
					continue
				}
				t.Logf("Local backup pod logs (partial):\n%s", logOutput[:min(len(logOutput), 500)])

				// Check if backup completed successfully
				if !strings.Contains(logOutput, "Backup completed successfully") {
					t.Logf("Local backup not yet completed, waiting...")
					time.Sleep(30 * time.Second)
					continue
				}

				// Check if consistency check completed
				if strings.Contains(logOutput, "No inconsistencies found") ||
					strings.Contains(logOutput, "Inconsistencies found") ||
					strings.Contains(logOutput, "Consistency Check Report tar archive created") {
					t.Logf("Local backup and consistency check completed successfully")
					return nil
				} else if strings.Contains(logOutput, "Consistency Check Failed") ||
					strings.Contains(logOutput, "Consistency check timed out") {
					t.Logf("Consistency check failed or timed out")
					return fmt.Errorf("consistency check failed or timed out")
				} else {
					// Consistency check is still running
					t.Logf("Local backup completed, consistency check still in progress...")
					time.Sleep(30 * time.Second)
					continue
				}
			}
		}

		if !found {
			t.Logf("No local backup pod found yet, waiting...")
			time.Sleep(30 * time.Second)
		}
	}

	if !found {
		t.Logf("No local backup pod found after timeout")
		return fmt.Errorf("no local backup pod found")
	}

	// If we reach here, we timed out waiting for consistency check
	t.Logf("Local backup consistency check did not complete within timeout")
	return fmt.Errorf("local backup consistency check did not complete within 10 minutes")
}

// installNeo4jBackupGCPCloudStorage performs cloud backup to GCP without consistency check
func installNeo4jBackupGCPCloudStorage(t *testing.T, standaloneReleaseName model.ReleaseName) error {
	backupReleaseName := model.NewReleaseName("standalone-backup-gcp-incon-" + TestNamespace(t))
	namespace := string(standaloneReleaseName.Namespace())

	t.Cleanup(func() {
		t.Log("Running cleanup for GCP backup test")
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	bucketName := model.BucketName
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		BucketName:               bucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", standaloneReleaseName.String()),
		DatabaseNamespace:        namespace,
		Database:                 "neo4j,system",
		CloudProvider:            "gcp",
		SecretName:               "gcpcred",
		SecretKeyName:            "credentials",
		Verbose:                  true,
		Type:                     "FULL",
		KeepBackupFiles:          true,
	}

	// Disable consistency check for cloud backup to avoid timeouts
	helmValues.ConsistencyCheck.Enable = false
	helmValues.ConsistencyCheck.Database = ""

	t.Logf("Installing GCP backup helm chart with values: %+v", helmValues)
	_, err := helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	if err != nil {
		t.Logf("Failed to install GCP backup helm chart: %v", err)
		return err
	}

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), backupReleaseName.String(), metav1.GetOptions{})
	if err != nil {
		t.Logf("Failed to get GCP backup cronjob: %v", err)
		return fmt.Errorf("cannot retrieve GCP backup cronjob: %v", err)
	}

	if cronjob.Spec.Schedule != helmValues.Neo4J.JobSchedule {
		t.Logf("GCP backup cronjob schedule mismatch. Got %s, want %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule)
		return fmt.Errorf("GCP backup cronjob schedule %s not matching with the schedule defined in values.yaml %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule)
	}

	// Poll for cloud backup completion - reasonable timeout without consistency check
	deadline := time.Now().Add(8 * time.Minute)
	var found bool
	var logOutput string

	for !time.Now().After(deadline) {
		pods, err := Clientset.CoreV1().Pods(namespace).List(context.Background(), metav1.ListOptions{})
		if err != nil {
			t.Logf("Error retrieving pod list: %v", err)
			time.Sleep(30 * time.Second)
			continue
		}

		found = false
		for _, pod := range pods.Items {
			if strings.Contains(pod.Name, "standalone-backup-gcp-incon") {
				found = true
				t.Logf("Found GCP backup pod: %s", pod.Name)
				t.Logf("Pod status: %s", pod.Status.Phase)

				var logsErr error
				logOutput, logsErr = kubectlLogs(t, pod.Name, namespace)
				if logsErr != nil {
					time.Sleep(30 * time.Second)
					continue
				}
				t.Logf("GCP backup pod logs (partial):\n%s", logOutput[:min(len(logOutput), 500)])

				// Check for required log entries
				requiredLogs := []string{
					"Connectivity established with Database",
					"Printing backup flags",
					"--include-metadata=all",
					"--type=FULL",
					"neo4j system",
					"Backup completed successfully",
					"Cloud backup completed successfully",
				}

				allLogsFound := true
				for _, requiredLog := range requiredLogs {
					if !strings.Contains(logOutput, requiredLog) {
						allLogsFound = false
						t.Logf("Required log entry not found: %s", requiredLog)
						// Continue checking, don't break immediately
					}
				}

				if allLogsFound {
					t.Logf("GCP backup completed successfully with all required logs")
					return nil
				}

				// If pod completed but logs are incomplete, wait a bit longer
				if pod.Status.Phase == "Succeeded" || pod.Status.Phase == "Failed" {
					if !allLogsFound {
						t.Logf("GCP backup pod completed but missing required logs, waiting for logs to be available...")
						time.Sleep(30 * time.Second)
					}
				} else {
					// Pod still running
					t.Logf("GCP backup still in progress...")
					time.Sleep(30 * time.Second)
				}
			}
		}

		if !found {
			t.Logf("No GCP backup pod found yet, waiting...")
			time.Sleep(30 * time.Second)
		}
	}

	if !found {
		t.Logf("No GCP backup pod found after timeout")
		return fmt.Errorf("no GCP backup pod found")
	}

	// If we reach here, we timed out waiting for backup completion
	t.Logf("GCP backup did not complete within timeout")
	return fmt.Errorf("GCP backup did not complete within 8 minutes")
}

// Helper function to get minimum of two integers
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func InstallNeo4jBackupGCPHelmChartWithWorkloadIdentity(t *testing.T, standaloneReleaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}
	shortName := standaloneReleaseName.ShortName()
	currentUnixTime := time.Now().Unix()
	backupReleaseName := model.NewReleaseName(fmt.Sprintf("%s-gcp-workload-%s", shortName, TestNamespace(t)))
	gcpServiceAccountName := fmt.Sprintf("%s-%d", gcpServiceAccountNamePrefix, currentUnixTime)
	k8sServiceAccountName := fmt.Sprintf("%s-%d", k8sServiceAccountNamePrefix, currentUnixTime)
	namespace := string(standaloneReleaseName.Namespace())

	t.Cleanup(func() {
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
		_ = deleteGCPServiceAccount(gcpServiceAccountName)
	})

	serviceAccount := v1.ServiceAccount{
		TypeMeta: metav1.TypeMeta{
			Kind:       "ServiceAccount",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      k8sServiceAccountName,
			Namespace: namespace,
			Annotations: map[string]string{
				"iam.gke.io/gcp-service-account": fmt.Sprintf("%s@%s.iam.gserviceaccount.com", gcpServiceAccountName, string(gcloud.CurrentProject())),
			},
		},
	}

	_, err := Clientset.CoreV1().ServiceAccounts(namespace).Create(context.Background(), &serviceAccount, metav1.CreateOptions{})
	if err != nil {
		return fmt.Errorf("error seen while creating k8s service account %s. \n Err := %v", k8sServiceAccountName, err)
	}

	err = createGCPServiceAccount(k8sServiceAccountName, namespace, gcpServiceAccountName)
	if err != nil {
		return fmt.Errorf("error seen while creating GCP service account. \n Err := %v", err)
	}

	bucketName := model.BucketName
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		BucketName:               bucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", standaloneReleaseName.String()),
		DatabaseNamespace:        string(standaloneReleaseName.Namespace()),
		Database:                 "neo4j,system",
		CloudProvider:            "gcp",
		Verbose:                  true,
		Type:                     "FULL",
		KeepBackupFiles:          true,
	}
	helmValues.ServiceAccountName = k8sServiceAccountName

	// Disable consistency checks for cloud storage backups to avoid timeouts
	helmValues.ConsistencyCheck.Enable = false
	helmValues.ConsistencyCheck.Database = ""

	_, err = helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	if err != nil {
		return err
	}

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), backupReleaseName.String(), metav1.GetOptions{})
	assert.NoError(t, err, "cannot retrieve gcp backup cronjob")
	assert.Equal(t, cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule, fmt.Sprintf("gcp cronjob schedule %s not matching with the schedule defined in values.yaml %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule))

	_, logOutput, pollErr := waitForBackupPodCompletion(t, namespace, "gcp-workload", "Backup completed successfully", 8*time.Minute)
	assert.NoError(t, pollErr, "gcp workload backup did not complete")
	if pollErr == nil {
		assert.Contains(t, logOutput, "Connectivity established with Database")
		assert.Contains(t, logOutput, "Printing backup flags")
		assert.Contains(t, logOutput, "--include-metadata=all")
		assert.Contains(t, logOutput, "--type=FULL")
		assert.Contains(t, logOutput, "neo4j system")
	}

	return nil
}

func InstallReverseProxyHelmChart(t *testing.T, standaloneReleaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}
	reverseProxyReleaseName := model.NewReleaseName("rp-" + TestNamespace(t))
	namespace := string(standaloneReleaseName.Namespace())

	t.Cleanup(func() {
		_ = runAll(t, "helm", [][]string{
			{"uninstall", reverseProxyReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	helmClient := model.NewHelmClient(model.DefaultNeo4jReverseProxyChartName)
	helmValues := model.DefaultNeo4jReverseProxyValues
	helmValues.ReverseProxy.ServiceName = fmt.Sprintf("%s-admin", standaloneReleaseName.String())
	helmValues.ReverseProxy.Namespace = namespace

	err := run(t, "helm", "upgrade", "--install", "ingress-nginx", "ingress-nginx", "--repo", "https://kubernetes.github.io/ingress-nginx", "--namespace", "ingress-nginx", "--create-namespace")
	if err != nil {
		return fmt.Errorf("failed to install ingress-nginx: %w", err)
	}

	if err := waitForDeploymentReady(t, "ingress-nginx", "ingress-nginx-controller", 3*time.Minute); err != nil {
		return fmt.Errorf("ingress-nginx controller not ready: %w", err)
	}

	_, err = helmClient.Install(t, reverseProxyReleaseName.String(), namespace, helmValues)
	if err != nil {
		return fmt.Errorf("failed to install reverse proxy chart: %w", err)
	}

	reverseProxyDepName := fmt.Sprintf("%s-reverseproxy-dep", reverseProxyReleaseName.String())
	if err := waitForDeploymentReady(t, namespace, reverseProxyDepName, 3*time.Minute); err != nil {
		return fmt.Errorf("reverse proxy deployment not ready: %w", err)
	}

	deployment, err := Clientset.AppsV1().Deployments(namespace).Get(context.Background(), reverseProxyDepName, metav1.GetOptions{})
	assert.NoError(t, err, "cannot retrieve reverse proxy deployment")
	assert.NotNil(t, deployment, "no reverse proxy deployment found")

	podName, err := waitForSingleReadyPod(t, namespace,
		fmt.Sprintf("name=%s-reverseproxy", reverseProxyReleaseName.String()), 3*time.Minute)
	if err != nil {
		return fmt.Errorf("reverse proxy pod not ready: %w", err)
	}

	cmd := []string{"ls", "-lst", "/reverse-proxy"}
	stdoutCmd, _, err := ExecInPod(standaloneReleaseName, cmd, podName)
	assert.NoError(t, err, "cannot exec in reverse proxy pod")
	assert.NotContains(t, stdoutCmd, "root")
	assert.Contains(t, stdoutCmd, "neo4j")

	ingressName := fmt.Sprintf("%s-reverseproxy-ingress", reverseProxyReleaseName.String())
	ingressIP, err := waitForIngressIP(t, namespace, ingressName, 5*time.Minute)
	if err != nil {
		return fmt.Errorf("reverse proxy ingress IP not ready: %w", err)
	}

	ingressURL := fmt.Sprintf("https://%s:443", ingressIP)
	stdout, _, err := RunCommand(exec.Command("wget", "-qO-", "--no-check-certificate", ingressURL))
	assert.NoError(t, err)
	assert.NotNil(t, string(stdout), "no wget output found")
	assert.Contains(t, string(stdout), "bolt_routing")
	assert.NotContains(t, string(stdout), "8443")

	return nil
}

// waitForDeploymentReady polls until the deployment has all replicas available.
func waitForDeploymentReady(t *testing.T, namespace, deploymentName string, timeout time.Duration) error {
	return poll.Until(context.Background(), t, poll.Opts{
		Interval:      10 * time.Second,
		Timeout:       timeout,
		Description:   fmt.Sprintf("deployment %s/%s to be ready", namespace, deploymentName),
		RetryableErrs: func(error) bool { return true },
	}, func(ctx context.Context) (bool, error) {
		deployment, err := Clientset.AppsV1().Deployments(namespace).Get(ctx, deploymentName, metav1.GetOptions{})
		if err != nil {
			return false, err
		}
		return deployment.Status.ReadyReplicas > 0 && deployment.Status.ReadyReplicas == deployment.Status.Replicas, nil
	})
}

// waitForSingleReadyPod polls until exactly one Ready pod matches the label selector, then returns its name.
func waitForSingleReadyPod(t *testing.T, namespace, labelSelector string, timeout time.Duration) (string, error) {
	return poll.UntilValue(context.Background(), t, poll.Opts{
		Interval:      10 * time.Second,
		Timeout:       timeout,
		Description:   fmt.Sprintf("single Ready pod in %s with selector %q", namespace, labelSelector),
		RetryableErrs: func(error) bool { return true },
	}, func(ctx context.Context) (string, bool, error) {
		pods, err := Clientset.CoreV1().Pods(namespace).List(ctx, metav1.ListOptions{LabelSelector: labelSelector})
		if err != nil {
			return "", false, err
		}
		var ready []v1.Pod
		for _, pod := range pods.Items {
			if pod.DeletionTimestamp != nil {
				continue
			}
			for _, cond := range pod.Status.Conditions {
				if cond.Type == v1.PodReady && cond.Status == v1.ConditionTrue {
					ready = append(ready, pod)
					break
				}
			}
		}
		if len(ready) == 1 {
			return ready[0].Name, true, nil
		}
		return "", false, nil
	})
}

// waitForIngressIP polls until the Ingress has a LoadBalancer IP or hostname assigned.
func waitForIngressIP(t *testing.T, namespace, ingressName string, timeout time.Duration) (string, error) {
	return poll.UntilValue(context.Background(), t, poll.Opts{
		Interval:      10 * time.Second,
		Timeout:       timeout,
		Description:   fmt.Sprintf("ingress %s/%s to get LoadBalancer address", namespace, ingressName),
		RetryableErrs: func(error) bool { return true },
	}, func(ctx context.Context) (string, bool, error) {
		ingress, err := Clientset.NetworkingV1().Ingresses(namespace).Get(ctx, ingressName, metav1.GetOptions{})
		if err != nil {
			return "", false, err
		}
		for _, lb := range ingress.Status.LoadBalancer.Ingress {
			if lb.IP != "" {
				return lb.IP, true, nil
			}
			if lb.Hostname != "" {
				return lb.Hostname, true, nil
			}
		}
		return "", false, nil
	})
}

func createGCPServiceAccount(k8sServiceAccountName string, namespace string, gcpServiceAccountName string) error {
	//mutex required since GCP does not allow you to create and add iam policies to service accounts concurrently
	log.Printf("k8sServiceAccountName = %s \n gcpServiceAccountName = %s", k8sServiceAccountName, gcpServiceAccountName)
	mutex.Lock()
	project := string(gcloud.CurrentProject())
	stdout, stderr, err := RunCommand(exec.Command("gcloud", "iam", "service-accounts", "create", gcpServiceAccountName,
		fmt.Sprintf("--project=%s", project)))
	if err != nil {
		return fmt.Errorf("error seen while trying to create gcp service account  %s \n Here's why err := %s \n stderr := %s", gcpServiceAccountName, err, string(stderr))
	}
	serviceAccountEmail := fmt.Sprintf("%s@%s.iam.gserviceaccount.com", gcpServiceAccountName, project)
	serviceAccountConfig := fmt.Sprintf("serviceAccount:%s", serviceAccountEmail)
	log.Printf("serviceAccountConfig %s serviceAccountEmail %s", serviceAccountConfig, serviceAccountEmail)
	log.Printf("GCP service account creation done \n Stdout = %s \n Stderr = %s", string(stdout), string(stderr))
	time.Sleep(10 * time.Second)

	if err := waitForServiceAccountCreation(project, serviceAccountEmail, 5); err != nil {
		return fmt.Errorf("failed waiting for service account creation: %v", err)
	}

	for _, role := range gcpServiceAccountProjectRoles {
		stdout, stderr, err = runGcloudCommandWithRetry(exec.Command("gcloud", "projects", "add-iam-policy-binding",
			project, "--member", serviceAccountConfig, "--role", role), 3, role+" role binding")
		if err != nil {
			return fmt.Errorf("error seen while trying to add %s iam policy binding to gcp service account %s \n Here's why err := %s \n stderr := %s", role, gcpServiceAccountName, err, string(stderr))
		}
		log.Printf("Added %s to %s \n Stdout = %s \n Stderr = %s", role, serviceAccountEmail, string(stdout), string(stderr))
	}

	stdout, stderr, err = runGcloudCommandWithRetry(exec.Command("gcloud", "iam", "service-accounts", "add-iam-policy-binding",
		serviceAccountEmail, "--role", "roles/iam.workloadIdentityUser",
		"--member", fmt.Sprintf("serviceAccount:%s.svc.id.goog[%s/%s]", string(gcloud.CurrentProject()), namespace, k8sServiceAccountName)), 3, "workloadIdentityUser role binding")
	if err != nil {
		return fmt.Errorf("error seen while trying to add iam policy binding to k8s service account %s \n Here's why err := %s \n stderr := %s", k8sServiceAccountName, err, string(stderr))
	}
	log.Printf("Adding iam policy binding to service account \n Stdout = %s \n Stderr = %s", string(stdout), string(stderr))

	// sleep for few seconds to allow the settings be applied...immediate helm install after this step leads to failure
	time.Sleep(60 * time.Second)
	mutex.Unlock()
	return nil
}

// introduceInconsistency corrupts a neo4j database relationship store file to introduce inconsistency
func introduceInconsistency(t *testing.T, releaseName model.ReleaseName) error {

	err := createMoviesDataSet(t, releaseName)
	if !assert.NoError(t, err) {
		return err
	}

	err = stopDatabase(t, releaseName, "neo4j")
	if !assert.NoError(t, err) {
		return err
	}

	// corrupting the database
	// echo "" > /var/lib/neo4j/data/databases/neo4j/block.relationship.xd.db
	cmd := []string{
		"bash",
		"-c",
		"cp /var/lib/neo4j/data/databases/neo4j/block.relationship.xd.db /var/lib/neo4j/data/block.relationship.xd.db.bak && echo '' > /var/lib/neo4j/data/databases/neo4j/block.relationship.xd.db",
	}
	stdout, stderr, err := ExecInPod(releaseName, cmd, "")
	if err != nil {
		return fmt.Errorf("error seen while executing command `echo \"\" > /var/lib/neo4j/data/databases/neo4j/block.relationship.xd.db' ,\n err :- %v", err)
	}
	if len(stderr) != 0 {
		return fmt.Errorf("found something in stderr while introducing inconsistency %v\n", stderr)
	}
	log.Printf("stdout of echo command for introducing inconsistency %s\n", stdout)

	err = startDatabase(t, releaseName, "neo4j")
	if !assert.NoError(t, err) {
		return err
	}

	return nil
}

// revertInconsistency replaces the corrupted file
func revertInconsistency(releaseName model.ReleaseName) error {

	cmd := []string{
		"bash",
		"-c",
		"mv /var/lib/neo4j/data/block.relationship.xd.db.bak /var/lib/neo4j/data/databases/neo4j/block.relationship.xd.db",
	}
	stdout, stderr, err := ExecInPod(releaseName, cmd, "")
	if err != nil {
		return fmt.Errorf("error seen while executing command `mv /var/lib/neo4j/data/block.relationship.xd.db.bak /var/lib/neo4j/data/databases/neo4j/block.relationship.xd.db' ,\n err :- %v", err)
	}
	if strings.TrimSpace(stderr) != "" {
		return fmt.Errorf("stderr is not empty while reverting inconsistency%v\n", stderr)
	}
	log.Printf("stdout while reverting inconsistency %s \n", stdout)
	return nil
}

func deleteGCPServiceAccount(gcpServiceAccountName string) error {
	log.Printf("Deleting GCP Service Account %s", gcpServiceAccountName)
	project := string(gcloud.CurrentProject())
	serviceAccountEmail := fmt.Sprintf("%s@%s.iam.gserviceaccount.com", gcpServiceAccountName, project)
	serviceAccountConfig := fmt.Sprintf("serviceAccount:%s", serviceAccountEmail)

	// Revoke project-level bindings BEFORE deleting the SA. If we delete
	// first, the bindings are stranded as `deleted:serviceAccount:...`
	// ghost members and GCP will fail subsequent add-iam-policy-binding
	// calls on this project with "Service account X does not exist",
	// referencing the ghost rather than anything the failing test touched.
	for _, role := range gcpServiceAccountProjectRoles {
		_, stderr, err := runGcloudCommandWithRetry(exec.Command("gcloud", "projects", "remove-iam-policy-binding",
			project, "--member", serviceAccountConfig, "--role", role), 3, "remove "+role+" binding")
		if err != nil {
			log.Printf("warning: failed to remove %s binding for %s: %v; stderr=%s", role, serviceAccountEmail, err, string(stderr))
		}
	}

	_, _, err := RunCommand(exec.Command("gcloud", "iam", "service-accounts", "delete", serviceAccountEmail))
	if err != nil {
		return fmt.Errorf("error seen while trying to delete gcp service account %s \n Here's why err := %s ", gcpServiceAccountName, err)
	}
	return nil
}

func createAWSBucket(accessKey string, secretKey string, region string, bucketName string) error {
	// Create a custom credentials provider
	credProvider := credentials.NewStaticCredentialsProvider(accessKey, secretKey, "")

	// Load the AWS configuration with the custom credentials provider
	cfg, err := config.LoadDefaultConfig(context.TODO(),
		config.WithRegion(region),
		config.WithCredentialsProvider(credProvider),
	)
	if err != nil {
		log.Printf("Error loading AWS config: %v\n", err)
		return err
	}

	// Create an S3 client
	client := s3.NewFromConfig(cfg)

	// Create the bucket
	_, err = client.CreateBucket(context.TODO(), &s3.CreateBucketInput{
		Bucket: aws.String(bucketName),
	})

	if err != nil {
		log.Printf("Error creating bucket: %v\n", err)
		return err
	}
	log.Printf("AWS bucket %s created", bucketName)
	return nil
}

func deleteAWSBucket(accessKey string, secretKey string, region string, bucketName string) error {
	if accessKey == "" || secretKey == "" {
		return fmt.Errorf("AWS credentials not provided, cannot delete bucket %s", bucketName)
	}

	credProvider := credentials.NewStaticCredentialsProvider(accessKey, secretKey, "")

	// Load the AWS configuration with the custom credentials provider
	cfg, err := config.LoadDefaultConfig(context.TODO(),
		config.WithRegion(region),
		config.WithCredentialsProvider(credProvider),
	)
	if err != nil {
		log.Printf("Error loading AWS config: %v\n", err)
		return err
	}

	// Create an S3 client
	client := s3.NewFromConfig(cfg)

	// Check if bucket exists first
	_, err = client.HeadBucket(context.TODO(), &s3.HeadBucketInput{
		Bucket: aws.String(bucketName),
	})
	if err != nil {
		// Bucket doesn't exist or we can't access it - this is fine, consider it already cleaned up
		log.Printf("Bucket %s does not exist or is not accessible (may already be deleted): %v\n", bucketName, err)
		return nil
	}

	// Delete all objects in the bucket
	paginator := s3.NewListObjectsV2Paginator(client, &s3.ListObjectsV2Input{
		Bucket: &bucketName,
	})

	for paginator.HasMorePages() {
		page, err := paginator.NextPage(context.TODO())
		if err != nil {
			return fmt.Errorf("failed to list objects: %v", err)
		}

		if len(page.Contents) > 0 {
			var objectIds []types.ObjectIdentifier
			for _, object := range page.Contents {
				objectIds = append(objectIds, types.ObjectIdentifier{Key: object.Key})
			}

			_, err = client.DeleteObjects(context.TODO(), &s3.DeleteObjectsInput{
				Bucket: &bucketName,
				Delete: &types.Delete{Objects: objectIds},
			})
			if err != nil {
				return fmt.Errorf("failed to delete objects: %v", err)
			}
		}
	}

	// Delete the bucket
	_, err = client.DeleteBucket(context.TODO(), &s3.DeleteBucketInput{
		Bucket: aws.String(bucketName),
	})

	if err != nil {
		log.Printf("Error deleting bucket: %v\n", err)
		return err
	}
	log.Printf("AWS bucket %s deleted", bucketName)
	return nil
}

func InstallNeo4jBackupWithFileCleanup(t *testing.T, standaloneReleaseName model.ReleaseName) error {
	backupReleaseName := model.NewReleaseName(fmt.Sprintf("backup-%s", standaloneReleaseName))
	namespace := string(backupReleaseName.Namespace())

	t.Cleanup(func() {
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
			{"delete", "namespace", namespace},
		}, false)
	})

	if _, err := createNamespace(t, backupReleaseName); err != nil {
		return err
	}

	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup.SecretName = "backup-secret"
	helmValues.Backup.SecretKeyName = "credentials"
	helmValues.Backup.CloudProvider = "gcp"
	helmValues.Backup.BucketName = "backup-bucket"
	helmValues.Backup.DatabaseAdminServiceName = fmt.Sprintf("%s-admin", standaloneReleaseName)
	helmValues.Backup.Database = "neo4j,system"
	helmValues.Backup.KeepBackupFiles = false

	secretKey := &v1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "backup-secret",
			Namespace: namespace,
		},
		Data: map[string][]byte{
			"credentials": []byte("demo-credentials"),
		},
		Type: "Opaque",
	}

	_, err := Clientset.CoreV1().Secrets(namespace).Create(context.TODO(), secretKey, metav1.CreateOptions{})
	if err != nil {
		return err
	}

	_, err = helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	return err
}

func TestProbeConfigurations(t *testing.T) {
	releaseName := model.NewReleaseName("neo4j-probes")
	chart := model.Neo4jHelmChartCommunityAndEnterprise

	testCases := []struct {
		name   string
		values model.HelmValues
	}{
		{
			name: "HTTP Probe",
			values: func() model.HelmValues {
				v := model.DefaultEnterpriseValues
				v.ReadinessProbe = model.ReadinessProbe{
					HTTPGet: &model.HTTPGetAction{
						Path: "/ready",
						Port: 7474,
					},
					FailureThreshold: 30,
					TimeoutSeconds:   15,
					PeriodSeconds:    10,
				}
				return v
			}(),
		},
		{
			name: "TCP Socket Probe",
			values: func() model.HelmValues {
				v := model.DefaultEnterpriseValues
				v.ReadinessProbe = model.ReadinessProbe{
					TCPSocket: &model.TCPSocketAction{
						Port: 7687,
					},
					FailureThreshold: 20,
					TimeoutSeconds:   10,
					PeriodSeconds:    5,
				}
				return v
			}(),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			closeable, err := installNeo4j(t, releaseName, chart)
			assert.NoError(t, err)
			t.Cleanup(func() { _ = closeable() })

			err = run(t, "kubectl", "--namespace", string(releaseName.Namespace()),
				"wait", "--for=condition=ready", "pod", releaseName.PodName(),
				timeouts.KubectlPodReady())
			assert.NoError(t, err)

			err = CheckProbes(t, releaseName)
			assert.NoError(t, err)
		})
	}
}

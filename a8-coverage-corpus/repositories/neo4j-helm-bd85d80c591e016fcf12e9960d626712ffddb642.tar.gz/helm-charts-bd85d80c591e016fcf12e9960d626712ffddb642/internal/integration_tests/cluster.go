package integration_tests

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"fmt"
	"math/big"
	"os"
	"os/exec"
	"strings"
	"testing"
	"time"

	"github.com/hashicorp/go-multierror"
	. "github.com/neo4j/helm-charts/internal/helpers"
	"github.com/neo4j/helm-charts/internal/integration_tests/gcloud"
	"github.com/neo4j/helm-charts/internal/model"
	"github.com/neo4j/helm-charts/internal/testutil/poll"
	"github.com/neo4j/helm-charts/internal/testutil/timeouts"
	"github.com/stretchr/testify/assert"
	corev1 "k8s.io/api/core/v1"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/labels"
)

// labelNodes labels nodes with the two testLabel values that are actually
// consumed as nodeSelectors by this test suite:
//
//	testLabel=<namespace>-1  → core-1 pod (see model.NodeSelectorLabel)
//	testLabel=<namespace>-5  → backup pods (see installBackupCluster* helpers)
//
// Each label is applied to multiple nodes so a single GKE node replacement
// (autorepair, autoupgrade, preemption) doesn't strand the scheduler with
// no matching node — core-1 in particular is long-lived for the whole test,
// and losing its only matching node leaves it Pending forever.
func labelNodes(t *testing.T, namespace string) error {

	var errors *multierror.Error
	nodesList, err := getNodesList()
	if err != nil {
		return err
	}
	const replicaCount = 3
	if len(nodesList.Items) < 2*replicaCount {
		return fmt.Errorf("labelNodes needs at least %d nodes, got %d", 2*replicaCount, len(nodesList.Items))
	}

	assignments := []struct {
		label    string
		nodeIdxs []int
	}{
		{label: fmt.Sprintf("testLabel=%s-1", namespace), nodeIdxs: []int{0, 1, 2}},
		{label: fmt.Sprintf("testLabel=%s-5", namespace), nodeIdxs: []int{3, 4, 5}},
	}
	for _, a := range assignments {
		for _, idx := range a.nodeIdxs {
			name := nodesList.Items[idx].ObjectMeta.Name
			if err := run(t, "kubectl", "label", "nodes", name, "--overwrite", a.label); err != nil {
				errors = multierror.Append(errors, err)
				t.Logf("Node label failed for %s=%s: %v", name, a.label, err)
			}
		}
	}

	return errors.ErrorOrNil()
}

// ensureNodeLabel makes sure at least one node in the cluster carries
// testLabel=<labelValue>. GKE may replace nodes mid-test (autorepair,
// autoscaling, preemption), dropping the labels applied by labelNodes().
// If no node still has the label, this picks a node without any testLabel
// and applies it, so subsequent helm installs that use this label as a
// nodeSelector find a matching node at template evaluation time.
func ensureNodeLabel(t *testing.T, labelValue string) error {
	selector := fmt.Sprintf("testLabel=%s", labelValue)
	if _, err := getNodeWithLabel(selector); err == nil {
		return nil
	}

	nodesList, err := getNodesList()
	if err != nil {
		return err
	}

	for _, node := range nodesList.Items {
		if _, hasLabel := node.ObjectMeta.Labels["testLabel"]; hasLabel {
			continue
		}
		t.Logf("ensureNodeLabel: %s missing, applying to node %s", selector, node.ObjectMeta.Name)
		return run(t, "kubectl", "label", "nodes", node.ObjectMeta.Name, selector)
	}

	return fmt.Errorf("no unlabeled node available to apply %s", selector)
}

// removeLabelFromNodes removes label testLabel from all the nodes added via labelNodes func
func removeLabelFromNodes(t *testing.T) error {

	var errors *multierror.Error
	nodesList, err := getNodesList()
	if err != nil {
		return err
	}

	for _, node := range nodesList.Items {
		err = run(t, "kubectl", "label", "nodes", node.ObjectMeta.Name, "testLabel-")
		if err != nil {
			errors = multierror.Append(errors, err)
			t.Logf("Node Label removal failed for %s: %v", node.ObjectMeta.Name, err)
		}
	}

	return errors.ErrorOrNil()
}

// clusterTests contains all the tests related to cluster
func clusterTests(clusterRelease model.ReleaseName) ([]SubTest, error) {

	subTests := []SubTest{
		{name: "Install Backup Helm Chart For AWS Local With Consistency Check", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, InstallNeo4jBackupAWSLocalWithConsistencyCheck(t, clusterRelease), "Local backup with consistency check should succeed")
		}},
		{name: "Install Backup Helm Chart For AWS Cloud Storage", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, InstallNeo4jBackupAWSCloudStorage(t, clusterRelease), "Cloud backup to AWS S3 should succeed")
		}},
		{name: "Install Backup Helm Chart For AWS Using S3", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, InstallNeo4jBackupAWSHelmChartViaS3(t, clusterRelease), "Backup to AWS using S3 should succeed")
		}},
		{name: "Install Backup Helm Chart For AWS Using S3 with TLS", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, InstallNeo4jBackupAWSHelmChartViaS3TLS(t, clusterRelease), "Backup to AWS using S3 with TLS should succeed")
		}},
		{name: "Install Backup Helm Chart For AWS Using Custom Aggregate Tempdir", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, InstallBackupViaTempDir(t, clusterRelease), "Backup with custom aggregate tempdir should succeed")
		}},
		{name: "Check Cluster Core Logs Format", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, CheckLogsFormat(t, clusterRelease), "Cluster core logs format should be in JSON")
		}},
		{name: "Check Neo4j Operations Pod for enabling server", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, CheckNeo4jOperationsPod(t, clusterRelease), "Neo4j Operations Pod should get executed")
		}},
		{name: "ImagePullSecret tests", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, imagePullSecretTests(t, clusterRelease), "Perform ImagePullSecret Tests")
		}},
		{name: "Check PriorityClassName", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, checkPriorityClassName(t, clusterRelease), "priorityClassName should match")
		}},
		{name: "Check K8s", test: func(t *testing.T) {
			assert.NoError(t, checkK8s(t, clusterRelease), "Neo4j Config check should succeed")
		}},
		{name: "Check Ldap Password", test: func(t *testing.T) {
			assert.NoError(t, checkLdapPassword(t, clusterRelease), "LdapPassword should be set")
		}},
		{name: "Create Node", test: func(t *testing.T) {
			assert.NoError(t, createNode(t, clusterRelease), "Create Node should succeed")
		}},
		{name: "Count Nodes", test: func(t *testing.T) {
			assert.NoError(t, checkNodeCount(t, clusterRelease), "Count Nodes should succeed")
		}},
		{name: "Database Creation Tests", test: func(t *testing.T) {
			assert.NoError(t, databaseCreationTests(t, clusterRelease, "customers"), "Creates \"customer\" database and checks for its existence")
		}},
		{name: "Install Backup Helm Chart For GCP With Workload Identity For Cluster", test: func(t *testing.T) {
			assert.NoError(t, InstallNeo4jBackupGCPHelmChartWithWorkloadIdentityForCluster(t, clusterRelease), "Backup to GCP with workload identity should succeed")
		}},
	}
	return subTests, nil
}

func InstallNeo4jBackupGCPHelmChartWithWorkloadIdentityForCluster(t *testing.T, clusterReleaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}
	shortName := clusterReleaseName.ShortName()
	currentUnixTime := time.Now().Unix()
	backupReleaseName := model.NewReleaseName(fmt.Sprintf("%s-gcp-workload-%s", shortName, TestNamespace(t)))
	gcpServiceAccountName := fmt.Sprintf("%s-%d", gcpServiceAccountNamePrefix, currentUnixTime)
	k8sServiceAccountName := fmt.Sprintf("%s-%d", k8sServiceAccountNamePrefix, currentUnixTime)
	namespace := string(clusterReleaseName.Namespace())

	t.Cleanup(func() {
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
		_ = deleteGCPServiceAccount(gcpServiceAccountName)
	})

	serviceAccount := v1.ServiceAccount{
		TypeMeta: metav1.TypeMeta{
			Kind:       "ServiceAccount",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:      k8sServiceAccountName,
			Namespace: namespace,
			Annotations: map[string]string{
				"iam.gke.io/gcp-service-account": fmt.Sprintf("%s@%s.iam.gserviceaccount.com", gcpServiceAccountName, gcloud.CurrentProject()),
			},
		},
	}

	_, err := Clientset.CoreV1().ServiceAccounts(namespace).Create(context.Background(), &serviceAccount, metav1.CreateOptions{})
	assert.NoError(t, err, fmt.Sprintf("error seen while creating k8s service account for cluster %s. \n Err := %v", k8sServiceAccountName, err))

	err = createGCPServiceAccount(k8sServiceAccountName, namespace, gcpServiceAccountName)
	assert.NoError(t, err, fmt.Sprintf("error seen while creating GCP service account for cluster %s. \n Err := %v", gcpServiceAccountName, err))

	bucketName := model.BucketName
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		BucketName:               bucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", clusterReleaseName.String()),
		DatabaseNamespace:        string(clusterReleaseName.Namespace()),
		Database:                 "neo4j,system",
		CloudProvider:            "gcp",
		Verbose:                  true,
		Type:                     "FULL",
		KeepBackupFiles:          true,
	}
	helmValues.ServiceAccountName = k8sServiceAccountName

	// Explicitly disable consistency checks for cloud storage backups to avoid timeouts
	// This follows the same pattern used for AWS cloud backups
	helmValues.ConsistencyCheck.Enable = false
	helmValues.ConsistencyCheck.Database = ""

	_, err = helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	assert.NoError(t, err)

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), backupReleaseName.String(), metav1.GetOptions{})
	assert.NoError(t, err, "cannot retrieve gcp backup cronjob")
	assert.Equal(t, cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule, fmt.Sprintf("gcp cronjob schedule %s not matching with the schedule defined in values.yaml %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule))

	_, logOutput, pollErr := waitForBackupPodCompletion(t, namespace, "gcp-workload", "Backup completed successfully", 8*time.Minute)
	assert.NoError(t, pollErr, "gcp workload backup did not complete")
	if pollErr == nil {
		assert.NotContains(t, logOutput, "Deleting file")
	}

	return nil
}

// InstallNeo4jBackupAWSLocalWithConsistencyCheck performs local backup with consistency check
func InstallNeo4jBackupAWSLocalWithConsistencyCheck(t *testing.T, releaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}
	backupReleaseName := model.NewReleaseName("cluster-backup-local-" + TestNamespace(t))
	namespace := string(releaseName.Namespace())

	t.Cleanup(func() {
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", releaseName.String()),
		DatabaseNamespace:        namespace,
		Database:                 "neo4j,system",
		CloudProvider:            "", // Local backup
		Verbose:                  true,
		Type:                     "FULL",
		KeepBackupFiles:          true,
	}
	helmValues.NodeSelector = map[string]string{
		"testLabel": fmt.Sprintf("%s-5", namespace),
	}
	// Enable consistency check for local backup
	helmValues.ConsistencyCheck.Enable = true
	helmValues.ConsistencyCheck.Database = "neo4j"

	if err := ensureNodeLabel(t, fmt.Sprintf("%s-5", namespace)); err != nil {
		return err
	}

	_, err := helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	assert.NoError(t, err)

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), backupReleaseName.String(), metav1.GetOptions{})
	assert.NoError(t, err, "cannot retrieve local backup cronjob")
	assert.Equal(t, cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule, fmt.Sprintf("local backup cronjob schedule %s not matching with the schedule defined in values.yaml %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule))

	// Poll for backup completion with consistency check - shorter timeout for local backup
	deadline := time.Now().Add(10 * time.Minute) // Local backup should be much faster
	var found bool
	var logOutput string

	for !time.Now().After(deadline) {
		pods, err := Clientset.CoreV1().Pods(namespace).List(context.Background(), metav1.ListOptions{})
		if err != nil {
			t.Logf("Error retrieving pod list: %v", err)
			time.Sleep(30 * time.Second)
			continue
		}

		found = false
		for _, pod := range pods.Items {
			if strings.Contains(pod.Name, "cluster-backup-local") {
				found = true
				var logsErr error
				logOutput, logsErr = kubectlLogs(t, pod.Name, namespace)
				if logsErr != nil {
					time.Sleep(30 * time.Second)
					continue
				}

				// Check if backup completed successfully
				if !strings.Contains(logOutput, "Backup completed successfully") {
					t.Logf("Local backup not yet completed, waiting...")
					time.Sleep(30 * time.Second)
					continue
				}

				// Check if consistency check completed successfully
				if strings.Contains(logOutput, "No inconsistencies found") {
					t.Logf("Local backup and consistency check completed successfully")
					assertPodOnLabeledNode(t, pod, fmt.Sprintf("testLabel=%s-5", namespace))
					return nil
				} else if strings.Contains(logOutput, "Consistency Check Failed") || strings.Contains(logOutput, "Consistency check timed out") {
					t.Logf("Consistency check failed or timed out")
					assert.Fail(t, "Consistency check failed", "Consistency check failed or timed out. Logs: %s", logOutput)
					return fmt.Errorf("consistency check failed")
				} else {
					// Consistency check is still running
					t.Logf("Local backup completed, consistency check still in progress...")
					time.Sleep(30 * time.Second)
					continue
				}
			}
		}

		if !found {
			t.Logf("No local backup pod found yet, waiting...")
			time.Sleep(30 * time.Second)
		}
	}

	if !found {
		assert.Fail(t, "No local backup pod found after timeout")
		return fmt.Errorf("no local backup pod found")
	}

	// If we reach here, we timed out waiting for consistency check
	assert.Fail(t, "Local backup consistency check did not complete within timeout", "Final logs: %s", logOutput)
	return fmt.Errorf("local backup consistency check did not complete within 10 minutes")
}

// InstallNeo4jBackupAWSCloudStorage performs cloud backup to AWS S3 without consistency check
func InstallNeo4jBackupAWSCloudStorage(t *testing.T, releaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}
	backupReleaseName := model.NewReleaseName("cluster-backup-aws-" + TestNamespace(t))
	namespace := string(releaseName.Namespace())

	t.Cleanup(func() {
		_ = runAll(t, "kubectl", [][]string{
			{"delete", "secret", "awscred", "--namespace", namespace, "--ignore-not-found"},
		}, false)
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	_ = runAll(t, "kubectl", [][]string{
		{"delete", "secret", "awscred", "--namespace", namespace, "--ignore-not-found"},
	}, false)

	time.Sleep(2 * time.Second)

	secretKey := &v1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "awscred",
			Namespace: namespace,
		},
		Data: map[string][]byte{
			"credentials": []byte(fmt.Sprintf("[default]\nregion = us-east-1\naws_access_key_id=%s\naws_secret_access_key=%s",
				os.Getenv("AWS_ACCESS_KEY_ID"),
				os.Getenv("AWS_SECRET_ACCESS_KEY"))),
		},
		Type: "Opaque",
	}

	_, err := Clientset.CoreV1().Secrets(namespace).Create(context.TODO(), secretKey, metav1.CreateOptions{})
	if err != nil {
		return fmt.Errorf("failed to create AWS credentials secret: %v", err)
	}

	_, err = Clientset.CoreV1().Secrets(namespace).Get(context.TODO(), "awscred", metav1.GetOptions{})
	if err != nil {
		return fmt.Errorf("failed to verify AWS credentials secret exists: %v", err)
	}

	time.Sleep(2 * time.Second)

	bucketName := model.BucketName
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		BucketName:               bucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", releaseName.String()),
		DatabaseNamespace:        namespace,
		Database:                 "neo4j,system",
		CloudProvider:            "aws",
		SecretName:               "awscred",
		SecretKeyName:            "credentials",
		S3Region:                 "us-east-1",
		S3ForcePathStyle:         true,
		Verbose:                  true,
		Type:                     "FULL",
		KeepBackupFiles:          true,
	}
	helmValues.NodeSelector = map[string]string{
		"testLabel": fmt.Sprintf("%s-5", namespace),
	}
	// Disable consistency check for cloud backup to avoid timeouts and reduce template size
	helmValues.ConsistencyCheck.Enable = false
	helmValues.ConsistencyCheck.Database = ""

	if err := ensureNodeLabel(t, fmt.Sprintf("%s-5", namespace)); err != nil {
		return err
	}

	_, err = helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	assert.NoError(t, err)

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), backupReleaseName.String(), metav1.GetOptions{})
	assert.NoError(t, err, "cannot retrieve aws cloud backup cronjob")
	assert.Equal(t, cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule, fmt.Sprintf("aws cloud backup cronjob schedule %s not matching with the schedule defined in values.yaml %s", cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule))

	// Poll for cloud backup completion - reasonable timeout without consistency check
	deadline := time.Now().Add(8 * time.Minute) // Cloud backup without consistency check
	var found bool
	var logOutput string

	for !time.Now().After(deadline) {
		pods, err := Clientset.CoreV1().Pods(namespace).List(context.Background(), metav1.ListOptions{})
		if err != nil {
			t.Logf("Error retrieving pod list: %v", err)
			time.Sleep(30 * time.Second)
			continue
		}

		found = false
		for _, pod := range pods.Items {
			if strings.Contains(pod.Name, "cluster-backup-aws") {
				found = true
				var logsErr error
				logOutput, logsErr = kubectlLogs(t, pod.Name, namespace)
				if logsErr != nil {
					time.Sleep(30 * time.Second)
					continue
				}

				// Check if backup completed successfully
				if strings.Contains(logOutput, "Backup completed successfully") {
					t.Logf("Cloud backup to AWS S3 completed successfully")
					assertPodOnLabeledNode(t, pod, fmt.Sprintf("testLabel=%s-5", namespace))

					// Verify backup files were created in S3
					if strings.Contains(logOutput, "neo4j-") && strings.Contains(logOutput, "system-") {
						t.Logf("Backup files successfully uploaded to S3")
					}
					return nil
				} else {
					t.Logf("Cloud backup not yet completed, waiting...")
					time.Sleep(30 * time.Second)
					continue
				}
			}
		}

		if !found {
			t.Logf("No cloud backup pod found yet, waiting...")
			time.Sleep(30 * time.Second)
		}
	}

	if !found {
		assert.Fail(t, "No AWS cloud backup pod found after timeout")
		return fmt.Errorf("no aws cloud backup pod found")
	}

	// If we reach here, we timed out waiting for backup completion
	assert.Fail(t, "Cloud backup did not complete within timeout", "Final logs: %s", logOutput)
	return fmt.Errorf("cloud backup did not complete within 8 minutes")
}

func InstallNeo4jBackupAWSHelmChartViaS3(t *testing.T, releaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}

	namespace := "default"
	backupReleaseName := model.NewReleaseName("cluster-backup-aws-s3" + TestNamespace(t))
	secretName := "awscred"

	t.Cleanup(func() {
		_ = runAll(t, "kubectl", [][]string{
			{"delete", "secret", secretName, "--namespace", namespace, "--ignore-not-found"},
		}, false)

		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	secretKey := &v1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      secretName,
			Namespace: namespace,
		},
		Data: map[string][]byte{
			"credentials": []byte(fmt.Sprintf("[default]\naws_access_key_id=%s\naws_secret_access_key=%s",
				os.Getenv("AWS_ACCESS_KEY_ID"),
				os.Getenv("AWS_SECRET_ACCESS_KEY"))),
		},
		Type: "Opaque",
	}

	_ = runAll(t, "kubectl", [][]string{
		{"delete", "secret", secretName, "--namespace", namespace, "--ignore-not-found"},
	}, false)

	_, err := Clientset.CoreV1().Secrets(namespace).Create(context.TODO(), secretKey, metav1.CreateOptions{})
	if err != nil {
		return fmt.Errorf("failed to create AWS credentials secret: %v", err)
	}

	_, err = Clientset.CoreV1().Secrets(namespace).Get(context.TODO(), secretName, metav1.GetOptions{})
	if err != nil {
		return fmt.Errorf("failed to verify AWS credentials secret exists: %v", err)
	}

	time.Sleep(2 * time.Second)

	bucketName := model.BucketName
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		BucketName:               bucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", releaseName.String()),
		DatabaseNamespace:        string(releaseName.Namespace()),
		Database:                 "neo4j,system",
		CloudProvider:            "aws",
		SecretName:               secretName,
		SecretKeyName:            "credentials",
		S3Endpoint:               "http://localhost:9000",
		S3Region:                 "us-east-1",
		S3SignatureVersion:       "4",
		S3ForcePathStyle:         true,
		Verbose:                  true,
		KeepBackupFiles:          true,
		Type:                     "FULL",
	}
	// Disable consistency check for S3 configuration test to avoid timeouts
	// This test focuses on S3 parameters, not consistency check functionality
	helmValues.ConsistencyCheck.Enable = false
	helmValues.ConsistencyCheck.Database = ""
	helmValues.Neo4J.JobSchedule = "* * * * *"

	_, err = helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	if err != nil {
		return fmt.Errorf("helm install failed: %v", err)
	}

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), backupReleaseName.String(), metav1.GetOptions{})
	if err != nil {
		return fmt.Errorf("cannot retrieve aws backup cronjob: %v", err)
	}

	if cronjob.Spec.Schedule != helmValues.Neo4J.JobSchedule {
		return fmt.Errorf("aws cronjob schedule %s not matching with the schedule defined in values.yaml %s",
			cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule)
	}

	pod, podErr := waitForPodByName(t, namespace, "cluster-backup-aws-s3", 8*time.Minute)
	if podErr != nil {
		return podErr
	}

	for _, container := range pod.Spec.Containers {
		s3ForcePathStyleFound := false
		s3RegionFound := false
		s3SignatureVersionFound := false

		for _, env := range container.Env {
			if env.Name == "S3_FORCE_PATH_STYLE" && env.Value == "true" {
				s3ForcePathStyleFound = true
			}
			if env.Name == "AWS_REGION" && env.Value == "us-east-1" {
				s3RegionFound = true
			}
			if env.Name == "S3_SIGNATURE_VERSION" && env.Value == "4" {
				s3SignatureVersionFound = true
			}
		}

		if !s3ForcePathStyleFound {
			return fmt.Errorf("S3_FORCE_PATH_STYLE environment variable not found or not set to true")
		}
		if !s3RegionFound {
			return fmt.Errorf("AWS_REGION environment variable not found or not set to us-east-1")
		}
		if !s3SignatureVersionFound {
			return fmt.Errorf("S3_SIGNATURE_VERSION environment variable not found or not set to 4")
		}
	}

	return nil
}

func InstallNeo4jBackupAWSHelmChartViaS3TLS(t *testing.T, releaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}

	namespace := "default"
	backupReleaseName := model.NewReleaseName("cluster-backup-aws-s3-tls" + TestNamespace(t))
	secretName := "awscred"
	caCertSecretName := "s3-ca-cert"

	t.Cleanup(func() {
		_ = runAll(t, "kubectl", [][]string{
			{"delete", "secret", secretName, "--namespace", namespace, "--ignore-not-found"},
			{"delete", "secret", caCertSecretName, "--namespace", namespace, "--ignore-not-found"},
		}, false)

		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	secretKey := &v1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      secretName,
			Namespace: namespace,
		},
		Data: map[string][]byte{
			"credentials": []byte(fmt.Sprintf("[default]\naws_access_key_id=%s\naws_secret_access_key=%s",
				os.Getenv("AWS_ACCESS_KEY_ID"),
				os.Getenv("AWS_SECRET_ACCESS_KEY"))),
		},
		Type: "Opaque",
	}

	_, err := Clientset.CoreV1().Secrets(namespace).Create(context.TODO(), secretKey, metav1.CreateOptions{})
	if err != nil && !strings.Contains(err.Error(), "already exists") {
		return fmt.Errorf("failed to create AWS credentials secret: %v", err)
	}

	_, err = Clientset.CoreV1().Secrets(namespace).Get(context.TODO(), secretName, metav1.GetOptions{})
	if err != nil {
		return fmt.Errorf("failed to verify AWS credentials secret exists: %v", err)
	}

	// Create CA certificate secret
	priv, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return fmt.Errorf("failed to generate private key: %v", err)
	}

	template := &x509.Certificate{
		SerialNumber: big.NewInt(1),
		Subject: pkix.Name{
			CommonName: "s3.amazonaws.com",
		},
		NotBefore:             time.Now(),
		NotAfter:              time.Now().Add(24 * time.Hour),
		KeyUsage:              x509.KeyUsageCertSign | x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
		IsCA:                  true,
		DNSNames:              []string{"s3.amazonaws.com"},
	}

	derBytes, err := x509.CreateCertificate(rand.Reader, template, template, &priv.PublicKey, priv)
	if err != nil {
		return fmt.Errorf("failed to create certificate: %v", err)
	}

	certPEM := new(bytes.Buffer)
	pem.Encode(certPEM, &pem.Block{Type: "CERTIFICATE", Bytes: derBytes})

	caCertSecret := &v1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      caCertSecretName,
			Namespace: namespace,
		},
		Data: map[string][]byte{
			"ca.crt": certPEM.Bytes(),
		},
		Type: "Opaque",
	}

	_, err = Clientset.CoreV1().Secrets(namespace).Create(context.TODO(), caCertSecret, metav1.CreateOptions{})
	if err != nil && !strings.Contains(err.Error(), "already exists") {
		return fmt.Errorf("failed to create CA certificate secret: %v", err)
	}

	_, err = Clientset.CoreV1().Secrets(namespace).Get(context.TODO(), caCertSecretName, metav1.GetOptions{})
	if err != nil {
		return fmt.Errorf("failed to verify CA certificate secret exists: %v", err)
	}

	time.Sleep(2 * time.Second)

	bucketName := model.BucketName
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		BucketName:               bucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", releaseName.String()),
		DatabaseNamespace:        string(releaseName.Namespace()),
		Database:                 "neo4j,system",
		CloudProvider:            "aws",
		SecretName:               secretName,
		SecretKeyName:            "credentials",
		S3Endpoint:               "https://s3.amazonaws.com",
		S3CASecretName:           caCertSecretName,
		S3CASecretKey:            "ca.crt",
		S3SkipVerify:             false,
		S3ForcePathStyle:         true,
		S3Region:                 "us-east-1",
		S3SignatureVersion:       "4",
		Verbose:                  true,
		KeepBackupFiles:          true,
		Type:                     "FULL",
	}
	// Disable consistency check for S3 TLS configuration test to avoid timeouts
	// This test focuses on S3 TLS parameters, not consistency check functionality
	helmValues.ConsistencyCheck.Enable = false
	helmValues.ConsistencyCheck.Database = ""
	helmValues.Neo4J.JobSchedule = "* * * * *"
	_, err = helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	if err != nil {
		return fmt.Errorf("helm install failed: %v", err)
	}

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), backupReleaseName.String(), metav1.GetOptions{})
	if err != nil {
		return fmt.Errorf("cannot retrieve aws backup cronjob: %v", err)
	}

	if cronjob.Spec.Schedule != helmValues.Neo4J.JobSchedule {
		return fmt.Errorf("aws cronjob schedule %s not matching with the schedule defined in values.yaml %s",
			cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule)
	}

	pod, podErr := waitForPodByName(t, namespace, "cluster-backup-aws-s3-tls", 8*time.Minute)
	if podErr != nil {
		return podErr
	}

	for _, container := range pod.Spec.Containers {
		for _, volumeMount := range container.VolumeMounts {
			if volumeMount.Name == "s3-ca-cert" {
				if volumeMount.MountPath != "/s3-ca-cert" {
					return fmt.Errorf("expected CA certificate mount path to be /s3-ca-cert but got %s", volumeMount.MountPath)
				}
			}
		}
		for _, env := range container.Env {
			if env.Name == "S3_CA_CERT_PATH" {
				if env.Value != "/s3-ca-cert/ca.crt" {
					return fmt.Errorf("expected S3_CA_CERT_PATH to be /s3-ca-cert/ca.crt but got %s", env.Value)
				}
			}
		}

		s3ForcePathStyleFound := false
		s3RegionFound := false
		s3SignatureVersionFound := false

		for _, env := range container.Env {
			if env.Name == "S3_FORCE_PATH_STYLE" && env.Value == "true" {
				s3ForcePathStyleFound = true
			}
			if env.Name == "AWS_REGION" && env.Value == "us-east-1" {
				s3RegionFound = true
			}
			if env.Name == "S3_SIGNATURE_VERSION" && env.Value == "4" {
				s3SignatureVersionFound = true
			}
		}

		if !s3ForcePathStyleFound {
			return fmt.Errorf("S3_FORCE_PATH_STYLE environment variable not found or not set to true")
		}
		if !s3RegionFound {
			return fmt.Errorf("AWS_REGION environment variable not found or not set to us-east-1")
		}
		if !s3SignatureVersionFound {
			return fmt.Errorf("S3_SIGNATURE_VERSION environment variable not found or not set to 4")
		}
	}

	return nil
}

// InstallBackupViaTempDir installs backup cronjob with a custom aggregate backup tempdir
func InstallBackupViaTempDir(t *testing.T, releaseName model.ReleaseName) error {
	if model.Neo4jEdition == "community" {
		t.Skip()
		return nil
	}

	backupReleaseName := model.NewReleaseName(fmt.Sprintf("%s-backup-s3-tmp", releaseName.String()))
	namespace := string(releaseName.Namespace())
	secretName := "miniocred"
	customTempDir := "/tmp/custom-aggregate-temp"

	// Add cleanup
	t.Cleanup(func() {
		_ = runAll(t, "helm", [][]string{
			{"uninstall", backupReleaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
		}, false)
	})

	secretKey := &v1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      secretName,
			Namespace: namespace,
		},
		Data: map[string][]byte{
			"credentials": []byte(fmt.Sprintf("[default]\nregion = us-east-1\naws_access_key_id=%s\naws_secret_access_key=%s",
				os.Getenv("AWS_ACCESS_KEY_ID"),
				os.Getenv("AWS_SECRET_ACCESS_KEY"))),
		},
		Type: "Opaque",
	}

	_, err := Clientset.CoreV1().Secrets(namespace).Create(context.TODO(), secretKey, metav1.CreateOptions{})
	if err != nil {
		return fmt.Errorf("failed to create AWS credentials secret: %v", err)
	}

	_, err = Clientset.CoreV1().Secrets(namespace).Get(context.TODO(), secretName, metav1.GetOptions{})
	if err != nil {
		return fmt.Errorf("failed to verify AWS credentials secret exists: %v", err)
	}

	time.Sleep(2 * time.Second)

	bucketName := model.BucketName
	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup = model.Backup{
		BucketName:               bucketName,
		DatabaseAdminServiceName: fmt.Sprintf("%s-admin", releaseName.String()),
		DatabaseNamespace:        string(releaseName.Namespace()),
		Database:                 "neo4j,system",
		CloudProvider:            "aws",
		SecretName:               secretName,
		SecretKeyName:            "credentials",
		S3Endpoint:               "s3.amazonaws.com",
		S3ForcePathStyle:         true,
		Verbose:                  true,
		Type:                     "FULL",
		AggregateBackup: model.AggregateBackup{
			Enabled: true,
			TempDir: customTempDir,
		},
	}
	// Disable consistency check for temp directory configuration test to avoid timeouts
	// This test focuses on custom temp directory functionality, not consistency check
	helmValues.ConsistencyCheck.Enable = false
	helmValues.ConsistencyCheck.Database = ""
	helmValues.Neo4J.JobSchedule = "* * * * *"

	_, err = helmClient.Install(t, backupReleaseName.String(), namespace, helmValues)
	if err != nil {
		return fmt.Errorf("helm install failed: %v", err)
	}

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), backupReleaseName.String(), metav1.GetOptions{})
	if err != nil {
		return fmt.Errorf("cannot retrieve aws backup cronjob: %v", err)
	}

	if cronjob.Spec.Schedule != helmValues.Neo4J.JobSchedule {
		return fmt.Errorf("aws cronjob schedule %s not matching with the schedule defined in values.yaml %s",
			cronjob.Spec.Schedule, helmValues.Neo4J.JobSchedule)
	}

	pod, podErr := waitForPodByName(t, namespace, backupReleaseName.String(), 8*time.Minute)
	if podErr != nil {
		return podErr
	}

	for _, container := range pod.Spec.Containers {
		for _, env := range container.Env {
			if env.Name == "AGGREGATE_BACKUP_TEMP_DIR" {
				if env.Value != customTempDir {
					return fmt.Errorf("expected AGGREGATE_BACKUP_TEMP_DIR to be %s but got %s", customTempDir, env.Value)
				}
			}
		}
	}

	return nil
}

// CheckLogsFormat checks whether the neo4j logs are in json format or not
func CheckLogsFormat(t *testing.T, releaseName model.ReleaseName) error {

	stdout, stderr, err := ExecInPod(releaseName, []string{"cat", "/logs/neo4j.log"}, "")
	if !assert.NoError(t, err) {
		return fmt.Errorf("error seen while executing command `cat /logs/neo4j.log' ,\n err :- %v", err)
	}
	if !assert.Contains(t, stdout, ",\"level\":\"INFO\",\"category\":\"c.n.s.e.EnterpriseBootstrapper\",\"message\":\"Command expansion is explicitly enabled for configuration\"}") {
		return fmt.Errorf("foes not contain the required json format\n stdout := %s", stdout)
	}
	if !assert.Len(t, stderr, 0) {
		return fmt.Errorf("stderr found while checking logs \n stderr := %s", stderr)
	}
	return nil
}

// CheckNeo4jOperationsPod checks whether the neo4j operations pod is executed or not
func CheckNeo4jOperationsPod(t *testing.T, releaseName model.ReleaseName) error {

	fetchPods := func() (*v1.PodList, error) {
		pods, err := getPodsWithSpecificLabel(releaseName.Namespace(), "app=neo4j-operations")
		if err != nil {
			return &v1.PodList{}, fmt.Errorf("error seen while fetching list of pods \n %v", err)
		}
		if len(pods.Items) == 0 {
			return &v1.PodList{}, fmt.Errorf("no pods found")
		}
		if len(pods.Items) > 1 {
			return &v1.PodList{}, fmt.Errorf("more than one operations pod found")
		}
		return pods, nil
	}

	pods, err := fetchPods()
	if err != nil {
		return err
	}
	pod := pods.Items[0]
	for pod.Status.Phase == v1.PodRunning {
		t.Logf("operations pod in running state..Waiting for it to be completed")
		time.Sleep(30 * time.Second)
		pods, err = fetchPods()
		if err != nil {
			return err
		}
		pod = pods.Items[0]
	}
	if pod.Status.Phase != v1.PodSucceeded {
		return fmt.Errorf("pod phase %v is not succeeded", pod.Status.Phase)
	}

	logOutput, err := kubectlLogs(t, pod.Name, string(releaseName.Namespace()))
	if err != nil {
		return err
	}
	stringOutput := strings.ToLower(logOutput)
	if !strings.Contains(stringOutput, "server is already enabled") {
		return fmt.Errorf("operations pod does not contain valid logs \n logs := %s", logOutput)
	}
	return nil
}

// imagePullSecretTests runs tests related to imagePullSecret feature
func imagePullSecretTests(t *testing.T, name model.ReleaseName) error {
	t.Run("Check cluster core has imagePullSecret image", func(t *testing.T) {
		t.Parallel()
		assert.NoError(t, checkCoreImageName(t, name), "Core-1 image name should match with customImage")
	})
	t.Run("Check imagePullSecret \"demo\" is created", func(t *testing.T) {
		t.Parallel()
		assert.NoError(t, checkImagePullSecret(t, name), "ImagePullSecret named \"demo\" should be present")
	})
	return nil
}

// nodeSelectorTests runs tests related to nodeSelector feature
func nodeSelectorTests(name model.ReleaseName) []SubTest {
	namespace := string(name.Namespace())
	return []SubTest{
		{name: fmt.Sprintf("Check cluster core 1 is assigned with label %s", model.NodeSelectorLabel(namespace)), test: func(t *testing.T) {
			t.Parallel()
			// Re-apply the label before asserting. If GKE replaced the node
			// carrying it mid-test the assertion would spuriously fail on a
			// condition unrelated to what we're actually verifying.
			if err := ensureNodeLabel(t, fmt.Sprintf("%s-1", namespace)); !assert.NoError(t, err) {
				return
			}
			assert.NoError(t, checkNodeSelectorLabel(t, name, model.NodeSelectorLabel(namespace)), fmt.Sprintf("Core-1 Pod should be deployed on node with label %s", model.NodeSelectorLabel(namespace)))
		}},
	}
}

// databaseCreationTests creates a database against a cluster and checks if its created or not
func databaseCreationTests(t *testing.T, loadBalancerName model.ReleaseName, dataBaseName string) error {
	t.Run("Create Database customers", func(t *testing.T) {
		assert.NoError(t, createDatabase(t, loadBalancerName, dataBaseName), "Creates database")
	})
	t.Run("Check Database customers exists", func(t *testing.T) {
		assert.NoError(t, checkDataBaseExists(t, loadBalancerName, dataBaseName), "Checks if database exists or not")
	})
	return nil
}

// checkPriorityClassName checks the priorityClassName is set to the pod or not
func checkPriorityClassName(t *testing.T, releaseName model.ReleaseName) error {

	pods, err := getAllPods(releaseName.Namespace())
	if !assert.NoError(t, err) {
		return err
	}
	priorityClassName := model.PriorityClassName(string(releaseName.Namespace()))
	for _, pod := range pods.Items {
		if strings.Contains(pod.Name, "core-2") {
			if !assert.Equal(t, priorityClassName, pod.Spec.PriorityClassName) {
				return fmt.Errorf("priorityClassName %s not matching with %s", pod.Spec.PriorityClassName, priorityClassName)
			}
			break
		}
	}
	return nil
}

// checkCoreImageName checks whether core-1 image is matching with imagePullSecret image or not
func checkCoreImageName(t *testing.T, releaseName model.ReleaseName) error {

	pods, err := getAllPods(releaseName.Namespace())
	if !assert.NoError(t, err) {
		return err
	}
	for _, pod := range pods.Items {
		if strings.Contains(pod.Name, "core-1") {
			container := pod.Spec.Containers[0]
			if !assert.Equal(t, container.Image, model.ImagePullSecretCustomImageName) {
				return fmt.Errorf("container image %s not matching with imagePullSecet customImage %s", container.Image, model.ImagePullSecretCustomImageName)
			}
			break
		}
	}
	return nil
}

// checkNodeSelectorLabel asserts the pod is scheduled on one of the nodes that
// carries the given label. Multiple nodes may carry the same label (see
// labelNodes) so we accept any of them rather than insisting on the first.
func checkNodeSelectorLabel(t *testing.T, releaseName model.ReleaseName, labelName string) error {

	matches, err := getNodesWithLabel(labelName)
	if !assert.NoError(t, err) {
		return err
	}
	if !assert.NotEmpty(t, matches, "no node carries label %s", labelName) {
		return fmt.Errorf("no node carries label %s", labelName)
	}
	pod, err := getSpecificPod(releaseName.Namespace(), releaseName.PodName())
	if !assert.NoError(t, err) {
		return fmt.Errorf("error while fetching pod list \n %v", err)
	}
	for _, node := range matches {
		if node.Name == pod.Spec.NodeName {
			return nil
		}
	}
	names := make([]string, 0, len(matches))
	for _, node := range matches {
		names = append(names, node.Name)
	}
	assert.Fail(t, fmt.Sprintf("pod %s is on node %s; expected one of %v", pod.Name, pod.Spec.NodeName, names))
	return fmt.Errorf("pod on %s; expected one of %v", pod.Spec.NodeName, names)
}

// assertPodOnLabeledNode asserts a pod was scheduled on one of the nodes that
// carries labelName. labelNodes applies each testLabel value to multiple
// nodes (self-healing against GKE node replacement), so an exact-equality
// check against getNodeWithLabel's first match flakes whenever the scheduler
// picks a different one of the matches.
func assertPodOnLabeledNode(t *testing.T, pod v1.Pod, labelName string) {
	matches, err := getNodesWithLabel(labelName)
	if !assert.NoError(t, err) {
		return
	}
	if !assert.NotEmpty(t, matches, "no node carries label %s", labelName) {
		return
	}
	for _, n := range matches {
		if n.Name == pod.Spec.NodeName {
			return
		}
	}
	names := make([]string, 0, len(matches))
	for _, n := range matches {
		names = append(names, n.Name)
	}
	assert.Fail(t, fmt.Sprintf("backup pod %s scheduled on %s; expected one of %v", pod.Name, pod.Spec.NodeName, names))
}

// checkImagePullSecret checks whether a secret of type docker-registry is created or not
func checkImagePullSecret(t *testing.T, releaseName model.ReleaseName) error {

	secret, err := getSpecificSecret(releaseName.Namespace(), "demo")
	if !assert.NoError(t, err) {
		return fmt.Errorf("No secret found for the provided imagePullSecret \n %v", err)
	}
	if !assert.Equal(t, secret.Name, "demo") {
		return fmt.Errorf("imagePullSecret name %s does not match with demo", secret.Name)
	}
	return nil
}

// headLessServiceTests contains all the tests related to headless service
func headLessServiceTests(headlessService model.ReleaseName) []SubTest {
	return []SubTest{
		{name: "Check Headless Service Configuration", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, checkHeadlessServiceConfiguration(t, headlessService), "Checks Headless Service configuration")
		}},
		{name: "Check Headless Service Endpoints", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, checkHeadlessServiceEndpoints(t, headlessService), "headless service endpoints should be equal to the cluster core created")
		}},
	}
}

// apocConfigTests contains all the tests related to apoc configs
func apocConfigTests(releaseName model.ReleaseName) []SubTest {
	return []SubTest{
		{name: "Execute apoc query", test: func(t *testing.T) {
			t.Parallel()
			assert.NoError(t, checkApocConfig(t, releaseName), "Apoc Cypher Query failing to execute")
		}},
	}
}

// checkClusterCorePasswordFailure checks if a cluster core is failing on installation or not with an incorrect password
func checkClusterCorePasswordFailure(t *testing.T) error {
	//creating a sample cluster core definition (which is not supposed to get installed)
	clusterReleaseName := model.NewReleaseName("cluster-" + TestNamespace(t))
	core := clusterCore{model.NewCoreReleaseName(clusterReleaseName, 4), nil}
	releaseName := core.Name()
	// we are not using the customized run() func here since we need to assert the error received on stdout
	//(present in out variable and not in err)
	out, err := exec.Command(
		"helm",
		model.BaseHelmCommand("install", releaseName, model.HelmChart, model.Neo4jEdition, "--set", "neo4j.password=my-password", "--set", "neo4j.name="+model.DefaultNeo4jName)...).CombinedOutput()
	if !assert.Error(t, err) {
		return fmt.Errorf("helm install should fail without the default password")
	}
	if !assert.Contains(t, string(out), "The desired password does not match the password stored in the Kubernetes Secret") {
		return fmt.Errorf("error thrown on password failure is different , err := %s", string(out))
	}
	return nil
}

func checkK8s(t *testing.T, name model.ReleaseName) error {
	t.Run("check pods", func(t *testing.T) {
		t.Parallel()
		assert.NoError(t, checkPods(t, name))
	})
	t.Run("check lb", func(t *testing.T) {
		t.Parallel()
		assert.NoError(t, checkLoadBalancerService(t, name, model.DefaultClusterSize))
	})
	return nil
}

// checkLoadBalancerService checks whether the loadbalancer exists or not
// It also checks that the number of endpoints should match with the given number of expected endpoints
func checkLoadBalancerService(t *testing.T, name model.ReleaseName, expectedEndPoints int) error {

	serviceName := fmt.Sprintf("%s-lb-neo4j", model.DefaultNeo4jName)
	lbService, err := Clientset.CoreV1().Services(string(name.Namespace())).Get(context.TODO(), serviceName, metav1.GetOptions{})
	if !assert.NoError(t, err) {
		return fmt.Errorf("loadbalancer service %s not found , Error seen := %v", serviceName, err)
	}

	lbEndpoints, err := Clientset.CoreV1().Endpoints(string(name.Namespace())).Get(context.TODO(), lbService.Name, metav1.GetOptions{})
	if !assert.NoError(t, err) {
		return fmt.Errorf("failed to get loadbalancer service endpoints %v", err)
	}
	if !assert.Len(t, lbEndpoints.Subsets, 1) {
		return fmt.Errorf("lbendpoints subsets length should be equal to 1")
	}
	if !assert.Len(t, lbEndpoints.Subsets[0].Addresses, expectedEndPoints) {
		return fmt.Errorf("loadbalancer endpoints count should be %d", expectedEndPoints)
	}
	return nil
}

// checkPods checks for the number of pods which should be 5 (3 cluster core + 2 read replica)
func checkPods(t *testing.T, name model.ReleaseName) error {
	pods, err := getPodsWithSpecificLabel(name.Namespace(), "helm.neo4j.com/clustering=true")
	if !assert.NoError(t, err) {
		return err
	}

	if !assert.Len(t, pods.Items, model.DefaultClusterSize) {
		return fmt.Errorf("number of pods should be %d", model.DefaultClusterSize)
	}
	for _, pod := range pods.Items {
		if assert.Contains(t, pod.Labels, "app") {
			if !assert.Equal(t, model.DefaultNeo4jName, pod.Labels["app"]) {
				return fmt.Errorf("pod should have label app=%s , found app=%s", model.DefaultNeo4jName, pod.Labels["app"])
			}
		}
	}

	return nil
}

// checkNeo4jLogsForAnyErrors checks whether neo4j.log and debug.log contain any errors or not
func checkNeo4jLogsForAnyErrors(t *testing.T, name model.ReleaseName) error {
	cmd := []string{
		"bash",
		"-c",
		"cat /logs/neo4j.log /logs/debug.log",
	}

	stdout, stderr, err := ExecInPod(name, cmd, "")
	if !assert.NoError(t, err) {
		return err
	}
	if !assert.Len(t, stderr, 0) {
		return fmt.Errorf("stderr found \n %s", stderr)
	}
	//commenting this one out, the issue is reported to kernel team (card created)
	//https://trello.com/c/z0g4J7om/7548-neo4j-447-startup-error-seen-in-community-edition
	// Should be uncommented or removed based on the findings in the above card
	if !assert.NotContains(t, stdout, " ERROR [") {
		return fmt.Errorf("Contains error logs \n%s", stdout)
	}
	return nil
}

// checkHeadlessServiceConfiguration checks whether the provided service is headless service or not
func checkHeadlessServiceConfiguration(t *testing.T, service model.ReleaseName) error {

	serviceName := fmt.Sprintf("%s-headless", model.DefaultNeo4jName)
	headlessService, err := Clientset.CoreV1().Services(string(service.Namespace())).Get(context.TODO(), serviceName, metav1.GetOptions{})
	if !assert.NoError(t, err) {
		return fmt.Errorf("headless service %s not found , Error seen := %v", service.String(), err)
	}
	//throw error if headless service is nil which means no headless service object is released
	if !assert.NotNil(t, headlessService) {
		return fmt.Errorf("headless service is nil")
	}
	if !assert.Equal(t, headlessService.Spec.ClusterIP, "None") {
		return fmt.Errorf("provided clusterIP is not 'None'...it is %s", headlessService.Spec.ClusterIP)
	}

	return nil
}

// checkHeadlessServiceEndpoints checks whether the headless endpoints have the cluster cores or not
// By default , headless service includes cluster core only and no read replicas
//
// This check is brittle by nature: there's always a window where a pod has been scheduled but
// not yet assigned an IP, or a pod is Terminating but still registered as an endpoint. To avoid
// flakes we:
//   - filter out pods that are Terminating (DeletionTimestamp set) or have empty PodIPs,
//   - filter out empty endpoint addresses (shouldn't happen, but seen in practice),
//   - and retry a few times if the sets briefly disagree.
func checkHeadlessServiceEndpoints(t *testing.T, service model.ReleaseName) error {

	serviceName := fmt.Sprintf("%s-headless", model.DefaultNeo4jName)

	headlessService, err := Clientset.CoreV1().Services(string(service.Namespace())).Get(context.TODO(), serviceName, metav1.GetOptions{})
	if !assert.NoError(t, err) {
		return fmt.Errorf("headless service %s not found , Error seen := %v", service.String(), err)
	}
	headlessServiceSelectors := labels.Set(headlessService.Spec.Selector)
	listOptions := metav1.ListOptions{LabelSelector: headlessServiceSelectors.AsSelector().String()}
	ns := string(service.Namespace())

	var endPointIPs, podIPs []string
	pollErr := poll.Until(context.Background(), t, poll.Opts{
		Interval:      5 * time.Second,
		Timeout:       30 * time.Second,
		Description:   fmt.Sprintf("headless service %s/%s endpoints to match pod IPs", ns, serviceName),
		RetryableErrs: func(error) bool { return true },
	}, func(ctx context.Context) (bool, error) {
		endpoints, err := Clientset.CoreV1().Endpoints(ns).Get(ctx, serviceName, metav1.GetOptions{})
		if err != nil {
			return false, fmt.Errorf("get endpoints: %w", err)
		}
		endPointIPs = endPointIPs[:0]
		if len(endpoints.Subsets) > 0 {
			for _, addr := range endpoints.Subsets[0].Addresses {
				if addr.IP != "" {
					endPointIPs = append(endPointIPs, addr.IP)
				}
			}
		}
		pods, err := Clientset.CoreV1().Pods(ns).List(ctx, listOptions)
		if err != nil {
			return false, fmt.Errorf("list pods: %w", err)
		}
		podIPs = podIPs[:0]
		for _, pod := range pods.Items {
			// Skip pods that are being torn down — they'll disappear from endpoints shortly.
			if pod.DeletionTimestamp != nil {
				continue
			}
			// Skip pods with no IP yet — transient between Pending and Running.
			if pod.Status.PodIP == "" {
				continue
			}
			podIPs = append(podIPs, pod.Status.PodIP)
		}
		if len(podIPs) > 0 && len(endPointIPs) > 0 && stringsElementsMatch(podIPs, endPointIPs) {
			return true, nil
		}
		t.Logf("headless endpoints / pod IPs not yet matched (pods=%v, endpoints=%v)", podIPs, endPointIPs)
		return false, nil
	})
	if pollErr != nil {
		assert.ElementsMatch(t, podIPs, endPointIPs)
		assert.NotEmpty(t, podIPs)
		assert.NotEmpty(t, endPointIPs)
		return pollErr
	}
	return nil
}

// stringsElementsMatch reports whether a and b contain the same strings, ignoring order.
func stringsElementsMatch(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	counts := make(map[string]int, len(a))
	for _, s := range a {
		counts[s]++
	}
	for _, s := range b {
		counts[s]--
		if counts[s] < 0 {
			return false
		}
	}
	return true
}

func performBackgroundInstall(t *testing.T, componentsToParallelInstall []helmComponent, clusterReleaseName model.ReleaseName) ([]Closeable, error) {

	results := make(chan parallelResult)
	for _, component := range componentsToParallelInstall {
		go func(comp helmComponent) {
			var parallelResult = parallelResult{
				Closeable: nil,
				error:     fmt.Errorf("illegal state: background install did not take place for %s in %s", comp.Name(), clusterReleaseName),
			}
			defer func() { results <- parallelResult }()
			parallelResult = comp.Install(t)
		}(component)
	}

	var closeables []Closeable
	var combinedError error
	for i := 0; i < len(componentsToParallelInstall); i++ {
		result := <-results
		closeables = append(closeables, result.Closeable)
		if result.error != nil {
			combinedError = CombineErrors(combinedError, result.error)
		}
	}
	if !assert.NoError(t, combinedError) {
		return closeables, combinedError
	}
	return closeables, nil
}

func TestBackupMultipleEndpointsE2E(t *testing.T) {
	t.Parallel()

	releaseName := model.NewReleaseName("multiple-backup-endpoints-" + TestNamespace(t))
	_, err := createNamespace(t, releaseName)
	if err != nil {
		return
	}
	namespace := string(releaseName.Namespace())

	// Add cleanup
	t.Cleanup(func() {
		_ = runAll(t, "helm", [][]string{
			{"uninstall", releaseName.String(), "--wait", "--timeout", "3m", "--namespace", namespace},
			{"delete", "namespace", namespace},
		}, false)
	})

	backupEndpoints := "10.3.3.2:6362,10.3.3.3:6362,10.3.3.4:6362"

	helmValues := model.DefaultNeo4jBackupValues
	helmValues.Backup.DatabaseBackupEndpoints = backupEndpoints
	helmValues.Backup.SecretName = "demo"
	helmValues.Backup.CloudProvider = "aws"
	helmValues.Backup.BucketName = "demo2"
	helmValues.Backup.Database = "neo4j1"
	helmValues.Backup.S3ForcePathStyle = true

	helmClient := model.NewHelmClient(model.DefaultNeo4jBackupChartName)
	_, err = helmClient.Install(t, releaseName.String(), namespace, helmValues)
	assert.NoError(t, err, "error installing helm chart with multiple backup endpoints")

	cronjob, err := Clientset.BatchV1().CronJobs(namespace).Get(context.Background(), releaseName.String(), metav1.GetOptions{})
	assert.NoError(t, err, "cannot retrieve cronjob for multiple backup endpoints")

	// Verify cronjob env vars
	assert.Contains(t, cronjob.Spec.JobTemplate.Spec.Template.Spec.Containers[0].Env, corev1.EnvVar{
		Name:  "DATABASE_BACKUP_ENDPOINTS",
		Value: backupEndpoints,
	}, "backup endpoints not set correctly in cronjob")

	_, _, pollErr := waitForBackupPodCompletion(t, namespace, releaseName.String(), "Backup Completed", 8*time.Minute)
	assert.NoError(t, pollErr, "backup with multiple endpoints did not complete")
}

func TestClusterProbeConfigurations(t *testing.T) {
	if model.Neo4jEdition != "enterprise" {
		t.Skip()
		return
	}

	clusterReleaseName := model.NewReleaseName("cluster-probes")
	chart := model.Neo4jHelmChartCommunityAndEnterprise

	testCases := []struct {
		name   string
		values model.HelmValues
	}{
		{
			name: "HTTP Probe",
			values: func() model.HelmValues {
				v := model.DefaultEnterpriseValues
				v.ReadinessProbe = model.ReadinessProbe{
					HTTPGet: &model.HTTPGetAction{
						Path: "/ready",
						Port: 7474,
					},
					FailureThreshold: 30,
					TimeoutSeconds:   15,
					PeriodSeconds:    10,
				}
				return v
			}(),
		},
		{
			name: "TCP Socket Probe",
			values: func() model.HelmValues {
				v := model.DefaultEnterpriseValues
				v.ReadinessProbe = model.ReadinessProbe{
					TCPSocket: &model.TCPSocketAction{
						Port: 7687,
					},
					FailureThreshold: 20,
					TimeoutSeconds:   10,
					PeriodSeconds:    5,
				}
				return v
			}(),
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			closeable, err := installNeo4j(t, clusterReleaseName, chart)
			assert.NoError(t, err)
			t.Cleanup(func() { _ = closeable() })

			err = run(t, "kubectl", "--namespace", string(clusterReleaseName.Namespace()),
				"wait", "--for=condition=ready", "pod", clusterReleaseName.PodName(),
				timeouts.KubectlPodReady())
			assert.NoError(t, err)

			err = CheckProbes(t, clusterReleaseName)
			assert.NoError(t, err)
		})
	}
}

# Helm-Charts

This repository contains Helm charts that supports both Neo4j standalone and Neo4j clusters

Helm charts for Neo4j clusters are supported from version >= 4.4.0

Helm charts can be downloaded from [here](https://neo4j.com/deployment-center/#tools-tab)

[Full Documentation can be found here](https://neo4j.com/docs/operations-manual/current/kubernetes/)

## OCI registry

Released charts are also available from Google Artifact Registry as OCI
artifacts. Specify the chart version explicitly:

```bash
helm install my-neo4j \
  oci://europe-west2-docker.pkg.dev/neo4j-helm/helm-charts/neo4j \
  --version 2026.7.1 \
  --values values.yaml
```

OCI registries do not use `helm repo add`. Release configuration and
verification details are documented in [docs/ci/oci-release.md](docs/ci/oci-release.md).

## Examples
See the `examples` directory for common usage patterns of this Helm Chart

* [Dynamic volumes with dedicated storage class](../dev/examples/dedicated-storage-class-cluster/README.md)
* [Using Bloom and GDS Plugins](../dev/examples/bloom-gds-license/README.md)
* [Manually created disks with a volume selector (Standalone)](../dev/examples/persistent-volume-selector-standalone/README.md)
* [Manually created disks with a volume selector (Cluster)](../dev/examples/persistent-volume-selector-cluster/README.md)
* [Manually created disks with a pre provisioned PVC](../dev/examples/persistent-volume-manual/README.md)
* [Multi AKS cluster](../dev/examples/multi-cluster/README.md)
* [Cross-cluster database replication (CCDR)](../dev/examples/ccdr/README.md)

 

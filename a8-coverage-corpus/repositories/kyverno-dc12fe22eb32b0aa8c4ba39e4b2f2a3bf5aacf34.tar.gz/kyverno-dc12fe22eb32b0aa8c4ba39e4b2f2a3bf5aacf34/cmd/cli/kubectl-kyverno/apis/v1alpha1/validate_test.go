package v1alpha1

import (
	"encoding/json"
	"path/filepath"
	"strings"
	"testing"

	"k8s.io/apimachinery/pkg/runtime"
)

func TestValidateAPICallResponses(t *testing.T) {
	t.Run("valid", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL: "https://example.com",
			Response: APICallResponse{
				StatusCode: 200,
				Body:       runtime.RawExtension{Raw: []byte(`{"a":1}`)},
			},
		}})
		if err != nil {
			t.Fatal(err)
		}
	})
	t.Run("empty url and urlPath", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{URL: " ", URLPath: " ", Response: APICallResponse{}}})
		if err == nil || !strings.Contains(err.Error(), "either url or urlPath is required") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("both url and urlPath", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{URL: "https://x", URLPath: "/path", Response: APICallResponse{}}})
		if err == nil || !strings.Contains(err.Error(), "mutually exclusive") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("bad status", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL:      "https://x",
			Response: APICallResponse{StatusCode: 99, Body: runtime.RawExtension{Raw: []byte(`{}`)}},
		}})
		if err == nil || !strings.Contains(err.Error(), "statusCode") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("missing body", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL:      "https://x",
			Response: APICallResponse{Body: runtime.RawExtension{}},
		}})
		if err == nil || !strings.Contains(err.Error(), "body is required") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("invalid json body", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL:      "https://x",
			Response: APICallResponse{Body: runtime.RawExtension{Raw: []byte(`{`)}},
		}})
		if err == nil || !strings.Contains(err.Error(), "valid JSON") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("body must be object not array", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL:      "https://x",
			Response: APICallResponse{Body: runtime.RawExtension{Raw: []byte(`[]`)}},
		}})
		if err == nil || !strings.Contains(err.Error(), "JSON object") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("body must be object not scalar", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL:      "https://x",
			Response: APICallResponse{Body: runtime.RawExtension{Raw: []byte(`"x"`)}},
		}})
		if err == nil || !strings.Contains(err.Error(), "JSON object") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("urlPath style path", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URLPath: "/apis/some/path",
			Response: APICallResponse{
				Body: runtime.RawExtension{Raw: []byte(`{}`)},
			},
		}})
		if err != nil {
			t.Fatal(err)
		}
	})
	t.Run("invalid url not absolute https", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL: "http://example.com/path",
			Response: APICallResponse{
				Body: runtime.RawExtension{Raw: []byte(`{}`)},
			},
		}})
		if err != nil {
			t.Fatal(err)
		}
	})
	t.Run("https URL missing host", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL: "https://",
			Response: APICallResponse{
				Body: runtime.RawExtension{Raw: []byte(`{}`)},
			},
		}})
		if err == nil || !strings.Contains(err.Error(), "has scheme but no host") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("https scheme fragment only", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL: "https:",
			Response: APICallResponse{
				Body: runtime.RawExtension{Raw: []byte(`{}`)},
			},
		}})
		if err == nil || !strings.Contains(err.Error(), "has scheme but no host") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("invalid urlPath not absolute", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URLPath: "relative/path",
			Response: APICallResponse{
				Body: runtime.RawExtension{Raw: []byte(`{}`)},
			},
		}})
		if err == nil || !strings.Contains(err.Error(), "absolute path starting") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("valid method GET", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL:    "https://example.com/config",
			Method: "GET",
			Response: APICallResponse{
				StatusCode: 200,
				Body:       runtime.RawExtension{Raw: []byte(`{"allowed":true}`)},
			},
		}})
		if err != nil {
			t.Fatal(err)
		}
	})
	t.Run("valid method POST", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL:    "https://authz.example.com/validate",
			Method: "POST",
			Response: APICallResponse{
				StatusCode: 200,
				Body:       runtime.RawExtension{Raw: []byte(`{"allowed":true}`)},
			},
		}})
		if err != nil {
			t.Fatal(err)
		}
	})
	t.Run("valid method POST lowercase normalised", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL:    "https://authz.example.com/validate",
			Method: "post",
			Response: APICallResponse{
				StatusCode: 201,
				Body:       runtime.RawExtension{Raw: []byte(`{"id":"42"}`)},
			},
		}})
		if err != nil {
			t.Fatal(err)
		}
	})
	t.Run("invalid method DELETE", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URL:    "https://example.com/items",
			Method: "DELETE",
			Response: APICallResponse{
				Body: runtime.RawExtension{Raw: []byte(`{}`)},
			},
		}})
		if err == nil || !strings.Contains(err.Error(), "method must be GET or POST") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("duplicate POST url key", func(t *testing.T) {
		body := runtime.RawExtension{Raw: []byte(`{"ok":true}`)}
		err := ValidateAPICallResponses([]APICallResponseEntry{
			{URL: "https://example.com/submit", Method: "POST", Response: APICallResponse{Body: body}},
			{URL: "https://example.com/submit", Method: "POST", Response: APICallResponse{Body: body}},
		})
		if err == nil || !strings.Contains(err.Error(), "duplicate entry") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("GET and POST same URL are not duplicates", func(t *testing.T) {
		body := runtime.RawExtension{Raw: []byte(`{"ok":true}`)}
		err := ValidateAPICallResponses([]APICallResponseEntry{
			{URL: "https://example.com/resource", Method: "GET", Response: APICallResponse{Body: body}},
			{URL: "https://example.com/resource", Method: "POST", Response: APICallResponse{Body: body}},
		})
		if err != nil {
			t.Fatalf("GET and POST on same URL should not be a duplicate: %v", err)
		}
	})
	t.Run("valid POST with urlPath", func(t *testing.T) {
		err := ValidateAPICallResponses([]APICallResponseEntry{{
			URLPath: "/apis/v1/validate",
			Method:  "POST",
			Response: APICallResponse{
				Body: runtime.RawExtension{Raw: []byte(`{"allowed":true}`)},
			},
		}})
		if err != nil {
			t.Fatal(err)
		}
	})
}

// TestValidateAPICallResponses_DuplicateKeys verifies that the duplicate-key
// detection logic handles all four key forms correctly:
// plain URL, GET:URL, POST:URL, and urlPath.
func TestValidateAPICallResponses_DuplicateKeys(t *testing.T) {
	body := runtime.RawExtension{Raw: []byte(`{"ok":true}`)}

	tests := []struct {
		name    string
		entries []APICallResponseEntry
		wantErr string
	}{
		{
			name: "plain URL duplicate",
			entries: []APICallResponseEntry{
				{URL: "https://example.com/x", Response: APICallResponse{Body: body}},
				{URL: "https://example.com/x", Response: APICallResponse{Body: body}},
			},
			wantErr: "duplicate entry",
		},
		{
			name: "GET:URL duplicate",
			entries: []APICallResponseEntry{
				{URL: "https://example.com/x", Method: "GET", Response: APICallResponse{Body: body}},
				{URL: "https://example.com/x", Method: "GET", Response: APICallResponse{Body: body}},
			},
			wantErr: "duplicate entry",
		},
		{
			name: "POST:URL duplicate",
			entries: []APICallResponseEntry{
				{URL: "https://example.com/x", Method: "POST", Response: APICallResponse{Body: body}},
				{URL: "https://example.com/x", Method: "POST", Response: APICallResponse{Body: body}},
			},
			wantErr: "duplicate entry",
		},
		{
			name: "urlPath duplicate",
			entries: []APICallResponseEntry{
				{URLPath: "/api/v1/check", Response: APICallResponse{Body: body}},
				{URLPath: "/api/v1/check", Response: APICallResponse{Body: body}},
			},
			wantErr: "duplicate entry",
		},
		{
			name: "GET:URL and POST:URL same path — allowed",
			entries: []APICallResponseEntry{
				{URL: "https://example.com/x", Method: "GET", Response: APICallResponse{Body: body}},
				{URL: "https://example.com/x", Method: "POST", Response: APICallResponse{Body: body}},
			},
			wantErr: "",
		},
		{
			name: "plain URL and GET:URL same path — allowed (different keys)",
			entries: []APICallResponseEntry{
				{URL: "https://example.com/x", Response: APICallResponse{Body: body}},
				{URL: "https://example.com/x", Method: "GET", Response: APICallResponse{Body: body}},
			},
			wantErr: "",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := ValidateAPICallResponses(tt.entries)
			if tt.wantErr == "" {
				if err != nil {
					t.Fatalf("expected no error, got: %v", err)
				}
			} else {
				if err == nil || !strings.Contains(err.Error(), tt.wantErr) {
					t.Fatalf("expected error containing %q, got: %v", tt.wantErr, err)
				}
			}
		})
	}
}

func TestValidateGlobalContextEntries(t *testing.T) {
	t.Run("valid with data", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name: "g",
			Data: &runtime.RawExtension{Raw: []byte(`{}`)},
			Projections: []GlobalContextProjection{
				{Name: "items", Path: "deployments"},
			},
		}})
		if err != nil {
			t.Fatal(err)
		}
	})
	t.Run("valid with resources", func(t *testing.T) {
		dep1, _ := json.Marshal(map[string]interface{}{
			"apiVersion": "apps/v1",
			"kind":       "Deployment",
			"metadata":   map[string]interface{}{"name": "dep1"},
		})
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name: "g",
			Resources: []runtime.RawExtension{
				{Raw: dep1},
			},
		}})
		if err != nil {
			t.Fatal(err)
		}
	})
	t.Run("data and resources mutually exclusive", func(t *testing.T) {
		dep, _ := json.Marshal(map[string]interface{}{"apiVersion": "v1", "kind": "Pod"})
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name:      "g",
			Data:      &runtime.RawExtension{Raw: []byte(`{"x":1}`)},
			Resources: []runtime.RawExtension{{Raw: dep}},
		}})
		if err == nil || !strings.Contains(err.Error(), "mutually exclusive") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("data and resourceFiles mutually exclusive", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name:          "g",
			Data:          &runtime.RawExtension{Raw: []byte(`{"x":1}`)},
			ResourceFiles: []string{"file.yaml"},
		}})
		if err == nil || !strings.Contains(err.Error(), "mutually exclusive") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("resources and resourceFiles mutually exclusive", func(t *testing.T) {
		dep, _ := json.Marshal(map[string]interface{}{"apiVersion": "v1", "kind": "Pod"})
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name:          "g",
			Resources:     []runtime.RawExtension{{Raw: dep}},
			ResourceFiles: []string{"file.yaml"},
		}})
		if err == nil || !strings.Contains(err.Error(), "mutually exclusive") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("valid resourceFiles", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name:          "g",
			ResourceFiles: []string{"deployments.yaml"},
		}})
		if err != nil {
			t.Fatal(err)
		}
	})
	t.Run("resourceFiles with empty path", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name:          "g",
			ResourceFiles: []string{"valid.yaml", " "},
		}})
		if err == nil || !strings.Contains(err.Error(), "file path must not be empty") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("no data source at all", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name: "g",
		}})
		if err == nil || !strings.Contains(err.Error(), "one of data, resources, or resourceFiles is required") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("empty name", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{Name: " "}})
		if err == nil || !strings.Contains(err.Error(), "name is required") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("projection missing name", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name:        "g",
			Data:        &runtime.RawExtension{Raw: []byte(`{}`)},
			Projections: []GlobalContextProjection{{Name: "", Path: "p"}},
		}})
		if err == nil || !strings.Contains(err.Error(), "projection name") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("projection missing path", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name:        "g",
			Data:        &runtime.RawExtension{Raw: []byte(`{}`)},
			Projections: []GlobalContextProjection{{Name: "n", Path: " "}},
		}})
		if err == nil || !strings.Contains(err.Error(), "path is required") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("duplicate name", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{
			{Name: "g", Data: &runtime.RawExtension{Raw: []byte(`{}`)}},
			{Name: "g", Data: &runtime.RawExtension{Raw: []byte(`{"x":1}`)}},
		})
		if err == nil || !strings.Contains(err.Error(), "duplicate name") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("invalid resource JSON", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name: "g",
			Resources: []runtime.RawExtension{
				{Raw: []byte(`{`)},
			},
		}})
		if err == nil || !strings.Contains(err.Error(), "valid JSON") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("resource must be object", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name: "g",
			Resources: []runtime.RawExtension{
				{Raw: []byte(`"scalar"`)},
			},
		}})
		if err == nil || !strings.Contains(err.Error(), "JSON object") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("empty resources slice", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name:      "g",
			Resources: []runtime.RawExtension{},
		}})
		if err != nil {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("empty resourceFiles slice", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name:          "g",
			ResourceFiles: []string{},
		}})
		if err != nil {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("resourceFiles with absolute path", func(t *testing.T) {
		absPath := string(filepath.Separator) + "absolute_path.yaml"
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name:          "g",
			ResourceFiles: []string{absPath},
		}})
		if err == nil || !strings.Contains(err.Error(), "must not be absolute") {
			t.Fatalf("got %v", err)
		}
	})
	t.Run("resourceFiles with path escape", func(t *testing.T) {
		err := ValidateGlobalContextEntries([]GlobalContextEntryValue{{
			Name:          "g",
			ResourceFiles: []string{"../outside.yaml"},
		}})
		if err == nil || !strings.Contains(err.Error(), "must not escape the test directory") {
			t.Fatalf("got %v", err)
		}
	})
}

func TestRawExtensionToObject(t *testing.T) {
	t.Run("empty", func(t *testing.T) {
		v, err := RawExtensionToObject(runtime.RawExtension{})
		if err != nil || v != nil {
			t.Fatalf("got %v, %v", v, err)
		}
	})
	t.Run("object", func(t *testing.T) {
		raw, _ := json.Marshal(map[string]int{"k": 1})
		v, err := RawExtensionToObject(runtime.RawExtension{Raw: raw})
		if err != nil {
			t.Fatal(err)
		}
		m := v.(map[string]interface{})
		if int(m["k"].(float64)) != 1 {
			t.Fatalf("%#v", v)
		}
	})
}

package test

import (
	"bytes"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/go-git/go-billy/v5"
	"github.com/go-git/go-billy/v5/memfs"
	kyvernov1 "github.com/kyverno/kyverno/api/kyverno/v1"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/apis/v1alpha1"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/output/color"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/test"
	engineapi "github.com/kyverno/kyverno/pkg/engine/api"
	"github.com/kyverno/kyverno/pkg/openreports"
	openreportsv1alpha1 "github.com/openreports/reports-api/apis/openreports.io/v1alpha1"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
)

func TestCommandWithInvalidArg(t *testing.T) {
	cmd := Command()
	assert.NotNil(t, cmd)
	b := bytes.NewBufferString("")
	cmd.SetErr(b)
	err := cmd.Execute()
	assert.Error(t, err)
	out, err := io.ReadAll(b)
	assert.NoError(t, err)
	expected := `Error: requires at least 1 arg(s), only received 0`
	assert.Equal(t, strings.TrimSpace(expected), strings.TrimSpace(string(out)))
}

func TestCommandNoTests(t *testing.T) {
	cmd := Command()
	assert.NotNil(t, cmd)
	errBuffer := bytes.NewBufferString("")
	cmd.SetErr(errBuffer)
	outBuffer := bytes.NewBufferString("")
	cmd.SetOut(outBuffer)
	cmd.SetArgs([]string{"."})
	err := cmd.Execute()
	assert.NoError(t, err)
	out, err := io.ReadAll(outBuffer)
	assert.NoError(t, err)
	expected := `No test yamls available`
	assert.Equal(t, strings.TrimSpace(expected), strings.TrimSpace(string(out)))
	errOut, err := io.ReadAll(errBuffer)
	assert.NoError(t, err)
	expected = ``
	assert.Equal(t, strings.TrimSpace(expected), strings.TrimSpace(string(errOut)))
}

func TestCommandRequireTests(t *testing.T) {
	cmd := Command()
	assert.NotNil(t, cmd)
	errBuffer := bytes.NewBufferString("")
	cmd.SetErr(errBuffer)
	outBuffer := bytes.NewBufferString("")
	cmd.SetOut(outBuffer)
	cmd.SetArgs([]string{".", "--require-tests"})
	err := cmd.Execute()
	assert.Error(t, err)
	out, err := io.ReadAll(outBuffer)
	assert.NoError(t, err)
	expected := `No test yamls available`
	assert.Equal(t, strings.TrimSpace(expected), strings.TrimSpace(string(out)))
	errOut, err := io.ReadAll(errBuffer)
	assert.NoError(t, err)
	expected = `Error: no tests found`
	assert.Equal(t, strings.TrimSpace(expected), strings.TrimSpace(string(errOut)))
}

func TestCommandWithInvalidFlag(t *testing.T) {
	cmd := Command()
	assert.NotNil(t, cmd)
	b := bytes.NewBufferString("")
	cmd.SetErr(b)
	cmd.SetArgs([]string{"--xxx"})
	err := cmd.Execute()
	assert.Error(t, err)
	out, err := io.ReadAll(b)
	assert.NoError(t, err)
	expected := `Error: unknown flag: --xxx`
	assert.Equal(t, strings.TrimSpace(expected), strings.TrimSpace(string(out)))
}

func TestCommandHelp(t *testing.T) {
	cmd := Command()
	assert.NotNil(t, cmd)
	b := bytes.NewBufferString("")
	cmd.SetOut(b)
	cmd.SetArgs([]string{"--help"})
	err := cmd.Execute()
	assert.NoError(t, err)
	out, err := io.ReadAll(b)
	assert.NoError(t, err)
	assert.True(t, strings.HasPrefix(string(out), cmd.Long))
}

func TestCheckResultDetectsMismatch(t *testing.T) {
	policy := &kyvernov1.ClusterPolicy{}
	policy.SetName("test-policy")

	resource := unstructured.Unstructured{
		Object: map[string]interface{}{
			"apiVersion": "v1",
			"kind":       "Pod",
			"metadata": map[string]interface{}{
				"name":      "test-pod",
				"namespace": "default",
			},
		},
	}

	tests := []struct {
		name           string
		ruleStatus     engineapi.RuleStatus
		expectedResult string
		wantOk         bool
		wantReason     string
	}{
		{
			name:           "expect fail but got pass - should detect mismatch",
			ruleStatus:     engineapi.RuleStatusPass,
			expectedResult: openreports.StatusFail,
			wantOk:         false,
			wantReason:     "Want fail, got pass",
		},
		{
			name:           "expect fail and got fail - should match",
			ruleStatus:     engineapi.RuleStatusFail,
			expectedResult: openreports.StatusFail,
			wantOk:         true,
			wantReason:     "Ok",
		},
		{
			name:           "expect pass and got pass - should match",
			ruleStatus:     engineapi.RuleStatusPass,
			expectedResult: openreports.StatusPass,
			wantOk:         true,
			wantReason:     "Ok",
		},
		{
			name:           "expect pass but got fail - should detect mismatch",
			ruleStatus:     engineapi.RuleStatusFail,
			expectedResult: openreports.StatusPass,
			wantOk:         false,
			wantReason:     "Want pass, got fail",
		},
		{
			name:           "expect fail but got error - should detect mismatch",
			ruleStatus:     engineapi.RuleStatusError,
			expectedResult: openreports.StatusFail,
			wantOk:         false,
			wantReason:     "Want fail, got error",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var rule engineapi.RuleResponse
			switch tt.ruleStatus {
			case engineapi.RuleStatusPass:
				rule = *engineapi.RulePass("test-rule", engineapi.Validation, "msg", nil)
			case engineapi.RuleStatusFail:
				rule = *engineapi.RuleFail("test-rule", engineapi.Validation, "msg", nil)
			case engineapi.RuleStatusError:
				rule = *engineapi.RuleError("test-rule", engineapi.Validation, "msg", nil, nil)
			}

			response := engineapi.NewEngineResponse(
				resource,
				engineapi.NewKyvernoPolicy(policy),
				nil,
			).WithPolicyResponse(engineapi.PolicyResponse{
				Rules: []engineapi.RuleResponse{rule},
			})

			testResult := v1alpha1.TestResult{
				TestResultBase: v1alpha1.TestResultBase{
					Policy: "test-policy",
					Rule:   "test-rule",
					Result: openreportsv1alpha1.Result(tt.expectedResult),
				},
			}

			ok, _, reason := checkResult(testResult, nil, "", response, rule, resource, true)
			assert.Equal(t, tt.wantOk, ok, "checkResult ok")
			assert.Contains(t, reason, tt.wantReason, "checkResult reason")
		})
	}
}

func TestCheckRuleResultOnly_GenerationNoGeneratedResources(t *testing.T) {
	policy := &kyvernov1.ClusterPolicy{}
	policy.SetName("test-policy")

	resource := unstructured.Unstructured{
		Object: map[string]interface{}{
			"apiVersion": "v1",
			"kind":       "Pod",
			"metadata": map[string]interface{}{
				"name":      "test-pod",
				"namespace": "default",
			},
		},
	}

	rule := *engineapi.RulePass("test-rule", engineapi.Generation, "policy evaluated successfully", nil)
	assert.Empty(t, rule.GeneratedResources())

	response := engineapi.NewEngineResponse(
		resource,
		engineapi.NewKyvernoPolicy(policy),
		nil,
	).WithPolicyResponse(engineapi.PolicyResponse{
		Rules: []engineapi.RuleResponse{rule},
	})

	testResult := v1alpha1.TestResult{
		TestResultBase: v1alpha1.TestResultBase{
			Policy: "test-policy",
			Rule:   "test-rule",
			Result: openreportsv1alpha1.Result(openreports.StatusPass),
		},
	}

	ok, _, reason := checkRuleResultOnly(testResult, response, rule)
	assert.True(t, ok)
	assert.Equal(t, "Ok", reason)
}

func TestResultCountsOnMismatch(t *testing.T) {
	color.Init(true)

	tests := []struct {
		name     string
		ok       bool
		expected string
		wantPass int
		wantFail int
	}{
		{
			name:     "mismatch with expected fail should count as failure",
			ok:       false,
			expected: openreports.StatusFail,
			wantPass: 0,
			wantFail: 1,
		},
		{
			name:     "match with expected fail should count as pass",
			ok:       true,
			expected: openreports.StatusFail,
			wantPass: 1,
			wantFail: 0,
		},
		{
			name:     "mismatch with expected pass should count as failure",
			ok:       false,
			expected: openreports.StatusPass,
			wantPass: 0,
			wantFail: 1,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			rc := &resultCounts{}
			testCount := 1
			testResult := v1alpha1.TestResult{
				TestResultBase: v1alpha1.TestResultBase{
					Policy: "test-policy",
					Rule:   "test-rule",
					Result: openreportsv1alpha1.Result(tt.expected),
				},
			}

			createRowsAccordingToResults(testResult, rc, &testCount, "test-rule", tt.ok, "msg", "reason", "v1/Pod/default/test-pod")

			assert.Equal(t, tt.wantPass, rc.Pass, "pass count")
			assert.Equal(t, tt.wantFail, rc.Fail, "fail count")
		})
	}
}

func Test_JSONPayload(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err, "Failed to get working directory")
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-validating-policy", "json-check-dockerfile")

	_, err = os.Stat(testDir)
	if os.IsNotExist(err) {
		t.Skip("Test directory not found, skipping test")
		return
	}

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	testCase := testCases[0]

	out := &bytes.Buffer{}
	t.Logf("Running test with files from %s", testCase.Dir())
	testResponse, err := runTest(out, testCase, false)
	require.NoError(t, err, "Failed to run test")

	t.Logf("Test output: %s", out.String())

	t.Run("Check policy results match output table", func(t *testing.T) {
		require.NotEmpty(t, testCase.Test.JSONPayloads, "Expected at least one JSON payload after migration")
		payloadKey := testCase.Test.JSONPayloads[0]
		responses := testResponse.Trigger[payloadKey]
		policyResults := make(map[string]struct {
			Status string
			Reason string
		})

		for _, response := range responses {
			policy := response.Policy().GetName()

			// Determine overall result - based on the table, all policies are passing
			status := "pass"
			reason := "Ok"

			policyResults[policy] = struct {
				Status string
				Reason string
			}{
				Status: status,
				Reason: reason,
			}
		}

		wgetResult, found := policyResults["check-dockerfile-disallow-wget"]
		if assert.True(t, found, "wget policy result not found") {
			assert.Equal(t, "pass", wgetResult.Status, "wget policy should pass according to output table")
			assert.Equal(t, "Ok", wgetResult.Reason, "wget policy reason should be 'Ok'")
		}

		curlResult, found := policyResults["check-dockerfile-disallow-curl"]
		if assert.True(t, found, "curl policy result not found") {
			assert.Equal(t, "pass", curlResult.Status, "curl policy should pass according to output table")
			assert.Equal(t, "Ok", curlResult.Reason, "curl policy reason should be 'Ok'")
		}
	})
}

func Test_JSONPayloads(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err, "Failed to get working directory")
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-validating-policy", "json-multiple-payloads")

	_, err = os.Stat(testDir)
	if os.IsNotExist(err) {
		t.Skip("Test directory not found, skipping test")
		return
	}

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	testCase := testCases[0]
	require.Len(t, testCase.Test.JSONPayloads, 2, "Expected 2 JSON payloads after loading")

	out := &bytes.Buffer{}
	testResponse, err := runTest(out, testCase, false)
	require.NoError(t, err, "Failed to run test")

	t.Run("Both payloads produce trigger responses", func(t *testing.T) {
		assert.Contains(t, testResponse.Trigger, "payload-pass.json", "pass payload should have trigger response")
		assert.Contains(t, testResponse.Trigger, "payload-fail.json", "fail payload should have trigger response")
	})

	t.Run("Pass payload produces a passing result", func(t *testing.T) {
		responses := testResponse.Trigger["payload-pass.json"]
		require.NotEmpty(t, responses, "Expected responses for pass payload")
		found := false
		for _, response := range responses {
			if response.Policy().GetName() == "deny-root-ca-enabled" {
				found = true
				for _, rule := range response.PolicyResponse.Rules {
					assert.Equal(t, "pass", string(rule.Status()), "expected pass for pass payload")
				}
			}
		}
		assert.True(t, found, "deny-root-ca-enabled policy result not found for pass payload")
	})

	t.Run("Fail payload produces a failing result", func(t *testing.T) {
		responses := testResponse.Trigger["payload-fail.json"]
		require.NotEmpty(t, responses, "Expected responses for fail payload")
		found := false
		for _, response := range responses {
			if response.Policy().GetName() == "deny-root-ca-enabled" {
				found = true
				for _, rule := range response.PolicyResponse.Rules {
					assert.Equal(t, "fail", string(rule.Status()), "expected fail for fail payload")
				}
			}
		}
		assert.True(t, found, "deny-root-ca-enabled policy result not found for fail payload")
	})
}

func TestRunTest_InvalidHTTPPayloadPath(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err)
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-validating-policy", "http-allow")

	_, err = os.Stat(testDir)
	if os.IsNotExist(err) {
		t.Skip("Test directory not found, skipping test")
		return
	}

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	testCase := testCases[0]
	testCase.Test.HTTPPayloads = []string{"./missing-http-request.json"}
	out := &bytes.Buffer{}

	_, err = runTest(out, testCase, false)
	require.Error(t, err)
	assert.ErrorContains(t, err, "failed to load HTTP payloads from path")
}

func TestRunTest_InvalidEnvoyPayloadPath(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err)
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-validating-policy", "envoy-allow")

	_, err = os.Stat(testDir)
	if os.IsNotExist(err) {
		t.Skip("Test directory not found, skipping test")
		return
	}

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	testCase := testCases[0]
	testCase.Test.EnvoyPayloads = []string{"./missing-envoy-request.json"}
	out := &bytes.Buffer{}

	_, err = runTest(out, testCase, false)
	require.Error(t, err)
	assert.ErrorContains(t, err, "failed to load Envoy payloads from path")
}

func TestRunTest_WithHTTPAndEnvoyPayloads(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err)
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")

	t.Run("http payload", func(t *testing.T) {
		testDir := filepath.Join(rootDir, "test", "cli", "test-validating-policy", "http-allow")
		_, statErr := os.Stat(testDir)
		if os.IsNotExist(statErr) {
			t.Skip("Test directory not found, skipping test")
			return
		}
		testFile := filepath.Join(testDir, "kyverno-test.yaml")
		testCases := test.LoadTest(nil, testFile)
		require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)
		out := &bytes.Buffer{}
		testResponse, err := runTest(out, testCases[0], false)
		require.NoError(t, err, "runTest http-allow: %s", out.String())
		require.NotEmpty(t, testResponse.Trigger, "expected trigger entries for HTTP payload")
		var found bool
		for _, responses := range testResponse.Trigger {
			for _, r := range responses {
				if r.Policy().GetName() == "http-allow" {
					found = true
					break
				}
			}
		}
		assert.True(t, found, "expected engine response for policy http-allow")
	})

	t.Run("envoy payload", func(t *testing.T) {
		testDir := filepath.Join(rootDir, "test", "cli", "test-validating-policy", "envoy-allow")
		_, statErr := os.Stat(testDir)
		if os.IsNotExist(statErr) {
			t.Skip("Test directory not found, skipping test")
			return
		}
		testFile := filepath.Join(testDir, "kyverno-test.yaml")
		testCases := test.LoadTest(nil, testFile)
		require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)
		out := &bytes.Buffer{}
		testResponse, err := runTest(out, testCases[0], false)
		require.NoError(t, err, "runTest envoy-allow: %s", out.String())
		require.NotEmpty(t, testResponse.Trigger, "expected trigger entries for Envoy payload")
		var found bool
		for _, responses := range testResponse.Trigger {
			for _, r := range responses {
				if r.Policy().GetName() == "envoy-allow" {
					found = true
					break
				}
			}
		}
		assert.True(t, found, "expected engine response for policy envoy-allow")
	})
}

func TestRunTest_CELHTTPGetMock(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err)
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test", "cel-http-get-mock")

	if _, statErr := os.Stat(testDir); os.IsNotExist(statErr) {
		t.Skip("Test directory not found, skipping test")
		return
	}

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	out := &bytes.Buffer{}
	testResponse, err := runTest(out, testCases[0], false)
	require.NoError(t, err, "runTest cel-http-get-mock failed: %s", out.String())
	require.NotEmpty(t, testResponse.Trigger, "expected engine responses for cel-http-get-mock")

	var found bool
	for _, responses := range testResponse.Trigger {
		for _, r := range responses {
			if r.Policy().GetName() == "check-external-config" {
				found = true
				require.NotEmpty(t, r.PolicyResponse.Rules, "expected rules in policy response")
				for _, rule := range r.PolicyResponse.Rules {
					assert.Equal(t, engineapi.RuleStatusPass, rule.Status(), "expected rule to pass")
				}
				break
			}
		}
		if found {
			break
		}
	}
	assert.True(t, found, "expected engine response for policy check-external-config")
}

func TestRunTest_CELHTTPPostMock(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err)
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test", "cel-http-post-mock")

	if _, statErr := os.Stat(testDir); os.IsNotExist(statErr) {
		t.Skip("Test directory not found, skipping test")
		return
	}

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	out := &bytes.Buffer{}
	testResponse, err := runTest(out, testCases[0], false)
	require.NoError(t, err, "runTest cel-http-post-mock failed: %s", out.String())
	require.NotEmpty(t, testResponse.Trigger, "expected engine responses for cel-http-post-mock")

	var found bool
	for _, responses := range testResponse.Trigger {
		for _, r := range responses {
			if r.Policy().GetName() == "check-pod-admission" {
				found = true
				require.NotEmpty(t, r.PolicyResponse.Rules, "expected rules in policy response")
				for _, rule := range r.PolicyResponse.Rules {
					assert.Equal(t, engineapi.RuleStatusPass, rule.Status(), "expected rule to pass")
				}
				break
			}
		}
		if found {
			break
		}
	}
	assert.True(t, found, "expected engine response for policy check-pod-admission")
}

func TestRunTest_CELHTTPPostMockDeny(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err)
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test", "cel-http-post-mock-deny")

	if _, statErr := os.Stat(testDir); os.IsNotExist(statErr) {
		t.Skip("Test directory not found, skipping test")
		return
	}

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	out := &bytes.Buffer{}
	testResponse, err := runTest(out, testCases[0], false)
	require.NoError(t, err, "runTest cel-http-post-mock-deny failed: %s", out.String())
	require.NotEmpty(t, testResponse.Trigger, "expected engine responses for cel-http-post-mock-deny")

	var found bool
	for _, responses := range testResponse.Trigger {
		for _, r := range responses {
			if r.Policy().GetName() == "check-pod-admission" {
				found = true
				require.NotEmpty(t, r.PolicyResponse.Rules, "expected rules in policy response")
				for _, rule := range r.PolicyResponse.Rules {
					assert.Equal(t, engineapi.RuleStatusFail, rule.Status(), "expected rule to fail")
				}
				break
			}
		}
		if found {
			break
		}
	}
	assert.True(t, found, "expected engine response for policy check-pod-admission (deny scenario)")
}

func TestMutatingPolicyContextResourceLookup(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err, "Failed to get working directory")
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-context-configmap-mpol")

	_, err = os.Stat(testDir)
	if os.IsNotExist(err) {
		t.Skip("Test directory not found, skipping test")
		return
	}

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	testCase := testCases[0]

	out := &bytes.Buffer{}
	t.Logf("Running MutatingPolicy context resource lookup test from %s", testCase.Dir())
	testResponse, err := runTest(out, testCase, false)
	require.NoError(t, err, "Failed to run test: %s", out.String())

	t.Logf("Test output: %s", out.String())

	t.Run("MutatingPolicy with resource.get() produces engine response", func(t *testing.T) {
		require.NotEmpty(t, testResponse.Trigger, "expected trigger entries for MutatingPolicy")
		var found bool
		for _, responses := range testResponse.Trigger {
			for _, r := range responses {
				if r.Policy().GetName() == "add-env-label" {
					found = true
					// Verify the policy produced a pass result
					for _, rule := range r.PolicyResponse.Rules {
						assert.Equal(t, engineapi.RuleStatusPass, rule.Status(), "expected rule to pass")
					}
					break
				}
			}
		}
		assert.True(t, found, "expected engine response for policy add-env-label")
	})
}

func TestGeneratingPolicyContextResourceLookup(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err, "Failed to get working directory")
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-context-configmap-gpol")

	_, err = os.Stat(testDir)
	if os.IsNotExist(err) {
		t.Skip("Test directory not found, skipping test")
		return
	}

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	testCase := testCases[0]

	out := &bytes.Buffer{}
	t.Logf("Running GeneratingPolicy context resource lookup test from %s", testCase.Dir())
	testResponse, err := runTest(out, testCase, false)
	require.NoError(t, err, "Failed to run test: %s", out.String())

	t.Logf("Test output: %s", out.String())

	t.Run("GeneratingPolicy with resource.get() produces engine response", func(t *testing.T) {
		require.NotEmpty(t, testResponse.Trigger, "expected trigger entries for GeneratingPolicy")
		var found bool
		for _, responses := range testResponse.Trigger {
			for _, r := range responses {
				if r.Policy().GetName() == "generate-env-config" {
					found = true
					require.NotEmpty(t, r.PolicyResponse.Rules, "expected rules in policy response")
					// Verify the policy produced a pass result
					for _, rule := range r.PolicyResponse.Rules {
						assert.Equal(t, engineapi.RuleStatusPass, rule.Status(), "expected rule to pass")
					}
					break
				}
			}
		}
		assert.True(t, found, "expected engine response for policy generate-env-config")
	})
}

func TestIsRulelessPolicyKind(t *testing.T) {
	rulelessKinds := []string{
		// cluster-scoped CEL kinds
		"ValidatingPolicy",
		"ValidatingAdmissionPolicy",
		"MutatingPolicy",
		"MutatingAdmissionPolicy",
		"ImageValidatingPolicy",
		"GeneratingPolicy",
		"DeletingPolicy",
		// namespaced variants
		"NamespacedValidatingPolicy",
		"NamespacedMutatingPolicy",
		"NamespacedImageValidatingPolicy",
		"NamespacedGeneratingPolicy",
		"NamespacedDeletingPolicy",
	}
	for _, kind := range rulelessKinds {
		t.Run(kind+"_is_ruleless", func(t *testing.T) {
			assert.True(t, isRulelessPolicyKind(kind),
				"expected %q to be detected as a ruleless policy kind", kind)
		})
	}

	ruleBasedKinds := []string{
		"ClusterPolicy",
		"Policy",
		"",        // empty string must not match
		"Unknown", // arbitrary unknown kind must not match
	}
	for _, kind := range ruleBasedKinds {
		t.Run(kind+"_is_NOT_ruleless", func(t *testing.T) {
			assert.False(t, isRulelessPolicyKind(kind),
				"expected %q to NOT be detected as a ruleless policy kind", kind)
		})
	}
}

func TestLookupRuleResponses(t *testing.T) {

	fakeResponse := *engineapi.RulePass("require-department-annotation", engineapi.Validation, "passed", nil)
	mismatchedRule := "validate-department-annotation"

	tests := []struct {
		name       string
		testResult v1alpha1.TestResult
		responses  []engineapi.RuleResponse
		wantCount  int
	}{
		{
			// Gen-1 policy: rule name matches exactly → should find it
			name: "Gen-1 policy with matching rule name returns the response",
			testResult: v1alpha1.TestResult{TestResultBase: v1alpha1.TestResultBase{
				Rule: "require-department-annotation", // matches fakeResponse name
			}},
			wantCount: 1,
		},
		{
			// Gen-1 policy: rule name does NOT match → correctly filtered out
			name: "Gen-1 policy with wrong rule name returns nothing",
			testResult: v1alpha1.TestResult{TestResultBase: v1alpha1.TestResultBase{
				Rule: mismatchedRule, // "validate-department-annotation" != engine response name
			}},
			wantCount: 0,
		},
		{
			name: "Gen-1 policy autogen rule name matches",
			testResult: v1alpha1.TestResult{TestResultBase: v1alpha1.TestResultBase{
				Rule: "require-department-annotation",
			}},
			responses: []engineapi.RuleResponse{
				*engineapi.RulePass("autogen-require-department-annotation", engineapi.Validation, "passed", nil),
			},
			wantCount: 1,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			responses := tt.responses
			if len(responses) == 0 {
				responses = []engineapi.RuleResponse{fakeResponse}
			}
			result := lookupRuleResponses(tt.testResult, responses...)
			assert.Len(t, result, tt.wantCount,
				"lookupRuleResponses returned unexpected number of responses")
		})
	}
}

func TestCheckResultGeneratedResources(t *testing.T) {
	policy := &kyvernov1.ClusterPolicy{}
	policy.SetName("test-policy")

	actual := unstructured.Unstructured{
		Object: map[string]interface{}{
			"apiVersion": "v1",
			"kind":       "ResourceQuota",
			"metadata": map[string]interface{}{
				"name":      "default-resourcequota",
				"namespace": "hello-world-namespace",
			},
			"spec": map[string]interface{}{
				"hard": map[string]interface{}{
					"requests.cpu": "4",
				},
			},
		},
	}

	matchingYAML := `apiVersion: v1
kind: ResourceQuota
metadata:
  name: default-resourcequota
  namespace: hello-world-namespace
spec:
  hard:
    requests.cpu: "4"
`
	nonMatchingYAML := `apiVersion: v1
kind: LimitRange
metadata:
  name: default-limitrange
  namespace: hello-world-namespace
spec:
  limits: []
`

	rule := *engineapi.RulePass("test-rule", engineapi.Generation, "generated", nil)
	response := engineapi.NewEngineResponse(
		actual,
		engineapi.NewKyvernoPolicy(policy),
		nil,
	).WithPolicyResponse(engineapi.PolicyResponse{
		Rules: []engineapi.RuleResponse{rule},
	})

	makeFS := func(t *testing.T, files map[string]string) billy.Filesystem {
		t.Helper()
		fs := memfs.New()
		for name, content := range files {
			f, err := fs.Create(name)
			require.NoError(t, err)
			_, err = f.Write([]byte(content))
			require.NoError(t, err)
			f.Close()
		}
		return fs
	}

	tests := []struct {
		name               string
		generatedResources []string
		fsFiles            map[string]string
		wantOk             bool
		wantReason         string
	}{
		{
			name:               "match found in list",
			generatedResources: []string{"nonmatch.yaml", "match.yaml"},
			fsFiles: map[string]string{
				"nonmatch.yaml": nonMatchingYAML,
				"match.yaml":    matchingYAML,
			},
			wantOk:     true,
			wantReason: "Ok",
		},
		{
			name:               "no match in list",
			generatedResources: []string{"nonmatch.yaml"},
			fsFiles: map[string]string{
				"nonmatch.yaml": nonMatchingYAML,
			},
			wantOk:     false,
			wantReason: "Resource error",
		},
		{
			name:               "all files missing",
			generatedResources: []string{"missing.yaml"},
			fsFiles:            map[string]string{},
			wantOk:             false,
			wantReason:         "Resource error",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			fs := makeFS(t, tt.fsFiles)
			testResult := v1alpha1.TestResult{
				TestResultBase: v1alpha1.TestResultBase{
					Policy: "test-policy",
					Rule:   "test-rule",
					Result: openreportsv1alpha1.Result(openreports.StatusPass),
				},
				TestResultData: v1alpha1.TestResultData{
					GeneratedResources: tt.generatedResources,
				},
			}
			ok, _, reason := checkResult(testResult, fs, "", response, rule, actual, true)
			assert.Equal(t, tt.wantOk, ok)
			assert.Equal(t, tt.wantReason, reason)
		})
	}
}

func TestRunTest_MutatingPoliciesWithCRD(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err, "Failed to get working directory")
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-mutating-policy", "mutate-custom-crd")

	if _, statErr := os.Stat(testDir); os.IsNotExist(statErr) {
		t.Skip("Test directory not found, skipping test")
		return
	}

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	testCase := testCases[0]

	out := &bytes.Buffer{}
	testResponse, err := runTest(out, testCase, false)
	require.NoError(t, err, "Failed to run test")
	t.Logf("Test output: %s", out.String())

	require.NotEmpty(t, testResponse.Trigger, "expected engine responses for custom CRD mutation test")
	var found bool
	for _, responses := range testResponse.Trigger {
		for _, r := range responses {
			if r.Policy().GetName() == "set-annotations-for-widget" {
				found = true
				require.NotEmpty(t, r.PolicyResponse.Rules, "expected rules evaluated for set-annotations-for-widget")
				break
			}
		}
	}
	require.True(t, found, "expected engine response for policy set-annotations-for-widget")
}

func TestRunTest_MutatingPolicySubresourceMatch(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err, "Failed to get working directory")
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-mutating-policy", "mutate-pod-binding-subresource")

	if _, statErr := os.Stat(testDir); os.IsNotExist(statErr) {
		t.Skip("Test directory not found, skipping test")
		return
	}

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	out := &bytes.Buffer{}
	testResponse, err := runTest(out, testCases[0], false)
	require.NoError(t, err, "Failed to run test: %s", out.String())

	// A resourceRule of "pods/binding" only matches when the engine request
	// carries the "binding" subresource. Before the fix, the CLI always sent
	// an empty subresource for MutatingPolicies, so matchConstraints never
	// matched and no rule (nor mutation) was produced for the trigger.
	var found bool
	for _, responses := range testResponse.Trigger {
		for _, r := range responses {
			if r.Policy().GetName() != "mutate-add-aws-zone-id" {
				continue
			}
			found = true
			require.NotEmpty(t, r.PolicyResponse.Rules, "expected the pods/binding matchConstraints rule to match and produce a rule response")
			annotations := r.PatchedResource.GetAnnotations()
			require.Equal(t, "test-az", annotations["pod-topology.k8s.aws/zone-id"], "expected the mutation to be applied to the binding resource")
		}
	}
	require.True(t, found, "expected engine response for policy mutate-add-aws-zone-id")
}

func TestRunTestDeletingPolicyObjectSelectorSkipsUnmatchedResource(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err, "Failed to get working directory")
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-deleting-policy", "object-selector")

	if _, statErr := os.Stat(testDir); os.IsNotExist(statErr) {
		t.Skip("Test directory not found, skipping test")
		return
	}
	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)

	out := &bytes.Buffer{}
	testResponse, err := runTest(out, testCases[0], false)
	require.NoError(t, err, "Failed to run test: %s", out.String())

	got := map[string]engineapi.RuleStatus{}
	for _, responses := range testResponse.Trigger {
		for _, response := range responses {
			for _, rule := range response.PolicyResponse.Rules {
				got[response.Resource.GetName()] = rule.Status()
			}
		}
	}

	assert.Equal(t, engineapi.RuleStatusPass, got["secret-delete"])
	// Resources excluded by matchConstraints (here: objectSelector) must not
	// produce any result row, matching vpol/mpol CLI behavior.
	_, found := got["secret-skip"]
	assert.False(t, found, "constraint-excluded resource must not produce a rule response")
}

func Test_OperationDelete(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err, "Failed to get working directory")
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-validating-policy", "operation-delete")

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1, "Expected exactly one test case in %s", testFile)
	testCase := testCases[0]

	out := &bytes.Buffer{}
	testResponse, err := runTest(out, testCase, false)
	require.NoError(t, err, "Failed to run test")

	resourceKey := "v1,Pod,test-ns,protected-pod"

	t.Run("DELETE run evaluates DELETE-scoped policy against oldObject", func(t *testing.T) {
		require.Contains(t, testResponse.TriggerByOperation, "DELETE")
		responses := testResponse.TriggerByOperation["DELETE"][resourceKey]
		require.NotEmpty(t, responses)
		var found bool
		for _, response := range responses {
			if response.Policy().GetName() != "deny-protected-deletion" {
				continue
			}
			for _, rule := range response.PolicyResponse.Rules {
				if rule.Status() == engineapi.RuleStatusFail {
					found = true
				}
			}
		}
		assert.True(t, found, "expected a failing rule for deny-protected-deletion in the DELETE run")
	})

	t.Run("default run skips the DELETE-scoped policy", func(t *testing.T) {
		responses := testResponse.Trigger[resourceKey]
		require.NotEmpty(t, responses)
		for _, response := range responses {
			if response.Policy().GetName() == "deny-protected-deletion" {
				assert.Empty(t, response.PolicyResponse.Rules, "DELETE-scoped policy must not match the default CREATE run")
			}
		}
	})

	t.Run("default run evaluates the CREATE-scoped policy", func(t *testing.T) {
		responses := testResponse.Trigger[resourceKey]
		var found bool
		for _, response := range responses {
			if response.Policy().GetName() != "require-env-label" {
				continue
			}
			for _, rule := range response.PolicyResponse.Rules {
				if rule.Status() == engineapi.RuleStatusFail {
					found = true
				}
			}
		}
		assert.True(t, found, "expected a failing rule for require-env-label in the default run")
	})
}

func Test_InvalidResultOperation(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err, "Failed to get working directory")
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-validating-policy", "operation-delete")

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1)
	testCase := testCases[0]
	testCase.Test.Results[0].Operation = "CONNECT"

	_, err = runTest(io.Discard, testCase, false)
	require.Error(t, err)
	assert.Contains(t, err.Error(), "invalid operation")
}

func Test_RunTestWarningsAsErrors(t *testing.T) {
	wd, err := os.Getwd()
	require.NoError(t, err, "Failed to get working directory")
	rootDir := filepath.Join(wd, "..", "..", "..", "..", "..")
	testDir := filepath.Join(rootDir, "test", "cli", "test-exceptions", "exceptions-deprecated")

	testFile := filepath.Join(testDir, "kyverno-test.yaml")
	testCases := test.LoadTest(nil, testFile)
	require.Len(t, testCases, 1)

	_, err = runTest(io.Discard, testCases[0], false, true)
	require.Error(t, err)
	assert.Contains(t, err.Error(), "--warnings-as-errors is set")
}

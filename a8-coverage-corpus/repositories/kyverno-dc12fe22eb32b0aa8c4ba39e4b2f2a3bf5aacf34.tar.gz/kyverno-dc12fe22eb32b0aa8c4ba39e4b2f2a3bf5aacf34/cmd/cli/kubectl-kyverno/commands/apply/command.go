package apply

import (
	"context"
	"fmt"
	"io"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"

	authv3 "github.com/envoyproxy/go-control-plane/envoy/service/auth/v3"
	"github.com/go-git/go-billy/v5"
	"github.com/go-git/go-billy/v5/memfs"
	git "github.com/go-git/go-git/v5"
	"github.com/go-git/go-git/v5/plumbing/transport/http"
	policiesv1beta1 "github.com/kyverno/api/api/policies.kyverno.io/v1beta1"
	authzhttp "github.com/kyverno/kyverno-authz/pkg/cel/libs/authz/http"
	kyvernov1 "github.com/kyverno/kyverno/api/kyverno/v1"
	kyvernov2 "github.com/kyverno/kyverno/api/kyverno/v2"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/command"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/commands/test"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/data"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/deprecations"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/exception"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/log"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/output/color"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/payload"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/policy"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/processor"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/source"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/store"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/userinfo"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/utils/common"
	"github.com/kyverno/kyverno/cmd/cli/kubectl-kyverno/variables"
	"github.com/kyverno/kyverno/pkg/autogen"
	celengine "github.com/kyverno/kyverno/pkg/cel/engine"
	"github.com/kyverno/kyverno/pkg/cel/matching"
	dpolcompiler "github.com/kyverno/kyverno/pkg/cel/policies/dpol/compiler"
	dpolengine "github.com/kyverno/kyverno/pkg/cel/policies/dpol/engine"
	ivpolengine "github.com/kyverno/kyverno/pkg/cel/policies/ivpol/engine"
	"github.com/kyverno/kyverno/pkg/cli/loader"
	"github.com/kyverno/kyverno/pkg/clients/dclient"
	"github.com/kyverno/kyverno/pkg/config"
	engineapi "github.com/kyverno/kyverno/pkg/engine/api"
	enginecontext "github.com/kyverno/kyverno/pkg/engine/context"
	"github.com/kyverno/kyverno/pkg/engine/factories"
	"github.com/kyverno/kyverno/pkg/engine/jmespath"
	imageverifycache "github.com/kyverno/kyverno/pkg/image/verification/cache"
	eval "github.com/kyverno/kyverno/pkg/image/verification/evaluator"
	"github.com/kyverno/kyverno/pkg/utils/conditions"
	gitutils "github.com/kyverno/kyverno/pkg/utils/git"
	matchutils "github.com/kyverno/kyverno/pkg/utils/match"
	utils "github.com/kyverno/kyverno/pkg/utils/restmapper"
	policyvalidation "github.com/kyverno/kyverno/pkg/validation/policy"
	"github.com/spf13/cobra"
	admissionregistrationv1 "k8s.io/api/admissionregistration/v1"
	admissionregistrationv1beta1 "k8s.io/api/admissionregistration/v1beta1"
	authenticationv1 "k8s.io/api/authentication/v1"
	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/meta"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/client-go/dynamic"
	"k8s.io/client-go/informers"
	"k8s.io/client-go/kubernetes"
	corev1listers "k8s.io/client-go/listers/core/v1"
	"k8s.io/client-go/metadata"
)

type SkippedInvalidPolicies struct {
	skipped []PolicyDiagnostic
	invalid []PolicyDiagnostic
}

type PolicyDiagnostic struct {
	name   string
	reason string
}

type ApplyCommandConfig struct {
	KubeConfig                string
	Context                   string
	Namespace                 string
	MutateLogPath             string
	Variables                 []string
	ValuesFile                string
	UserInfoPath              string
	ContextPath               string
	Cluster                   bool
	PolicyReport              bool
	OutputFormat              string
	Stdin                     bool
	RegistryAccess            bool
	AuditWarn                 bool
	ResourcePaths             []string
	PolicyPaths               []string
	TargetResourcePaths       []string
	ParamResources            []string
	GitBranch                 string
	GitUsername               string
	GitPassword               string
	warnExitCode              int
	warnNoPassed              bool
	warningsAsErrors          bool
	Exception                 []string
	ContinueOnFail            bool
	inlineExceptions          bool
	exceptionsWithinResources bool
	exceptionsWithinPolicies  bool
	GenerateExceptions        bool
	GeneratedExceptionTTL     time.Duration
	JSONPaths                 []string
	HTTPPayloadPaths          []string
	EnvoyPayloadPaths         []string
	ClusterWideResources      bool
	Concurrent                int
	BatchSize                 int
	ContinueOnError           bool
	ShowPerformance           bool
	CrdPaths                  []string
	deprecationWarnings       []string
	// Cloner is an optional function for cloning git repositories.
	// If nil, defaults to gitutils.Clone. Tests can inject a fake
	// to avoid real network calls while still exercising the git-URL
	// policy loading code path.
	Cloner gitutils.CloneFunc
}

// cloneRepo clones a git repository using the configured Cloner function.
// If no Cloner is set, it falls back to the default gitutils.Clone which
// includes a timeout to prevent indefinite hangs.
func (c *ApplyCommandConfig) cloneRepo(repoURL string, fs billy.Filesystem, branch string, auth http.BasicAuth) (*git.Repository, error) {
	cloneFn := gitutils.CloneFunc(gitutils.Clone)
	if c.Cloner != nil {
		cloneFn = c.Cloner
	}
	return cloneFn(repoURL, fs, branch, auth)
}

func Command() *cobra.Command {
	var removeColor, detailedResults, table bool
	applyCommandConfig := &ApplyCommandConfig{}
	cmd := &cobra.Command{
		Use:          "apply",
		Short:        command.FormatDescription(true, websiteUrl, false, description...),
		Long:         command.FormatDescription(false, websiteUrl, false, description...),
		Example:      command.FormatExamples(examples...),
		SilenceUsage: true,
		RunE: func(cmd *cobra.Command, args []string) (err error) {
			out := cmd.OutOrStdout()
			color.Init(removeColor)
			applyCommandConfig.PolicyPaths = args
			rc, _, skipInvalidPolicies, responses, err := applyCommandConfig.applyCommandHelper(out)
			if err != nil {
				return err
			}
			cmd.SilenceErrors = true
			printSkippedAndInvalidPolicies(out, skipInvalidPolicies)
			if applyCommandConfig.PolicyReport {
				printReports(out, responses, applyCommandConfig.AuditWarn, applyCommandConfig.OutputFormat)
			} else if applyCommandConfig.GenerateExceptions {
				printExceptions(out, responses, applyCommandConfig.AuditWarn, applyCommandConfig.OutputFormat, applyCommandConfig.GeneratedExceptionTTL)
			} else if table {
				printTable(out, detailedResults, applyCommandConfig.AuditWarn, responses...)
			} else {
				for _, response := range responses {
					var failedRules []engineapi.RuleResponse
					resPath := fmt.Sprintf("%s/%s/%s", response.Resource.GetNamespace(), response.Resource.GetKind(), response.Resource.GetName())
					if resPath == "//" {
						resPath = "JSON payload"
					}
					for _, rule := range response.PolicyResponse.Rules {
						if rule.Status() == engineapi.RuleStatusFail {
							failedRules = append(failedRules, rule)
						}
						if rule.RuleType() == engineapi.Mutation {
							if rule.Status() == engineapi.RuleStatusSkip {
								fmt.Fprintln(out, "\nskipped mutate policy", response.Policy().GetName(), "->", "resource", resPath)
							} else if rule.Status() == engineapi.RuleStatusError {
								fmt.Fprintln(out, "\nerror while applying mutate policy", response.Policy().GetName(), "->", "resource", resPath, "\nerror: ", rule.Message())
							}
						}
						if rule.RuleType() == engineapi.Generation {
							if rule.Status() == engineapi.RuleStatusError {
								fmt.Fprintln(out, "\nerror while applying generate policy", response.Policy().GetName(), "->", "resource", resPath, "\nerror:", rule.Message())
							}
						}
					}
					if len(failedRules) > 0 {
						auditWarn := false
						if applyCommandConfig.AuditWarn && response.GetValidationFailureAction().Audit() {
							auditWarn = true
						}
						if auditWarn {
							fmt.Fprintln(out, "policy", response.Policy().GetName(), "->", "resource", resPath, "failed as audit warning:")
						} else {
							fmt.Fprintln(out, "policy", response.Policy().GetName(), "->", "resource", resPath, "failed:")
						}
						for i, rule := range failedRules {
							msg := rule.Message()
							if msg == "" {
								msg = "validation failed"
							}
							fmt.Fprintln(out, i+1, "-", rule.Name(), msg)
						}
					}
				}
				printViolations(out, rc)
			}
			return exit(out, rc, applyCommandConfig.warnExitCode, applyCommandConfig.warnNoPassed)
		},
	}

	cmd.Flags().StringSliceVarP(&applyCommandConfig.JSONPaths, "json", "", []string{}, "Path to JSON payload files")
	cmd.Flags().StringSliceVarP(&applyCommandConfig.HTTPPayloadPaths, "http-payload", "", []string{}, "Path to HTTP check request payload files (JSON)")
	cmd.Flags().StringSliceVarP(&applyCommandConfig.EnvoyPayloadPaths, "envoy-payload", "", []string{}, "Path to Envoy check request payload files (JSON)")
	cmd.Flags().StringSliceVarP(&applyCommandConfig.ResourcePaths, "resource", "r", []string{}, "Path to resource files")
	cmd.Flags().StringSliceVarP(&applyCommandConfig.ResourcePaths, "resources", "", []string{}, "Path to resource files")
	cmd.Flags().StringSliceVarP(&applyCommandConfig.TargetResourcePaths, "target-resource", "", []string{}, "Path to individual files containing target resources files for policies that have mutate existing")
	cmd.Flags().StringSliceVarP(&applyCommandConfig.TargetResourcePaths, "target-resources", "", []string{}, "Path to a directory containing target resources files for policies that have mutate existing")
	cmd.Flags().BoolVarP(&applyCommandConfig.Cluster, "cluster", "c", false, "Checks if policies should be applied to cluster in the current context")
	cmd.Flags().StringVarP(&applyCommandConfig.MutateLogPath, "output", "o", "", "Prints the mutated/generated resources in provided file/directory")
	// currently `set` flag supports variable for single policy applied on single resource
	cmd.Flags().StringVarP(&applyCommandConfig.UserInfoPath, "userinfo", "u", "", "Admission Info including Roles, Cluster Roles and Subjects")
	cmd.Flags().StringSliceVarP(&applyCommandConfig.Variables, "set", "s", nil, "Variables that are required")
	cmd.Flags().StringVarP(&applyCommandConfig.ValuesFile, "values-file", "f", "", "File containing values for policy variables")
	cmd.Flags().StringVarP(&applyCommandConfig.ContextPath, "context-file", "", "", "File containing context data for CEL policies")
	cmd.Flags().BoolVarP(&applyCommandConfig.PolicyReport, "policy-report", "p", false, "Generates policy report when passed (default policyviolation)")
	cmd.Flags().StringVarP(&applyCommandConfig.OutputFormat, "output-format", "", "yaml", "Specifies the policy report format (json or yaml). Default: yaml.")
	cmd.Flags().StringVarP(&applyCommandConfig.Namespace, "namespace", "n", "", "Optional Policy parameter passed with cluster flag")
	cmd.Flags().BoolVarP(&applyCommandConfig.Stdin, "stdin", "i", false, "Optional mutate policy parameter to pipe directly through to kubectl")
	cmd.Flags().BoolVar(&applyCommandConfig.RegistryAccess, "registry", false, "If set to true, access the image registry using local docker credentials to populate external data")
	cmd.Flags().StringVar(&applyCommandConfig.KubeConfig, "kubeconfig", "", "path to kubeconfig file with authorization and master location information")
	cmd.Flags().StringVar(&applyCommandConfig.Context, "context", "", "The name of the kubeconfig context to use")
	cmd.Flags().StringVarP(&applyCommandConfig.GitBranch, "git-branch", "b", "", "test git repository branch")
	cmd.Flags().StringVar(&applyCommandConfig.GitUsername, "username", "", "Username for connecting to git repository")
	cmd.Flags().StringVar(&applyCommandConfig.GitPassword, "password", "", "Password for connecting to git repository")
	cmd.Flags().BoolVar(&applyCommandConfig.AuditWarn, "audit-warn", false, "If set to true, will flag audit policies as warnings instead of failures")
	cmd.Flags().IntVar(&applyCommandConfig.warnExitCode, "warn-exit-code", 0, "Set the exit code for warnings; if failures or errors are found, will exit 1")
	cmd.Flags().BoolVar(&applyCommandConfig.warnNoPassed, "warn-no-pass", false, "Specify if warning exit code should be raised if no objects satisfied a policy; can be used together with --warn-exit-code flag")
	cmd.Flags().BoolVar(&applyCommandConfig.warningsAsErrors, "warnings-as-errors", false, "Treat deprecation warnings as errors")
	cmd.Flags().BoolVar(&removeColor, "remove-color", false, "Remove any color from output")
	cmd.Flags().BoolVar(&detailedResults, "detailed-results", false, "If set to true, display detailed results")
	cmd.Flags().BoolVarP(&table, "table", "t", false, "Show results in table format")
	cmd.Flags().StringSliceVarP(&applyCommandConfig.ParamResources, "parameter-resource", "", []string{}, "Path to resource files that act as ValidatingAdmissionPolicy/MutatingAdmissionPolicy parameters")
	cmd.Flags().StringSliceVarP(&applyCommandConfig.Exception, "exception", "e", nil, "Policy exception to be considered when evaluating policies against resources")
	cmd.Flags().StringSliceVarP(&applyCommandConfig.Exception, "exceptions", "", nil, "Policy exception to be considered when evaluating policies against resources")
	cmd.Flags().BoolVar(&applyCommandConfig.ContinueOnFail, "continue-on-fail", false, "If set to true, will continue to apply policies on the next resource upon failure to apply to the current resource instead of exiting out")
	cmd.Flags().BoolVarP(&applyCommandConfig.inlineExceptions, "exceptions-with-resources", "", false, "Evaluate policy exceptions from the resources path")
	cmd.Flags().BoolVarP(&applyCommandConfig.exceptionsWithinResources, "exceptions-within-resources", "", false, "Evaluate policy exceptions from the resources path")
	cmd.Flags().BoolVarP(&applyCommandConfig.exceptionsWithinPolicies, "exceptions-within-policies", "", false, "Evaluate policy exceptions from the policies path")
	cmd.Flags().BoolVarP(&applyCommandConfig.GenerateExceptions, "generate-exceptions", "", false, "Generate policy exceptions for each violation")
	cmd.Flags().DurationVarP(&applyCommandConfig.GeneratedExceptionTTL, "generated-exception-ttl", "", time.Hour*24*30, "Default TTL for generated exceptions")
	cmd.Flags().BoolVarP(&applyCommandConfig.ClusterWideResources, "cluster-wide-resources", "", false, "If set to true, will apply policies to cluster-wide resources")

	cmd.Flags().IntVar(&applyCommandConfig.Concurrent, "concurrent", 1, "Number of concurrent workers for resource loading")
	cmd.Flags().IntVar(&applyCommandConfig.BatchSize, "batch-size", 100, "Number of resources to fetch per API call")
	cmd.Flags().BoolVar(&applyCommandConfig.ContinueOnError, "continue-on-error", true, "Continue processing despite resource loading errors")
	cmd.Flags().BoolVar(&applyCommandConfig.ShowPerformance, "show-performance", false, "Show resource loading performance metrics")
	cmd.Flags().StringSliceVar(&applyCommandConfig.CrdPaths, "crd-paths", []string{}, "List of paths to CRD files to be used for apply command")
	cmd.Flags().StringSliceVar(&applyCommandConfig.CrdPaths, "crd-path", nil, "Deprecated: use --crd-paths instead")
	_ = cmd.Flags().MarkDeprecated("crd-path", "use --crd-paths instead")
	return cmd
}

func (c *ApplyCommandConfig) applyCommandHelper(out io.Writer) (*processor.ResultCounts, []*unstructured.Unstructured, SkippedInvalidPolicies, []engineapi.EngineResponse, error) {
	var skippedInvalidPolicies SkippedInvalidPolicies
	c.deprecationWarnings = nil
	err := c.checkArguments()
	if err != nil {
		return nil, nil, skippedInvalidPolicies, nil, err
	}
	mutateLogPathIsDir, err := c.getMutateLogPathIsDir()
	if err != nil {
		return nil, nil, skippedInvalidPolicies, nil, err
	}
	if err := c.cleanPreviousContent(mutateLogPathIsDir); err != nil {
		return nil, nil, skippedInvalidPolicies, nil, err
	}
	crdProcessor := data.NewCRDProcessor(nil)
	data.InjectProcessor(crdProcessor)

	var userInfo *kyvernov2.RequestInfo
	if c.UserInfoPath != "" {
		info, err := userinfo.Load(nil, c.UserInfoPath, "")
		if err != nil {
			return nil, nil, skippedInvalidPolicies, nil, fmt.Errorf("failed to load request info (%w)", err)
		}
		deprecations.CheckUserInfo(out, c.UserInfoPath, info)
		userInfo = &info.RequestInfo
	}
	variables, err := variables.New(out, nil, "", c.ValuesFile, nil, c.Variables...)
	if err != nil {
		return nil, nil, skippedInvalidPolicies, nil, fmt.Errorf("failed to decode yaml (%w)", err)
	}
	if _, err := processor.NormalizeValuesOperation(variables.GlobalOperation()); err != nil {
		return nil, nil, skippedInvalidPolicies, nil, err
	}
	var store store.Store

	kpols, polexs, celpolexs, vaps, vapBindings, maps, mapBindings, vps, ivps, gps, dps, cps, mps, envoyPols, httpPols, err := c.loadPolicies(out)
	if err != nil {
		return nil, nil, skippedInvalidPolicies, nil, err
	}
	if err := c.failOnDeprecationWarnings(); err != nil {
		return nil, nil, skippedInvalidPolicies, nil, err
	}
	genericPolicies := make([]engineapi.GenericPolicy, 0, len(kpols)+len(vaps)+len(vps)+len(ivps)+len(gps)+len(dps)+len(cps))
	for _, pol := range kpols {
		genericPolicies = append(genericPolicies, engineapi.NewKyvernoPolicy(pol))
	}
	for _, pol := range vaps {
		genericPolicies = append(genericPolicies, engineapi.NewValidatingAdmissionPolicy(&pol))
	}
	for _, pol := range maps {
		genericPolicies = append(genericPolicies, engineapi.NewMutatingAdmissionPolicy(&pol))
	}
	for _, pol := range vps {
		genericPolicies = append(genericPolicies, engineapi.NewValidatingPolicyFromLike(pol))
	}
	for _, pol := range ivps {
		genericPolicies = append(genericPolicies, engineapi.NewImageValidatingPolicyFromLike(pol))
	}
	for _, pol := range gps {
		genericPolicies = append(genericPolicies, engineapi.NewGeneratingPolicyFromLike(pol))
	}
	for i := range dps {
		genericPolicies = append(genericPolicies, engineapi.NewDeletingPolicyFromLike(dps[i]))
	}
	for i := range cps {
		genericPolicies = append(genericPolicies, engineapi.NewCleanupPolicyFromInterface(cps[i]))
	}
	for i := range mps {
		genericPolicies = append(genericPolicies, engineapi.NewMutatingPolicyFromLike(mps[i]))
	}
	var targetResources []*unstructured.Unstructured
	if len(c.TargetResourcePaths) > 0 {
		targetResources, _, err = c.loadResources(out, c.TargetResourcePaths, genericPolicies, nil)
		if err != nil {
			return nil, nil, skippedInvalidPolicies, nil, err
		}
	}
	var parameterResources []*unstructured.Unstructured
	if len(c.ParamResources) > 0 {
		parameterResources, _, err = c.loadResources(out, c.ParamResources, genericPolicies, nil)
		if err != nil {
			return nil, nil, skippedInvalidPolicies, nil, err
		}
	}

	dClient, err := c.initStoreAndClusterClient(&store, append(targetResources, parameterResources...)...)
	if err != nil {
		return nil, nil, skippedInvalidPolicies, nil, err
	}

	resources, jsonPayloads, err := c.loadResources(out, c.ResourcePaths, genericPolicies, dClient)
	if err != nil {
		return nil, nil, skippedInvalidPolicies, nil, err
	}

	// Separate GlobalContextEntry resources from regular resources
	var gctxEntries []*kyvernov2.GlobalContextEntry
	resources, gctxEntries, err = extractGlobalContextEntries(resources)
	if err != nil {
		return nil, nil, skippedInvalidPolicies, nil, err
	}

	if !c.Cluster && (len(resources)+len(targetResources)+len(parameterResources)) > 0 {
		dClient, err = createFakeClientFromResources(resources, targetResources, parameterResources)
		if err != nil {
			return nil, nil, skippedInvalidPolicies, nil, fmt.Errorf("failed to create local resource client: %w", err)
		}
		store.AllowApiCall(true)

		if len(gctxEntries) > 0 && dClient != nil {
			gctxStore, err := buildGlobalContextStore(context.Background(), gctxEntries, dClient, jmespath.New(config.NewDefaultConfiguration(false)))
			if err != nil {
				return nil, nil, skippedInvalidPolicies, nil, fmt.Errorf("failed to build global context store: %w", err)
			}
			store.SetGlobalContextStore(gctxStore)
		}
	}

	var exceptions []*kyvernov2.PolicyException
	var celExceptions []*policiesv1beta1.PolicyException
	if c.exceptionsWithinResources || c.inlineExceptions {
		results := exception.SelectFrom(resources)
		exceptions = results.Exceptions
		celExceptions = results.CELExceptions
	} else {
		results, err := exception.Load(c.Exception...)
		if err != nil {
			return nil, nil, skippedInvalidPolicies, nil, fmt.Errorf("Error: failed to load exceptions (%s)", err)
		}
		if results != nil {
			for _, warning := range results.Warnings {
				msg := fmt.Sprintf("Warning: %s", warning)
				fmt.Fprintln(out, msg)
				c.deprecationWarnings = append(c.deprecationWarnings, msg)
			}
			exceptions = results.Exceptions
			celExceptions = results.CELExceptions
		}
	}
	if err := c.failOnDeprecationWarnings(); err != nil {
		return nil, nil, skippedInvalidPolicies, nil, err
	}

	if c.exceptionsWithinPolicies {
		exceptions = append(exceptions, polexs...)
		celExceptions = append(celExceptions, celpolexs...)
	}

	if !c.Stdin && !c.PolicyReport && !c.GenerateExceptions {
		var policyRulesCount int
		for _, policy := range kpols {
			policyRulesCount += len(autogen.Default.ComputeRules(policy, ""))
		}
		policyRulesCount += len(vaps)
		policyRulesCount += len(vps)
		policyRulesCount += len(ivps)
		policyRulesCount += len(maps)
		policyRulesCount += len(gps)
		policyRulesCount += len(dps)
		policyRulesCount += len(cps)
		policyRulesCount += len(mps)
		policyRulesCount += len(envoyPols)
		policyRulesCount += len(httpPols)
		exceptionsCount := len(exceptions)
		exceptionsCount += len(celExceptions)
		resourceCount := len(resources) + len(jsonPayloads)
		if exceptionsCount > 0 {
			fmt.Fprintf(out, "\nApplying %d policy rule(s) to %d resource(s) with %d exception(s)...\n", policyRulesCount, resourceCount, exceptionsCount)
		} else {
			fmt.Fprintf(out, "\nApplying %d policy rule(s) to %d resource(s)...\n", policyRulesCount, resourceCount)
		}
	}
	envoyRequests := make([]*authv3.CheckRequest, 0, len(c.EnvoyPayloadPaths))
	for _, path := range c.EnvoyPayloadPaths {
		request, err := processor.LoadEnvoyRequests(path)
		if err != nil {
			return nil, nil, skippedInvalidPolicies, nil, fmt.Errorf("failed to parse envoy payload from %s: %w", path, err)
		}
		envoyRequests = append(envoyRequests, request)
	}
	httpRequests := make([]*authzhttp.CheckRequest, 0, len(c.HTTPPayloadPaths))
	for _, path := range c.HTTPPayloadPaths {
		request, err := processor.LoadHTTPRequests(path)
		if err != nil {
			return nil, nil, skippedInvalidPolicies, nil, fmt.Errorf("failed to parse HTTP payload from %s: %w", path, err)
		}
		httpRequests = append(httpRequests, request)
	}

	rc, resources1, responses1, err := c.applyPolicies(
		out,
		&store,
		variables,
		kpols,
		vaps,
		vapBindings,
		vps,
		gps,
		mps,
		maps,
		mapBindings,
		resources,
		parameterResources,
		jsonPayloads,
		exceptions,
		celExceptions,
		&skippedInvalidPolicies,
		dClient,
		userInfo,
		mutateLogPathIsDir,
	)
	if err != nil {
		return rc, resources1, skippedInvalidPolicies, responses1, err
	}
	responses4, err := c.applyImageValidatingPolicies(ivps, jsonPayloads, resources1, celExceptions, variables.Namespace, userInfo, rc, dClient, variables.GlobalOperation())
	if err != nil {
		return rc, resources1, skippedInvalidPolicies, responses4, err
	}

	responses5, err := c.applyDeletingPolicies(dps, resources1, celExceptions, variables.Namespace, rc, dClient, "resource")
	if err != nil {
		return rc, resources1, skippedInvalidPolicies, responses4, err
	}

	responses6, err := c.applyDeletingPolicies(dps, jsonPayloads, celExceptions, variables.Namespace, rc, dClient, "json")
	if err != nil {
		return rc, resources1, skippedInvalidPolicies, responses4, err
	}

	responses7, err := c.applyCleanupPolicies(cps, resources1, variables.Namespace, rc, dClient, "resource")
	if err != nil {
		return rc, resources1, skippedInvalidPolicies, responses7, err
	}

	authzProcessor := processor.NewAuthzProcessor(rc, dClient, httpPols, envoyPols)

	httpResponses, err := authzProcessor.ApplyHTTPPolicies(httpRequests)
	if err != nil {
		return rc, resources1, skippedInvalidPolicies, responses4, err
	}

	envoyResponses, err := authzProcessor.ApplyEnvoyPolicies(envoyRequests)
	if err != nil {
		return rc, resources1, skippedInvalidPolicies, responses4, err
	}

	responses := make([]engineapi.EngineResponse, 0, len(responses1)+len(responses4)+len(responses5)+len(responses6)+len(httpResponses)+len(envoyResponses))
	responses = append(responses, responses1...)
	responses = append(responses, responses4...)
	responses = append(responses, responses5...)
	responses = append(responses, responses6...)
	responses = append(responses, responses7...)
	responses = append(responses, httpResponses...)
	responses = append(responses, envoyResponses...)
	return rc, resources1, skippedInvalidPolicies, responses, nil
}

func (c *ApplyCommandConfig) getMutateLogPathIsDir() (bool, error) {
	mutateLogPathIsDir, err := checkMutateLogPath(c.MutateLogPath)
	if err != nil {
		return false, fmt.Errorf("failed to create file/folder (%w)", err)
	}
	return mutateLogPathIsDir, nil
}

func (c *ApplyCommandConfig) applyPolicies(
	out io.Writer,
	store *store.Store,
	vars *variables.Variables,
	policies []kyvernov1.PolicyInterface,
	vaps []admissionregistrationv1.ValidatingAdmissionPolicy,
	vapBindings []admissionregistrationv1.ValidatingAdmissionPolicyBinding,
	vpols []policiesv1beta1.ValidatingPolicyLike,
	gpols []policiesv1beta1.GeneratingPolicyLike,
	mpols []policiesv1beta1.MutatingPolicyLike,
	maps []admissionregistrationv1beta1.MutatingAdmissionPolicy,
	mapBindings []admissionregistrationv1beta1.MutatingAdmissionPolicyBinding,
	resources []*unstructured.Unstructured,
	parameterResources []*unstructured.Unstructured,
	jsonPayloads []*unstructured.Unstructured,
	exceptions []*kyvernov2.PolicyException,
	celExceptions []*policiesv1beta1.PolicyException,
	skipInvalidPolicies *SkippedInvalidPolicies,
	dClient dclient.Interface,
	userInfo *kyvernov2.RequestInfo,
	mutateLogPathIsDir bool,
) (*processor.ResultCounts, []*unstructured.Unstructured, []engineapi.EngineResponse, error) {
	if vars != nil {
		vars.SetInStore(store)
	}
	var rc processor.ResultCounts
	// validate policies
	validPolicies := make([]kyvernov1.PolicyInterface, 0, len(policies))
	for _, pol := range policies {
		// TODO we should return this info to the caller
		sa := config.KyvernoUserName(config.KyvernoServiceAccountName())
		_, err := policyvalidation.Validate(pol, nil, nil, true, sa, sa)
		if err != nil {
			log.Log.Error(err, "policy validation error")
			rc.IncrementError(1)
			if strings.HasPrefix(err.Error(), "variable 'element.name'") {
				skipInvalidPolicies.invalid = append(skipInvalidPolicies.invalid, PolicyDiagnostic{name: pol.GetName(), reason: err.Error()})
			} else {
				skipInvalidPolicies.skipped = append(skipInvalidPolicies.skipped, PolicyDiagnostic{name: pol.GetName(), reason: err.Error()})
			}
			continue
		}
		validPolicies = append(validPolicies, pol)
	}
	var responses []engineapi.EngineResponse
	namespaceCache := make(map[string]*unstructured.Unstructured)

	params := make([]runtime.Object, len(parameterResources))
	for i, p := range parameterResources {
		params[i] = p
	}
	for _, resource := range resources {
		processor := processor.PolicyProcessor{
			Store:                             store,
			Policies:                          validPolicies,
			ValidatingAdmissionPolicies:       vaps,
			ValidatingAdmissionPolicyBindings: vapBindings,
			ValidatingPolicies:                vpols,
			GeneratingPolicies:                gpols,
			MutatingPolicies:                  mpols,
			MutatingAdmissionPolicies:         maps,
			MutatingAdmissionPolicyBindings:   mapBindings,
			Resource:                          *resource,
			PolicyExceptions:                  exceptions,
			CELExceptions:                     celExceptions,
			MutateLogPath:                     c.MutateLogPath,
			MutateLogPathIsDir:                mutateLogPathIsDir,
			ParameterResources:                params,
			Variables:                         vars,
			ContextPath:                       c.ContextPath,
			UserInfo:                          userInfo,
			PolicyReport:                      c.PolicyReport,
			NamespaceSelectorMap:              vars.NamespaceSelectors(),
			Stdin:                             c.Stdin,
			Rc:                                &rc,
			PrintPatchResource:                true,
			Cluster:                           c.Cluster,
			Client:                            dClient,
			AuditWarn:                         c.AuditWarn,
			Subresources:                      vars.Subresources(),
			Out:                               out,
			CrdPaths:                          c.CrdPaths,
			NamespaceCache:                    namespaceCache,
		}
		ers, err := processor.ApplyPoliciesOnResource()
		if err != nil {
			if c.ContinueOnFail {
				log.Log.V(2).Info(fmt.Sprintf("failed to apply policies on resource %s (%s)\n", resource.GetName(), err.Error()))
				continue
			}
			return &rc, resources, responses, fmt.Errorf("failed to apply policies on resource %s (%w)", resource.GetName(), err)
		}
		responses = append(responses, ers...)
	}
	for _, resource := range jsonPayloads {
		processor := processor.PolicyProcessor{
			Store:                             store,
			Policies:                          validPolicies,
			ValidatingAdmissionPolicies:       vaps,
			ValidatingAdmissionPolicyBindings: vapBindings,
			ValidatingPolicies:                vpols,
			MutatingPolicies:                  mpols,
			MutatingAdmissionPolicies:         maps,
			MutatingAdmissionPolicyBindings:   mapBindings,
			JsonPayload:                       *resource,
			PolicyExceptions:                  exceptions,
			CELExceptions:                     celExceptions,
			MutateLogPath:                     c.MutateLogPath,
			MutateLogPathIsDir:                mutateLogPathIsDir,
			Variables:                         vars,
			ContextPath:                       c.ContextPath,
			UserInfo:                          userInfo,
			PolicyReport:                      c.PolicyReport,
			NamespaceSelectorMap:              vars.NamespaceSelectors(),
			Stdin:                             c.Stdin,
			Rc:                                &rc,
			PrintPatchResource:                true,
			Cluster:                           c.Cluster,
			Client:                            dClient,
			AuditWarn:                         c.AuditWarn,
			Subresources:                      vars.Subresources(),
			Out:                               out,
			CrdPaths:                          c.CrdPaths,
			NamespaceCache:                    namespaceCache,
		}
		ers, err := processor.ApplyPoliciesOnResource()
		if err != nil {
			if c.ContinueOnFail {
				log.Log.V(2).Info(fmt.Sprintf("failed to apply policies on resource %s (%s)\n", resource.GetName(), err.Error()))
				continue
			}
			return &rc, resources, responses, fmt.Errorf("failed to apply policies on resource %s (%w)", resource.GetName(), err)
		}
		responses = append(responses, ers...)
	}
	for _, policy := range validPolicies {
		if policy.GetNamespace() == "" && policy.GetKind() == "Policy" {
			log.Log.V(3).Info(fmt.Sprintf("Policy %s has no namespace detected. Ensure that namespaced policies are correctly loaded.", policy.GetNamespace()))
		}
	}
	return &rc, resources, responses, nil
}

func (c *ApplyCommandConfig) applyImageValidatingPolicies(
	ivps []policiesv1beta1.ImageValidatingPolicyLike,
	jsonPayloads []*unstructured.Unstructured,
	resources []*unstructured.Unstructured,
	celExceptions []*policiesv1beta1.PolicyException,
	namespaceProvider func(string) *corev1.Namespace,
	userInfo *kyvernov2.RequestInfo,
	rc *processor.ResultCounts,
	dclient dclient.Interface,
	operation string,
) ([]engineapi.EngineResponse, error) {
	if len(ivps) == 0 {
		return nil, nil
	}
	provider, err := ivpolengine.NewProvider(ivps, celExceptions)
	if err != nil {
		return nil, err
	}

	var lister corev1listers.SecretLister
	if dclient != nil {
		kubeClient := dclient.GetKubeClient()
		informerFactory := informers.NewSharedInformerFactory(kubeClient, 0)

		stopCh := make(chan struct{})
		// This informer will automatically die at the end of this function and thats ok,
		// we don't care about it past applying image validating policies anyways
		defer close(stopCh)
		informerFactory.Start(stopCh)
		informerFactory.WaitForCacheSync(stopCh)

		lister = informerFactory.Core().V1().Secrets().Lister()
	}
	engine := ivpolengine.NewEngine(
		provider,
		namespaceProvider,
		matching.NewMatcher(),
		lister,
		imageverifycache.DisabledImageVerifyCache(),
		config.NewDefaultConfiguration(false),
	)

	restMapper, err := utils.GetRESTMapper(dclient)
	if err != nil {
		return nil, err
	}
	contextProvider, err := processor.NewContextProvider(dclient, restMapper, nil, c.ContextPath, c.RegistryAccess, !c.Cluster, nil, nil)
	if err != nil {
		return nil, err
	}

	responses := make([]engineapi.EngineResponse, 0)
	for _, resource := range resources {
		gvk := resource.GroupVersionKind()
		mapping, err := restMapper.RESTMapping(gvk.GroupKind(), gvk.Version)
		if err != nil {
			log.Log.Error(err, "failed to map gvk to gvr", "gkv", gvk)
			if c.ContinueOnFail {
				continue
			}
			return responses, fmt.Errorf("failed to map gvk to gvr %s (%v)\n", gvk, err)
		}
		gvr := mapping.Resource
		var user authenticationv1.UserInfo
		if userInfo != nil {
			user = userInfo.AdmissionUserInfo
		}
		op, object, oldObject := processor.AdmissionRequestShape(operation, resource)
		request := celengine.Request(
			contextProvider,
			resource.GroupVersionKind(),
			gvr,
			"",
			resource.GetName(),
			resource.GetNamespace(),
			op,
			user,
			object,
			oldObject,
			false,
			nil,
		)
		engineResponse, err := engine.HandleValidating(context.TODO(), request, nil)
		if err != nil {
			if c.ContinueOnFail {
				fmt.Printf("failed to apply image validating policies on resource %s (%v)\n", resource.GetName(), err)
				continue
			}
			return responses, fmt.Errorf("failed to apply image validating policies on resource %s (%w)", resource.GetName(), err)
		}
		resp := engineapi.EngineResponse{
			Resource:       *resource,
			PolicyResponse: engineapi.PolicyResponse{},
		}

		for _, r := range engineResponse.Policies {
			resp.PolicyResponse.Rules = []engineapi.RuleResponse{r.Result}
			resp = resp.WithPolicy(engineapi.NewImageValidatingPolicyFromLike(r.Policy))
			rc.AddValidatingPolicyResponse(resp)
			responses = append(responses, resp)
		}
	}

	ivpols := make([]*eval.CompiledImageValidatingPolicy, 0)
	pMap := make(map[string]policiesv1beta1.ImageValidatingPolicyLike)

	for i := range ivps {
		p := ivps[i]
		pMap[p.GetName()] = p
		ivpols = append(ivpols, &eval.CompiledImageValidatingPolicy{Policy: p})
	}

	for _, json := range jsonPayloads {
		result, err := eval.Evaluate(context.TODO(), ivpols, json.Object, nil, nil, lister)
		if err != nil {
			if c.ContinueOnFail {
				fmt.Printf("failed to apply image validating policies on JSON payload: %v\n", err)
				continue
			}
			return responses, fmt.Errorf("failed to apply image validating policies on JSON payload: %w", err)
		}
		resp := engineapi.EngineResponse{
			Resource:       *json,
			PolicyResponse: engineapi.PolicyResponse{},
		}
		for p, rslt := range result {
			if rslt.Error != nil {
				resp.PolicyResponse.Rules = []engineapi.RuleResponse{
					*engineapi.RuleError("evaluation", engineapi.ImageVerify, "failed to evaluate policy for JSON", rslt.Error, nil),
				}
			} else if rslt.Result {
				resp.PolicyResponse.Rules = []engineapi.RuleResponse{
					*engineapi.RulePass(p, engineapi.ImageVerify, "success", nil),
				}
			} else {
				resp.PolicyResponse.Rules = []engineapi.RuleResponse{
					*engineapi.RuleFail(p, engineapi.ImageVerify, rslt.Message, rslt.AuditAnnotations),
				}
			}
			resp = resp.WithPolicy(engineapi.NewImageValidatingPolicyFromLike(pMap[p]))
			rc.AddValidatingPolicyResponse(resp)
			responses = append(responses, resp)
		}
	}
	return responses, nil
}

func (c *ApplyCommandConfig) applyDeletingPolicies(
	dps []policiesv1beta1.DeletingPolicyLike,
	resources []*unstructured.Unstructured,
	celExceptions []*policiesv1beta1.PolicyException,
	namespaceProvider func(string) *corev1.Namespace,
	rc *processor.ResultCounts,
	dclient dclient.Interface,
	payloadType string,
) ([]engineapi.EngineResponse, error) {
	provider, err := dpolengine.NewProvider(dpolcompiler.NewCompiler(), dps, celExceptions)
	if err != nil {
		return nil, err
	}

	restMapper, err := utils.GetRESTMapper(dclient)
	if err != nil {
		return nil, err
	}

	contextProvider, err := processor.NewContextProvider(dclient, restMapper, nil, c.ContextPath, c.RegistryAccess, !c.Cluster, nil, nil)
	if err != nil {
		return nil, err
	}

	engine := dpolengine.NewEngine(namespaceProvider, restMapper, contextProvider, matching.NewMatcher())

	policies, err := provider.Fetch(context.Background())
	if err != nil {
		return nil, err
	}

	responses := make([]engineapi.EngineResponse, 0)
	for _, resource := range resources {
		for _, dpol := range policies {
			genericPolicy := engineapi.NewDeletingPolicyFromLike(dpol.Policy)
			if genericPolicy == nil {
				return nil, fmt.Errorf("unsupported deleting policy type %T", dpol.Policy)
			}
			policyName := dpol.Policy.GetName()
			resp, err := engine.Handle(context.TODO(), dpol, *resource)
			if err != nil {
				response := engineapi.NewEngineResponse(*resource, genericPolicy, nil)
				response = response.WithPolicyResponse(engineapi.PolicyResponse{Rules: []engineapi.RuleResponse{
					*engineapi.NewRuleResponse(policyName, engineapi.Deletion, err.Error(), engineapi.RuleStatusError, nil),
				}})

				responses = append(responses, response)
				rc.AddValidatingPolicyResponse(response)

				if c.ContinueOnFail {
					fmt.Printf("failed to apply deleting policies on %s: %v\n", payloadType, err)
					continue
				}
				return responses, fmt.Errorf("failed to apply deleting policies on %s: %w", payloadType, err)
			}

			status := engineapi.RuleStatusPass
			message := fmt.Sprintf("%s matched", payloadType)
			if !resp.Match {
				if !resp.PolicyMatched {
					// The resource is not selected by the policy's matchConstraints
					// (resourceRules, objectSelector, namespaceSelector). Align with
					// the other CEL policy types (vpol/mpol), which emit no result
					// row for constraint-excluded resources.
					continue
				}
				status = engineapi.RuleStatusFail
				message = fmt.Sprintf("%s did not match", payloadType)
			}

			response := engineapi.NewEngineResponse(*resource, genericPolicy, nil)
			response = response.WithPolicyResponse(engineapi.PolicyResponse{Rules: []engineapi.RuleResponse{
				*engineapi.NewRuleResponse(policyName, engineapi.Deletion, message, status, nil),
			}})

			responses = append(responses, response)

			rc.AddValidatingPolicyResponse(response)
		}
	}

	return responses, nil
}

func (c *ApplyCommandConfig) applyCleanupPolicies(
	cps []kyvernov2.CleanupPolicyInterface,
	resources []*unstructured.Unstructured,
	namespaceProvider func(string) *corev1.Namespace,
	rc *processor.ResultCounts,
	dclient dclient.Interface,
	payloadType string,
) ([]engineapi.EngineResponse, error) {
	if len(cps) == 0 || len(resources) == 0 {
		return nil, nil
	}

	// Use a basic configuration for JMESPath and image info loading.
	// Cleanup policies are destructive-intent selectors, so we only evaluate and report.
	cfg := config.NewDefaultConfiguration(false)
	jp := jmespath.New(cfg)
	ctxFactory := factories.DefaultContextLoaderFactory(nil)

	responses := make([]engineapi.EngineResponse, 0, len(cps)*len(resources))

	for _, cp := range cps {
		policyName := cp.GetName()
		spec := cp.GetSpec()
		if spec == nil {
			// Treat missing spec as an evaluation error for each candidate resource.
			for _, resource := range resources {
				response := engineapi.NewEngineResponse(*resource, engineapi.NewCleanupPolicyFromInterface(cp), nil)
				response = response.WithPolicyResponse(engineapi.PolicyResponse{
					Rules: []engineapi.RuleResponse{
						*engineapi.NewRuleResponse(policyName, engineapi.Deletion, "cleanup policy has no spec", engineapi.RuleStatusError, nil),
					},
				})
				rc.AddValidatingPolicyResponse(response)
				responses = append(responses, response)
			}
			continue
		}

		// Prepare an engine context and load policy context entries once.
		// The condition evaluation will update the target resource and namespace for each candidate.
		engineCtx := enginecontext.NewContext(jp)
		ctxLoader := ctxFactory(nil, kyvernov1.Rule{})
		if err := ctxLoader.Load(context.TODO(), jp, dclient, nil, spec.Context, engineCtx); err != nil {
			for _, resource := range resources {
				response := engineapi.NewEngineResponse(*resource, engineapi.NewCleanupPolicyFromInterface(cp), nil)
				response = response.WithPolicyResponse(engineapi.PolicyResponse{
					Rules: []engineapi.RuleResponse{
						*engineapi.NewRuleResponse(policyName, engineapi.Deletion, err.Error(), engineapi.RuleStatusError, nil),
					},
				})
				rc.AddValidatingPolicyResponse(response)
				responses = append(responses, response)
			}
			if c.ContinueOnFail {
				continue
			}
			return responses, err
		}

		engineCtx.Checkpoint()

		for _, resource := range resources {
			// Default to "not matched" unless all match/exclude checks pass and (if present) conditions evaluate to true.
			status := engineapi.RuleStatusFail
			message := fmt.Sprintf("%s did not match", payloadType)
			wouldDelete := false

			// 1) Namespace scope check (namespaced vs cluster-scoped)
			if err := matchutils.CheckNamespace(cp.GetNamespace(), *resource); err == nil {
				// 2) Resolve namespace labels for selector evaluation
				var namespaceLabels map[string]string
				if resource.GetNamespace() != "" && namespaceProvider != nil {
					if nsObj := namespaceProvider(resource.GetNamespace()); nsObj != nil {
						namespaceLabels = nsObj.GetLabels()
					}
				}

				// 3) MatchResources check (nil error => match)
				if err := matchutils.CheckMatchesResources(
					*resource,
					spec.MatchResources,
					namespaceLabels,
					kyvernov2.RequestInfo{},
					resource.GroupVersionKind(),
					"",
				); err == nil {
					// 4) ExcludeResources check (nil error => exclude matches => not deleted)
					excluded := false
					if spec.ExcludeResources != nil {
						if err := matchutils.CheckMatchesResources(
							*resource,
							*spec.ExcludeResources,
							namespaceLabels,
							kyvernov2.RequestInfo{},
							resource.GroupVersionKind(),
							"",
						); err == nil {
							excluded = true
						}
					}

					if !excluded {
						// 5) Conditions evaluation (nil conditions => match => pass)
						if spec.Conditions == nil {
							wouldDelete = true
						} else {
							// Update context for this specific candidate.
							engineCtx.Reset()
							if resource.Object == nil {
								status = engineapi.RuleStatusError
								message = "resource object is nil"
							} else if err := engineCtx.SetTargetResource(resource.Object); err != nil {
								status = engineapi.RuleStatusError
								message = err.Error()
							} else if err := engineCtx.AddNamespace(resource.GetNamespace()); err != nil {
								status = engineapi.RuleStatusError
								message = err.Error()
							} else if err := engineCtx.AddImageInfos(resource, cfg); err != nil {
								status = engineapi.RuleStatusError
								message = err.Error()
							} else {
								passed, err := conditions.CheckAnyAllConditions(log.Log, engineCtx, *spec.Conditions)
								if err != nil {
									status = engineapi.RuleStatusError
									message = err.Error()
								} else {
									wouldDelete = passed
								}
							}
						}
					}
				}
			}

			if status != engineapi.RuleStatusError {
				if wouldDelete {
					status = engineapi.RuleStatusPass
					message = fmt.Sprintf("%s matched", payloadType)
				}
			}

			response := engineapi.NewEngineResponse(*resource, engineapi.NewCleanupPolicyFromInterface(cp), nil)
			response = response.WithPolicyResponse(engineapi.PolicyResponse{
				Rules: []engineapi.RuleResponse{
					*engineapi.NewRuleResponse(policyName, engineapi.Deletion, message, status, nil),
				},
			})
			rc.AddValidatingPolicyResponse(response)
			responses = append(responses, response)
		}
	}

	return responses, nil
}

func (c *ApplyCommandConfig) loadResources(out io.Writer, paths []string, policies []engineapi.GenericPolicy, dClient dclient.Interface) ([]*unstructured.Unstructured, []*unstructured.Unstructured, error) {
	resourceOptions := loader.ResourceOptions{
		Namespace:       c.Namespace,
		Concurrency:     c.Concurrent,
		BatchSize:       c.BatchSize,
		ContinueOnError: c.ContinueOnError,
		Timeout:         5 * time.Minute,
	}
	resources, err := common.GetResourceAccordingToResourcePath(out, nil, paths, c.Cluster, policies, dClient, c.Namespace, c.PolicyReport, c.ClusterWideResources, "", resourceOptions, c.ShowPerformance)
	if err != nil {
		return resources, nil, fmt.Errorf("failed to load resources (%w)", err)
	}
	resources = test.ProcessResources(resources)
	var jsonPayloads []*unstructured.Unstructured
	if len(c.JSONPaths) > 0 {
		for _, path := range c.JSONPaths {
			payload, err := payload.Load(path)
			if err != nil {
				return nil, nil, fmt.Errorf("failed to load JSON payload (%w)", err)
			}

			jsonPayloads = append(jsonPayloads, &unstructured.Unstructured{Object: payload.(map[string]interface{})})
		}
	}
	return resources, jsonPayloads, nil
}

func (c *ApplyCommandConfig) loadPolicies(out io.Writer) (
	[]kyvernov1.PolicyInterface,
	[]*kyvernov2.PolicyException,
	[]*policiesv1beta1.PolicyException,
	[]admissionregistrationv1.ValidatingAdmissionPolicy,
	[]admissionregistrationv1.ValidatingAdmissionPolicyBinding,
	[]admissionregistrationv1beta1.MutatingAdmissionPolicy,
	[]admissionregistrationv1beta1.MutatingAdmissionPolicyBinding,
	[]policiesv1beta1.ValidatingPolicyLike,
	[]policiesv1beta1.ImageValidatingPolicyLike,
	[]policiesv1beta1.GeneratingPolicyLike,
	[]policiesv1beta1.DeletingPolicyLike,
	[]kyvernov2.CleanupPolicyInterface,
	[]policiesv1beta1.MutatingPolicyLike,
	[]*policiesv1beta1.ValidatingPolicy, // Envoy policies
	[]*policiesv1beta1.ValidatingPolicy, // HTTP policies
	error,
) {
	// load policies
	var policies []kyvernov1.PolicyInterface
	var exceptions []*kyvernov2.PolicyException
	var celExceptions []*policiesv1beta1.PolicyException
	var vaps []admissionregistrationv1.ValidatingAdmissionPolicy
	var vapBindings []admissionregistrationv1.ValidatingAdmissionPolicyBinding
	var vps []policiesv1beta1.ValidatingPolicyLike
	var maps []admissionregistrationv1beta1.MutatingAdmissionPolicy
	var mapBindings []admissionregistrationv1beta1.MutatingAdmissionPolicyBinding
	var ivps []policiesv1beta1.ImageValidatingPolicyLike
	var gps []policiesv1beta1.GeneratingPolicyLike
	var dps []policiesv1beta1.DeletingPolicyLike
	var cps []kyvernov2.CleanupPolicyInterface
	var mps []policiesv1beta1.MutatingPolicyLike
	var envoyPols []*policiesv1beta1.ValidatingPolicy
	var httpPols []*policiesv1beta1.ValidatingPolicy
	for _, path := range c.PolicyPaths {
		isGit := source.IsGit(path)
		if isGit {
			gitSourceURL, err := url.Parse(path)
			if err != nil {
				return nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, fmt.Errorf("failed to load policies (%w)", err)
			}
			pathElems := strings.Split(gitSourceURL.Path[1:], "/")
			if len(pathElems) <= 1 {
				err := fmt.Errorf("invalid URL path %s - expected https://<any_git_source_domain>/:owner/:repository/:branch (without --git-branch flag) OR https://<any_git_source_domain>/:owner/:repository/:directory (with --git-branch flag)", gitSourceURL.Path)
				return nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, fmt.Errorf("failed to parse URL (%w)", err)
			}
			gitSourceURL.Path = strings.Join([]string{pathElems[0], pathElems[1]}, "/")
			repoURL := gitSourceURL.String()
			var gitPathToYamls string
			c.GitBranch, gitPathToYamls = common.GetGitBranchOrPolicyPaths(c.GitBranch, repoURL, path)
			fs := memfs.New()
			auth := &http.BasicAuth{
				Username: c.GitUsername,
				Password: c.GitPassword,
			}
			if _, err := c.cloneRepo(repoURL, fs, c.GitBranch, *auth); err != nil {
				log.Log.V(3).Info(fmt.Sprintf("failed to clone repository  %v as it is not valid", repoURL), "error", err)
				return nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, fmt.Errorf("failed to clone repository (%w)", err)
			}
			policyYamls, err := gitutils.ListYamls(fs, gitPathToYamls)
			if err != nil {
				return nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, fmt.Errorf("failed to list YAMLs in repository (%w)", err)
			}
			for _, policyYaml := range policyYamls {
				loaderResults, err := policy.Load(fs, "", policyYaml)
				if loaderResults != nil && loaderResults.NonFatalErrors != nil {
					for _, err := range loaderResults.NonFatalErrors {
						log.Log.Error(err.Error, "Non-fatal parsing error for single document")
					}
				}
				if err != nil {
					continue
				}
				c.recordPolicyWarnings(out, loaderResults.Warnings)
				policies = append(policies, loaderResults.Policies...)
				vaps = append(vaps, loaderResults.VAPs...)
				vapBindings = append(vapBindings, loaderResults.VAPBindings...)
				vps = append(vps, loaderResults.ValidatingPolicies...)
				maps = append(maps, loaderResults.MAPs...)
				mapBindings = append(mapBindings, loaderResults.MAPBindings...)
				ivps = append(ivps, loaderResults.ImageValidatingPolicies...)
				exceptions = append(exceptions, loaderResults.PolicyExceptions...)
				celExceptions = append(celExceptions, loaderResults.PolicyCelExceptions...)
				gps = append(gps, loaderResults.GeneratingPolicies...)
				dps = append(dps, loaderResults.DeletingPolicies...)
				cps = append(cps, loaderResults.CleanupPolicies...)
				mps = append(mps, loaderResults.MutatingPolicies...)
				envoyPols = append(envoyPols, loaderResults.EnvoyPolicies...)
				httpPols = append(httpPols, loaderResults.HTTPPolicies...)
			}
		} else {
			loaderResults, err := policy.Load(nil, "", path)
			if loaderResults != nil && loaderResults.NonFatalErrors != nil {
				for _, err := range loaderResults.NonFatalErrors {
					log.Log.Error(err.Error, "Non-fatal parsing error for single document")
				}
			}
			if err != nil {
				log.Log.V(3).Info("skipping invalid YAML file", "path", path, "error", err)
			} else {
				c.recordPolicyWarnings(out, loaderResults.Warnings)
				policies = append(policies, loaderResults.Policies...)
				vaps = append(vaps, loaderResults.VAPs...)
				vapBindings = append(vapBindings, loaderResults.VAPBindings...)
				vps = append(vps, loaderResults.ValidatingPolicies...)
				maps = append(maps, loaderResults.MAPs...)
				mapBindings = append(mapBindings, loaderResults.MAPBindings...)
				ivps = append(ivps, loaderResults.ImageValidatingPolicies...)
				exceptions = append(exceptions, loaderResults.PolicyExceptions...)
				celExceptions = append(celExceptions, loaderResults.PolicyCelExceptions...)
				gps = append(gps, loaderResults.GeneratingPolicies...)
				dps = append(dps, loaderResults.DeletingPolicies...)
				cps = append(cps, loaderResults.CleanupPolicies...)
				mps = append(mps, loaderResults.MutatingPolicies...)
				envoyPols = append(envoyPols, loaderResults.EnvoyPolicies...)
				httpPols = append(httpPols, loaderResults.HTTPPolicies...)
			}
		}
		for _, policy := range policies {
			if policy.GetNamespace() == "" && policy.GetKind() == "Policy" {
				log.Log.V(3).Info(fmt.Sprintf("Namespace is empty for a namespaced Policy %s. This might cause incorrect report generation.", policy.GetName()))
			}
		}
	}
	return policies, exceptions, celExceptions, vaps, vapBindings, maps, mapBindings, vps, ivps, gps, dps, cps, mps, envoyPols, httpPols, nil
}

func (c *ApplyCommandConfig) recordPolicyWarnings(out io.Writer, warnings []policy.LoaderWarning) {
	for _, warning := range warnings {
		msg := fmt.Sprintf("Warning: %s: %s", warning.Path, warning.Warning)
		fmt.Fprintln(out, msg)
		c.deprecationWarnings = append(c.deprecationWarnings, msg)
	}
}

func (c *ApplyCommandConfig) failOnDeprecationWarnings() error {
	if c.warningsAsErrors && len(c.deprecationWarnings) > 0 {
		return fmt.Errorf("found %d deprecation warning(s) and --warnings-as-errors is set", len(c.deprecationWarnings))
	}
	return nil
}

func (c *ApplyCommandConfig) initStoreAndClusterClient(store *store.Store, targetResources ...*unstructured.Unstructured) (dclient.Interface, error) {
	store.SetLocal(true)
	store.SetRegistryAccess(c.RegistryAccess)
	if c.Cluster {
		store.AllowApiCall(true)
	}
	var err error
	var dClient dclient.Interface

	if c.Cluster {
		restConfig, err := config.CreateClientConfigWithContext(c.KubeConfig, c.Context)
		if err != nil {
			return nil, err
		}
		kubeClient, err := kubernetes.NewForConfig(restConfig)
		if err != nil {
			return nil, err
		}
		dynamicClient, err := dynamic.NewForConfig(restConfig)
		if err != nil {
			return nil, err
		}
		metadataClient, err := metadata.NewForConfig(restConfig)
		if err != nil {
			return nil, err
		}
		dClient, err = dclient.NewClient(context.Background(), dynamicClient, kubeClient, 15*time.Minute, false, metadataClient)
		if err != nil {
			return nil, err
		}
	}
	if len(targetResources) > 0 && !c.Cluster {
		var targets []runtime.Object
		for _, t := range targetResources {
			targets = append(targets, t)
		}
		dClient, err = dclient.NewFakeClient(runtime.NewScheme(), map[schema.GroupVersionResource]string{}, targets...)
		if err != nil {
			return nil, err
		}
		dClient.SetDiscovery(dclient.NewFakeDiscoveryClient(nil))
	}
	return dClient, err
}

func (c *ApplyCommandConfig) cleanPreviousContent(mutateLogPathIsDir bool) error {
	// empty the previous contents of the file just in case if the file already existed before with some content(so as to perform overwrites)
	// the truncation of files for the case when mutateLogPath is dir, is handled under pkg/kyverno/apply/common.go
	if !mutateLogPathIsDir && c.MutateLogPath != "" {
		c.MutateLogPath = filepath.Clean(c.MutateLogPath)
		// Necessary for us to include the file via variable as it is part of the CLI.
		f, err := os.OpenFile(c.MutateLogPath, os.O_TRUNC|os.O_WRONLY, 0o600) // #nosec G304
		if err != nil {
			return fmt.Errorf("failed to truncate the existing file at %s (%w)", c.MutateLogPath, err)
		}
		f.Close()
	}
	return nil
}

func hasStdinPath(paths []string) bool {
	for _, path := range paths {
		if path == "-" {
			return true
		}
	}
	return false
}

func (c *ApplyCommandConfig) checkArguments() error {
	if c.ValuesFile != "" && c.Variables != nil {
		return fmt.Errorf("pass the values either using set flag or values_file flag")
	}
	if len(c.PolicyPaths) == 0 {
		return fmt.Errorf("require policy")
	}
	if hasStdinPath(c.PolicyPaths) && hasStdinPath(c.ResourcePaths) {
		return fmt.Errorf("a stdin pipe can be used for either policies or resources, not both")
	}
	if len(c.ResourcePaths) != 0 && len(c.JSONPaths) != 0 {
		return fmt.Errorf("both resource and json files can not be used together, use one or the other")
	}
	if len(c.ResourcePaths) == 0 && len(c.JSONPaths) == 0 && len(c.HTTPPayloadPaths) == 0 && len(c.EnvoyPayloadPaths) == 0 && !c.Cluster {
		return fmt.Errorf("resource file(s) or cluster required")
	}
	normalized := make([]string, 0, len(c.CrdPaths))
	for _, p := range c.CrdPaths {
		if strings.TrimSpace(p) != "" {
			normalized = append(normalized, p)
		}
	}
	c.CrdPaths = normalized
	if len(c.CrdPaths) != 0 && strings.TrimSpace(c.KubeConfig) != "" {
		return fmt.Errorf("crd-paths and kubeconfig flags are mutually exclusive, please use only one of them")
	}
	return nil
}

type WarnExitCodeError struct {
	ExitCode int
}

func (w WarnExitCodeError) Error() string {
	return fmt.Sprintf("exit as warnExitCode is %d", w.ExitCode)
}

func createFakeClientFromResources(resources, targetResources, parameterResources []*unstructured.Unstructured) (dclient.Interface, error) {
	allResources := make([]*unstructured.Unstructured, 0, len(resources)+len(targetResources)+len(parameterResources))
	allResources = append(allResources, resources...)
	allResources = append(allResources, targetResources...)
	allResources = append(allResources, parameterResources...)

	gvrToListKind := make(map[schema.GroupVersionResource]string)
	// gvrToGVK holds the authoritative GVR→GVK mapping derived directly from
	// each resource's TypeMeta. This avoids relying on inferKindFromResourceName,
	// which mishandles multi-word kinds such as ClusterRole ("clusterroles" → "Clusterrol").
	gvrToGVK := make(map[schema.GroupVersionResource]schema.GroupVersionKind)
	var discoveryGVRs []schema.GroupVersionResource
	seen := make(map[schema.GroupVersionResource]bool)

	objects := make([]runtime.Object, 0, len(allResources))
	for _, r := range allResources {
		objects = append(objects, r.DeepCopy())
		gvk := r.GroupVersionKind()
		if gvk.Kind == "" || gvk.Version == "" {
			return nil, fmt.Errorf("resource %s/%s is missing TypeMeta (apiVersion=%q kind=%q)", r.GetNamespace(), r.GetName(), r.GetAPIVersion(), gvk.Kind)
		}
		gvr, _ := meta.UnsafeGuessKindToResource(gvk)
		if !seen[gvr] {
			seen[gvr] = true
			gvrToListKind[gvr] = gvk.Kind + "List"
			gvrToGVK[gvr] = gvk
			discoveryGVRs = append(discoveryGVRs, gvr)
		}
	}

	fakeClient, err := dclient.NewFakeClient(runtime.NewScheme(), gvrToListKind, objects...)
	if err != nil {
		return nil, err
	}
	disco := dclient.NewFakeDiscoveryClient(discoveryGVRs)
	for gvr, gvk := range gvrToGVK {
		disco.AddGVRToGVKMapping(gvr, gvk)
	}
	fakeClient.SetDiscovery(disco)
	return fakeClient, nil
}

func exit(out io.Writer, rc *processor.ResultCounts, warnExitCode int, warnNoPassed bool) error {
	if rc.Fail > 0 {
		return fmt.Errorf("exit as there are policy violations")
	} else if rc.Error > 0 {
		return fmt.Errorf("exit as there are policy errors")
	} else if rc.Warn > 0 && warnExitCode != 0 {
		fmt.Fprintf(out, "exit as warnExitCode is %d", warnExitCode)
		return WarnExitCodeError{
			ExitCode: warnExitCode,
		}
	} else if rc.Pass == 0 && warnNoPassed {
		fmt.Fprintln(out, "exit as no objects satisfied policy")
		return WarnExitCodeError{
			ExitCode: warnExitCode,
		}
	}
	return nil
}

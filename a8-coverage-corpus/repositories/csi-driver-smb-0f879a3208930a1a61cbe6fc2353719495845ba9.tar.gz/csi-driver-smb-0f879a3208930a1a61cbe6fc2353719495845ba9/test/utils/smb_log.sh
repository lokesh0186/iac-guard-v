#!/bin/bash

# Copyright 2020 The Kubernetes Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

cleanup() {
    echo "hit unexpected error during log print, exit 0"
    exit 0
}

trap cleanup ERR

NS=kube-system
CONTAINER=smb
DRIVER=smb
if [[ "$#" -gt 0 ]]; then
    DRIVER=$1
fi

echo "print out all nodes status ..."
kubectl get nodes -o wide
echo "======================================================================================"

echo "print out all default namespace pods status ..."
kubectl get pods -n default -o wide
echo "======================================================================================"

echo "print out smb-server pod logs ..."
echo "======================================================================================"
kubectl get pods -n default -l app=smb-server --no-headers -o custom-columns=":metadata.name" \
    | xargs --no-run-if-empty -I {} sh -c 'echo "--- Pod: {} ---"; kubectl logs {} -n default --all-containers 2>/dev/null || true; kubectl describe pod {} -n default 2>/dev/null | grep -A 20 "Events:" || true'
echo "======================================================================================"

echo "print out all $NS namespace pods status ..."
kubectl get pods -n${NS} -o wide
echo "======================================================================================"

echo "print out csi-$DRIVER-controller pods ..."
echo "======================================================================================"
LABEL="app=csi-$DRIVER-controller"
kubectl get pods -n${NS} -l${LABEL} \
    | awk 'NR>1 {print $1}' \
    | xargs -I {} kubectl logs {} --prefix -c${CONTAINER} -n${NS}

echo "checking csi-$DRIVER pod restarts and collecting crash logs ..."
echo "======================================================================================"
for pod in $(kubectl get pods -n${NS} -l "app in (csi-$DRIVER-controller, csi-$DRIVER-node, csi-$DRIVER-node-win)" --no-headers | awk '$4 != "0" {print $1}'); do
    echo ">>> Pod $pod has restarts, collecting debug info ..."
    echo "--- kubectl describe pod $pod ---"
    kubectl describe pod "$pod" -n${NS} || true
    echo "--- previous container logs for pod $pod ---"
    for container in $(kubectl get pod "$pod" -n${NS} -o jsonpath='{.spec.containers[*].name}'); do
        echo "  --- container: $container (previous) ---"
        kubectl logs "$pod" -n${NS} -c "$container" --previous 2>&1 || true
    done
    echo "======================================================================================"
done

echo "print out csi-$DRIVER-node logs ..."
echo "======================================================================================"
LABEL="app=csi-$DRIVER-node"
kubectl get pods -n${NS} -l${LABEL} \
    | awk 'NR>1 {print $1}' \
    | xargs -I {} kubectl logs {} --prefix -c${CONTAINER} -n${NS}

echo "print out csi-$DRIVER-node-win events ..."
echo "======================================================================================"
LABEL="app=csi-$DRIVER-node-win"
kubectl describe pods -n${NS} -l${LABEL}

echo "print out csi-$DRIVER-node-win logs ..."
echo "======================================================================================"
LABEL="app=csi-$DRIVER-node-win"
kubectl get pods -n${NS} -l${LABEL} \
    | awk 'NR>1 {print $1}' \
    | xargs -I {} kubectl logs {} --prefix -c${CONTAINER} -n${NS}

echo "print out service logs ..."
echo "======================================================================================"
kubectl get service -A

echo "print out metrics ..."
echo "======================================================================================"
ip=`kubectl get svc csi-$DRIVER-controller -n kube-system --no-headers | awk '{print $4}'`
curl http://$ip:29644/metrics

# Install CSI driver with Helm 3

## Prerequisites

- [install Helm](https://helm.sh/docs/intro/quickstart/#install-helm)

### Tips

- run smb-controller on control plane node: `--set controller.runOnControlPlane=true`
- set controller replicas to `2`: `--set controller.replicas=2` (requires ≥ 2 schedulable nodes — see [High-availability controller](#high-availability-controller) below)
- Microk8s based kubernetes recommended settings:
    - `--set linux.kubelet="/var/snap/microk8s/common/var/lib/kubelet"` - sets correct path to microk8s kubelet even though a user has a folder link to it.

### install a specific version
> [!IMPORTANT]  
> Starting from version `1.18.0`, the prefix `v` is removed from helm chart release so they are in line with [semver](https://semver.org). Therefore, when upgrading, refer to version `1.18.0` instead of `v1.18.0`.

Add the helm repo — pick **one** source (both host the same charts; do not run both, the second overwrites the first):

Option 1: raw.githubusercontent.com (default)

```console
helm repo add csi-driver-smb https://raw.githubusercontent.com/kubernetes-csi/csi-driver-smb/master/charts
```

Option 2: GitHub Pages mirror (available since 1.20.0, not affected by raw.githubusercontent.com rate limits)

```console
helm repo add csi-driver-smb https://kubernetes-csi.github.io/csi-driver-smb
```

Then update the repo cache, search for available versions, and install:

```console
helm repo update csi-driver-smb
helm search repo csi-driver-smb --versions
helm install csi-driver-smb csi-driver-smb/csi-driver-smb --namespace kube-system --version 1.20.3
```

### High-availability controller

`controller.replicas > 1` requires the same number of schedulable nodes as replicas. The controller Deployment uses `hostNetwork: true` (needed to mount SMB shares for CreateVolume), so all containers in the pod share the node's network namespace. Its `liveness-probe` sidecar listens on a **fixed host port** (`controller.livenessProbe.healthPort`, default `29642`), which the `smb` container's livenessProbe HTTP-GETs.

Scheduling two controller replicas onto the same node causes the second pod's `liveness-probe` sidecar to fail binding the port (already taken by the first pod), which trips the `smb` container's livenessProbe and puts the pod into `CrashLoopBackOff`.

To run controller replicas > 1:

1. Ensure your cluster has at least `controller.replicas` schedulable nodes (single-node clusters, including default `k3d` / `kind` configurations, must keep `controller.replicas=1`).
2. Add `podAntiAffinity` on `kubernetes.io/hostname` so replicas cannot co-locate. The `matchLabels` value below must match the controller pods' `app` label, which is derived from `controller.name` (default `csi-smb-controller`) — update it if you override `controller.name`:

```yaml
controller:
  replicas: 2
  affinity:
    podAntiAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        - topologyKey: kubernetes.io/hostname
          labelSelector:
            matchLabels:
              app: csi-smb-controller
```

> [!NOTE]
> Leader-election log lines like `"Failed to update lease optimistically, falling back to slow path"` in the active controller are **normal noise** when there are 2+ candidates racing for the same lease. They do not indicate a bug.

### install driver with customized driver name, deployment name

> only supported from `v1.2.0`+

- following example would install a driver with name `smb2`

```console
helm install csi-driver-smb2 csi-driver-smb/csi-driver-smb --namespace kube-system --set driver.name="smb2.csi.k8s.io" --set controller.name="csi-smb2-controller" --set rbac.name=smb2 --set serviceAccount.controller=csi-smb2-controller-sa --set serviceAccount.node=csi-smb2-node-sa --set node.name=csi-smb2-node --set node.livenessProbe.healthPort=39643
```

### search for all available chart versions

```console
helm search repo -l csi-driver-smb
```

## uninstall CSI driver

```console
helm uninstall csi-driver-smb -n kube-system
```

## latest chart configuration

The following table lists the configurable parameters of the latest SMB CSI Driver chart and default values.

| Parameter                                               | Description                                                                                                | Default                                                 |
|---------------------------------------------------------|------------------------------------------------------------------------------------------------------------|---------------------------------------------------------|
| `driver.name`                                           | alternative driver name                                                                                    | `smb.csi.k8s.io`                                        |
| `feature.enableGetVolumeStats`                          | allow GET_VOLUME_STATS on agent node                                                                       | `false`                                                 |
| `image.baseRepo`                                        | base repository of driver images                                                                           | `registry.k8s.io/sig-storage`                           |
| `image.smb.repository`                                  | csi-driver-smb docker image                                                                                | `gcr.io/k8s-staging-sig-storage/smbplugin`              |
| `image.smb.tag`                                         | csi-driver-smb docker image tag                                                                            | `canary`                                                |
| `image.smb.pullPolicy`                                  | csi-driver-smb image pull policy                                                                           | `IfNotPresent`                                          |
| `image.csiProvisioner.tag`                              | csi-provisioner docker image tag                                                                           | `v6.3.0`                                                |
| `image.csiProvisioner.pullPolicy`                       | csi-provisioner image pull policy                                                                          | `IfNotPresent`                                          |
| `image.livenessProbe.repository`                        | liveness-probe docker image                                                                                | `/livenessprobe`                                        |
| `image.livenessProbe.tag`                               | liveness-probe docker image tag                                                                            | `v2.19.0`                                                |
| `image.livenessProbe.pullPolicy`                        | liveness-probe image pull policy                                                                           | `IfNotPresent`                                          |
| `image.nodeDriverRegistrar.repository`                  | csi-node-driver-registrar docker image                                                                     | `/csi-node-driver-registrar`                            |
| `image.nodeDriverRegistrar.tag`                         | csi-node-driver-registrar docker image tag                                                                 | `v2.17.0`                                                |
| `image.nodeDriverRegistrar.pullPolicy`                  | csi-node-driver-registrar image pull policy                                                                | `IfNotPresent`                                          |
| `imagePullSecrets`                                      | Specify docker-registry secret names as an array                                                           | `[]` (does not add image pull secrets to deployed pods) |
| `serviceAccount.create`                                 | whether create service account of csi-smb-controller                                                       | `true`                                                  |
| `rbac.create`                                           | whether create rbac of csi-smb-controller                                                                  | `true`                                                  |
| `rbac.name`                                             | driver name in rbac role                                                                                   | `true`                                                  |
| `podAnnotations`                                        | collection of annotations to add to all the pods                                                           | `{}`                                                    |
| `podLabels`                                             | collection of labels to add to all the pods                                                                | `{}`                                                    |
| `priorityClassName`                                     | priority class name to be added to pods                                                                    | `system-cluster-critical`                               |
| `securityContext`                                       | security context to be added to pods                                                                       | `{ seccompProfile: {type: RuntimeDefault} }`            |
| `controller.name`                                       | name of driver deployment                                                                                  | `csi-smb-controller`                                    |
| `controller.replicas`                                   | replica num of csi-smb-controller                                                                          | `1`                                                     |
| `controller.dnsPolicy`                                  | dnsPolicy of driver node daemonset, available values: `Default`, `ClusterFirstWithHostNet`, `ClusterFirst` |    `ClusterFirstWithHostNet`                            |
| `controller.metricsPort`                                | metrics port of csi-smb-controller                                                                         | `29644`                                                 |
| `controller.livenessProbe.healthPort `                  | health check port for liveness probe                                                                       | `29642`                                                 |
| `controller.logLevel`                                   | controller driver log level                                                                                | `5`                                                     |
| `controller.workingMountDir`                            | working directory for provisioner to mount smb shares temporarily                                          | `/tmp`                                                  |
| `controller.runOnMaster`                                | run controller on master node                                                                              | `false`                                                 |
| `controller.runOnControlPlane`                          | run controller on control plane node                                                                       | `false`                                                 |
| `controller.resources.csiProvisioner.limits.memory`     | csi-provisioner memory limits                                                                              | `400Mi`                                                 |
| `controller.resources.csiProvisioner.requests.cpu`      | csi-provisioner cpu requests limits                                                                        | `10m`                                                   |
| `controller.resources.csiProvisioner.requests.memory`   | csi-provisioner memory requests limits                                                                     | `20Mi`                                                  |
| `controller.resources.livenessProbe.limits.memory`      | liveness-probe memory limits                                                                               | `300Mi`                                                 |
| `controller.resources.livenessProbe.requests.cpu`       | liveness-probe cpu requests limits                                                                         | `10m`                                                   |
| `controller.resources.livenessProbe.requests.memory`    | liveness-probe memory requests limits                                                                      | `20Mi`                                                  |
| `controller.resources.smb.limits.memory`                | smb-csi-driver memory limits                                                                               | `200Mi`                                                 |
| `controller.resources.smb.requests.cpu`                 | smb-csi-driver cpu requests limits                                                                         | `10m`                                                   |
| `controller.resources.smb.requests.memory`              | smb-csi-driver memory requests limits                                                                      | `20Mi`                                                  |
| `controller.resources.csiResizer.limits.memory`         | csi-resizer memory limits                                                                                  | `400Mi`                                                 |
| `controller.resources.csiResizer.requests.cpu`          | csi-resizer cpu requests limits                                                                            | `10m`                                                   |
| `controller.resources.csiResizer.requests.memory`       | csi-resizer memory requests limits                                                                         | `20Mi`                                                  |
| `controller.affinity`                                   | controller pod affinity                                                                                    | `{}`                                                    |
| `controller.nodeSelector`                               | controller pod node selector                                                                               | `{}`                                                    |
| `controller.tolerations`                                | controller pod tolerations                                                                                 | `[]`                                                    |
| `node.maxUnavailable`                                   | `maxUnavailable` value of csi-smb-node daemonset                                                           | `1`                                                     |
| `node.livenessProbe.healthPort `                        | health check port for liveness probe                                                                       | `29643`                                                 |
| `node.nodeDriverRegistrar.healthPort`                        | health check port for node-driver-registrar liveness probe                                                 | `29641`                                                 |
| `node.nodeDriverRegistrar.livenessProbe.enabled`             | enable node-driver-registrar liveness probe                                                                | `true`                                                  |
| `node.nodeDriverRegistrar.livenessProbe.initialDelaySeconds` | node-driver-registrar liveness probe initialDelaySeconds                                                   | `20`                                                    |
| `node.nodeDriverRegistrar.livenessProbe.timeoutSeconds`      | node-driver-registrar liveness probe timeoutSeconds                                                        | `10`                                                    |
| `node.nodeDriverRegistrar.livenessProbe.periodSeconds`       | node-driver-registrar liveness probe periodSeconds                                                         | `20`                                                     |
| `node.nodeDriverRegistrar.livenessProbe.failureThreshold`    | node-driver-registrar liveness probe failureThreshold                                                      | `2`                                                     |
| `node.logLevel`                                         | node driver log level                                                                                      | `5`                                                     |
| `node.affinity`                                         | node pod affinity                                                                                          | {}                                                      |
| `node.nodeSelector`                                     | node pod node selector                                                                                     | `{}`                                                    |
| `linux.enabled`                                         | whether enable linux feature                                                                               | `true`                                                  |
| `linux.dsName`                                          | name of driver daemonset on linux                                                                          | `csi-smb-node`                                          |
| `linux.dnsPolicy`                                       | dnsPolicy of driver node daemonset, available values: `Default`, `ClusterFirstWithHostNet`, `ClusterFirst` | `ClusterFirstWithHostNet`                               |
| `linux.kubelet`                                         | configure kubelet directory path on Linux agent node node                                                  | `/var/lib/kubelet`                                      |
| `linux.krb5CacheDirectory`                              | directory for kerberos cache on Linux agent node node, empty string means default                          | `/var/lib/kubelet/kerberos/`                            |
| `linux.krb5Prefix`                                      | prefix for kerberos cache on Linux agent node node, empty string means default                             | `krb5cc_`                                               |
| `linux.krb5AutoConfig`                                  | when true (and `linux.krb5CacheDirectory` is non-empty), an initContainer drops `/etc/krb5.conf.d/90-csi-driver-smb.conf` on every Linux node so `cifs.upcall` finds the per-uid credential cache produced by the driver | `false`                                                 |
| `linux.resources.livenessProbe.limits.memory`           | liveness-probe memory limits                                                                               | `100Mi`                                                 |
| `linux.resources.livenessProbe.requests.cpu`            | liveness-probe cpu requests limits                                                                         | `10m`                                                   |
| `linux.resources.livenessProbe.requests.memory`         | liveness-probe memory requests limits                                                                      | `20Mi`                                                  |
| `linux.resources.nodeDriverRegistrar.limits.memory`     | csi-node-driver-registrar memory limits                                                                    | `100Mi`                                                 |
| `linux.resources.nodeDriverRegistrar.requests.cpu`      | csi-node-driver-registrar cpu requests limits                                                              | `10m`                                                   |
| `linux.resources.nodeDriverRegistrar.requests.memory`   | csi-node-driver-registrar memory requests limits                                                           | `20Mi`                                                  |
| `linux.resources.smb.limits.memory`                     | smb-csi-driver memory limits                                                                               | `200Mi`                                                 |
| `linux.resources.smb.requests.cpu`                      | smb-csi-driver cpu requests limits                                                                         | `10m`                                                   |
| `linux.resources.smb.requests.memory`                   | smb-csi-driver memory requests limits                                                                      | `20Mi`                                                  |
| `windows.enabled`                                       | whether enable windows feature                                                                             | `true`                                                 |
| `windows.useHostProcessContainers`                | whether deploy driver daemonset with HostProcess containers on windows | `true`                                                             |
| `windows.dsName`                                        | name of driver daemonset on windows                                                                        | `csi-smb-node-win`                                      |
| `windows.removeSMBMappingDuringUnmount`                 | remove SMBMapping during unmount on Windows node windows                                                   | `true`                                                  |
| `windows.resources.livenessProbe.limits.memory`         | liveness-probe memory limits                                                                               | `200Mi`                                                 |
| `windows.resources.livenessProbe.requests.cpu`          | liveness-probe cpu requests limits                                                                         | `10m`                                                   |
| `windows.resources.livenessProbe.requests.memory`       | liveness-probe memory requests limits                                                                      | `20Mi`                                                  |
| `windows.resources.nodeDriverRegistrar.limits.memory`   | csi-node-driver-registrar memory limits                                                                    | `200Mi`                                                 |
| `windows.resources.nodeDriverRegistrar.requests.cpu`    | csi-node-driver-registrar cpu requests limits                                                              | `10m`                                                   |
| `windows.resources.nodeDriverRegistrar.requests.memory` | csi-node-driver-registrar memory requests limits                                                           | `20Mi`                                                  |
| `windows.resources.smb.limits.memory`                   | smb-csi-driver memory limits                                                                               | `400Mi`                                                 |
| `windows.resources.smb.requests.cpu`                    | smb-csi-driver cpu requests limits                                                                         | `10m`                                                   |
| `windows.resources.smb.requests.memory`                 | smb-csi-driver memory requests limits                                                                      | `20Mi`                                                  |
| `windows.kubelet`                                       | configure kubelet directory path on Windows agent node                                                     | `'C:\var\lib\kubelet'`                                  |
| `storageClasses` | create multiple storage classes | `[]` |  |

### Csi Proxy support on windows
 > if you have set `windows.useHostProcessContainers` as `true`, csi-proxy is not needed by CSI driver.

The helm can setup the host-process deamonset for the csi proxy, by setting windows.csiproxy.enabled to true.

The following table lists the configurable parameters of the latest CSI-proxy Driver chart and default values.

| Parameter                                               | Description                                                                                                | Default                                                 |
|---------------------------------------------------------|------------------------------------------------------------------------------------------------------------|---------------------------------------------------------|
| `windows.csiproxy.enabled`                              | whether enable csi-proxy daemonset                                                                         | `false`                                                 |
| `windows.csiproxy.dsName`                               | name of driver csi-proxy daemonset on windows                                                              | `csi-proxy-win`                                         |
| `windows.csiproxy.username`                             | name of windows user on the host machine to run the proxy as                                               | `NT AUTHORITY\\SYSTEM`                                  |
| `windows.csiproxy.affinity`                             | controller pod affinity                                                                                    | `{}`                                                    |
| `windows.csiproxy.nodeSelector`                         | controller pod node selector                                                                               | `{"kubernetes.io/os": windows}                          |
| `windows.csiproxy.tolerations`                          | controller pod tolerations                                                                                 | `[]`                                                    |
| `image.csiproxy.repository`                             | csiproxy docker image                                                                                      | `ghcr.io/kubernetes-sigs/sig-windows/csi-proxy`         |
| `image.csiproxy.tag`                                    | csiproxy docker image tag                                                                                  | `v1.1.2`                                                |
| `image.csiproxy.pullPolicy`                             | csiproxy image pull policy                                                                                 | `IfNotPresent`                                          |

## Create multiple storage classes

 - create multiple storage classes with different configurations using the `storageClasses` parameter:

```yaml
storageClasses:
  - name: smb-csi
    annotations:
      storageclass.kubernetes.io/is-default-class: "true"
    parameters:
      source: "//smb-server.default.svc.cluster.local/share"
      # if csi.storage.k8s.io/provisioner-secret is provided, will create a sub directory
      # with PV name under source
      csi.storage.k8s.io/provisioner-secret-name: smbcreds
      csi.storage.k8s.io/provisioner-secret-namespace: default
      csi.storage.k8s.io/node-stage-secret-name: smbcreds
      csi.storage.k8s.io/node-stage-secret-namespace: default
    reclaimPolicy: Delete
    volumeBindingMode: Immediate
    allowVolumeExpansion: true
    mountOptions:
      - dir_mode=0777
      - file_mode=0777
      - noperm
      - mfsymlinks
      - cache=strict
      - noserverino  # required to prevent data corruption
  - name: smb-csi-retain
    parameters:
      source: "//smb-server.default.svc.cluster.local/share"
      # if csi.storage.k8s.io/provisioner-secret is provided, will create a sub directory
      # with PV name under source
      csi.storage.k8s.io/provisioner-secret-name: smbcreds
      csi.storage.k8s.io/provisioner-secret-namespace: default
      csi.storage.k8s.io/node-stage-secret-name: smbcreds
      csi.storage.k8s.io/node-stage-secret-namespace: default
    reclaimPolicy: Retain
    volumeBindingMode: Immediate
    allowVolumeExpansion: true
    mountOptions:
      - dir_mode=0777
      - file_mode=0777
      - noperm
      - mfsymlinks
      - cache=strict
      - noserverino  # required to prevent data corruption
```

 - install with custom values:
```console
helm install csi-driver-smb csi-driver-smb/csi-driver-smb --namespace kube-system -f custom-values.yaml
```

## troubleshooting

- Add `--wait -v=5 --debug` in `helm install` command to get detailed error
- Use `kubectl describe` to acquire more info

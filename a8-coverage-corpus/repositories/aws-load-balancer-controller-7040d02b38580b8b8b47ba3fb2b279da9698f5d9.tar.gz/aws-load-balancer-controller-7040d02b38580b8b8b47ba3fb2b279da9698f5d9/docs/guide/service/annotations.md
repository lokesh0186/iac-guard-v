## Service annotations

!!!note ""
    - Annotation keys and values can only be strings. All other types below must be string-encoded, for example:
        - boolean: `"true"`
        - integer: `"42"`
        - stringList: `"s1,s2,s3"`
        - stringMap: `"k1=v1,k2=v2"`
        - json: `"{ \"key\": \"value\" }"`

## Annotations
!!!warning
    These annotations are specific to the kubernetes [service resources reconciled](#lb-type) by the AWS Load Balancer Controller. Although the list was initially derived from the k8s in-tree `kube-controller-manager`, this
    documentation is not an accurate reference for the services reconciled by the in-tree controller. 

!!!question "EKS Auto Mode users"
    If you are using EKS Auto Mode, please see the
    [EKS Auto Mode documentation](https://docs.aws.amazon.com/eks/latest/userguide/auto-configure-nlb.html#_considerations)
    for key differences between the load balancing capability of EKS Auto Mode and the open source load balancer controller.

| Name                                                                                                                 | Type                                          | Default                  | Notes                                                                                                                                                                                                                                                                                                                                                                                                                |
|----------------------------------------------------------------------------------------------------------------------|-----------------------------------------------|--------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| [service.beta.kubernetes.io/load-balancer-source-ranges](#lb-source-ranges)                                          | stringList                                    |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-security-group-prefix-lists](#lb-security-group-prefix-lists)          | stringList                                    |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-type](#lb-type)                                                        | string                                        |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-nlb-target-type](#nlb-target-type)                                     | string                                        |                          | default `instance` in case of LoadBalancerClass                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-name](#load-balancer-name)                                             | string                                        |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-internal](#lb-internal)                                                | boolean                                       | false                    | deprecated, in favor of [aws-load-balancer-scheme](#lb-scheme)                                                                                                                                                                                                                                                                                                                                                       |
| [service.beta.kubernetes.io/aws-load-balancer-scheme](#lb-scheme)                                                    | string                                        | internal                 |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-proxy-protocol](#proxy-protocol-v2)                                    | string                                        |                          | Set to `"*"` to enable                                                                                                                                                                                                                                                                                                                                                                                               |
| [service.beta.kubernetes.io/aws-load-balancer-proxy-protocol-per-target-group](#proxy-protocol-v2)                   | string                                        |                          | If specified,configures proxy protocol for the target groups corresponding to the ports mentioned and disables for the rest. For example, if you have services deployed on ports `"80, 443 and 22"`, the annotation value `"80, 443"` will enable proxy protocol for ports 80 and 443 only, and disable for port 22. This annotation is overriden by `"service.beta.kubernetes.io/aws-load-balancer-proxy-protocol"` |
| [service.beta.kubernetes.io/aws-load-balancer-ip-address-type](#ip-address-type)                                     | string                                        | ipv4                     | ipv4 \| dualstack                                                                                                                                                                                                                                                                                                                                                                                                    |
| [service.beta.kubernetes.io/aws-load-balancer-access-log-enabled](#deprecated-attributes)                            | boolean                                       | false                    | deprecated, in favor of [aws-load-balancer-attributes](#load-balancer-attributes)                                                                                                                                                                                                                                                                                                                                    |
| [service.beta.kubernetes.io/aws-load-balancer-access-log-s3-bucket-name](#deprecated-attributes)                     | string                                        |                          | deprecated, in favor of [aws-load-balancer-attributes](#load-balancer-attributes)                                                                                                                                                                                                                                                                                                                                    |
| [service.beta.kubernetes.io/aws-load-balancer-access-log-s3-bucket-prefix](#deprecated-attributes)                   | string                                        |                          | deprecated, in favor of [aws-load-balancer-attributes](#load-balancer-attributes)                                                                                                                                                                                                                                                                                                                                    |
| [service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled](#deprecated-attributes)             | boolean                                       | false                    | deprecated, in favor of [aws-load-balancer-attributes](#load-balancer-attributes)                                                                                                                                                                                                                                                                                                                                    |
| [service.beta.kubernetes.io/aws-load-balancer-ssl-cert](#ssl-cert)                                                   | stringList                                    |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-ssl-ports](#ssl-ports)                                                 | stringList                                    |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-ssl-negotiation-policy](#ssl-negotiation-policy)                       | string                                        | ELBSecurityPolicy-2016-08 |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-backend-protocol](#backend-protocol)                                   | string                                        |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-additional-resource-tags](#additional-resource-tags)                   | stringMap                                     |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-healthcheck-protocol](#healthcheck-protocol)                           | string                                        | TCP                      |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-healthcheck-port ](#healthcheck-port)                                  | integer \| traffic-port \| named-service-port | traffic-port             |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-healthcheck-path](#healthcheck-path)                                   | string                                        | "/" for HTTP(S) protocols |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-healthcheck-healthy-threshold](#healthcheck-healthy-threshold)         | integer                                       | 3                        |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-healthcheck-unhealthy-threshold](#healthcheck-unhealthy-threshold)     | integer                                       | 3                        |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-healthcheck-timeout](#healthcheck-timeout)                             | integer                                       | 10                       |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-healthcheck-interval](#healthcheck-interval)                           | integer                                       | 10                       |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-healthcheck-success-codes](#healthcheck-success-codes)                 | string                                        | 200-399                  |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-eip-allocations](#eip-allocations)                                     | stringList                                    |                          | internet-facing lb only. Length must match the number of subnets                                                                                                                                                                                                                                                                                                                                                     |
| [service.beta.kubernetes.io/aws-load-balancer-private-ipv4-addresses](#private-ipv4-addresses)                       | stringList                                    |                          | internal lb only. Length must match the number of subnets                                                                                                                                                                                                                                                                                                                                                            |
| [service.beta.kubernetes.io/aws-load-balancer-ipv6-addresses](#ipv6-addresses)                                       | stringList                                    |                          | dualstack lb only. Length must match the number of subnets                                                                                                                                                                                                                                                                                                                                                           |
| [service.beta.kubernetes.io/aws-load-balancer-target-group-attributes](#target-group-attributes)                     | stringMap                                     |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-subnets](#subnets)                                                     | stringList                                    |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-alpn-policy](#alpn-policy)                                             | string                                        |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-target-node-labels](#target-node-labels)                               | stringMap                                     |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-attributes](#load-balancer-attributes)                                 | stringMap                                     |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      |
| [service.beta.kubernetes.io/aws-load-balancer-security-groups](#security-groups)                                     | stringList                                    |                          |                                                                                                                                                                                                                                                                                                                                                                                                                      | 
| [service.beta.kubernetes.io/aws-load-balancer-manage-backend-security-group-rules](#manage-backend-sg-rules)         | boolean                                       | true                     | If `service.beta.kubernetes.io/aws-load-balancer-security-groups` is specified, this must also be explicitly specified otherwise it defaults to `false`.                                                                                                                                                                                                                                                             |
| [service.beta.kubernetes.io/aws-load-balancer-inbound-sg-rules-on-private-link-traffic](#update-security-settings)   | string                                        |                          |                                                                                   
| [service.beta.kubernetes.io/aws-load-balancer-listener-attributes.${Protocol}-${Port}](#listener-attributes)         | stringMap                                     |                          |
| [service.beta.kubernetes.io/aws-load-balancer-multi-cluster-target-group](#multi-cluster-target-group)               | boolean                                       | false                    | If specified, the controller will only operate on targets that exist within the cluster, ignoring targets from other sources.                                                                                                                                                                                                                                                                                        |
| [service.beta.kubernetes.io/aws-load-balancer-enable-prefix-for-ipv6-source-nat](#enable-prefix-for-ipv6-source-nat) | string                                        | off                      | Optional annotation. dualstack lb only. Allowed values - on and off                                                                                                                                                                                                                                                                                                                                                  |
| [service.beta.kubernetes.io/aws-load-balancer-source-nat-ipv6-prefixes](#source-nat-ipv6-prefixes)                   | stringList                                    |                          | Optional annotation. dualstack lb only. This annotation is only applicable when user has to set the service.beta.kubernetes.io/aws-load-balancer-enable-prefix-for-ipv6-source-nat to "on". Length must match the number of subnets                                                                                                                                                                                  |
| [service.beta.kubernetes.io/aws-load-balancer-minimum-load-balancer-capacity](#load-balancer-capacity-reservation)   | stringMap                                     |                          |
| [service.beta.kubernetes.io/aws-load-balancer-enable-icmp-for-path-mtu-discovery](#icmp-path-mtu-discovery)          | string                                        |                          | If specified, a security group rule is added to the managed security group to allow explicit ICMP traffic for [Path MTU discovery](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/network_mtu.html#path_mtu_discovery) for IPv4 and dual-stack VPCs. Creates a rule for each source range if `service.beta.kubernetes.io/load-balancer-source-ranges` is present.                                               |
| [service.beta.kubernetes.io/aws-load-balancer-enable-tcp-udp-listener](#tcp-udp-listener)                            | boolean                                       | false                    | If specified, the controller will attempt to try TCP_UDP Listeners when the service defines a TCP and UDP port on the same port number.                                                                                                                                                                                                                                                                              |
| [service.beta.kubernetes.io/aws-load-balancer-disable-nlb-sg](#nlb-sg-disable)                                       | boolean                                       | false                    | If specified, the controller will not create or manage Security Groups for the service.                                                                                                                                                                                                                                                                                                                              |
| [service.beta.kubernetes.io/aws-load-balancer-quic-enabled-ports](#nlb-quic-enabled)                                 | stringList                                    |                     | If specified, the controller will upgrade each port specified from UDP to QUIC or TCP_UDP to TCP_QUIC.                                                                                                                                                                                                                                                                                                               |
| [service.beta.kubernetes.io/actions.${protocol}-${port}](#nlb-default-action)                      | stringMap                                      |                     | If specified, the controller will add the specified action on the listener denoted by the port.                                                                                                                                                                                                                                                                                                                      |


## Traffic Routing
Traffic Routing can be controlled with following annotations:

- <a name="load-balancer-name">`service.beta.kubernetes.io/aws-load-balancer-name`</a> specifies the custom name to use for the load balancer. Name longer than 32 characters will be treated as an error.

    !!!note "limitations"
        - If you modify this annotation after service creation, there is no effect.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-name: custom-name
        ```

- <a name="lb-type">`service.beta.kubernetes.io/aws-load-balancer-type`</a> specifies the load balancer type. This controller reconciles those service resources with this annotation set to either `nlb-ip` or `external`.

    !!!tip
        This annotation specifies the controller used to provision LoadBalancers (as specified in [legacy-cloud-provider](#legacy-cloud-provider)). Refer to [lb-scheme](#lb-scheme) to specify whether the LoadBalancer is internet-facing or internal.
    
    !!!note ""
        - [Deprecated] For type `nlb-ip`, the controller will provision an NLB with targets registered by IP address. This value is supported for backwards compatibility.
        - For type `external`, the NLB target type depends on the [nlb-target-type](#nlb-target-type) annotation.

    !!!warning "Limitations"
        - Do not add or modify this annotation on an existing Service.
        - Adding or modifying this annotation on an existing Service can result in misconfigured resources, such as leaked AWS resources or exposing your NLB to the internet.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-type: external
        ```

- <a name="nlb-target-type">`service.beta.kubernetes.io/aws-load-balancer-nlb-target-type`</a> specifies the target type to configure for NLB. You can choose between
`instance` and `ip`.
    - `instance` mode will route traffic to all EC2 instances within cluster on the [NodePort](https://kubernetes.io/docs/concepts/services-networking/service/#type-nodeport) opened for your service. The kube-proxy on the individual worker nodes sets up the forwarding of the traffic from the NodePort to the pods behind the service.

        !!!note ""
            - service must be of type `NodePort` or `LoadBalancer` for `instance` targets
            - for k8s 1.22 and later if `spec.allocateLoadBalancerNodePorts` is set to `false`, `NodePort` must be allocated manually

        !!!note "default value"
            If you configure `spec.loadBalancerClass`, the controller defaults to `instance` target type

        !!!warning "NodePort allocation"
            k8s version 1.22 and later support disabling NodePort allocation by setting the service field `spec.allocateLoadBalancerNodePorts` to `false`. If the NodePort is not allocated for a service port, the controller will fail to reconcile instance mode NLB.

      - `ip` mode will route traffic directly to the pod IP. In this mode, AWS NLB sends traffic directly to the Kubernetes pods behind the service, eliminating the need for an extra network hop through the worker nodes in the Kubernetes cluster.

        !!!note ""
            - `ip` target mode supports pods running on AWS EC2 instances and AWS Fargate
            - network plugin must use native AWS VPC networking configuration for pod IP, for example [Amazon VPC CNI plugin](https://github.com/aws/amazon-vpc-cni-k8s).

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-nlb-target-type: instance
        ```

- <a name="subnets">`service.beta.kubernetes.io/aws-load-balancer-subnets`</a> specifies the [Availability Zone](http://docs.aws.amazon.com/AWSEC2/latest/UserGuide/using-regions-availability-zones.html)
the NLB will route traffic to. See [Network Load Balancers](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/network-load-balancers.html#availability-zones) for more details.

    !!!tip
        Subnets are auto-discovered if this annotation is not specified, see [Subnet Discovery](../../deploy/subnet_discovery.md) for further details.

    !!!note ""
        You must specify at least one subnet in any of the AZs, both subnetID or subnetName(Name tag on subnets) can be used.

    !!!warning "limitations"
        - Each subnets must be from a different Availability Zone
        - Similar to any delete operation, removing an Availability Zone can be a potentially disruptive operation. We recommend you evaluate for any potential impact on existing connections, traffic flows, or production workloads. Refer to [product documentation](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/availability-zones.html) for prescriptive guidance on how to use this capability in a safe manner.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-subnets: subnet-xxxx, mySubnet
        ```

- <a name="alpn-policy">`service.beta.kubernetes.io/aws-load-balancer-alpn-policy`</a> allows you to configure the [ALPN policies](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/create-tls-listener.html#alpn-policies)
on the load balancer.

    !!!tip "supported policies"
        - `HTTP1Only` Negotiate only HTTP/1.*. The ALPN preference list is http/1.1, http/1.0.
        - `HTTP2Only` Negotiate only HTTP/2. The ALPN preference list is h2.
        - `HTTP2Optional` Prefer HTTP/1.* over HTTP/2 (which can be useful for HTTP/2 testing). The ALPN preference list is http/1.1, http/1.0, h2.
        - `HTTP2Preferred` Prefer HTTP/2 over HTTP/1.*. The ALPN preference list is h2, http/1.1, http/1.0.
        - `None` Do not negotiate ALPN. This is the default.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-alpn-policy: HTTP2Preferred
        ```

- <a name="target-node-labels">`service.beta.kubernetes.io/aws-load-balancer-target-node-labels`</a> specifies which nodes to include in the target group registration for `instance` target type.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-target-node-labels: label1=value1, label2=value2
        ```

- <a name="eip-allocations">`service.beta.kubernetes.io/aws-load-balancer-eip-allocations`</a> specifies a list of [elastic IP address](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/elastic-ip-addresses-eip.html) configuration for an internet-facing NLB.

    !!!note
        - This configuration is optional, and you can use it to assign static IP addresses to your NLB
        - You must specify the same number of eip allocations as load balancer subnets [annotation](#subnets)
        - NLB must be internet-facing

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-eip-allocations: eipalloc-xyz, eipalloc-zzz
        ```


- <a name="private-ipv4-addresses">`service.beta.kubernetes.io/aws-load-balancer-private-ipv4-addresses`</a> specifies a list of private IPv4 addresses for an internal NLB.

    !!!note
        - NLB must be internal
        - This configuration is optional, and you can use it to assign static IPv4 addresses to your NLB
        - You must specify the same number of private IPv4 addresses as load balancer subnets [annotation](#subnets)
        - You must specify the IPv4 addresses from the load balancer subnet IPv4 ranges

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-private-ipv4-addresses: 192.168.10.15, 192.168.32.16
        ```

- <a name="ipv6-addresses">`service.beta.kubernetes.io/aws-load-balancer-ipv6-addresses`</a> specifies a list of IPv6 addresses for an dualstack NLB.

    !!!note
        - NLB must be dualstack
        - This configuration is optional, and you can use it to assign static IPv6 addresses to your NLB
        - You must specify the same number of private IPv6 addresses as load balancer subnets [annotation](#subnets)
        - You must specify the IPv6 addresses from the load balancer subnet IPv6 ranges

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-ipv6-addresses: 2600:1f13:837:8501::1, 2600:1f13:837:8504::1
        ```

- <a name="icmp-path-mtu-discovery">`service.beta.kubernetes.io/aws-load-balancer-enable-icmp-for-path-mtu-discovery`</a> enables the creation of security group rules to the managed security group to allow explicit ICMP traffic for [Path MTU discovery](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/network_mtu.html#path_mtu_discovery) for IPv4 and dual-stack VPCs. Creates a rule for each source range if `service.beta.kubernetes.io/load-balancer-source-ranges` is present.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-enable-icmp-for-path-mtu-discovery: "on"
        ```
- <a name="nlb-default-action">`service.beta.kubernetes.io/actions.${protocol}-${port}`</a> provides a method for configuring the action on a listener on the specified port. It supports configuring weighted target groups.

    !!!note
        - Weighted target groups are supported for the following protocols: TCP, TLS, UDP, TCP_UDP
        - The `baseServiceWeight` is the weight of the target group associated with the implicit service
    
    !!!note
        - Forward actions on listeners can specify whether to enable target group stickiness. When enabled, target group stickiness causes subsequent connections from the same source IP address to prefer the previously chosen target group.
        - For listeners, if a forward action contains multiple target groups and any of them have stickiness enabled, then the forward action must also have target group stickiness enabled.
        - For TLS listeners, target group stickiness is not supported.
        - For TLS listeners, you can't add both TCP target groups and TLS target groups to the action. All target groups in the default action must use the same protocol.
        - For dualstack load balancers, you can't add both IPv4 target groups and IPv6 target groups to the same action. All target groups in the default action must use the same IP address type.

    !!!example
        ```
        service.beta.kubernetes.io/actions.TCP-80: >
          {
            "type": "forward",
            "forwardConfig": {
              "baseServiceWeight": 10,
              "targetGroups": [
                {
                  "serviceName": "service-1",
                  "servicePort": 81,
                  "weight": 20
                },
                {
                  "serviceName": "service-2",
                  "servicePort": 82,
                  "weight": 30
                }
              ],
              "targetGroupStickinessConfig": {
                "enabled": true
              }
            }
          }
        ```

## Traffic Listening
Traffic Listening can be controlled with following annotations:

- <a name="ip-address-type">`service.beta.kubernetes.io/aws-load-balancer-ip-address-type`</a> specifies the [IP address type](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/network-load-balancers.html#ip-address-type) of NLB.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-ip-address-type: ipv4
        ```

## Support UDP-based services over IPv6
You can configure dualstack NLB to support UDP-based services over IPv6 via the following annotations:

- <a name="enable-prefix-for-ipv6-source-nat">service.beta.kubernetes.io/aws-load-balancer-enable-prefix-for-ipv6-source-nat</a> specifies whether Prefix for IPv6 source NAT is enabled or not. UDP-based support can be enabled for dualstack NLBs only if Prefix for IPv6 source NAT is enabled.

    !!!note
        - Applicable to Network Load Balancers using dualstack IP address type.
        - This configuration is optional, and you can use it to enable UDP support over IPv6.
        - Allowed values are either “on” or “off”
        - Once the source prefix for source NATing is enabled, it cannot be disabled if load balancer has a UDP listener attached.
        - Steps to disable the aws-load-balancer-enable-prefix-for-ipv6-source-nat after it is enabled and UDP listeners already attached.
        - You will have to first remove the UDP listeners and apply the manifest.
        - Update the manifest to set source NATing to "off" and then apply the manifest again.

    !!!example
        - Enable prefix for IPv6 Source NAT
        ```
        service.beta.kubernetes.io/aws-load-balancer-enable-prefix-for-ipv6-source-nat: "on"
        ```

- <a name="source-nat-ipv6-prefixes">service.beta.kubernetes.io/aws-load-balancer-source-nat-ipv6-prefixes</a> specifies a list of IPv6 prefixes that should be used for IPv6 source NATing.

    !!!note
        - Applicable to Network Load Balancers using dualstack IP address type.
        - This annotation can be specified only if service.beta.kubernetes.io/aws-load-balancer-enable-prefix-for-ipv6-source-nat annotation is set to “on”.
        - This configuration is optional and it can be used to specify custom IPv6 prefixes for IPv6 source NATing to support UDP based services routing in Network Load Balancers using dualstack IP address type.
        - If service.beta.kubernetes.io/aws-load-balancer-enable-prefix-for-ipv6-source-nat annotation is set to “on”, and you don’t specify this annotation, then IPv6 prefix/CIDR for source NATing will be auto-assigned to each subnet.
        - If you are specifying this annotation, you must specify the same number of items in the list as the load balancer subnets annotation and following the same order. Each item in the list can have value of either “auto_assigned” or a valid IPv6 prefix/CIDR with prefix length of 80 and it should be in range of the corresponding subnet CIDR.
        - Once the source NAT IPv6 prefixes are set, the IPv6 prefixes cannot be updated if the load balancer has a UDP listener attached.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-source-nat-ipv6-prefixes: 1025:0223:0009:6487:0001::/80, auto_assigned, 1025:0223:0010:6487:0001::/80
        ```

## Resource attributes
NLB resource attributes can be controlled via the following annotations:

- <a name="proxy-protocol-v2">service.beta.kubernetes.io/aws-load-balancer-proxy-protocol</a> specifies whether to enable proxy protocol v2 on the target group.
Set to '*' to enable proxy protocol v2. This annotation takes precedence over the annotation `service.beta.kubernetes.io/aws-load-balancer-target-group-attributes`
for proxy protocol v2 configuration.

    !!!note ""
        The only valid value for this annotation is `*`.

- <a name="target-group-attributes">`service.beta.kubernetes.io/aws-load-balancer-target-group-attributes`</a> specifies the
[Target Group Attributes](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/load-balancer-target-groups.html#target-group-attributes) to be configured. You can specify attributes globally for all target groups or override them for specific ports using port-specific annotations.

    !!!example
        - set the deregistration delay to 120 seconds (available range is 0-3600 seconds)
            ```
            # Global attributes for all target groups
            service.beta.kubernetes.io/aws-load-balancer-target-group-attributes: deregistration_delay.timeout_seconds=120
            
            # Port-specific attributes (overrides global attributes for port 3306)
            service.beta.kubernetes.io/aws-load-balancer-target-group-attributes.3306: proxy_protocol_v2.client_to_server.header_placement=on_first_ack
            ```
            
        - Port-specific attributes with empty values
            ```
            # Global attributes for all target groups
            service.beta.kubernetes.io/aws-load-balancer-target-group-attributes: target.group-attr-1=80
            
            # Port-specific attributes (empty values don't override global attributes)
            service.beta.kubernetes.io/aws-load-balancer-target-group-attributes.3306: target.group-attr-1=
            ```
            Note: When a port-specific attribute value is empty, it will not override the global attribute value. This allows you to selectively remove attributes for specific ports without affecting other ports that should inherit the global value.
        - enable source IP affinity
            ```
            service.beta.kubernetes.io/aws-load-balancer-target-group-attributes: stickiness.enabled=true,stickiness.type=source_ip
            ```
        - enable proxy protocol version 2
            ```
            service.beta.kubernetes.io/aws-load-balancer-target-group-attributes: proxy_protocol_v2.enabled=true
            ```
        - enable connection termination on deregistration
            ```
            service.beta.kubernetes.io/aws-load-balancer-target-group-attributes: deregistration_delay.connection_termination.enabled=true
            ```
        - enable [client IP preservation](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/load-balancer-target-groups.html#client-ip-preservation)
            ```
            service.beta.kubernetes.io/aws-load-balancer-target-group-attributes: preserve_client_ip.enabled=true
            ```
        - disable immediate [connection termination for unhealthy targets](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/target-group-health.html#unhealthy-target-connection-termination) and configure a 30s draining interval (available range is  0-360000 seconds)
            ```
            service.beta.kubernetes.io/aws-load-balancer-target-group-attributes: target_health_state.unhealthy.connection_termination.enabled=false,target_health_state.unhealthy.draining_interval_seconds=30
            ```


- <a name="load-balancer-attributes">`service.beta.kubernetes.io/aws-load-balancer-attributes`</a> specifies [Load Balancer Attributes](http://docs.aws.amazon.com/elasticloadbalancing/latest/APIReference/API_LoadBalancerAttribute.html) that should be applied to the NLB.

    !!!warning ""
        Only attributes defined in the annotation will be updated. To unset any AWS defaults(e.g. Disabling access logs after having them enabled once), the values need to be explicitly set to the original values(`access_logs.s3.enabled=false`) and omitting them is not sufficient.
        Custom attributes set in this annotation's config map will be overriden by annotation-specific attributes. For backwards compatibility, existing annotations for the individual load balancer attributes get precedence in case of ties.
  
    !!!note ""
        - If `deletion_protection.enabled=true` is in the annotation, the controller will not be able to delete the NLB during reconciliation. Once the attribute gets edited to `deletion_protection.enabled=false` during reconciliation, the deployer will force delete the resource.
        - Please note, if the deletion protection is not enabled via annotation (e.g. via AWS console), the controller still deletes the underlying resource.
    
    !!!example
        - enable access log to s3
        ```
        service.beta.kubernetes.io/aws-load-balancer-attributes: access_logs.s3.enabled=true,access_logs.s3.bucket=my-access-log-bucket,access_logs.s3.prefix=my-app
        ```
        - enable NLB deletion protection
        ```
        service.beta.kubernetes.io/aws-load-balancer-attributes: deletion_protection.enabled=true
        ```
        - enable cross zone load balancing
        ```
        service.beta.kubernetes.io/aws-load-balancer-attributes: load_balancing.cross_zone.enabled=true
        ```
        - enable client availability zone affinity
        ```
        service.beta.kubernetes.io/aws-load-balancer-attributes: dns_record.client_routing_policy=availability_zone_affinity
        ```

    
- <a name="listener-attributes">`service.beta.kubernetes.io/aws-load-balancer-listener-attributes.${Protocol}-${Port}`</a> specifies listener attributes that should be applied to the listener.

    !!!warning ""
        Only attributes defined in the annotation will be updated. To reset any AWS defaults, the values need to be explicitly set to the original values and omitting it is not sufficient.
  
    !!!example
        - configure [TCP idle timeout](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/update-idle-timeout.html) value. 
        ```
        service.beta.kubernetes.io/aws-load-balancer-listener-attributes.TCP-80: tcp.idle_timeout.seconds=400
        ```

  - <a name="tcp-udp-listener">`service.beta.kubernetes.io/aws-load-balancer-enable-tcp-udp-listener`</a> allows creation of [TCP_UDP](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/load-balancer-listeners.html#listener-configuration) listener type when the service defines a TCP and UDP port on the same port number.

    !!!note ""
    - To change the default from false to true, use the controller flag `--feature-gates=EnableTCPUDPListener=true` to allow creation of TCP_UDP listeners for all services.
  
    !!!example
      - Allow for the creation of TCP_UDP listeners for a service.
    ```
    service.beta.kubernetes.io/aws-load-balancer-enable-tcp-udp-listener: "true"
    ```

  - <a name="nlb-sg-disable">`service.beta.kubernetes.io/aws-load-balancer-disable-nlb-sg`</a> disables creation and management of SGs for the NLB. Note: This value shouldn't be changed after initial service creation. Once an NLB has been created, SGs can not be removed likewise, SGs can not be added to an existing NLB without an SG attached.

    !!!warning ""
      - This is a fine-grained way of setting the controller level feature flag `--feature-gates=NLBSecurityGroup=false` to disable SG management for a specific service.
  
    !!!example
    ```
    service.beta.kubernetes.io/aws-load-balancer-disable-nlb-sg: "true"
    ```
    
  - <a name="nlb-quic-enabled">`service.beta.kubernetes.io/aws-load-balancer-quic-enabled-ports`</a> Upgrades the UDP protocol to QUIC.

    !!!warning ""
        This annotation only applies to UDP ports. The annotation is ignored when the specified port is NOT UDP based.

    !!!note ""
        Ensure that the pods belonging to the service have been QUIC enabled. See [QUIC use-case](../use_cases/quic/index.md) for more information.

    !!!example
    ```
    service.beta.kubernetes.io/aws-load-balancer-quic-enabled-ports: "443"
    ```

- <a name="deprecated-attributes"></a>the following annotations are deprecated in v2.3.0 release in favor of [service.beta.kubernetes.io/aws-load-balancer-attributes](#load-balancer-attributes)

    !!!note ""
        ```
        service.beta.kubernetes.io/aws-load-balancer-access-log-enabled
        service.beta.kubernetes.io/aws-load-balancer-access-log-s3-bucket-name
        service.beta.kubernetes.io/aws-load-balancer-access-log-s3-bucket-prefix
        service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled 
        ```

- <a name="multi-cluster-target-group">`service.beta.kubernetes.io/aws-load-balancer-multi-cluster-target-group`</a> Allows you to share the created Target Group ARN with other Load Balancer Controller managed clusters.

    !!!warning ""
    This feature does not offer any Deletion Protection. Deleting the service will still delete the Target Group. If you need to support
    Target Groups shared with multiple clusters, it's recommended to use an out-of-band Target Group that is not managed by a Load Balancer Controller.

    !!!note ""
    - It is not recommended to change this value frequently, if ever. The recommended way to set this value is on creation of the service.

    !!!example
    ```
    service.beta.kubernetes.io/aws-load-balancer-multi-cluster-target-group: "true"
    ```


## AWS Resource Tags
The AWS Load Balancer Controller automatically applies following tags to the AWS resources it creates (NLB/TargetGroups/Listener/ListenerRule):

- `elbv2.k8s.aws/cluster: ${clusterName}`
- `service.k8s.aws/stack: ${stackID}`
- `service.k8s.aws/resource: ${resourceID}`

In addition, you can use annotations to specify additional tags

- <a name="additional-resource-tags">`service.beta.kubernetes.io/aws-load-balancer-additional-resource-tags`</a> specifies additional tags to apply to the AWS resources.

    !!!note ""
        - you cannot override the default controller tags mentioned above or the tags specified in the `--default-tags` controller flag
        - if any of the tag conflicts with the ones configured via `--external-managed-tags` controller flag, the controller fails to reconcile the service

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-additional-resource-tags: Environment=dev,Team=test
        ```

## Health Check
Health check on target groups can be configured with following annotations:

- <a name="healthcheck-protocol">`service.beta.kubernetes.io/aws-load-balancer-healthcheck-protocol`</a> specifies the target group health check protocol.

    !!!note ""
        - you can specify `tcp`, or `http` or `https`, `tcp` is the default
        - `tcp` is the default health check protocol if the service `spec.externalTrafficPolicy` is `Cluster`, `http` if `Local`
        - if the service `spec.externalTrafficPolicy` is `Local`, do **not** use `tcp` for health check
        - Supports only single protocol per service

    !!!example
        ```service.beta.kubernetes.io/aws-load-balancer-healthcheck-protocol: http
        ```

- <a name="healthcheck-port">`service.beta.kubernetes.io/aws-load-balancer-healthcheck-port`</a> specifies the TCP port to use for target group health check.

    !!!note "accepted values"
        - `traffic-port` - use the same port as the target group traffic (default when `externalTrafficPolicy=Cluster`)
        - Integer string (e.g., `"80"`) - use this specific port number
        - Service port name (e.g., `"http"`) - resolves based on target type:
            - **Instance targets**: uses the Service port's `NodePort`
            - **IP targets**: uses the Service port's `targetPort` (must be numeric, not a named port)
        - **Default**: `spec.healthCheckNodePort` when `externalTrafficPolicy=Local`, otherwise `traffic-port`

    !!!example
        - set the health check port to `traffic-port`
            ```
            service.beta.kubernetes.io/aws-load-balancer-healthcheck-port: traffic-port
            ```
        - set the health check port to port `80`
            ```
            service.beta.kubernetes.io/aws-load-balancer-healthcheck-port: "80"
            ```
        - set the health check port to a named Service port
            ```
            service.beta.kubernetes.io/aws-load-balancer-healthcheck-port: "http"
            ```

- <a name="healthcheck-path">`service.beta.kubernetes.io/aws-load-balancer-healthcheck-path`</a> specifies the http path for the health check in case of http/https protocol.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-healthcheck-path: /healthz
        ```

- <a name="healthcheck-healthy-threshold">`service.beta.kubernetes.io/aws-load-balancer-healthcheck-healthy-threshold`</a> specifies the consecutive health check successes required before a target is considered healthy.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-healthcheck-healthy-threshold: "3"
        ```

- <a name="healthcheck-unhealthy-threshold">`service.beta.kubernetes.io/aws-load-balancer-healthcheck-unhealthy-threshold`</a> specifies the consecutive health check failures before a target gets marked unhealthy.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-healthcheck-unhealthy-threshold: "3"
        ```

- <a name="healthcheck-interval">`service.beta.kubernetes.io/aws-load-balancer-healthcheck-interval`</a> specifies the interval between consecutive health checks.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-healthcheck-interval: "10"
        ```

- <a name="healthcheck-success-codes">`service.beta.kubernetes.io/aws-load-balancer-healthcheck-success-codes`</a> specifies the http success codes for the health check in case of http/https protocol.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-healthcheck-success-codes: "200-399"
        ```

- <a name="healthcheck-timeout">`service.beta.kubernetes.io/aws-load-balancer-healthcheck-timeout`</a> specifies the target group health check timeout. The target has to respond within the timeout for a successful health check.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-healthcheck-timeout: "10"
        ```

## TLS
You can configure TLS support via the following annotations:

- <a name="ssl-cert">`service.beta.kubernetes.io/aws-load-balancer-ssl-cert`</a> specifies the ARN of one or more certificates managed by the [AWS Certificate Manager](https://aws.amazon.com/certificate-manager).

    !!!note ""
        The first certificate in the list is the default certificate and remaining certificates are for the optional certificate list.
        See [Server Certificates](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/create-tls-listener.html#tls-listener-certificates) for further details.

    !!!example
        - single certificate
            ```
            service.beta.kubernetes.io/aws-load-balancer-ssl-cert: arn:aws:acm:us-west-2:xxxxx:certificate/xxxxxxx
            ```
        - multiple certificates
            ```
            service.beta.kubernetes.io/aws-load-balancer-ssl-cert: arn:aws:acm:us-west-2:xxxxx:certificate/cert1,arn:aws:acm:us-west-2:xxxxx:certificate/cert2,arn:aws:acm:us-west-2:xxxxx:certificate/cert3
            ```



- <a name="ssl-ports">`service.beta.kubernetes.io/aws-load-balancer-ssl-ports`</a> specifies the frontend ports with TLS listeners.

    !!!note ""
        - You must configure at least one [certificate](#ssl-cert) for TLS listeners
        - You can specify a list of port names or port values, `*` does **not** match any ports
        - If you don't specify this annotation, controller creates TLS listener for all the service ports
        - Specify this annotation if you need both TLS and non-TLS listeners on the same load balancer

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-ssl-ports: 443, custom-port
        ```

- <a name="ssl-negotiation-policy">`service.beta.kubernetes.io/aws-load-balancer-ssl-negotiation-policy`</a> specifies the [Security Policy](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/create-tls-listener.html#describe-ssl-policies) for NLB frontend connections, allowing you to control the protocol and ciphers.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-ssl-negotiation-policy: ELBSecurityPolicy-TLS13-1-2-2021-06
        ```

- <a name="backend-protocol">`service.beta.kubernetes.io/aws-load-balancer-backend-protocol`</a> specifies whether to use TLS for the backend traffic between the load balancer and the kubernetes pods.

    !!!note ""
        - If you specify `ssl` as the backend protocol, NLB uses TLS connections for the traffic to your kubernetes pods in case of TLS listeners
        - You can specify `ssl` or `tcp` (default)

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-backend-protocol: ssl
        ```


## Access control
Load balancer access can be controlled via following annotations:

- <a name="lb-source-ranges">`service.beta.kubernetes.io/load-balancer-source-ranges`</a> specifies the CIDRs that are allowed to access the NLB.

    !!!tip
        - We recommend specifying CIDRs in the service `spec.loadBalancerSourceRanges` instead
        - For enhanced security with `internal` network load balancers, we recommend limiting access by specifying allowed source IP ranges.  This can be done using either the `service.beta.kubernetes.io/load-balancer-source-ranges` annotation or the `spec.loadBalancerSourceRanges` field.

    !!!note "Default"
        - `0.0.0.0/0` will be used if the IPAddressType is "ipv4"
        - `0.0.0.0/0` and `::/0` will be used if the IPAddressType is "dualstack"

    !!!warning ""
        This annotation will be ignored in case preserve client IP is not enabled.
        - preserve client IP is disabled by default for `IP` targets
        - preserve client IP is enabled by default for `instance` targets
    
    !!!warning ""
        Preserve client IP has no effect on traffic converted from IPv4 to IPv6 and on traffic converted from IPv6 to IPv4. The source IP of this type of traffic is always the private IP address of the Network Load Balancer.
        - This could cause the clients that have their traffic converted to bypass the specified CIDRs that are allowed to access the NLB.

    !!!warning ""
        this annotation will be ignored if `service.beta.kubernetes.io/aws-load-balancer-security-groups` is specified.

    !!!example
        ```
        service.beta.kubernetes.io/load-balancer-source-ranges: 10.0.0.0/24
        ```

- <a name="lb-security-group-prefix-lists">`service.beta.kubernetes.io/aws-load-balancer-security-group-prefix-lists`</a> specifies the managed prefix lists that are allowed to access the NLB.

    !!!warning ""
        this annotation will be ignored if `service.beta.kubernetes.io/aws-load-balancer-security-groups` is specified.

    !!!warning ""
        If you'd like to use this annotation, make sure your security group rule quota is enough. If you'd like to know how the managed prefix list affects your quota, see the [reference](https://docs.aws.amazon.com/vpc/latest/userguide/working-with-aws-managed-prefix-lists.html#aws-managed-prefix-list-weights) in the AWS documentation for more details.

    !!!tip ""
        If you only use this annotation without `load-balancer-source-ranges`, the controller managed security group would ignore the `load-balancer-source-ranges` default settings.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-security-group-prefix-lists: pl-00000000, pl-1111111
        ```

- <a name="lb-scheme">`service.beta.kubernetes.io/aws-load-balancer-scheme`</a> specifies whether the NLB will be internet-facing or internal.  Valid values are `internal`, `internet-facing`. If not specified, default is `internal`.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-scheme: "internet-facing"
        ```

- <a name="lb-internal">`service.beta.kubernetes.io/aws-load-balancer-internal`</a> specifies whether the NLB will be internet-facing or internal.

    !!!note "deprecation note"
        This annotation is deprecated starting v2.2.0 release in favor of the new [aws-load-balancer-scheme](#lb-scheme) annotation. It will be supported, but in case of ties, the aws-load-balancer-scheme gets precedence.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-internal: "true"
        ```
- <a name="security-groups">`service.beta.kubernetes.io/aws-load-balancer-security-groups`</a>  specifies the frontend securityGroups you want to attach to an NLB.

    !!!note ""
        When this annotation is not present, the controller will automatically create one security group. The security group will be attached to the LoadBalancer and allow access from `load-balancer-source-ranges` and `aws-load-balancer-security-group-prefix-lists` to the `listen-ports`.
        Also, the securityGroups for target instances/ENIs will be modified to allow inbound traffic from this securityGroup.

    !!!note ""
        If you specify this annotation, you need to configure the security groups on your target instances/ENIs to allow inbound traffic from the load balancer. You could also set the [`manage-backend-security-group-rules`](#manage-backend-sg-rules) if you want the controller to manage the security group rules.

    !!!tip ""
        Both name and ID of securityGroups are supported. Name matches a `Name` tag, not the `groupName` attribute.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-security-groups: sg-xxxx, nameOfSg1, nameOfSg2
        ```
 
- <a name="manage-backend-sg-rules">`service.beta.kubernetes.io/aws-load-balancer-manage-backend-security-group-rules`</a> specifies whether the controller should automatically add the ingress rules to the instance/ENI security group.

    !!!warning ""
        If you disable the automatic management of security group rules for an NLB (e.g.: by setting `service.beta.kubernetes.io/aws-load-balancer-security-groups`), you will need to manually add appropriate ingress rules to your EC2 instance or ENI security groups to allow access to the traffic and health check ports.

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-manage-backend-security-group-rules: "false"
        ```

- <a name="update-security-settings">`service.beta.kubernetes.io/aws-load-balancer-inbound-sg-rules-on-private-link-traffic`</a> specifies whether to apply security group rules to traffic sent to the load balancer through AWS PrivateLink. 

    !!!example
        ```
        service.beta.kubernetes.io/aws-load-balancer-inbound-sg-rules-on-private-link-traffic: "off"
        ```

## Capacity Unit Reservation
Load balancer capacity unit reservation can be configured via following annotations:

- <a name="load-balancer-capacity-reservation">`service.beta.kubernetes.io/aws-load-balancer-minimum-load-balancer-capacity`</a> specifies the
  [Capacity Unit Reservation](https://docs.aws.amazon.com/elasticloadbalancing/latest/network/capacity-unit-reservation.html) to be configured.

    !!!example
        - set the capacity unit reservation to 1000
          ```
          service.beta.kubernetes.io/aws-load-balancer-minimum-load-balancer-capacity: CapacityUnits=3000
          ```
        - reset the capacity unit reservation
          ```
          service.beta.kubernetes.io/aws-load-balancer-minimum-load-balancer-capacity: CapacityUnits=0
          ```
    
    !!!note "Notes"
         - If you specify this annotation, but remove it later, the capacity unit reservation is not reset. You need to reset the capacity by setting the capacity units to zero as show in the example above.
         - If users do not want the controller to manage the capacity unit reservation on load balancer, they can disable the feature by setting controller command line feature gate flag ```--feature-gates=LBCapacityReservation=true```

## Legacy Cloud Provider
The AWS Load Balancer Controller manages Kubernetes Services in a compatible way with the AWS cloud provider's legacy service controller.

- For users on v2.5.0+, The AWS LBC provides a mutating webhook for service resources to set the `spec.loadBalancerCLass` field for Serive of type LoadBalancer, effectively making the AWS LBC the default controller for Service of type LoadBalancer. 
  Users can disable this feature and revert to using the AWS Cloud Controller Manager as the default service controller by setting the helm chart value `enableServiceMutatorWebhook` to false with `--set enableServiceMutatorWebhook=false` .
- For users on older versions, the annotation `service.beta.kubernetes.io/aws-load-balancer-type` is used to determine which controller reconciles the service. If the annotation value is `nlb-ip` or `external`,
  recent versions of the legacy cloud provider ignore the Service resource so that the AWS LBC can take over. For all other values of the annotation, the legacy cloud provider will handle the service. 
  Note that this annotation should be specified during service creation and not edited later. Support for the annotation was added to the legacy cloud provider in Kubernetes v1.20, and is backported to v1.18.18+ and v1.19.10+.

package ingress

import (
	"context"
	"fmt"
	"strings"

	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/certs"
	awsmetrics "sigs.k8s.io/aws-load-balancer-controller/v3/pkg/metrics/aws"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/shared_utils"

	"sigs.k8s.io/controller-runtime/pkg/reconcile"

	"github.com/go-logr/logr"
	"github.com/pkg/errors"
	corev1 "k8s.io/api/core/v1"
	networking "k8s.io/api/networking/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/record"
	elbv2api "sigs.k8s.io/aws-load-balancer-controller/v3/apis/elbv2/v1beta1"
	"sigs.k8s.io/aws-load-balancer-controller/v3/controllers/ingress/eventhandlers"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/annotations"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/aws/services"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/config"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/deploy"
	elbv2deploy "sigs.k8s.io/aws-load-balancer-controller/v3/pkg/deploy/elbv2"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/deploy/tracking"
	ctrlerrors "sigs.k8s.io/aws-load-balancer-controller/v3/pkg/error"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/ingress"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/k8s"
	lbcmetrics "sigs.k8s.io/aws-load-balancer-controller/v3/pkg/metrics/lbc"
	metricsutil "sigs.k8s.io/aws-load-balancer-controller/v3/pkg/metrics/util"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/model/core"
	elbv2model "sigs.k8s.io/aws-load-balancer-controller/v3/pkg/model/elbv2"
	networkingpkg "sigs.k8s.io/aws-load-balancer-controller/v3/pkg/networking"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/runtime"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/controller"
	"sigs.k8s.io/controller-runtime/pkg/event"
	"sigs.k8s.io/controller-runtime/pkg/source"
)

const (
	ingressTagPrefix = "ingress.k8s.aws"
	controllerName   = "ingress"

	// the groupVersion of used Ingress & IngressClass resource.
	ingressResourcesGroupVersion = "networking.k8s.io/v1"
	ingressClassKind             = "IngressClass"
)

// NewGroupReconciler constructs new GroupReconciler
func NewGroupReconciler(cloud services.Cloud, k8sClient client.Client, eventRecorder record.EventRecorder,
	finalizerManager k8s.FinalizerManager, networkingSGManager networkingpkg.SecurityGroupManager,
	networkingManager networkingpkg.NetworkingManager, networkingSGReconciler networkingpkg.SecurityGroupReconciler, subnetsResolver networkingpkg.SubnetsResolver,
	elbv2TaggingManager elbv2deploy.TaggingManager, controllerConfig config.ControllerConfig, backendSGProvider networkingpkg.BackendSGProvider,
	sgResolver networkingpkg.SecurityGroupResolver, secretsManager k8s.SecretsManager, logger logr.Logger, metricsCollector lbcmetrics.MetricCollector, reconcileCounters *metricsutil.ReconcileCounters,
	targetGroupCollector awsmetrics.TargetGroupCollector, targetGroupNameToArnMapper shared_utils.TargetGroupARNMapper,
) *groupReconciler {
	annotationParser := annotations.NewSuffixAnnotationParser(annotations.AnnotationPrefixIngress)
	authConfigBuilder := ingress.NewDefaultAuthConfigBuilder(annotationParser)
	enhancedBackendBuilder := ingress.NewDefaultEnhancedBackendBuilder(k8sClient, annotationParser, authConfigBuilder, controllerConfig.IngressConfig.TolerateNonExistentBackendService, controllerConfig.IngressConfig.TolerateNonExistentBackendAction)
	referenceIndexer := ingress.NewDefaultReferenceIndexer(enhancedBackendBuilder, authConfigBuilder, logger)
	trackingProvider := tracking.NewDefaultProvider(ingressTagPrefix, controllerConfig.ClusterName)
	certDiscovery := certs.NewACMCertDiscovery(cloud.ACM(), controllerConfig.IngressConfig.AllowedCertificateAuthorityARNs, controllerConfig.FeatureGates.Enabled(config.EnableCertificateManagement), logger)
	modelBuilder := ingress.NewDefaultModelBuilder(k8sClient, eventRecorder,
		cloud.EC2(), cloud.ELBV2(), cloud.WAFv2(), cloud.ACM(),
		annotationParser, subnetsResolver,
		authConfigBuilder, enhancedBackendBuilder, trackingProvider, elbv2TaggingManager, controllerConfig.FeatureGates,
		cloud.VpcID(), controllerConfig.ClusterName, controllerConfig.DefaultTags, controllerConfig.ExternalManagedTags,
		controllerConfig.DefaultSSLPolicy, controllerConfig.DefaultTargetType, controllerConfig.DefaultLoadBalancerScheme, backendSGProvider, sgResolver,
		controllerConfig.EnableBackendSecurityGroup, controllerConfig.EnableManageBackendSecurityGroupRules, controllerConfig.DisableRestrictedSGRules, controllerConfig.IngressConfig.AllowedCertificateAuthorityARNs, controllerConfig.FeatureGates.Enabled(config.EnableIPTargetType), controllerConfig.FeatureGates.Enabled(config.EnableCertificateManagement), controllerConfig.IngressConfig.DefaultPCAArn, targetGroupNameToArnMapper, secretsManager, logger, metricsCollector,
		certDiscovery)
	stackMarshaller := deploy.NewDefaultStackMarshaller()
	stackDeployer := deploy.NewDefaultStackDeployer(cloud, k8sClient, networkingManager, networkingSGManager, networkingSGReconciler, elbv2TaggingManager,
		controllerConfig, ingressTagPrefix, logger, metricsCollector, controllerName, controllerConfig.FeatureGates.Enabled(config.EnhancedDefaultBehavior), targetGroupCollector, true)
	classLoader := ingress.NewDefaultClassLoader(k8sClient, true)
	classAnnotationMatcher := ingress.NewDefaultClassAnnotationMatcher(controllerConfig.IngressConfig.IngressClass)
	manageIngressesWithoutIngressClass := controllerConfig.IngressConfig.IngressClass == ""
	groupLoader := ingress.NewDefaultGroupLoader(k8sClient, eventRecorder, annotationParser, classLoader, classAnnotationMatcher, manageIngressesWithoutIngressClass)
	groupFinalizerManager := ingress.NewDefaultFinalizerManager(finalizerManager)

	return &groupReconciler{
		k8sClient:         k8sClient,
		eventRecorder:     eventRecorder,
		referenceIndexer:  referenceIndexer,
		modelBuilder:      modelBuilder,
		stackMarshaller:   stackMarshaller,
		stackDeployer:     stackDeployer,
		backendSGProvider: backendSGProvider,
		secretsManager:    secretsManager,

		groupLoader:           groupLoader,
		groupFinalizerManager: groupFinalizerManager,
		featureGates:          controllerConfig.FeatureGates,
		logger:                logger,
		metricsCollector:      metricsCollector,
		controllerName:        controllerName,
		reconcileCounters:     reconcileCounters,

		maxConcurrentReconciles: controllerConfig.IngressConfig.MaxConcurrentReconciles,
	}
}

// GroupReconciler reconciles a IngressGroup
type groupReconciler struct {
	k8sClient         client.Client
	eventRecorder     record.EventRecorder
	referenceIndexer  ingress.ReferenceIndexer
	modelBuilder      ingress.ModelBuilder
	stackMarshaller   deploy.StackMarshaller
	stackDeployer     deploy.StackDeployer
	backendSGProvider networkingpkg.BackendSGProvider
	secretsManager    k8s.SecretsManager

	groupLoader           ingress.GroupLoader
	groupFinalizerManager ingress.FinalizerManager
	featureGates          config.FeatureGates
	logger                logr.Logger
	metricsCollector      lbcmetrics.MetricCollector
	controllerName        string
	reconcileCounters     *metricsutil.ReconcileCounters

	maxConcurrentReconciles int
}

// +kubebuilder:rbac:groups=elbv2.k8s.aws,resources=ingressclassparams,verbs=get;list;watch
// +kubebuilder:rbac:groups=networking.k8s.io,resources=ingresses,verbs=get;list;watch;update;patch
// +kubebuilder:rbac:groups=networking.k8s.io,resources=ingresses/status,verbs=update;patch
// +kubebuilder:rbac:groups=networking.k8s.io,resources=ingressclasses,verbs=get;list;watch
// +kubebuilder:rbac:groups=extensions,resources=ingresses,verbs=get;list;watch;update;patch
// +kubebuilder:rbac:groups=extensions,resources=ingresses/status,verbs=update;patch
// +kubebuilder:rbac:groups="",resources=services,verbs=get;list;watch;update;patch
// +kubebuilder:rbac:groups="",resources=events,verbs=create;patch

func (r *groupReconciler) Reconcile(ctx context.Context, req reconcile.Request) (ctrl.Result, error) {
	r.reconcileCounters.IncrementIngress(req.NamespacedName)
	return runtime.HandleReconcileError(r.reconcile(ctx, req), r.logger)
}

func (r *groupReconciler) reconcile(ctx context.Context, req reconcile.Request) error {
	ingGroupID := ingress.DecodeGroupIDFromReconcileRequest(req)
	var err error
	var ingGroup ingress.Group
	loadIngressFn := func() {
		ingGroup, err = r.groupLoader.Load(ctx, ingGroupID)
	}
	r.metricsCollector.ObserveControllerReconcileLatency(controllerName, "fetch_ingress", loadIngressFn)
	if err != nil {
		return ctrlerrors.NewErrorWithMetrics(controllerName, "fetch_ingress_error", err, r.metricsCollector)
	}

	addFinalizerFn := func() {
		err = r.groupFinalizerManager.AddGroupFinalizer(ctx, ingGroupID, ingGroup.Members)
	}
	r.metricsCollector.ObserveControllerReconcileLatency(controllerName, "add_group_finalizer", addFinalizerFn)
	if err != nil {
		r.recordIngressGroupEvent(ctx, ingGroup, corev1.EventTypeWarning, k8s.IngressEventReasonFailedAddFinalizer, fmt.Sprintf("Failed add finalizer due to %v", err))
		return ctrlerrors.NewErrorWithMetrics(controllerName, "add_group_finalizer_error", err, r.metricsCollector)
	}

	_, lb, frontendNlb, listenerPorts, err := r.buildAndDeployModel(ctx, ingGroup)
	if err != nil {
		return err
	}

	if len(ingGroup.Members) > 0 && lb != nil {
		var statusErr error
		dnsResolveAndUpdateStatus := func() {
			var lbDNS string
			lbDNS, statusErr = lb.DNSName().Resolve(ctx)
			if statusErr != nil {
				return
			}
			normalizedLbDNSName := strings.ToLower(lbDNS)
			var frontendNlbDNS string
			var normalizedFrontendNlbDNS string
			if frontendNlb != nil {
				frontendNlbDNS, statusErr = frontendNlb.DNSName().Resolve(ctx)
				if statusErr != nil {
					return
				}
				normalizedFrontendNlbDNS = strings.ToLower(frontendNlbDNS)
			}
			statusErr = r.updateIngressGroupStatus(ctx, ingGroup, normalizedLbDNSName, normalizedFrontendNlbDNS, listenerPorts)
			if statusErr != nil {
				r.recordIngressGroupEvent(ctx, ingGroup, corev1.EventTypeWarning, k8s.IngressEventReasonFailedUpdateStatus,
					fmt.Sprintf("Failed update status due to %v", statusErr))
			}
		}
		r.metricsCollector.ObserveControllerReconcileLatency(controllerName, "dns_resolve_and_update_status", dnsResolveAndUpdateStatus)
		if statusErr != nil {
			return ctrlerrors.NewErrorWithMetrics(controllerName, "dns_resolve_and_update_status_error", statusErr, r.metricsCollector)
		}
	}

	if len(ingGroup.InactiveMembers) > 0 {
		removeGroupFinalizerFn := func() {
			err = r.groupFinalizerManager.RemoveGroupFinalizer(ctx, ingGroupID, ingGroup.InactiveMembers)
		}
		r.metricsCollector.ObserveControllerReconcileLatency(controllerName, "remove_group_finalizer", removeGroupFinalizerFn)
		if err != nil {
			r.recordIngressGroupEvent(ctx, ingGroup, corev1.EventTypeWarning, k8s.IngressEventReasonFailedRemoveFinalizer, fmt.Sprintf("Failed remove finalizer due to %v", err))
			return ctrlerrors.NewErrorWithMetrics(controllerName, "remove_group_finalizer_error", err, r.metricsCollector)
		}
	}

	r.recordIngressGroupEvent(ctx, ingGroup, corev1.EventTypeNormal, k8s.IngressEventReasonSuccessfullyReconciled, "Successfully reconciled")
	return nil
}

func (r *groupReconciler) buildAndDeployModel(ctx context.Context, ingGroup ingress.Group) (core.Stack, *elbv2model.LoadBalancer, *elbv2model.LoadBalancer, []int32, error) {
	var stack core.Stack
	var lb *elbv2model.LoadBalancer
	var secrets []types.NamespacedName
	var backendSGRequired bool
	var err error
	var frontendNlb *elbv2model.LoadBalancer
	var listenerPorts []int32
	buildModelFn := func() {
		stack, lb, secrets, backendSGRequired, frontendNlb, listenerPorts, err = r.modelBuilder.Build(ctx, ingGroup, r.metricsCollector)
	}
	r.metricsCollector.ObserveControllerReconcileLatency(controllerName, "build_model", buildModelFn)
	if err != nil {
		r.recordIngressGroupEvent(ctx, ingGroup, corev1.EventTypeWarning, k8s.IngressEventReasonFailedBuildModel, fmt.Sprintf("Failed build model due to %v", err))
		return nil, nil, nil, nil, ctrlerrors.NewErrorWithMetrics(controllerName, "build_model_error", err, r.metricsCollector)
	}
	stackJSON, err := r.stackMarshaller.Marshal(stack)
	if err != nil {
		r.recordIngressGroupEvent(ctx, ingGroup, corev1.EventTypeWarning, k8s.IngressEventReasonFailedBuildModel, fmt.Sprintf("Failed build model due to %v", err))
		return nil, nil, nil, nil, err
	}
	r.logger.Info("successfully built model", "model", stackJSON)

	if r.featureGates.Enabled(config.IngressPlanAnnotation) && len(ingGroup.Members) > 0 {
		if err := patchDryRunPlanAnnotation(ctx, r.k8sClient, ingGroup.Members[0].Ing, stackJSON); err != nil {
			r.logger.Error(err, "failed to patch dry-run plan annotation", "ingress", k8s.NamespacedName(ingGroup.Members[0].Ing))
		}
		// Clear the dry-run-plan annotation from every non-primary member so a
		// group that moves its holder across reconciles (e.g. a member with a
		// lower group.order is added) doesn't leave stale plans behind. The
		// migration console's discovery step errors out when it finds multiple
		// ingresses in a group carrying the annotation — this cleanup keeps
		// that invariant. We swallow individual failures to avoid blocking the
		// main reconcile; the next pass retries.
		for _, m := range ingGroup.Members[1:] {
			if err := clearDryRunPlanAnnotation(ctx, r.k8sClient, m.Ing); err != nil {
				r.logger.Error(err, "failed to clear stale dry-run plan annotation", "ingress", k8s.NamespacedName(m.Ing))
			}
		}
	} else if !r.featureGates.Enabled(config.IngressPlanAnnotation) && len(ingGroup.Members) > 0 {
		for _, m := range ingGroup.Members {
			if err := clearDryRunPlanAnnotation(ctx, r.k8sClient, m.Ing); err != nil {
				r.logger.Error(err, "failed to clear dry-run plan annotation after feature disable", "ingress", k8s.NamespacedName(m.Ing))
			}
		}
	}

	deployModelFn := func() {
		err = r.stackDeployer.Deploy(ctx, stack, r.metricsCollector, "ingress")
	}
	r.metricsCollector.ObserveControllerReconcileLatency(controllerName, "deploy_model", deployModelFn)
	if err != nil {
		var requeueNeededAfter *ctrlerrors.RequeueNeededAfter
		if errors.As(err, &requeueNeededAfter) {
			return nil, nil, nil, nil, err
		}
		r.recordIngressGroupEvent(ctx, ingGroup, corev1.EventTypeWarning, k8s.IngressEventReasonFailedDeployModel, fmt.Sprintf("Failed deploy model due to %v", err))
		return nil, nil, nil, nil, ctrlerrors.NewErrorWithMetrics(controllerName, "deploy_model_error", err, r.metricsCollector)
	}
	r.logger.Info("successfully deployed model", "ingressGroup", ingGroup.ID)
	r.secretsManager.MonitorSecrets(ingGroup.ID.String(), secrets)
	var inactiveResources []types.NamespacedName
	inactiveResources = append(inactiveResources, k8s.ToSliceOfNamespacedNames(ingGroup.InactiveMembers)...)
	if !backendSGRequired {
		inactiveResources = append(inactiveResources, k8s.ToSliceOfNamespacedNames(ingGroup.Members)...)
	}
	if err := r.backendSGProvider.Release(ctx, networkingpkg.ResourceTypeIngress, inactiveResources); err != nil {
		return nil, nil, nil, nil, ctrlerrors.NewErrorWithMetrics(controllerName, "release_auto_generated_backend_sg_error", err, r.metricsCollector)
	}
	return stack, lb, frontendNlb, listenerPorts, nil
}

func (r *groupReconciler) recordIngressGroupEvent(_ context.Context, ingGroup ingress.Group, eventType string, reason string, message string) {
	for _, member := range ingGroup.Members {
		r.eventRecorder.Event(member.Ing, eventType, reason, message)
	}
}

func (r *groupReconciler) updateIngressGroupStatus(ctx context.Context, ingGroup ingress.Group, lbDNS string, frontendNLBDNS string, listenerPorts []int32) error {
	for _, member := range ingGroup.Members {
		if err := r.updateIngressStatus(ctx, lbDNS, frontendNLBDNS, member.Ing, listenerPorts); err != nil {
			return err
		}
	}
	return nil
}

func (r *groupReconciler) updateIngressStatus(ctx context.Context, lbDNS string, frontendNlbDNS string, ing *networking.Ingress, ports []int32) error {
	ingressPorts := make([]networking.IngressPortStatus, len(ports))
	for i, port := range ports {
		ingressPorts[i] = networking.IngressPortStatus{
			Port: port,
		}
	}

	ingOld := ing.DeepCopy()
	if len(ing.Status.LoadBalancer.Ingress) != 1 ||
		ing.Status.LoadBalancer.Ingress[0].IP != "" ||
		ing.Status.LoadBalancer.Ingress[0].Hostname != lbDNS {
		ing.Status.LoadBalancer.Ingress = []networking.IngressLoadBalancerIngress{
			{
				Hostname: lbDNS,
				Ports:    ingressPorts,
			},
		}
	} else if len(ports) > 0 {
		ing.Status.LoadBalancer.Ingress[0].Ports = ingressPorts
	}

	// Ensure frontendNLBDNS is appended if it is not already added
	if frontendNlbDNS != "" && !hasFrontendNlbHostName(ing.Status.LoadBalancer.Ingress, frontendNlbDNS) {
		ing.Status.LoadBalancer.Ingress = append(ing.Status.LoadBalancer.Ingress, networking.IngressLoadBalancerIngress{
			Hostname: frontendNlbDNS,
		})
	}

	if !isIngressStatusEqual(ingOld.Status.LoadBalancer.Ingress, ing.Status.LoadBalancer.Ingress) {
		if err := r.k8sClient.Status().Patch(ctx, ing, client.MergeFrom(ingOld)); err != nil {
			return errors.Wrapf(err, "failed to update ingress status: %v", k8s.NamespacedName(ing))
		}
	}

	return nil
}

func (r *groupReconciler) SetupWithManager(ctx context.Context, mgr ctrl.Manager, clientSet *kubernetes.Clientset) error {
	c, err := controller.New(controllerName, mgr, controller.Options{
		MaxConcurrentReconciles: r.maxConcurrentReconciles,
		Reconciler:              r,
	})
	if err != nil {
		return err
	}

	resList, err := clientSet.ServerResourcesForGroupVersion(ingressResourcesGroupVersion)
	if err != nil {
		return err
	}
	ingressClassResourceAvailable := k8s.IsResourceKindAvailable(resList, ingressClassKind)
	if err := r.setupIndexes(ctx, mgr.GetFieldIndexer(), ingressClassResourceAvailable); err != nil {
		return err
	}
	if err := r.setupWatches(ctx, c, mgr, ingressClassResourceAvailable, clientSet); err != nil {
		return err
	}
	return nil
}

func (r *groupReconciler) setupIndexes(ctx context.Context, fieldIndexer client.FieldIndexer, ingressClassResourceAvailable bool) error {
	if err := fieldIndexer.IndexField(ctx, &networking.Ingress{}, ingress.IndexKeyServiceRefName,
		func(obj client.Object) []string {
			return r.referenceIndexer.BuildServiceRefIndexes(context.Background(), obj.(*networking.Ingress))
		},
	); err != nil {
		return err
	}
	if err := fieldIndexer.IndexField(ctx, &networking.Ingress{}, ingress.IndexKeySecretRefName,
		func(obj client.Object) []string {
			return r.referenceIndexer.BuildSecretRefIndexes(context.Background(), obj.(*networking.Ingress))
		},
	); err != nil {
		return err
	}
	if err := fieldIndexer.IndexField(ctx, &corev1.Service{}, ingress.IndexKeySecretRefName,
		func(obj client.Object) []string {
			return r.referenceIndexer.BuildSecretRefIndexes(context.Background(), obj.(*corev1.Service))
		},
	); err != nil {
		return err
	}
	if ingressClassResourceAvailable {
		if err := fieldIndexer.IndexField(ctx, &networking.IngressClass{}, ingress.IndexKeyIngressClassParamsRefName,
			func(obj client.Object) []string {
				return r.referenceIndexer.BuildIngressClassParamsRefIndexes(ctx, obj.(*networking.IngressClass))
			},
		); err != nil {
			return err
		}
		if err := fieldIndexer.IndexField(ctx, &networking.Ingress{}, ingress.IndexKeyIngressClassRefName,
			func(obj client.Object) []string {
				return r.referenceIndexer.BuildIngressClassRefIndexes(ctx, obj.(*networking.Ingress))
			},
		); err != nil {
			return err
		}
	}
	return nil
}

func (r *groupReconciler) setupWatches(_ context.Context, c controller.Controller, mgr ctrl.Manager, ingressClassResourceAvailable bool, clientSet *kubernetes.Clientset) error {
	ingEventChan := make(chan event.TypedGenericEvent[*networking.Ingress])
	svcEventChan := make(chan event.TypedGenericEvent[*corev1.Service])
	secretEventsChan := make(chan event.TypedGenericEvent[*corev1.Secret])
	r.secretsManager.SetEventChannel(secretEventsChan)
	ingEventHandler := eventhandlers.NewEnqueueRequestsForIngressEvent(r.groupLoader, r.eventRecorder,
		r.logger.WithName("eventHandlers").WithName("ingress"))
	svcEventHandler := eventhandlers.NewEnqueueRequestsForServiceEvent(ingEventChan, r.k8sClient, r.eventRecorder,
		r.logger.WithName("eventHandlers").WithName("service"))
	secretEventHandler := eventhandlers.NewEnqueueRequestsForSecretEvent(ingEventChan, svcEventChan, r.k8sClient, r.eventRecorder,
		r.logger.WithName("eventHandlers").WithName("secret"))
	if err := c.Watch(source.Channel(ingEventChan, ingEventHandler)); err != nil {
		return err
	}
	if err := c.Watch(source.Channel(svcEventChan, svcEventHandler)); err != nil {
		return err
	}
	if err := c.Watch(source.Kind(mgr.GetCache(), &networking.Ingress{}, ingEventHandler)); err != nil {
		return err
	}
	if err := c.Watch(source.Kind(mgr.GetCache(), &corev1.Service{}, svcEventHandler)); err != nil {
		return err
	}
	if err := c.Watch(source.Channel(secretEventsChan, secretEventHandler)); err != nil {
		return err
	}
	if ingressClassResourceAvailable {
		ingClassEventChan := make(chan event.TypedGenericEvent[*networking.IngressClass])
		ingClassParamsEventHandler := eventhandlers.NewEnqueueRequestsForIngressClassParamsEvent(ingClassEventChan, r.k8sClient, r.eventRecorder,
			r.logger.WithName("eventHandlers").WithName("ingressClassParams"))
		ingClassEventHandler := eventhandlers.NewEnqueueRequestsForIngressClassEvent(ingEventChan, r.k8sClient, r.eventRecorder,
			r.logger.WithName("eventHandlers").WithName("ingressClass"))
		if err := c.Watch(source.Channel(ingClassEventChan, ingClassEventHandler)); err != nil {
			return err
		}
		if err := c.Watch(source.Kind(mgr.GetCache(), &elbv2api.IngressClassParams{}, ingClassParamsEventHandler)); err != nil {
			return err
		}
		if err := c.Watch(source.Kind(mgr.GetCache(), &networking.IngressClass{}, ingClassEventHandler)); err != nil {
			return err
		}
	}
	return nil
}

func isIngressStatusEqual(a, b []networking.IngressLoadBalancerIngress) bool {
	if len(a) != len(b) {
		return false
	}

	hostnameToPortsA := make(map[string]map[int32]struct{})
	hostnameToPortsB := make(map[string]map[int32]struct{})

	for _, ingress := range a {
		if ingress.Hostname == "" {
			continue
		}

		portSet := make(map[int32]struct{})
		for _, portStatus := range ingress.Ports {
			portSet[portStatus.Port] = struct{}{}
		}
		hostnameToPortsA[ingress.Hostname] = portSet
	}

	for _, ingress := range b {
		if ingress.Hostname == "" {
			continue
		}

		portSet := make(map[int32]struct{})
		for _, portStatus := range ingress.Ports {
			portSet[portStatus.Port] = struct{}{}
		}
		hostnameToPortsB[ingress.Hostname] = portSet
	}

	// Check if the maps are equal (same hostnames with same ports)
	if len(hostnameToPortsA) != len(hostnameToPortsB) {
		return false
	}

	// Check if all hostnames in A exist in B with the same ports
	for hostname, portsA := range hostnameToPortsA {
		portsB, exists := hostnameToPortsB[hostname]
		if !exists {
			return false // Hostname in A doesn't exist in B
		}

		// Check if port sets are equal (same length and same values)
		if len(portsA) != len(portsB) {
			return false
		}

		// Check if all ports in A exist in B
		for port := range portsA {
			if _, exists := portsB[port]; !exists {
				return false
			}
		}
	}
	return true
}

func hasFrontendNlbHostName(ingressList []networking.IngressLoadBalancerIngress, frontendNlbDNS string) bool {
	for _, ingress := range ingressList {
		if ingress.Hostname == frontendNlbDNS {
			return true
		}
	}
	return false
}

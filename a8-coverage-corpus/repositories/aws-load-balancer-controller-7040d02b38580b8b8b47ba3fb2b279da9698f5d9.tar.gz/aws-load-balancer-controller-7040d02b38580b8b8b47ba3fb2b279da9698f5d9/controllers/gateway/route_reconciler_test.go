package gateway

import (
	"context"
	"testing"
	"time"

	"github.com/go-logr/logr"
	"github.com/stretchr/testify/assert"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	clientgoscheme "k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/util/workqueue"
	"k8s.io/utils/ptr"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/gateway/routeutils"
	"sigs.k8s.io/controller-runtime/pkg/client"
	testclient "sigs.k8s.io/controller-runtime/pkg/client/fake"
	"sigs.k8s.io/controller-runtime/pkg/log"
	gwv1 "sigs.k8s.io/gateway-api/apis/v1"
)

func TestDeferredReconcilerConstructor(t *testing.T) {
	dq := workqueue.NewDelayingQueue()
	defer dq.ShutDown()
	k8sClient := testclient.NewClientBuilder().Build()
	logger := logr.New(&log.NullLogSink{})

	d := NewRouteReconciler(dq, k8sClient, logger)

	deferredReconciler := d.(*routeReconcilerImpl)
	assert.Equal(t, dq, deferredReconciler.queue)
	assert.Equal(t, k8sClient, deferredReconciler.k8sClient)
	assert.Equal(t, logger, deferredReconciler.logger)
}

func Test_isRouteStatusIdentical(t *testing.T) {
	tests := []struct {
		name     string
		routeOld client.Object
		routeNew client.Object
		want     bool
	}{
		{
			name: "identical route status",
			routeOld: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-1",
								},
								ControllerName: "example.com/controller",
								Conditions: []metav1.Condition{
									{
										Type:    "Accepted",
										Status:  metav1.ConditionTrue,
										Reason:  "Accepted",
										Message: "Route accepted",
									},
								},
							},
						},
					},
				},
			},
			routeNew: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-1",
								},
								ControllerName: "example.com/controller",
								Conditions: []metav1.Condition{
									{
										Type:    "Accepted",
										Status:  metav1.ConditionTrue,
										Reason:  "Accepted",
										Message: "Route accepted",
									},
								},
							},
						},
					},
				},
			},
			want: true,
		},
		{
			name: "different route status",
			routeOld: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-1",
								},
								ControllerName: "example.com/controller",
								Conditions: []metav1.Condition{
									{
										Type:    "Accepted",
										Status:  metav1.ConditionTrue,
										Reason:  "Accepted",
										Message: "Route accepted",
									},
								},
							},
						},
					},
				},
			},
			routeNew: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-1",
								},
								ControllerName: "example.com/controller",
								Conditions: []metav1.Condition{
									{
										Type:    "Accepted",
										Status:  metav1.ConditionFalse,
										Reason:  "Not Accepted",
										Message: "Route not accepted",
									},
								},
							},
						},
					},
				},
			},
			want: false,
		},
		{
			name: "different number of parents",
			routeOld: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-1",
								},
							},
						},
					},
				},
			},
			routeNew: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-1",
								},
							},
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-2",
								},
							},
						},
					},
				},
			},
			want: false,
		},
		{
			name: "different controller names",
			routeOld: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-1",
								},
								ControllerName: "controller-1",
							},
						},
					},
				},
			},
			routeNew: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-1",
								},
								ControllerName: "controller-2",
							},
						},
					},
				},
			},
			want: false,
		},
		{
			name: "different conditions",
			routeOld: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-1",
								},
								Conditions: []metav1.Condition{
									{
										Type:   "Ready",
										Status: metav1.ConditionTrue,
									},
								},
							},
						},
					},
				},
			},
			routeNew: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-1",
								},
								Conditions: []metav1.Condition{
									{
										Type:   "Ready",
										Status: metav1.ConditionFalse,
									},
								},
							},
						},
					},
				},
			},
			want: false,
		},
		{
			name: "different parent references",
			routeOld: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-1",
								},
							},
						},
					},
				},
			},
			routeNew: &gwv1.HTTPRoute{
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name: "gateway-2",
								},
							},
						},
					},
				},
			},
			want: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			d := &routeReconcilerImpl{}
			got := d.isRouteStatusIdentical(tt.routeOld, tt.routeNew)
			if got != tt.want {
				t.Errorf("isRouteStatusIdentical() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_getParentStatusKey(t *testing.T) {
	portPtr := func(p gwv1.PortNumber) *gwv1.PortNumber {
		return &p
	}
	routeNamespace := "route-namespace"

	tests := []struct {
		name   string
		status gwv1.RouteParentStatus
		want   string
	}{
		{
			name: "provide all fields",
			status: gwv1.RouteParentStatus{
				ParentRef: gwv1.ParentReference{
					Group:       (*gwv1.Group)(ptr.To("networking.k8s.io")),
					Kind:        (*gwv1.Kind)(ptr.To("Gateway")),
					Namespace:   (*gwv1.Namespace)(ptr.To("test-namespace")),
					Name:        "test-gateway",
					SectionName: (*gwv1.SectionName)(ptr.To("test-section")),
					Port:        portPtr(80),
				},
			},
			want: "networking.k8s.io/Gateway/test-namespace/test-gateway/test-section/80",
		},
		{
			name: "no namespace should use route namespace",
			status: gwv1.RouteParentStatus{
				ParentRef: gwv1.ParentReference{
					Group:       (*gwv1.Group)(ptr.To("networking.k8s.io")),
					Kind:        (*gwv1.Kind)(ptr.To("Gateway")),
					Name:        "test-gateway",
					SectionName: (*gwv1.SectionName)(ptr.To("test-section")),
					Port:        portPtr(80),
				},
			},
			want: "networking.k8s.io/Gateway/route-namespace/test-gateway/test-section/80",
		},
		{
			name: "no section or port",
			status: gwv1.RouteParentStatus{
				ParentRef: gwv1.ParentReference{
					Group:     (*gwv1.Group)(ptr.To("networking.k8s.io")),
					Kind:      (*gwv1.Kind)(ptr.To("Gateway")),
					Namespace: (*gwv1.Namespace)(ptr.To("test-namespace")),
					Name:      "test-gateway",
				},
			},
			want: "networking.k8s.io/Gateway/test-namespace/test-gateway//",
		},
		{
			name: "ListenerSet parent ref",
			status: gwv1.RouteParentStatus{
				ParentRef: gwv1.ParentReference{
					Group:       (*gwv1.Group)(ptr.To("gateway.networking.k8s.io")),
					Kind:        (*gwv1.Kind)(ptr.To("ListenerSet")),
					Namespace:   (*gwv1.Namespace)(ptr.To("ls-namespace")),
					Name:        "test-listener-set",
					SectionName: (*gwv1.SectionName)(ptr.To("ls-section")),
					Port:        portPtr(8080),
				},
			},
			want: "gateway.networking.k8s.io/ListenerSet/ls-namespace/test-listener-set/ls-section/8080",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := getParentStatusKey(tt.status.ParentRef, routeNamespace)
			if got != tt.want {
				t.Errorf("getParentStatusKey() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_resolveParentResource(t *testing.T) {
	scheme := runtime.NewScheme()
	clientgoscheme.AddToScheme(scheme)
	gwv1.Install(scheme)

	listenerSetKind := gwv1.Kind("ListenerSet")
	gatewayKind := gwv1.Kind("Gateway")
	testNamespace := gwv1.Namespace("test-namespace")

	tests := []struct {
		name       string
		parentRef  gwv1.ParentReference
		namespace  string
		objects    []client.Object
		wantErr    bool
		errContain string
	}{
		{
			name: "resolve Gateway - exists",
			parentRef: gwv1.ParentReference{
				Kind:      &gatewayKind,
				Name:      "test-gateway",
				Namespace: &testNamespace,
			},
			namespace: "default",
			objects: []client.Object{
				&gwv1.Gateway{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test-gateway",
						Namespace: "test-namespace",
					},
				},
			},
			wantErr: false,
		},
		{
			name: "resolve Gateway - not found",
			parentRef: gwv1.ParentReference{
				Kind:      &gatewayKind,
				Name:      "missing-gateway",
				Namespace: &testNamespace,
			},
			namespace: "default",
			objects:   []client.Object{},
			wantErr:   true,
		},
		{
			name: "resolve ListenerSet - exists",
			parentRef: gwv1.ParentReference{
				Kind:      &listenerSetKind,
				Name:      "test-listener-set",
				Namespace: &testNamespace,
			},
			namespace: "default",
			objects: []client.Object{
				&gwv1.ListenerSet{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test-listener-set",
						Namespace: "test-namespace",
					},
				},
			},
			wantErr: false,
		},
		{
			name: "resolve ListenerSet - not found",
			parentRef: gwv1.ParentReference{
				Kind:      &listenerSetKind,
				Name:      "missing-listener-set",
				Namespace: &testNamespace,
			},
			namespace: "default",
			objects:   []client.Object{},
			wantErr:   true,
		},
		{
			name: "resolve ListenerSet - uses route namespace when parentRef namespace is nil",
			parentRef: gwv1.ParentReference{
				Kind: &listenerSetKind,
				Name: "test-listener-set",
			},
			namespace: "route-namespace",
			objects: []client.Object{
				&gwv1.ListenerSet{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "test-listener-set",
						Namespace: "route-namespace",
					},
				},
			},
			wantErr: false,
		},
		{
			name: "unknown parent reference kind",
			parentRef: gwv1.ParentReference{
				Kind: (*gwv1.Kind)(ptr.To("UnknownKind")),
				Name: "test-resource",
			},
			namespace:  "default",
			objects:    []client.Object{},
			wantErr:    true,
			errContain: "Unknown parent reference kind UnknownKind",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			k8sClient := testclient.NewClientBuilder().WithScheme(scheme).WithObjects(tt.objects...).Build()
			reconciler := &routeReconcilerImpl{
				logger:    logr.New(&log.NullLogSink{}),
				k8sClient: k8sClient,
			}
			err := reconciler.resolveParentResource(tt.parentRef, tt.namespace)
			if tt.wantErr {
				assert.Error(t, err)
				if tt.errContain != "" {
					assert.Contains(t, err.Error(), tt.errContain)
				}
			} else {
				assert.NoError(t, err)
			}
		})
	}
}

func TestEnqueue(t *testing.T) {
	tests := []struct {
		name                    string
		routeData               routeutils.RouteData
		routeStatusInfo         routeutils.RouteStatusInfo
		routeMetadataDescriptor routeutils.RouteMetadata
		parentRefGateway        gwv1.ParentReference

		validateEnqueued func(t *testing.T, enqueued []routeutils.EnqueuedType) // Use the type here
	}{
		{
			name: "enqueue with accepted status",
			routeData: routeutils.RouteData{
				RouteStatusInfo: routeutils.RouteStatusInfo{
					Accepted:     true,
					ResolvedRefs: true,
				},
				RouteMetadata: routeutils.RouteMetadata{
					RouteName:      "test-name",
					RouteNamespace: "test-namespace",
					RouteKind:      "test-kind",
				},
				ParentRef: gwv1.ParentReference{},
			},
			validateEnqueued: func(t *testing.T, enqueued []routeutils.EnqueuedType) {
				assert.Len(t, enqueued, 1)
				assert.Equal(t, true, enqueued[0].RouteData.RouteStatusInfo.Accepted)
				assert.Equal(t, true, enqueued[0].RouteData.RouteStatusInfo.ResolvedRefs)
				assert.Equal(t, "test-name", enqueued[0].RouteData.RouteMetadata.RouteName)
				assert.Equal(t, "test-namespace", enqueued[0].RouteData.RouteMetadata.RouteNamespace)
				assert.Equal(t, "test-kind", enqueued[0].RouteData.RouteMetadata.RouteKind)
			},
		},
		{
			name: "enqueue with rejected status",
			routeData: routeutils.RouteData{
				RouteStatusInfo: routeutils.RouteStatusInfo{
					Accepted:     false,
					ResolvedRefs: false,
				},
				RouteMetadata: routeutils.RouteMetadata{
					RouteName:      "test-name",
					RouteNamespace: "test-namespace",
					RouteKind:      "test-kind",
				},
				ParentRef: gwv1.ParentReference{},
			},
			validateEnqueued: func(t *testing.T, enqueued []routeutils.EnqueuedType) {
				assert.Len(t, enqueued, 1)
				assert.Equal(t, false, enqueued[0].RouteData.RouteStatusInfo.Accepted)
				assert.Equal(t, false, enqueued[0].RouteData.RouteStatusInfo.ResolvedRefs)
				assert.Equal(t, "test-name", enqueued[0].RouteData.RouteMetadata.RouteName)
				assert.Equal(t, "test-namespace", enqueued[0].RouteData.RouteMetadata.RouteNamespace)
				assert.Equal(t, "test-kind", enqueued[0].RouteData.RouteMetadata.RouteKind)
			},
		},
		{
			name: "enqueue with empty route name",
			routeData: routeutils.RouteData{
				RouteStatusInfo: routeutils.RouteStatusInfo{
					Accepted:     false,
					ResolvedRefs: false,
				},
				RouteMetadata: routeutils.RouteMetadata{
					RouteNamespace: "test-namespace",
					RouteKind:      "test-kind",
				},
				ParentRef: gwv1.ParentReference{},
			},
			validateEnqueued: func(t *testing.T, enqueued []routeutils.EnqueuedType) {
				assert.Len(t, enqueued, 1)
				assert.Equal(t, false, enqueued[0].RouteData.RouteStatusInfo.Accepted)
				assert.Equal(t, false, enqueued[0].RouteData.RouteStatusInfo.ResolvedRefs)
				assert.Equal(t, "", enqueued[0].RouteData.RouteMetadata.RouteName)
				assert.Equal(t, "test-namespace", enqueued[0].RouteData.RouteMetadata.RouteNamespace)
				assert.Equal(t, "test-kind", enqueued[0].RouteData.RouteMetadata.RouteKind)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mock := routeutils.NewMockRouteReconciler()

			mock.Enqueue(tt.routeData)

			tt.validateEnqueued(t, mock.Enqueued)
		})
	}
}

func Test_updateRouteStatus(t *testing.T) {

	testNamespace := gwv1.Namespace("test-namespace")
	validateGw := func(status gwv1.RouteParentStatus, expectedName string) {
		assert.Equal(t, status.ParentRef.Name, gwv1.ObjectName(expectedName))
		assert.Equal(t, status.ParentRef.Namespace, &testNamespace)
		assert.Equal(t, 2, len(status.Conditions))
		conditionsEqIgnoreTime(t, status.Conditions[0], metav1.Condition{
			Type:               string(gwv1.RouteConditionResolvedRefs),
			Status:             metav1.ConditionTrue,
			Reason:             string(gwv1.RouteReasonResolvedRefs),
			Message:            "",
			ObservedGeneration: 0,
		})
		conditionsEqIgnoreTime(t, status.Conditions[1], metav1.Condition{
			Type:               string(gwv1.RouteConditionAccepted),
			Status:             metav1.ConditionTrue,
			Reason:             string(gwv1.RouteReasonAccepted),
			Message:            "",
			ObservedGeneration: 0,
		})
	}

	tests := []struct {
		name           string
		route          client.Object
		routeData      routeutils.RouteData
		validateResult func(t *testing.T, route client.Object)
	}{
		{
			name: "update HTTPRoute status - condition accepted",
			route: &gwv1.HTTPRoute{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-route",
					Namespace: "test-namespace",
				},
				Spec: gwv1.HTTPRouteSpec{
					Hostnames: []gwv1.Hostname{"example.com"},
					CommonRouteSpec: gwv1.CommonRouteSpec{
						ParentRefs: []gwv1.ParentReference{
							{
								Name:      "test-gateway",
								Namespace: &testNamespace,
							},
						},
					},
				},
			},
			routeData: routeutils.RouteData{
				RouteStatusInfo: routeutils.RouteStatusInfo{
					Accepted:     true,
					ResolvedRefs: true,
					Reason:       string(gwv1.RouteConditionAccepted),
					Message:      "route accepted",
				},
				ParentRef: gwv1.ParentReference{
					Name:      "test-gateway",
					Namespace: &testNamespace,
				},
			},
			validateResult: func(t *testing.T, route client.Object) {
				httpRoute := route.(*gwv1.HTTPRoute)
				assert.Len(t, httpRoute.Status.Parents, 1)
				validateGw(httpRoute.Status.Parents[0], "test-gateway")
			},
		},
		{
			name: "update HTTPRoute status - multiple parents - other ref not in status yet.",
			route: &gwv1.HTTPRoute{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-route",
					Namespace: "test-namespace",
				},
				Spec: gwv1.HTTPRouteSpec{
					Hostnames: []gwv1.Hostname{"example.com"},
					CommonRouteSpec: gwv1.CommonRouteSpec{
						ParentRefs: []gwv1.ParentReference{
							{
								Name:      "test-gateway",
								Namespace: &testNamespace,
							},
							{
								Name:      "test-gateway-2",
								Namespace: &testNamespace,
							},
						},
					},
				},
			},
			routeData: routeutils.RouteData{
				RouteStatusInfo: routeutils.RouteStatusInfo{
					Accepted:     true,
					ResolvedRefs: true,
					Reason:       string(gwv1.RouteConditionAccepted),
					Message:      "route accepted",
				},
				ParentRef: gwv1.ParentReference{
					Name:      "test-gateway",
					Namespace: &testNamespace,
				},
			},
			validateResult: func(t *testing.T, route client.Object) {
				httpRoute := route.(*gwv1.HTTPRoute)
				assert.Len(t, httpRoute.Status.Parents, 1)
				validateGw(httpRoute.Status.Parents[0], "test-gateway")
			},
		},
		{
			name: "update HTTPRoute status - dont overwrite newer parent ref",
			route: &gwv1.HTTPRoute{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-route",
					Namespace: "test-namespace",
				},
				Spec: gwv1.HTTPRouteSpec{
					Hostnames: []gwv1.Hostname{"example.com"},
					CommonRouteSpec: gwv1.CommonRouteSpec{
						ParentRefs: []gwv1.ParentReference{
							{
								Name:      "test-gateway",
								Namespace: &testNamespace,
							},
							{
								Name:      "test-gateway-2",
								Namespace: &testNamespace,
							},
						},
					},
				},
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name:      "test-gateway",
									Namespace: &testNamespace,
								},
								ControllerName: "example.com/controller",
								Conditions: []metav1.Condition{
									{
										Type:               string(gwv1.RouteConditionResolvedRefs),
										Status:             metav1.ConditionTrue,
										Reason:             string(gwv1.RouteReasonResolvedRefs),
										Message:            "foo",
										ObservedGeneration: 1000,
									},
									{
										Type:               string(gwv1.RouteConditionAccepted),
										Status:             metav1.ConditionTrue,
										Reason:             string(gwv1.RouteReasonAccepted),
										Message:            "bar",
										ObservedGeneration: 1000,
									},
								},
							},
						},
					},
				},
			},
			routeData: routeutils.RouteData{
				RouteStatusInfo: routeutils.RouteStatusInfo{
					Accepted:     true,
					ResolvedRefs: true,
					Reason:       string(gwv1.RouteConditionAccepted),
					Message:      "route accepted",
				},
				ParentRef: gwv1.ParentReference{
					Name:      "test-gateway",
					Namespace: &testNamespace,
				},
			},
			validateResult: func(t *testing.T, route client.Object) {
				httpRoute := route.(*gwv1.HTTPRoute)
				assert.Len(t, httpRoute.Status.Parents, 1)
				status := httpRoute.Status.Parents[0]
				assert.Equal(t, status.ParentRef.Name, gwv1.ObjectName("test-gateway"))
				assert.Equal(t, status.ParentRef.Namespace, &testNamespace)
				assert.Equal(t, 2, len(status.Conditions))
				conditionsEqIgnoreTime(t, status.Conditions[0], metav1.Condition{
					Type:               string(gwv1.RouteConditionResolvedRefs),
					Status:             metav1.ConditionTrue,
					Reason:             string(gwv1.RouteReasonResolvedRefs),
					Message:            "foo",
					ObservedGeneration: 1000,
				})
				conditionsEqIgnoreTime(t, status.Conditions[1], metav1.Condition{
					Type:               string(gwv1.RouteConditionAccepted),
					Status:             metav1.ConditionTrue,
					Reason:             string(gwv1.RouteReasonAccepted),
					Message:            "bar",
					ObservedGeneration: 1000,
				})
			},
		},
		{
			name: "update HTTPRoute status - multiple parents",
			route: &gwv1.HTTPRoute{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-route",
					Namespace: "test-namespace",
				},
				Spec: gwv1.HTTPRouteSpec{
					Hostnames: []gwv1.Hostname{"example.com"},
					CommonRouteSpec: gwv1.CommonRouteSpec{
						ParentRefs: []gwv1.ParentReference{
							{
								Name:      "test-gateway",
								Namespace: &testNamespace,
							},
							{
								Name:      "test-gateway-2",
								Namespace: &testNamespace,
							},
						},
					},
				},
				Status: gwv1.HTTPRouteStatus{
					RouteStatus: gwv1.RouteStatus{
						Parents: []gwv1.RouteParentStatus{
							{
								ParentRef: gwv1.ParentReference{
									Name:      "test-gateway-2",
									Namespace: &testNamespace,
								},
								ControllerName: "example.com/controller",
								Conditions: []metav1.Condition{
									{
										Type:               string(gwv1.RouteConditionResolvedRefs),
										Status:             metav1.ConditionTrue,
										Reason:             string(gwv1.RouteReasonResolvedRefs),
										Message:            "",
										ObservedGeneration: 0,
									},
									{
										Type:               string(gwv1.RouteConditionAccepted),
										Status:             metav1.ConditionTrue,
										Reason:             string(gwv1.RouteReasonAccepted),
										Message:            "",
										ObservedGeneration: 0,
									},
								},
							},
						},
					},
				},
			},
			routeData: routeutils.RouteData{
				RouteStatusInfo: routeutils.RouteStatusInfo{
					Accepted:     true,
					ResolvedRefs: true,
					Reason:       string(gwv1.RouteConditionAccepted),
					Message:      "route accepted",
				},
				ParentRef: gwv1.ParentReference{
					Name:      "test-gateway",
					Namespace: &testNamespace,
				},
			},
			validateResult: func(t *testing.T, route client.Object) {
				httpRoute := route.(*gwv1.HTTPRoute)
				assert.Len(t, httpRoute.Status.Parents, 2)

				if httpRoute.Status.Parents[0].ParentRef.Name == "test-gateway" {
					validateGw(httpRoute.Status.Parents[0], "test-gateway")
					validateGw(httpRoute.Status.Parents[1], "test-gateway-2")
				} else {
					validateGw(httpRoute.Status.Parents[1], "test-gateway")
					validateGw(httpRoute.Status.Parents[0], "test-gateway-2")
				}
			},
		},
		{
			name: "update gwv1.TCPRoute status - condition accepted",
			route: &gwv1.TCPRoute{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-tcp-route",
					Namespace: "test-namespace",
				},
				Spec: gwv1.TCPRouteSpec{
					CommonRouteSpec: gwv1.CommonRouteSpec{
						ParentRefs: []gwv1.ParentReference{
							{
								Name:      "test-gateway",
								Namespace: &testNamespace,
							},
						},
					},
				},
			},
			routeData: routeutils.RouteData{
				RouteStatusInfo: routeutils.RouteStatusInfo{
					Accepted:     true,
					ResolvedRefs: true,
					Reason:       string(gwv1.RouteConditionAccepted),
					Message:      "route accepted",
				},
				ParentRef: gwv1.ParentReference{
					Name:      "test-gateway",
					Namespace: &testNamespace,
				},
			},
			validateResult: func(t *testing.T, route client.Object) {
				tcpRoute := route.(*gwv1.TCPRoute)
				assert.Len(t, tcpRoute.Status.Parents, 1)
				validateGw(tcpRoute.Status.Parents[0], "test-gateway")
			},
		},
		{
			name: "update gwv1.UDPRoute status - condition accepted",
			route: &gwv1.UDPRoute{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-udp-route",
					Namespace: "test-namespace",
				},
				Spec: gwv1.UDPRouteSpec{
					CommonRouteSpec: gwv1.CommonRouteSpec{
						ParentRefs: []gwv1.ParentReference{
							{
								Name:      "test-gateway",
								Namespace: &testNamespace,
							},
						},
					},
				},
			},
			routeData: routeutils.RouteData{
				RouteStatusInfo: routeutils.RouteStatusInfo{
					Accepted:     true,
					ResolvedRefs: true,
					Reason:       string(gwv1.RouteConditionAccepted),
					Message:      "route accepted",
				},
				ParentRef: gwv1.ParentReference{
					Name:      "test-gateway",
					Namespace: &testNamespace,
				},
			},
			validateResult: func(t *testing.T, route client.Object) {
				udpRoute := route.(*gwv1.UDPRoute)
				assert.Len(t, udpRoute.Status.Parents, 1)
				validateGw(udpRoute.Status.Parents[0], "test-gateway")
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger := logr.New(&log.NullLogSink{})
			scheme := runtime.NewScheme()
			clientgoscheme.AddToScheme(scheme)
			gwv1.Install(scheme)

			k8sClient := testclient.NewClientBuilder().WithScheme(scheme).WithStatusSubresource(tt.route).Build()
			k8sClient.Create(context.Background(), &gwv1.Gateway{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-gateway",
					Namespace: "test-namespace",
				},
			})
			k8sClient.Create(context.Background(), &gwv1.Gateway{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-gateway-2",
					Namespace: "test-namespace",
				},
			})
			reconciler := &routeReconcilerImpl{
				logger:    logger,
				k8sClient: k8sClient,
			}
			err := reconciler.updateRouteStatus(tt.route, tt.routeData)
			assert.NoError(t, err)
			if tt.validateResult != nil {
				tt.validateResult(t, tt.route)
			}
		})
	}
}

func Test_setConditionsWithRouteStatusInfo(t *testing.T) {
	route := &gwv1.HTTPRoute{
		ObjectMeta: metav1.ObjectMeta{
			Generation: 1,
		},
	}

	tests := []struct {
		name           string
		info           routeutils.RouteStatusInfo
		validateResult func(t *testing.T, conditions []metav1.Condition)
	}{
		{
			name: "accepted true and resolvedRef true",
			info: routeutils.RouteStatusInfo{
				Accepted:     true,
				ResolvedRefs: true,
				Reason:       string(gwv1.RouteConditionAccepted),
				Message:      "route accepted",
			},
			validateResult: func(t *testing.T, conditions []metav1.Condition) {
				assert.Len(t, conditions, 2)
				acceptedCondition := findCondition(conditions, string(gwv1.RouteConditionAccepted))
				assert.NotNil(t, acceptedCondition)
				assert.Equal(t, metav1.ConditionTrue, acceptedCondition.Status)
				assert.Equal(t, string(gwv1.RouteReasonAccepted), acceptedCondition.Reason)

				resolvedRefCondition := findCondition(conditions, string(gwv1.RouteConditionResolvedRefs))
				assert.NotNil(t, resolvedRefCondition)
				assert.Equal(t, metav1.ConditionTrue, resolvedRefCondition.Status)
				assert.Equal(t, string(gwv1.RouteReasonResolvedRefs), resolvedRefCondition.Reason)
			},
		},
		{
			name: "accepted false and resolvedRef true",
			info: routeutils.RouteStatusInfo{
				Accepted:     false,
				ResolvedRefs: true,
				Reason:       string(gwv1.RouteReasonNotAllowedByListeners),
				Message:      "route not allowed by listeners",
			},
			validateResult: func(t *testing.T, conditions []metav1.Condition) {
				assert.Len(t, conditions, 2)
				acceptedCondition := findCondition(conditions, string(gwv1.RouteConditionAccepted))
				assert.NotNil(t, acceptedCondition)
				assert.Equal(t, metav1.ConditionFalse, acceptedCondition.Status)

				resolvedRefCondition := findCondition(conditions, string(gwv1.RouteConditionResolvedRefs))
				assert.NotNil(t, resolvedRefCondition)
				assert.Equal(t, metav1.ConditionTrue, resolvedRefCondition.Status)
			},
		},
		{
			name: "accepted true and resolvedRef false",
			info: routeutils.RouteStatusInfo{
				Accepted:     true,
				ResolvedRefs: false,
				Reason:       string(gwv1.RouteReasonRefNotPermitted),
				Message:      "ref not permitted",
			},
			validateResult: func(t *testing.T, conditions []metav1.Condition) {
				assert.Len(t, conditions, 2)
				acceptedCondition := findCondition(conditions, string(gwv1.RouteConditionAccepted))
				assert.NotNil(t, acceptedCondition)
				assert.Equal(t, metav1.ConditionTrue, acceptedCondition.Status)

				resolvedRefCondition := findCondition(conditions, string(gwv1.RouteConditionResolvedRefs))
				assert.NotNil(t, resolvedRefCondition)
				assert.Equal(t, metav1.ConditionFalse, resolvedRefCondition.Status)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger := logr.New(&log.NullLogSink{})
			reconciler := &routeReconcilerImpl{
				logger: logger,
			}
			parentStatus := &gwv1.RouteParentStatus{}
			reconciler.setConditionsWithRouteStatusInfo(route, parentStatus, tt.info)
			if tt.validateResult != nil {
				tt.validateResult(t, parentStatus.Conditions)
			}
		})
	}
}

func Test_areConditionsEqual(t *testing.T) {
	tests := []struct {
		name     string
		oldCon   []metav1.Condition
		newCon   []metav1.Condition
		expected bool
	}{
		{
			name: "same conditions - true",
			oldCon: []metav1.Condition{
				{
					Type:   string(gwv1.RouteConditionAccepted),
					Status: metav1.ConditionTrue,
				},
				{
					Type:   string(gwv1.RouteConditionResolvedRefs),
					Status: metav1.ConditionTrue,
				},
			},
			newCon: []metav1.Condition{
				{
					Type:   string(gwv1.RouteConditionAccepted),
					Status: metav1.ConditionTrue,
				},
				{
					Type:   string(gwv1.RouteConditionResolvedRefs),
					Status: metav1.ConditionTrue,
				},
			},
			expected: true,
		},
		{
			name: "different conditions - false",
			oldCon: []metav1.Condition{
				{
					Type:   string(gwv1.RouteConditionAccepted),
					Status: metav1.ConditionTrue,
				},
				{
					Type:   string(gwv1.RouteConditionResolvedRefs),
					Status: metav1.ConditionTrue,
				},
			},
			newCon: []metav1.Condition{
				{
					Type:   string(gwv1.RouteConditionAccepted),
					Status: metav1.ConditionFalse,
				},
				{
					Type:   string(gwv1.RouteConditionResolvedRefs),
					Status: metav1.ConditionTrue,
				},
			},
			expected: false,
		},
		{
			name: "different conditions on Reason - false",
			oldCon: []metav1.Condition{
				{
					Type:   string(gwv1.RouteConditionAccepted),
					Status: metav1.ConditionTrue,
					Reason: "good",
				},
				{
					Type:   string(gwv1.RouteConditionResolvedRefs),
					Status: metav1.ConditionTrue,
				},
			},
			newCon: []metav1.Condition{
				{
					Type:   string(gwv1.RouteConditionAccepted),
					Status: metav1.ConditionTrue,
					Reason: "test-good",
				},
				{
					Type:   string(gwv1.RouteConditionResolvedRefs),
					Status: metav1.ConditionTrue,
				},
			},
			expected: false,
		},
		{
			name: "different conditions on LastTransitionTime - true",
			oldCon: []metav1.Condition{
				{
					Type:               string(gwv1.RouteConditionAccepted),
					Status:             metav1.ConditionTrue,
					LastTransitionTime: metav1.NewTime(time.Date(2025, 1, 1, 0, 0, 0, 0, time.UTC)),
				},
				{
					Type:   string(gwv1.RouteConditionResolvedRefs),
					Status: metav1.ConditionTrue,
				},
			},
			newCon: []metav1.Condition{
				{
					Type:               string(gwv1.RouteConditionAccepted),
					Status:             metav1.ConditionTrue,
					LastTransitionTime: metav1.NewTime(time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)),
				},
				{
					Type:   string(gwv1.RouteConditionResolvedRefs),
					Status: metav1.ConditionTrue,
				},
			},
			expected: true,
		},
		{
			name: "different conditions on ObservedGeneration - false",
			oldCon: []metav1.Condition{
				{
					Type:               string(gwv1.RouteConditionAccepted),
					Status:             metav1.ConditionTrue,
					ObservedGeneration: 1,
				},
				{
					Type:   string(gwv1.RouteConditionResolvedRefs),
					Status: metav1.ConditionTrue,
				},
			},
			newCon: []metav1.Condition{
				{
					Type:               string(gwv1.RouteConditionAccepted),
					Status:             metav1.ConditionTrue,
					ObservedGeneration: 2,
				},
				{
					Type:   string(gwv1.RouteConditionResolvedRefs),
					Status: metav1.ConditionTrue,
				},
			},
			expected: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := areConditionsEqual(tt.oldCon, tt.newCon)
			assert.Equal(t, tt.expected, result)
		})
	}
}

// helper function
func findCondition(conditions []metav1.Condition, conditionType string) *metav1.Condition {
	for _, condition := range conditions {
		if condition.Type == conditionType {
			return &condition
		}
	}
	return nil
}

func Test_getParentRefKeyFromRouteData(t *testing.T) {
	testNamespace := gwv1.Namespace("test-namespace")
	testGroup := gwv1.Group("test-group")
	testKind := gwv1.Kind("test-kind")
	routeNamespace := "route-namespace"
	tests := []struct {
		name       string
		gatewayRef gwv1.ParentReference
		want       string
	}{
		{
			name: "all fields provided",
			gatewayRef: gwv1.ParentReference{
				Group:       &testGroup,
				Kind:        &testKind,
				Namespace:   &testNamespace,
				Name:        "test-gateway",
				SectionName: ptr.To(gwv1.SectionName("test-section")),
				Port:        ptr.To(gwv1.PortNumber(80)),
			},
			want: "test-group/test-kind/test-namespace/test-gateway/test-section/80",
		},
		{
			name: "no namespace provided",
			gatewayRef: gwv1.ParentReference{
				Group:       &testGroup,
				Kind:        &testKind,
				Name:        "test-gateway",
				SectionName: ptr.To(gwv1.SectionName("test-section")),
				Port:        ptr.To(gwv1.PortNumber(80)),
			},
			want: "test-group/test-kind/route-namespace/test-gateway/test-section/80",
		},
		{
			name: "no section or port",
			gatewayRef: gwv1.ParentReference{
				Namespace: &testNamespace,
				Name:      "test-gateway",
			},
			want: "//test-namespace/test-gateway//",
		},
		{
			name: "with port only",
			gatewayRef: gwv1.ParentReference{
				Namespace: &testNamespace,
				Name:      "test-gateway",
				Port:      ptr.To(gwv1.PortNumber(443)),
			},
			want: "//test-namespace/test-gateway//443",
		},
		{
			name: "with section only",
			gatewayRef: gwv1.ParentReference{
				Namespace:   &testNamespace,
				Name:        "test-gateway",
				SectionName: ptr.To(gwv1.SectionName("https")),
			},
			want: "//test-namespace/test-gateway/https/",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := getParentRefKeyFromRouteData(tt.gatewayRef, routeNamespace)
			assert.Equal(t, tt.want, got)
		})
	}
}

func conditionsEqIgnoreTime(t *testing.T, actual, expected metav1.Condition) {
	assert.Equal(t, expected.Status, actual.Status)
	assert.Equal(t, expected.Type, actual.Type)
	assert.Equal(t, expected.Message, actual.Message)
	assert.Equal(t, expected.Reason, actual.Reason)
	assert.Equal(t, expected.ObservedGeneration, actual.ObservedGeneration)
}

package eventhandlers

import (
	"context"
	"fmt"

	"github.com/go-logr/logr"
	"k8s.io/client-go/tools/record"
	"k8s.io/client-go/util/workqueue"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/gateway/routeutils"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/event"
	"sigs.k8s.io/controller-runtime/pkg/handler"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"
	gatewayv1 "sigs.k8s.io/gateway-api/apis/v1"
)

// NewEnqueueRequestsForReferenceGrantEvent creates handler for ReferenceGrant resources
func NewEnqueueRequestsForReferenceGrantEvent(httpRouteEventChan chan<- event.TypedGenericEvent[*gatewayv1.HTTPRoute],
	grpcRouteEventChan chan<- event.TypedGenericEvent[*gatewayv1.GRPCRoute],
	tcpRouteEventChan chan<- event.TypedGenericEvent[*gatewayv1.TCPRoute],
	udpRouteEventChan chan<- event.TypedGenericEvent[*gatewayv1.UDPRoute],
	tlsRouteEventChan chan<- event.TypedGenericEvent[*gatewayv1.TLSRoute],
	k8sClient client.Client, eventRecorder record.EventRecorder, logger logr.Logger) handler.TypedEventHandler[*gatewayv1.ReferenceGrant, reconcile.Request] {
	return &enqueueRequestsForReferenceGrantEvent{
		httpRouteEventChan: httpRouteEventChan,
		grpcRouteEventChan: grpcRouteEventChan,
		tcpRouteEventChan:  tcpRouteEventChan,
		udpRouteEventChan:  udpRouteEventChan,
		tlsRouteEventChan:  tlsRouteEventChan,
		k8sClient:          k8sClient,
		eventRecorder:      eventRecorder,
		logger:             logger,
	}
}

var _ handler.TypedEventHandler[*gatewayv1.ReferenceGrant, reconcile.Request] = (*enqueueRequestsForReferenceGrantEvent)(nil)

// enqueueRequestsForReferenceGrantEvent handles ReferenceGrant events
type enqueueRequestsForReferenceGrantEvent struct {
	httpRouteEventChan chan<- event.TypedGenericEvent[*gatewayv1.HTTPRoute]
	grpcRouteEventChan chan<- event.TypedGenericEvent[*gatewayv1.GRPCRoute]
	tcpRouteEventChan  chan<- event.TypedGenericEvent[*gatewayv1.TCPRoute]
	udpRouteEventChan  chan<- event.TypedGenericEvent[*gatewayv1.UDPRoute]
	tlsRouteEventChan  chan<- event.TypedGenericEvent[*gatewayv1.TLSRoute]
	k8sClient          client.Client
	eventRecorder      record.EventRecorder
	logger             logr.Logger
}

func (h *enqueueRequestsForReferenceGrantEvent) Create(ctx context.Context, e event.TypedCreateEvent[*gatewayv1.ReferenceGrant], _ workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	referenceGrantNew := e.Object
	h.logger.V(1).Info("enqueue reference grant create event", "reference grant", referenceGrantNew.Name)
	h.enqueueImpactedRoutes(ctx, referenceGrantNew, nil)
}

func (h *enqueueRequestsForReferenceGrantEvent) Update(ctx context.Context, e event.TypedUpdateEvent[*gatewayv1.ReferenceGrant], _ workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	referenceGrantNew := e.ObjectNew
	referenceGrantOld := e.ObjectOld
	h.logger.V(1).Info("enqueue reference grant update event", "reference grant", referenceGrantNew.Name)
	h.enqueueImpactedRoutes(ctx, referenceGrantNew, referenceGrantOld)
}

func (h *enqueueRequestsForReferenceGrantEvent) Delete(ctx context.Context, e event.TypedDeleteEvent[*gatewayv1.ReferenceGrant], _ workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	refgrant := e.Object
	h.logger.V(1).Info("enqueue reference grant delete event", "reference grant", refgrant.Name)
	h.enqueueImpactedRoutes(ctx, refgrant, nil)
}

func (h *enqueueRequestsForReferenceGrantEvent) Generic(ctx context.Context, e event.TypedGenericEvent[*gatewayv1.ReferenceGrant], _ workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	refgrant := e.Object
	h.logger.V(1).Info("enqueue reference grant generic event", "reference grant", refgrant.Name)
	h.enqueueImpactedRoutes(ctx, refgrant, nil)
}

func (h *enqueueRequestsForReferenceGrantEvent) enqueueImpactedRoutes(ctx context.Context, newRefGrant *gatewayv1.ReferenceGrant, oldRefGrant *gatewayv1.ReferenceGrant) {

	impactedRoutes := make(map[string]gatewayv1.ReferenceGrantFrom)

	for i, from := range newRefGrant.Spec.From {
		impactedRoutes[generateGrantFromKey(from)] = newRefGrant.Spec.From[i]
	}

	if oldRefGrant != nil {
		for i, from := range oldRefGrant.Spec.From {
			impactedRoutes[generateGrantFromKey(from)] = oldRefGrant.Spec.From[i]
		}
	}

	for _, impactedFrom := range impactedRoutes {
		switch string(impactedFrom.Kind) {
		case string(routeutils.HTTPRouteKind):
			if h.httpRouteEventChan == nil {
				continue
			}
			routes, err := routeutils.ListHTTPRoutes(ctx, h.k8sClient, &client.ListOptions{Namespace: string(impactedFrom.Namespace)})
			if err == nil {
				for _, route := range routes {
					h.httpRouteEventChan <- event.TypedGenericEvent[*gatewayv1.HTTPRoute]{
						Object: route.GetRawRoute().(*gatewayv1.HTTPRoute),
					}
				}

			} else {
				h.logger.Error(err, "Unable to list impacted http routes for reference grant event handler")
			}
		case string(routeutils.GRPCRouteKind):
			if h.grpcRouteEventChan == nil {
				continue
			}
			routes, err := routeutils.ListGRPCRoutes(ctx, h.k8sClient, &client.ListOptions{Namespace: string(impactedFrom.Namespace)})
			if err == nil {
				for _, route := range routes {
					h.grpcRouteEventChan <- event.TypedGenericEvent[*gatewayv1.GRPCRoute]{
						Object: route.GetRawRoute().(*gatewayv1.GRPCRoute),
					}
				}

			} else {
				h.logger.Error(err, "Unable to list impacted grpc routes for reference grant event handler")
			}
		case string(routeutils.TCPRouteKind):
			if h.tcpRouteEventChan == nil {
				continue
			}
			routes, err := routeutils.ListTCPRoutes(ctx, h.k8sClient, &client.ListOptions{Namespace: string(impactedFrom.Namespace)})
			if err == nil {
				for _, route := range routes {
					h.tcpRouteEventChan <- event.TypedGenericEvent[*gatewayv1.TCPRoute]{
						Object: route.GetRawRoute().(*gatewayv1.TCPRoute),
					}
				}

			} else {
				h.logger.Error(err, "Unable to list impacted tcp routes for reference grant event handler")
			}
		case string(routeutils.UDPRouteKind):
			if h.udpRouteEventChan == nil {
				continue
			}
			routes, err := routeutils.ListUDPRoutes(ctx, h.k8sClient, &client.ListOptions{Namespace: string(impactedFrom.Namespace)})
			if err == nil {
				for _, route := range routes {
					h.udpRouteEventChan <- event.TypedGenericEvent[*gatewayv1.UDPRoute]{
						Object: route.GetRawRoute().(*gatewayv1.UDPRoute),
					}
				}

			} else {
				h.logger.Error(err, "Unable to list impacted udp routes for reference grant event handler")
			}
		case string(routeutils.TLSRouteKind):
			if h.tlsRouteEventChan == nil {
				continue
			}
			routes, err := routeutils.ListTLSRoutes(ctx, h.k8sClient, &client.ListOptions{Namespace: string(impactedFrom.Namespace)})
			if err == nil {
				for _, route := range routes {
					h.tlsRouteEventChan <- event.TypedGenericEvent[*gatewayv1.TLSRoute]{
						Object: route.GetRawRoute().(*gatewayv1.TLSRoute),
					}
				}

			} else {
				h.logger.Error(err, "Unable to list impacted tls routes for reference grant event handler")
			}
		}
	}
}

func generateGrantFromKey(from gatewayv1.ReferenceGrantFrom) string {
	return fmt.Sprintf("%s-%s", from.Kind, from.Namespace)
}

package gateway

import (
	"context"
	"fmt"
	"strings"

	"github.com/go-logr/logr"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/record"
	elbv2gw "sigs.k8s.io/aws-load-balancer-controller/v3/apis/gateway/v1"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/config"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/gateway/constants"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/gateway/gatewayutils"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/gateway/referencecounter"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/k8s"
	ctrl "sigs.k8s.io/controller-runtime"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/controller"
	"sigs.k8s.io/controller-runtime/pkg/handler"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"
	"sigs.k8s.io/controller-runtime/pkg/source"
	gwv1 "sigs.k8s.io/gateway-api/apis/v1"
)

// NewTargetGroupConfigurationReconciler constructs a reconciler that responds to targetgroup configuration changes
func NewTargetGroupConfigurationReconciler(k8sClient client.Client, eventRecorder record.EventRecorder, controllerConfig config.ControllerConfig, serviceReferenceCounter referencecounter.ServiceReferenceCounter, finalizerManager k8s.FinalizerManager, logger logr.Logger, successCallback func(name string, namespace string), errorCallBack func(name string, namespace string, err error)) Reconciler {

	return &targetgroupConfigurationReconciler{
		k8sClient:               k8sClient,
		eventRecorder:           eventRecorder,
		logger:                  logger,
		finalizerManager:        finalizerManager,
		finalizer:               controllerConfig.GatewayFinalizerConfig.TargetGroupConfigurationFinalizer,
		serviceReferenceCounter: serviceReferenceCounter,
		gwRetrieveFn:            gatewayutils.GetGatewaysManagedByLBController,
		workers:                 controllerConfig.GatewayClassMaxConcurrentReconciles,
		successCallback:         successCallback,
		errorCallBack:           errorCallBack,
	}
}

// targetgroupConfigurationReconciler reconciles target group configurations
type targetgroupConfigurationReconciler struct {
	k8sClient               client.Client
	logger                  logr.Logger
	eventRecorder           record.EventRecorder
	finalizerManager        k8s.FinalizerManager
	finalizer               string
	serviceReferenceCounter referencecounter.ServiceReferenceCounter

	gwRetrieveFn func(ctx context.Context, k8sClient client.Client, gwController string) ([]*gwv1.Gateway, error)
	workers      int

	successCallback func(name string, namespace string)
	errorCallBack   func(name string, namespace string, err error)
}

func (r *targetgroupConfigurationReconciler) SetupWatches(_ context.Context, ctrl controller.Controller, mgr ctrl.Manager, _ *kubernetes.Clientset) error {

	if err := ctrl.Watch(source.Kind(mgr.GetCache(), &elbv2gw.TargetGroupConfiguration{}, &handler.TypedEnqueueRequestForObject[*elbv2gw.TargetGroupConfiguration]{})); err != nil {
		return err
	}

	return nil
}

func (r *targetgroupConfigurationReconciler) Reconcile(ctx context.Context, req reconcile.Request) (ctrl.Result, error) {
	err := r.reconcile(ctx, req)
	return handleReconcileResult(req, err, r.logger, r.successCallback, r.errorCallBack)
}

func (r *targetgroupConfigurationReconciler) reconcile(ctx context.Context, req reconcile.Request) error {
	tgConf := &elbv2gw.TargetGroupConfiguration{}
	if err := r.k8sClient.Get(ctx, req.NamespacedName, tgConf); err != nil {
		return client.IgnoreNotFound(err)
	}

	r.logger.V(1).Info("Found tg configuration", "cfg", tgConf)

	if tgConf.DeletionTimestamp == nil || tgConf.DeletionTimestamp.IsZero() {
		return r.handleUpdate(tgConf)
	}
	return r.handleDelete(tgConf)
}

func (r *targetgroupConfigurationReconciler) handleUpdate(tgConf *elbv2gw.TargetGroupConfiguration) error {
	if k8s.HasFinalizer(tgConf, r.finalizer) {
		return nil
	}
	return r.finalizerManager.AddFinalizers(context.Background(), tgConf, r.finalizer)
}

func (r *targetgroupConfigurationReconciler) handleDelete(tgConf *elbv2gw.TargetGroupConfiguration) error {
	if !k8s.HasFinalizer(tgConf, r.finalizer) {
		return nil
	}

	allGateways := make([]types.NamespacedName, 0)

	for _, c := range constants.FullGatewayControllerSet.UnsortedList() {
		partial, err := r.gwRetrieveFn(context.Background(), r.k8sClient, c)
		if err != nil {
			return err
		}

		for _, gw := range partial {

			if gw.Status.Conditions != nil {
				for _, cond := range gw.Status.Conditions {
					if cond.Type == string(gwv1.GatewayReasonAccepted) && cond.Status == metav1.ConditionTrue {
						allGateways = append(allGateways, k8s.NamespacedName(gw))
					}
				}
			}
		}
	}

	if tgConf.Spec.TargetReference == nil {
		// TGC without targetReference is a default TGC (used via LBC reference).
		// Check if any LoadBalancerConfiguration still references this TGC before allowing deletion.
		inUseLBC, err := r.isDefaultTGCInUse(context.Background(), tgConf)
		if err != nil {
			return err
		}
		if inUseLBC != "" {
			return fmt.Errorf("default targetgroup configuration [%+v] is still in use by LoadBalancerConfiguration [%s]", k8s.NamespacedName(tgConf), inUseLBC)
		}
		return r.finalizerManager.RemoveFinalizers(context.Background(), tgConf, r.finalizer)
	}

	svcReference := types.NamespacedName{
		Namespace: tgConf.Namespace,
		Name:      tgConf.Spec.TargetReference.Name,
	}

	svc := &corev1.Service{}
	err := r.k8sClient.Get(context.Background(), svcReference, svc)

	referenceCheckNeeded := true
	if err != nil {
		notFoundErr := client.IgnoreNotFound(err)
		if notFoundErr != nil {
			return notFoundErr
		}
		referenceCheckNeeded = false
	}

	if referenceCheckNeeded {
		eligibleForRemoval := r.serviceReferenceCounter.IsEligibleForRemoval(svcReference, allGateways)

		// if the targetgroup configuration is still in use, we should not delete it
		if !eligibleForRemoval {
			return fmt.Errorf("targetgroup configuration [%+v] is still in use", k8s.NamespacedName(tgConf))
		}
	}
	return r.finalizerManager.RemoveFinalizers(context.Background(), tgConf, r.finalizer)
}

// isDefaultTGCInUse checks if any LoadBalancerConfiguration in the same namespace references
// this TGC as its defaultTargetGroupConfiguration, and if that LBC is in use by any Gateway or GatewayClass.
// Returns the namespaced names of all in-use LBCs found, or empty string if none.
func (r *targetgroupConfigurationReconciler) isDefaultTGCInUse(ctx context.Context, tgConf *elbv2gw.TargetGroupConfiguration) (string, error) {
	lbConfigList := &elbv2gw.LoadBalancerConfigurationList{}
	if err := r.k8sClient.List(ctx, lbConfigList, client.InNamespace(tgConf.Namespace)); err != nil {
		return "", err
	}

	var inUseLBCs []string
	for i := range lbConfigList.Items {
		lbConfig := &lbConfigList.Items[i]
		if lbConfig.Spec.DefaultTargetGroupConfiguration == nil || lbConfig.Spec.DefaultTargetGroupConfiguration.Name != tgConf.Name {
			continue
		}

		inUse, err := gatewayutils.IsLBConfigInUse(ctx, lbConfig, r.k8sClient, constants.FullGatewayControllerSet)
		if err != nil {
			return "", err
		}
		if inUse {
			inUseLBCs = append(inUseLBCs, k8s.NamespacedName(lbConfig).String())
		}
	}
	if len(inUseLBCs) > 0 {
		return strings.Join(inUseLBCs, ", "), nil
	}
	return "", nil
}

func (r *targetgroupConfigurationReconciler) SetupWithManager(_ context.Context, mgr ctrl.Manager) (controller.Controller, error) {
	return controller.New(constants.TargetGroupConfigurationController, mgr, controller.Options{
		MaxConcurrentReconciles: r.workers,
		Reconciler:              r,
	})

}

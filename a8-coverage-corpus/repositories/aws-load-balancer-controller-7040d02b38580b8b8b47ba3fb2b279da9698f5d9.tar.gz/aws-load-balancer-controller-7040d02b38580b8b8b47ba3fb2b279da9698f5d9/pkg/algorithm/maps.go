package algorithm

import (
	"strings"

	"k8s.io/apimachinery/pkg/util/sets"
)

// awsSystemTagPrefix is the prefix for AWS-reserved system tags, which are immutable.
const awsSystemTagPrefix = "aws:"

// MapFindFirst get from list of maps until first found.
func MapFindFirst(key string, maps ...map[string]string) (string, bool) {
	for _, m := range maps {
		v, ok := m[key]
		if ok {
			return v, ok
		}
	}
	return "", false
}

// MergeStringMap will merge multiple map[string]string into single one.
// The merge is executed for maps argument in sequential order, if a key already exists, the value from previous map is kept.
// e.g. MergeStringMap(map[string]string{"a": "1", "b": "2"}, map[string]string{"a": "3", "d": "4"}) == map[string]string{"a": "1", "b": "2", "d": "4"}
func MergeStringMap(maps ...map[string]string) map[string]string {
	ret := make(map[string]string)
	for _, _map := range maps {
		for k, v := range _map {
			if _, ok := ret[k]; !ok {
				ret[k] = v
			}
		}
	}
	return ret
}

// DiffStringMap will diff desired with current.
// Returns the k/v that need to be add/updated and k/v that need to be deleted to make current match desired.
func DiffStringMap(desired map[string]string, current map[string]string) (map[string]string, map[string]string) {
	modify := make(map[string]string)
	remove := make(map[string]string)

	for key, desiredVal := range desired {
		currentVal, ok := current[key]
		if !ok || currentVal != desiredVal {
			modify[key] = desiredVal
		}
	}

	for key, currentVal := range current {
		if _, ok := desired[key]; !ok {
			remove[key] = currentVal
		}
	}

	return modify, remove
}

// DiffStringMapIgnoreAWSTags is like DiffStringMap but filters out AWS-reserved system tags
// (prefixed with "aws:") from both results. These tags are immutable.
func DiffStringMapIgnoreAWSTags(desired map[string]string, current map[string]string) (map[string]string, map[string]string) {
	modify, remove := DiffStringMap(desired, current)
	RemoveKeysByPrefix(modify, awsSystemTagPrefix)
	RemoveKeysByPrefix(remove, awsSystemTagPrefix)
	return modify, remove
}

// RemoveKeysByPrefix removes all entries from the map whose key starts with the given prefix.
func RemoveKeysByPrefix(m map[string]string, prefix string) {
	for key := range m {
		if strings.HasPrefix(key, prefix) {
			delete(m, key)
		}
	}
}

func CSVToStringSet(csv string) sets.Set[string] {
	s := sets.Set[string]{}

	if len(csv) == 0 {
		return s
	}

	for _, v := range strings.Split(csv, ",") {
		s.Insert(v)
	}

	return s
}

func StringSetToCSV(s sets.Set[string]) string {
	keyList := make([]string, 0, len(s))
	for k := range s {
		keyList = append(keyList, k)
	}
	return strings.Join(keyList, ",")
}

// ContainsSubMapKeys reports whether all keys from map s have a value in map m (ignoring the actual value)
func ContainsSubMapKeys(m map[string]string, s map[string]string) bool {
	for k := range s {
		if _, ok := m[k]; !ok {
			return false
		}
	}

	return true
}

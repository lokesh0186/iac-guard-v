package routeutils

import (
	"context"
	"fmt"
	"strings"
	"testing"
	"time"

	corev1 "k8s.io/api/core/v1"
	elbv2gw "sigs.k8s.io/aws-load-balancer-controller/v3/apis/gateway/v1"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/testutils"

	"github.com/golang/mock/gomock"
	"github.com/stretchr/testify/assert"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/types"
	mock_client "sigs.k8s.io/aws-load-balancer-controller/v3/mocks/controller-runtime/client"
	"sigs.k8s.io/controller-runtime/pkg/client"
	gwv1 "sigs.k8s.io/gateway-api/apis/v1"
)

var _ RouteDescriptor = &mockPreLoadRouteDescriptor{}

// Mock implementations
type mockPreLoadRouteDescriptor struct {
	backendRefs                []gwv1.BackendRef
	listenerRuleConfigurations []gwv1.LocalObjectReference
	namespacedName             types.NamespacedName
	compatibleHostnames        []gwv1.Hostname
}

func (m mockPreLoadRouteDescriptor) GetAttachedRules() []RouteRule {
	//TODO implement me
	panic("implement me")
}

func (m mockPreLoadRouteDescriptor) GetRouteNamespacedName() types.NamespacedName {
	return m.namespacedName
}

func (m mockPreLoadRouteDescriptor) GetRouteKind() RouteKind {
	//TODO implement me
	panic("implement me")
}

func (m mockPreLoadRouteDescriptor) GetHostnames() []gwv1.Hostname {
	//TODO implement me
	panic("implement me")
}

func (m mockPreLoadRouteDescriptor) GetParentRefs() []gwv1.ParentReference {
	//TODO implement me
	panic("implement me")
}

func (m mockPreLoadRouteDescriptor) GetRawRoute() interface{} {
	//TODO implement me
	panic("implement me")
}

func (m mockPreLoadRouteDescriptor) GetBackendRefs() []gwv1.BackendRef {
	return m.backendRefs
}

func (m mockPreLoadRouteDescriptor) GetRouteListenerRuleConfigRefs() []gwv1.LocalObjectReference {
	return m.listenerRuleConfigurations
}

func (m mockPreLoadRouteDescriptor) GetRouteGeneration() int64 {
	//TODO implement me
	panic("implement me")
}

func (m mockPreLoadRouteDescriptor) GetRouteCreateTimestamp() time.Time {
	//TODO implement me
	panic("implement me")
}

func (m mockPreLoadRouteDescriptor) GetRouteIdentifier() string {
	//TODO implement me
	panic("implement me")
}

func (m mockPreLoadRouteDescriptor) GetCompatibleHostnamesByPort() map[int32][]gwv1.Hostname {
	return map[int32][]gwv1.Hostname{80: m.compatibleHostnames}
}

func (m mockPreLoadRouteDescriptor) setCompatibleHostnamesByPort(hostnamesByPort map[int32][]gwv1.Hostname) {
	if hostnamesByPort[80] != nil {
		m.compatibleHostnames = hostnamesByPort[80]
	}
}

func (m mockPreLoadRouteDescriptor) loadAttachedRules(context context.Context, k8sClient client.Client, gatewayDefaultTGConfig *elbv2gw.TargetGroupConfiguration) (RouteDescriptor, []routeLoadError) {
	//TODO implement me
	panic("implement me")
}

// Test ListL4Routes
func Test_ListL4Routes(t *testing.T) {
	tests := []struct {
		name           string
		mockSetup      func(*gomock.Controller) client.Client
		expectedRoutes int
		expectedErr    error
	}{
		{
			name: "Successfully lists all L4 routes",
			mockSetup: func(ctrl *gomock.Controller) client.Client {
				k8sClient := testutils.GenerateTestClient()
				k8sClient.Create(context.Background(), &gwv1.TCPRoute{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "foo1",
						Namespace: "bar1",
					},
					Spec: gwv1.TCPRouteSpec{
						Rules: []gwv1.TCPRouteRule{
							{
								BackendRefs: []gwv1.BackendRef{
									{},
									{},
								},
							},
							{
								BackendRefs: []gwv1.BackendRef{
									{},
									{},
									{},
									{},
								},
							},
							{
								BackendRefs: []gwv1.BackendRef{},
							},
						},
					},
				})
				k8sClient.Create(context.Background(), &gwv1.UDPRoute{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "foo1",
						Namespace: "bar1",
					},
					Spec: gwv1.UDPRouteSpec{
						Rules: []gwv1.UDPRouteRule{
							{
								BackendRefs: []gwv1.BackendRef{
									{},
									{},
								},
							},
							{
								BackendRefs: []gwv1.BackendRef{
									{},
									{},
									{},
									{},
								},
							},
							{
								BackendRefs: []gwv1.BackendRef{},
							},
						},
					},
				})
				k8sClient.Create(context.Background(), &gwv1.TLSRoute{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "foo1",
						Namespace: "bar1",
					},
					Spec: gwv1.TLSRouteSpec{
						Hostnames: []gwv1.Hostname{
							"host1",
						},
						Rules: []gwv1.TLSRouteRule{
							{
								BackendRefs: []gwv1.BackendRef{
									{},
									{},
								},
							},
							{
								BackendRefs: []gwv1.BackendRef{
									{},
									{},
									{},
									{},
								},
							},
							{
								BackendRefs: []gwv1.BackendRef{},
							},
						},
					},
				})
				return k8sClient
			},
			expectedRoutes: 3,
		},
		{
			name: "Handles error in TCP routes",
			mockSetup: func(ctrl *gomock.Controller) client.Client {
				mockClient := mock_client.NewMockClient(ctrl)
				// Setup mock responses for TCP, UDP, and TLS routes
				mockClient.EXPECT().List(gomock.Any(), &gwv1.TCPRouteList{}).Return(fmt.Errorf("TCP error"))
				mockClient.EXPECT().List(gomock.Any(), &gwv1.UDPRouteList{}).Return(nil)
				mockClient.EXPECT().List(gomock.Any(), &gwv1.TLSRouteList{}).Return(nil)
				return mockClient
			},
			expectedRoutes: 0,
			expectedErr:    fmt.Errorf("failed to list L4 routes, [TCPRoute]"),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			client := tt.mockSetup(ctrl)
			routes, err := ListL4Routes(context.Background(), client)

			if tt.expectedErr == nil {
				assert.NoError(t, err)
			} else {
				assert.Equal(t, tt.expectedErr.Error(), err.Error())
			}
			assert.Len(t, routes, tt.expectedRoutes)

		})
	}
}

// Test ListL7Routes
func Test_ListL7Routes(t *testing.T) {
	tests := []struct {
		name           string
		mockSetup      func(*gomock.Controller) client.Client
		expectedRoutes int
		expectedErr    error
	}{
		{
			name: "Successfully lists all L7 routes",
			mockSetup: func(ctrl *gomock.Controller) client.Client {
				k8sClient := testutils.GenerateTestClient()
				k8sClient.Create(context.Background(), &gwv1.HTTPRoute{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "foo1",
						Namespace: "bar1",
					},
					Spec: gwv1.HTTPRouteSpec{
						Hostnames: []gwv1.Hostname{
							"host1",
						},
						Rules: []gwv1.HTTPRouteRule{
							{
								BackendRefs: []gwv1.HTTPBackendRef{
									{},
									{},
								},
							},
							{
								BackendRefs: []gwv1.HTTPBackendRef{
									{},
									{},
									{},
									{},
								},
							},
							{
								BackendRefs: []gwv1.HTTPBackendRef{},
							},
						},
					},
				})
				k8sClient.Create(context.Background(), &gwv1.GRPCRoute{
					ObjectMeta: metav1.ObjectMeta{
						Name:      "foo1",
						Namespace: "bar1",
					},
					Spec: gwv1.GRPCRouteSpec{
						Hostnames: []gwv1.Hostname{
							"host1",
						},
						Rules: []gwv1.GRPCRouteRule{
							{
								BackendRefs: []gwv1.GRPCBackendRef{
									{},
									{},
								},
							},
							{
								BackendRefs: []gwv1.GRPCBackendRef{
									{},
									{},
									{},
									{},
								},
							},
							{
								BackendRefs: []gwv1.GRPCBackendRef{},
							},
						},
					},
				})
				return k8sClient
			},
			expectedRoutes: 2,
			expectedErr:    nil,
		},
		{
			name: "Handles error in HTTP routes",
			mockSetup: func(ctrl *gomock.Controller) client.Client {
				mockClient := mock_client.NewMockClient(ctrl)
				mockClient.EXPECT().List(gomock.Any(), &gwv1.HTTPRouteList{}).Return(fmt.Errorf("HTTP error"))
				mockClient.EXPECT().List(gomock.Any(), &gwv1.GRPCRouteList{}).Return(nil)
				return mockClient
			},
			expectedRoutes: 0,
			expectedErr:    fmt.Errorf("failed to list L7 routes, [HTTPRoute]"),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()

			client := tt.mockSetup(ctrl)
			routes, err := ListL7Routes(context.Background(), client)

			if tt.expectedErr == nil {
				assert.NoError(t, err)
			} else {
				assert.Equal(t, tt.expectedErr.Error(), err.Error())
			}
			assert.Len(t, routes, tt.expectedRoutes)

		})
	}
}

// Test FilterRoutesBySvc
func Test_FilterRoutesBySvc(t *testing.T) {
	namespace := "test-ns"
	svcName := "test-svc"

	tests := []struct {
		name          string
		routes        []preLoadRouteDescriptor
		service       *corev1.Service
		expectedCount int
	}{
		{
			name:          "Nil service returns nil",
			routes:        []preLoadRouteDescriptor{},
			service:       nil,
			expectedCount: 0,
		},
		{
			name:   "Empty routes returns nil",
			routes: []preLoadRouteDescriptor{},
			service: &corev1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      svcName,
					Namespace: namespace,
				},
			},
			expectedCount: 0,
		},
		{
			name: "Filters matching routes",
			routes: []preLoadRouteDescriptor{
				mockPreLoadRouteDescriptor{
					backendRefs: []gwv1.BackendRef{
						{
							BackendObjectReference: gwv1.BackendObjectReference{
								Name: gwv1.ObjectName(svcName),
							},
						},
					},
					namespacedName: types.NamespacedName{
						Namespace: namespace,
						Name:      "route-1",
					},
				},
				&mockPreLoadRouteDescriptor{
					backendRefs: []gwv1.BackendRef{
						{
							BackendObjectReference: gwv1.BackendObjectReference{
								Name: gwv1.ObjectName("other-svc"),
							},
						},
					},
					namespacedName: types.NamespacedName{
						Namespace: namespace,
						Name:      "route-2",
					},
				},
			},
			service: &corev1.Service{
				ObjectMeta: metav1.ObjectMeta{
					Name:      svcName,
					Namespace: namespace,
				},
			},
			expectedCount: 1,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			filtered := FilterRoutesBySvc(tt.routes, tt.service)
			assert.Len(t, filtered, tt.expectedCount)
		})
	}
}

// Test isServiceReferredByRoute
func Test_IsServiceReferredByRoute(t *testing.T) {
	tests := []struct {
		name     string
		route    preLoadRouteDescriptor
		svcID    types.NamespacedName
		expected bool
	}{
		{
			name: "Route refers to service",
			route: mockPreLoadRouteDescriptor{
				backendRefs: []gwv1.BackendRef{
					{
						BackendObjectReference: gwv1.BackendObjectReference{
							Name: gwv1.ObjectName("test-svc"),
						},
					},
				},
				namespacedName: types.NamespacedName{
					Namespace: "test-ns",
					Name:      "route-1",
				},
			},
			svcID: types.NamespacedName{
				Namespace: "test-ns",
				Name:      "test-svc",
			},
			expected: true,
		},
		{
			name: "Route does not refer to service",
			route: mockPreLoadRouteDescriptor{
				backendRefs: []gwv1.BackendRef{
					{
						BackendObjectReference: gwv1.BackendObjectReference{
							Name: gwv1.ObjectName("other-svc"),
						},
					},
				},
				namespacedName: types.NamespacedName{
					Namespace: "test-ns",
					Name:      "route-1",
				},
			},
			svcID: types.NamespacedName{
				Namespace: "test-ns",
				Name:      "test-svc",
			},
			expected: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := isServiceReferredByRoute(tt.route, tt.svcID)
			assert.Equal(t, tt.expected, result)
		})
	}
}

// Test isHostNameInValidFormat
func TestIsHostNameInValidFormat(t *testing.T) {
	tests := []struct {
		name     string
		hostname string
		want     bool
		wantErr  string
	}{
		{
			name:     "IPv4 address",
			hostname: "192.168.1.1",
			want:     false,
			wantErr:  "hostname can not be IP address",
		},
		{
			name:     "Label too short",
			hostname: "test..com",
			want:     false,
			wantErr:  "invalid hostname label length",
		},
		{
			name:     "Label too long",
			hostname: strings.Repeat("a", 64) + ".com",
			want:     false,
			wantErr:  "invalid hostname label length",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := IsHostNameInValidFormat(tt.hostname)
			if got != tt.want {
				t.Errorf("IsHostNameInValidFormat() got = %v, want %v", got, tt.want)
			}

			if tt.wantErr == "" && err != nil {
				t.Errorf("IsHostNameInValidFormat() unexpected error = %v", err)
			}
			if tt.wantErr != "" && err == nil {
				t.Errorf("IsHostNameInValidFormat() expected error containing %q but got nil", tt.wantErr)
			}
			if tt.wantErr != "" && err != nil && !strings.Contains(err.Error(), tt.wantErr) {
				t.Errorf("IsHostNameInValidFormat() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

// Test isHostnameCompatible
func Test_isHostnameCompatible(t *testing.T) {
	tests := []struct {
		name        string
		hostnameOne string
		hostnameTwo string
		want        bool
	}{
		{
			name:        "exact match",
			hostnameOne: "example.com",
			hostnameTwo: "example.com",
			want:        true,
		},
		{
			name:        "first hostname is wildcard - matching",
			hostnameOne: "*.example.com",
			hostnameTwo: "test.example.com",
			want:        true,
		},
		{
			name:        "second hostname is wildcard - matching",
			hostnameOne: "test.example.com",
			hostnameTwo: "*.example.com",
			want:        true,
		},
		{
			name:        "both hostnames are wildcards - matching",
			hostnameOne: "*.example.com",
			hostnameTwo: "*.test.example.com",
			want:        true,
		},
		{
			name:        "first hostname is wildcard - not matching",
			hostnameOne: "*.example.com",
			hostnameTwo: "test.different.com",
			want:        false,
		},
		{
			name:        "second hostname is wildcard - not matching",
			hostnameOne: "test.different.com",
			hostnameTwo: "*.example.com",
			want:        false,
		},
		{
			name:        "wildcard with subdomain - matching",
			hostnameOne: "*.sub.example.com",
			hostnameTwo: "test.sub.example.com",
			want:        true,
		},
		{
			name:        "wildcard with root domain",
			hostnameOne: "*.example.com",
			hostnameTwo: "example.com",
			want:        false,
		},
		{
			name:        "multiple subdomains - matching",
			hostnameOne: "*.example.com",
			hostnameTwo: "a.b.example.com",
			want:        true,
		},
		{
			name:        "partial wildcard match - not matching",
			hostnameOne: "*.example.com",
			hostnameTwo: "testexample.com",
			want:        false,
		},
		{
			name:        "invalid wildcard format",
			hostnameOne: "*example.com",
			hostnameTwo: "test.example.com",
			want:        false,
		},
		{
			name:        "case sensitivity test",
			hostnameOne: "*.Example.com",
			hostnameTwo: "test.example.com",
			want:        false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := isHostnameCompatible(tt.hostnameOne, tt.hostnameTwo)
			if got != tt.want {
				t.Errorf("isHostnameCompatible() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_getCompatibleHostname(t *testing.T) {
	tests := []struct {
		name         string
		hostnameOne  string
		hostnameTwo  string
		wantHostname string
		wantOk       bool
	}{
		{
			name:         "exact match",
			hostnameOne:  "example.com",
			hostnameTwo:  "example.com",
			wantHostname: "example.com",
			wantOk:       true,
		},
		{
			name:         "wildcard in first, specific in second",
			hostnameOne:  "*.example.com",
			hostnameTwo:  "api.example.com",
			wantHostname: "api.example.com",
			wantOk:       true,
		},
		{
			name:         "wildcard in second, specific in first",
			hostnameOne:  "api.example.com",
			hostnameTwo:  "*.example.com",
			wantHostname: "api.example.com",
			wantOk:       true,
		},
		{
			name:         "incompatible hostnames",
			hostnameOne:  "example.com",
			hostnameTwo:  "different.com",
			wantHostname: "",
			wantOk:       false,
		},
		{
			name:         "wildcard does not match",
			hostnameOne:  "*.example.com",
			hostnameTwo:  "api.different.com",
			wantHostname: "",
			wantOk:       false,
		},
		{
			name:         "both wildcards same domain",
			hostnameOne:  "*.example.com",
			hostnameTwo:  "*.example.com",
			wantHostname: "*.example.com",
			wantOk:       true,
		},
		{
			name:         "both wildcards different domains",
			hostnameOne:  "*.example.com",
			hostnameTwo:  "*.different.com",
			wantHostname: "",
			wantOk:       false,
		},
		{
			name:         "nested subdomain with wildcard",
			hostnameOne:  "*.example.com",
			hostnameTwo:  "sub.api.example.com",
			wantHostname: "sub.api.example.com",
			wantOk:       true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotHostname, gotOk := getCompatibleHostname(tt.hostnameOne, tt.hostnameTwo)
			if gotHostname != tt.wantHostname {
				t.Errorf("getCompatibleHostname() hostname = %v, want %v", gotHostname, tt.wantHostname)
			}
			if gotOk != tt.wantOk {
				t.Errorf("getCompatibleHostname() ok = %v, want %v", gotOk, tt.wantOk)
			}
		})
	}
}

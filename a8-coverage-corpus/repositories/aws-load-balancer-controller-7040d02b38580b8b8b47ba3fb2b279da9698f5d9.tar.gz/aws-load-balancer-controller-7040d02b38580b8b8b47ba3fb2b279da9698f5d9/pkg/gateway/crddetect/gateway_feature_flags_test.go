package crddetect

import (
	"testing"

	"github.com/go-logr/logr"
	"github.com/stretchr/testify/assert"
	"k8s.io/apimachinery/pkg/util/sets"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/config"
)

func TestApplyGatewayFeatureFlags(t *testing.T) {
	lbcKinds := sets.New[string]("TargetGroupConfiguration", "LoadBalancerConfiguration", "ListenerRuleConfiguration")

	testCases := []struct {
		name               string
		presentKinds       map[string]sets.Set[string]
		albEnabled         bool
		nlbEnabled         bool
		listenerSetEnabled bool
	}{
		{
			name:               "no kinds present",
			presentKinds:       map[string]sets.Set[string]{},
			albEnabled:         false,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
		{
			name: "v1 present but LBC CRDs missing",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion: sets.New[string]("Gateway", "GatewayClass", "HTTPRoute", "GRPCRoute", "TLSRoute", "ReferenceGrant"),
			},
			albEnabled:         false,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
		{
			name: "v1 and LBC CRDs present",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("Gateway", "GatewayClass", "HTTPRoute", "GRPCRoute", "TLSRoute", "ReferenceGrant"),
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         true,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
		{
			name: "tcproute and udproute not served at v1 (gateway api < 1.6) - NLB disabled",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("Gateway", "GatewayClass", "HTTPRoute", "GRPCRoute", "TLSRoute", "ReferenceGrant"),
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         true,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
		{
			name: "all standard CRDs present but LBC CRDs missing",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion: sets.New[string]("Gateway", "GatewayClass", "HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute", "ReferenceGrant"),
			},
			albEnabled:         false,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
		{
			name: "all present including LBC CRDs but ListenerSet missing",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("Gateway", "GatewayClass", "HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute", "ReferenceGrant"),
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         true,
			nlbEnabled:         true,
			listenerSetEnabled: false,
		},
		{
			name: "all present including ListenerSet and LBC CRDs",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("Gateway", "GatewayClass", "HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute", "ListenerSet", "ReferenceGrant"),
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         true,
			nlbEnabled:         true,
			listenerSetEnabled: true,
		},
		{
			name: "gateway missing",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("GatewayClass", "HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute", "ReferenceGrant"),
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         false,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
		{
			name: "gateway class missing",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("Gateway", "HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute", "ReferenceGrant"),
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         false,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
		{
			name: "httproute missing",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("Gateway", "GatewayClass", "GRPCRoute", "TLSRoute", "TCPRoute", "UDPRoute", "ReferenceGrant"),
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         false,
			nlbEnabled:         true,
			listenerSetEnabled: false,
		},
		{
			name: "grpcroute missing",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("Gateway", "GatewayClass", "HTTPRoute", "TLSRoute", "TCPRoute", "UDPRoute", "ReferenceGrant"),
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         false,
			nlbEnabled:         true,
			listenerSetEnabled: false,
		},
		{
			name: "tlsroute missing",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("Gateway", "GatewayClass", "HTTPRoute", "GRPCRoute", "TCPRoute", "UDPRoute", "ReferenceGrant"),
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         true,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
		{
			name: "tcproute missing",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("Gateway", "GatewayClass", "HTTPRoute", "GRPCRoute", "TLSRoute", "UDPRoute", "ReferenceGrant"),
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         true,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
		{
			name: "udproute missing",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("Gateway", "GatewayClass", "HTTPRoute", "GRPCRoute", "TLSRoute", "TCPRoute", "ReferenceGrant"),
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         true,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
		{
			name: "ListenerSet present without full gateway CRDs",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion: sets.New[string]("ListenerSet"),
			},
			albEnabled:         false,
			nlbEnabled:         false,
			listenerSetEnabled: true,
		},
		{
			name: "LBC CRDs present but no standard gateway CRDs",
			presentKinds: map[string]sets.Set[string]{
				LBCGatewayGroupVersion: lbcKinds,
			},
			albEnabled:         false,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
		{
			name: "partial LBC CRDs - TargetGroupConfiguration missing",
			presentKinds: map[string]sets.Set[string]{
				GatewayV1GroupVersion:  sets.New[string]("Gateway", "GatewayClass", "HTTPRoute", "GRPCRoute", "ReferenceGrant"),
				LBCGatewayGroupVersion: sets.New[string]("LoadBalancerConfiguration", "ListenerRuleConfiguration"),
			},
			albEnabled:         false,
			nlbEnabled:         false,
			listenerSetEnabled: false,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			cfg := config.NewFeatureGates()
			applyGatewayFeatureFlags(tc.presentKinds, cfg, logr.Discard())

			assert.Equal(t, tc.albEnabled, cfg.Enabled(config.ALBGatewayAPI))
			assert.Equal(t, tc.nlbEnabled, cfg.Enabled(config.NLBGatewayAPI))
			assert.Equal(t, tc.listenerSetEnabled, cfg.Enabled(config.GatewayListenerSet))
		})
	}
}

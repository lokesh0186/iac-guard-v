package model

import elbv2gw "sigs.k8s.io/aws-load-balancer-controller/v3/apis/gateway/v1"

type mockTagHelper struct {
	tags map[string]string
	err  error
}

func (m *mockTagHelper) getLoadBalancerTags(lbConf elbv2gw.LoadBalancerConfiguration) (map[string]string, error) {
	return m.tags, m.err
}

func (m *mockTagHelper) getTargetGroupTags(tgProps *elbv2gw.TargetGroupProps) (map[string]string, error) {
	return m.tags, m.err
}

func (m *mockTagHelper) getListenerRuleTags(lrConf *elbv2gw.ListenerRuleConfiguration) (map[string]string, error) {
	return m.tags, m.err
}

var _ tagHelper = &mockTagHelper{}

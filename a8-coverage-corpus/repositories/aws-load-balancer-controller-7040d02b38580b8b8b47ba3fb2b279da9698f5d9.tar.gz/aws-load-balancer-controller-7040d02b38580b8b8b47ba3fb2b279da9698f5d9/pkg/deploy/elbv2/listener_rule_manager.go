package elbv2

import (
	"context"
	awssdk "github.com/aws/aws-sdk-go-v2/aws"
	elbv2sdk "github.com/aws/aws-sdk-go-v2/service/elasticloadbalancingv2"
	elbv2types "github.com/aws/aws-sdk-go-v2/service/elasticloadbalancingv2/types"
	"github.com/go-logr/logr"
	"github.com/pkg/errors"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/aws/services"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/config"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/deploy/tracking"
	elbv2model "sigs.k8s.io/aws-load-balancer-controller/v3/pkg/model/elbv2"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/runtime"
	"slices"
	"sort"
	"strconv"
	"time"
)

// ListenerRuleManager is responsible for create/update/delete ListenerRule resources.
type ListenerRuleManager interface {
	Create(ctx context.Context, resLR *elbv2model.ListenerRule, desiredRuleConfig *resLRDesiredRuleConfig) (elbv2model.ListenerRuleStatus, error)

	UpdateRules(ctx context.Context, resLR *elbv2model.ListenerRule, sdkLR ListenerRuleWithTags, desiredRuleConfig *resLRDesiredRuleConfig) (elbv2model.ListenerRuleStatus, error)

	UpdateRulesTags(ctx context.Context, resLR *elbv2model.ListenerRule, sdkLR ListenerRuleWithTags) (elbv2model.ListenerRuleStatus, error)

	Delete(ctx context.Context, sdkLR ListenerRuleWithTags) error

	SetRulePriorities(ctx context.Context, matchedResAndSDKLRsBySettings []resAndSDKListenerRulePair, unmatchedSDKLRs []ListenerRuleWithTags) error
}

// NewDefaultListenerRuleManager constructs new defaultListenerRuleManager.
func NewDefaultListenerRuleManager(elbv2Client services.ELBV2, trackingProvider tracking.Provider,
	taggingManager TaggingManager, externalManagedTags []string, featureGates config.FeatureGates, logger logr.Logger) *defaultListenerRuleManager {
	return &defaultListenerRuleManager{
		elbv2Client:                 elbv2Client,
		trackingProvider:            trackingProvider,
		taggingManager:              taggingManager,
		externalManagedTags:         externalManagedTags,
		featureGates:                featureGates,
		logger:                      logger,
		waitLSExistencePollInterval: defaultWaitLSExistencePollInterval,
		waitLSExistenceTimeout:      defaultWaitLSExistenceTimeout,
	}
}

// default implementation for ListenerRuleManager.
type defaultListenerRuleManager struct {
	elbv2Client         services.ELBV2
	trackingProvider    tracking.Provider
	taggingManager      TaggingManager
	externalManagedTags []string
	featureGates        config.FeatureGates
	logger              logr.Logger

	waitLSExistencePollInterval time.Duration
	waitLSExistenceTimeout      time.Duration
}

func (m *defaultListenerRuleManager) Create(ctx context.Context, resLR *elbv2model.ListenerRule, desiredRuleConfig *resLRDesiredRuleConfig) (elbv2model.ListenerRuleStatus, error) {
	req, err := buildSDKCreateListenerRuleInput(resLR.Spec, desiredRuleConfig, m.featureGates)
	if err != nil {
		return elbv2model.ListenerRuleStatus{}, err
	}
	var ruleTags map[string]string
	if m.featureGates.Enabled(config.ListenerRulesTagging) {
		ruleTags = m.trackingProvider.ResourceTags(resLR.Stack(), resLR, resLR.Spec.Tags)
	}
	req.Tags = convertTagsToSDKTags(ruleTags)

	m.logger.Info("creating listener rule",
		"stackID", resLR.Stack().StackID(),
		"resourceID", resLR.ID())
	var sdkLR ListenerRuleWithTags
	if err := runtime.RetryImmediateOnError(m.waitLSExistencePollInterval, m.waitLSExistenceTimeout, isListenerNotFoundError, func() error {
		resp, err := m.elbv2Client.CreateRuleWithContext(ctx, req)
		if err != nil {
			return err
		}
		sdkLR = ListenerRuleWithTags{
			ListenerRule: &resp.Rules[0],
			Tags:         ruleTags,
		}
		return nil
	}); err != nil {
		return elbv2model.ListenerRuleStatus{}, errors.Wrap(err, "failed to create listener rule")
	}
	m.logger.Info("created listener rule",
		"stackID", resLR.Stack().StackID(),
		"resourceID", resLR.ID(),
		"arn", awssdk.ToString(sdkLR.ListenerRule.RuleArn))

	return buildResListenerRuleStatus(sdkLR), nil
}

func (m *defaultListenerRuleManager) UpdateRulesTags(ctx context.Context, resLR *elbv2model.ListenerRule, sdkLR ListenerRuleWithTags) (elbv2model.ListenerRuleStatus, error) {
	if m.featureGates.Enabled(config.ListenerRulesTagging) {
		if err := m.updateSDKListenerRuleWithTags(ctx, resLR, sdkLR); err != nil {
			return elbv2model.ListenerRuleStatus{}, err
		}
	}
	return buildResListenerRuleStatus(sdkLR), nil
}

func (m *defaultListenerRuleManager) UpdateRules(ctx context.Context, resLR *elbv2model.ListenerRule, sdkLR ListenerRuleWithTags, desiredRuleConfig *resLRDesiredRuleConfig) (elbv2model.ListenerRuleStatus, error) {
	if err := m.updateSDKListenerRuleWithSettings(ctx, resLR, sdkLR, desiredRuleConfig); err != nil {
		return elbv2model.ListenerRuleStatus{}, err
	}
	return buildResListenerRuleStatus(sdkLR), nil
}

func (m *defaultListenerRuleManager) Delete(ctx context.Context, sdkLR ListenerRuleWithTags) error {
	req := &elbv2sdk.DeleteRuleInput{
		RuleArn: sdkLR.ListenerRule.RuleArn,
	}
	m.logger.Info("deleting listener rule",
		"arn", awssdk.ToString(req.RuleArn))
	if _, err := m.elbv2Client.DeleteRuleWithContext(ctx, req); err != nil {
		return err
	}
	m.logger.Info("deleted listener rule",
		"arn", awssdk.ToString(req.RuleArn))
	return nil
}

func (m *defaultListenerRuleManager) SetRulePriorities(ctx context.Context, matchedResAndSDKLRsBySettings []resAndSDKListenerRulePair, unmatchedSDKLRs []ListenerRuleWithTags) error {
	req := buildSDKSetRulePrioritiesInput(matchedResAndSDKLRsBySettings, unmatchedSDKLRs)
	m.logger.Info("setting listener rule priorities",
		"rule priority pairs", req.RulePriorities)
	if _, err := m.elbv2Client.SetRulePrioritiesWithContext(ctx, req); err != nil {
		return err
	}
	m.logger.Info("setting listener rule priorities complete",
		"rule priority pairs", req.RulePriorities)
	return nil
}

func (m *defaultListenerRuleManager) updateSDKListenerRuleWithTags(ctx context.Context, resLR *elbv2model.ListenerRule, sdkLR ListenerRuleWithTags) error {
	desiredTags := m.trackingProvider.ResourceTags(resLR.Stack(), resLR, resLR.Spec.Tags)
	return m.taggingManager.ReconcileTags(ctx, awssdk.ToString(sdkLR.ListenerRule.RuleArn), desiredTags,
		WithCurrentTags(sdkLR.Tags),
		WithIgnoredTagKeys(m.externalManagedTags))
}

func (m *defaultListenerRuleManager) updateSDKListenerRuleWithSettings(ctx context.Context, resLR *elbv2model.ListenerRule, sdkLR ListenerRuleWithTags, desiredRuleConfig *resLRDesiredRuleConfig) error {
	desiredActions := desiredRuleConfig.desiredActions
	desiredConditions := desiredRuleConfig.desiredConditions
	desiredTransforms := desiredRuleConfig.desiredTransforms

	req := buildSDKModifyListenerRuleInput(resLR.Spec, desiredActions, desiredConditions, desiredTransforms)
	req.RuleArn = sdkLR.ListenerRule.RuleArn
	m.logger.Info("modifying listener rule",
		"stackID", resLR.Stack().StackID(),
		"resourceID", resLR.ID(),
		"arn", awssdk.ToString(sdkLR.ListenerRule.RuleArn))
	if _, err := m.elbv2Client.ModifyRuleWithContext(ctx, req); err != nil {
		return err
	}
	m.logger.Info("modified listener rule",
		"stackID", resLR.Stack().StackID(),
		"resourceID", resLR.ID(),
		"arn", awssdk.ToString(sdkLR.ListenerRule.RuleArn))
	return nil
}

func buildSDKCreateListenerRuleInput(lrSpec elbv2model.ListenerRuleSpec, desiredRuleConfig *resLRDesiredRuleConfig, featureGates config.FeatureGates) (*elbv2sdk.CreateRuleInput, error) {
	ctx := context.Background()
	lsARN, err := lrSpec.ListenerARN.Resolve(ctx)
	if err != nil {
		return nil, err
	}
	sdkObj := &elbv2sdk.CreateRuleInput{}
	sdkObj.ListenerArn = awssdk.String(lsARN)
	sdkObj.Priority = awssdk.Int32(lrSpec.Priority)
	if desiredRuleConfig != nil && desiredRuleConfig.desiredActions != nil {
		sdkObj.Actions = desiredRuleConfig.desiredActions
	} else {
		actions, err := buildSDKActions(lrSpec.Actions, featureGates)
		if err != nil {
			return nil, err
		}
		sdkObj.Actions = actions
	}
	if desiredRuleConfig != nil && desiredRuleConfig.desiredConditions != nil {
		sdkObj.Conditions = desiredRuleConfig.desiredConditions
	} else {
		sdkObj.Conditions = buildSDKRuleConditions(lrSpec.Conditions)
	}
	if desiredRuleConfig != nil && desiredRuleConfig.desiredTransforms != nil {
		sdkObj.Transforms = desiredRuleConfig.desiredTransforms
	} else if len(lrSpec.Transforms) > 0 {
		sdkObj.Transforms = buildSDKTransforms(lrSpec.Transforms)
	}
	return sdkObj, nil
}

func buildSDKModifyListenerRuleInput(_ elbv2model.ListenerRuleSpec, desiredActions []elbv2types.Action, desiredConditions []elbv2types.RuleCondition, desiredTransforms []elbv2types.RuleTransform) *elbv2sdk.ModifyRuleInput {
	sdkObj := &elbv2sdk.ModifyRuleInput{}
	sdkObj.Actions = desiredActions
	sdkObj.Conditions = desiredConditions

	// ELB ModifyRule API treats empty `actions`/`conditions`/`transforms` list as null, meaning "do not modify the existing property"
	// Since actions and conditions are required, this is fine for actions and conditions
	// But since transforms are optional, we need to set an explicit `resetTransforms` flag when we actually want to delete all existing transforms
	// So we conditionally set `transforms` and `resetTransforms`
	if len(desiredTransforms) > 0 {
		sdkObj.Transforms = desiredTransforms
	} else {
		resetTransforms := true
		sdkObj.ResetTransforms = &resetTransforms
	}

	return sdkObj
}

func buildSDKSetRulePrioritiesInput(matchedResAndSDKLRsBySettings []resAndSDKListenerRulePair, unmatchedSDKLRs []ListenerRuleWithTags) *elbv2sdk.SetRulePrioritiesInput {
	var rulePriorities []elbv2types.RulePriorityPair
	var lastAvailablePriority int32 = 50000
	var sdkLRs []ListenerRuleWithTags

	// Sort the unmatched existing SDK rules based on their priority to be pushed down in same order
	sort.Slice(unmatchedSDKLRs, func(i, j int) bool {
		priorityI, _ := strconv.Atoi(awssdk.ToString(unmatchedSDKLRs[i].ListenerRule.Priority))
		priorityJ, _ := strconv.Atoi(awssdk.ToString(unmatchedSDKLRs[j].ListenerRule.Priority))
		return priorityI < priorityJ
	})
	// Push down all the unmatched existing SDK rules on load balancer so that updated rules can take their place
	for _, sdkLR := range slices.Backward(unmatchedSDKLRs) {
		sdkLR.ListenerRule.Priority = awssdk.String(strconv.Itoa(int(lastAvailablePriority)))
		sdkLRs = append(sdkLRs, sdkLR)
		lastAvailablePriority--
	}
	//Re-Prioritize matched rules by settings
	for _, resAndSDKLR := range matchedResAndSDKLRsBySettings {
		resAndSDKLR.sdkLR.ListenerRule.Priority = awssdk.String(strconv.Itoa(int(resAndSDKLR.resLR.Spec.Priority)))
		sdkLRs = append(sdkLRs, resAndSDKLR.sdkLR)
	}
	for _, sdkLR := range sdkLRs {
		p, _ := strconv.ParseInt(awssdk.ToString(sdkLR.ListenerRule.Priority), 10, 32)
		rulePriorityPair := elbv2types.RulePriorityPair{
			RuleArn:  sdkLR.ListenerRule.RuleArn,
			Priority: awssdk.Int32(int32(p)),
		}
		rulePriorities = append(rulePriorities, rulePriorityPair)
	}
	sdkObj := &elbv2sdk.SetRulePrioritiesInput{
		RulePriorities: rulePriorities,
	}
	return sdkObj
}
func buildResListenerRuleStatus(sdkLR ListenerRuleWithTags) elbv2model.ListenerRuleStatus {
	return elbv2model.ListenerRuleStatus{
		RuleARN: awssdk.ToString(sdkLR.ListenerRule.RuleArn),
	}
}

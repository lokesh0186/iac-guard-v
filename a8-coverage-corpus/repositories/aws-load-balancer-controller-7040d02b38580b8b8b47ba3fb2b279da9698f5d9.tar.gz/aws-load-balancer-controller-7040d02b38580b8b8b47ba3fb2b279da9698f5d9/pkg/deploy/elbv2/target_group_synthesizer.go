package elbv2

import (
	"context"

	awssdk "github.com/aws/aws-sdk-go-v2/aws"
	"github.com/go-logr/logr"
	"github.com/pkg/errors"
	"k8s.io/apimachinery/pkg/util/sets"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/aws/services"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/config"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/deploy/tracking"
	"sigs.k8s.io/aws-load-balancer-controller/v3/pkg/model/core"
	elbv2model "sigs.k8s.io/aws-load-balancer-controller/v3/pkg/model/elbv2"
)

// NewTargetGroupSynthesizer constructs targetGroupSynthesizer
func NewTargetGroupSynthesizer(elbv2Client services.ELBV2, trackingProvider tracking.Provider, taggingManager TaggingManager,
	tgManager TargetGroupManager, logger logr.Logger, featureGates config.FeatureGates, stack core.Stack, findSDKTargetGroups func() TargetGroupsResult) *targetGroupSynthesizer {
	return &targetGroupSynthesizer{
		elbv2Client:         elbv2Client,
		trackingProvider:    trackingProvider,
		taggingManager:      taggingManager,
		tgManager:           tgManager,
		featureGates:        featureGates,
		logger:              logger,
		stack:               stack,
		unmatchedSDKTGs:     nil,
		findSDKTargetGroups: findSDKTargetGroups,
	}
}

// targetGroupSynthesizer is responsible for synthesize TargetGroup resources types for certain stack.
type targetGroupSynthesizer struct {
	elbv2Client      services.ELBV2
	trackingProvider tracking.Provider
	taggingManager   TaggingManager
	tgManager        TargetGroupManager
	featureGates     config.FeatureGates
	logger           logr.Logger

	stack               core.Stack
	unmatchedSDKTGs     []TargetGroupWithTags
	findSDKTargetGroups func() TargetGroupsResult
}

func (s *targetGroupSynthesizer) Synthesize(ctx context.Context) error {
	var resTGs []*elbv2model.TargetGroup
	s.stack.ListResources(&resTGs)
	res := s.findSDKTargetGroups()
	if res.Err != nil {
		return res.Err
	}
	sdkTGs := res.TargetGroups
	matchedResAndSDKTGs, unmatchedResTGs, unmatchedSDKTGs, err := matchResAndSDKTargetGroups(resTGs, sdkTGs,
		s.trackingProvider.ResourceIDTagKey(), s.featureGates)
	if err != nil {
		return err
	}

	// For TargetGroups, we delete unmatched ones during post synthesize given below facts:
	// * unmatched targetGroups might still be use by a listener rule.
	s.unmatchedSDKTGs = unmatchedSDKTGs

	for _, resTG := range unmatchedResTGs {
		tgStatus, err := s.tgManager.Create(ctx, resTG)
		if err != nil {
			return err
		}
		resTG.SetStatus(tgStatus)
	}
	for _, resAndSDKTG := range matchedResAndSDKTGs {
		tgStatus, err := s.tgManager.Update(ctx, resAndSDKTG.resTG, resAndSDKTG.sdkTG)
		if err != nil {
			return err
		}
		resAndSDKTG.resTG.SetStatus(tgStatus)
	}
	return nil
}

func (s *targetGroupSynthesizer) PostSynthesize(ctx context.Context) error {
	for _, sdkTG := range s.unmatchedSDKTGs {
		if err := s.tgManager.Delete(ctx, sdkTG); err != nil {
			return err
		}
	}
	return nil
}

type resAndSDKTargetGroupPair struct {
	resTG *elbv2model.TargetGroup
	sdkTG TargetGroupWithTags
}

func matchResAndSDKTargetGroups(resTGs []*elbv2model.TargetGroup, sdkTGs []TargetGroupWithTags,
	resourceIDTagKey string, featureGates config.FeatureGates) ([]resAndSDKTargetGroupPair, []*elbv2model.TargetGroup, []TargetGroupWithTags, error) {
	var matchedResAndSDKTGs []resAndSDKTargetGroupPair
	var unmatchedResTGs []*elbv2model.TargetGroup
	var unmatchedSDKTGs []TargetGroupWithTags

	resTGsByID := mapResTargetGroupByResourceID(resTGs)
	sdkTGsByID, err := mapSDKTargetGroupByResourceID(sdkTGs, resourceIDTagKey)
	if err != nil {
		return nil, nil, nil, err
	}

	resTGIDs := sets.StringKeySet(resTGsByID)
	sdkTGIDs := sets.StringKeySet(sdkTGsByID)
	for _, resID := range resTGIDs.Intersection(sdkTGIDs).List() {
		resTG := resTGsByID[resID]
		sdkTGs := sdkTGsByID[resID]
		foundMatch := false
		for _, sdkTG := range sdkTGs {
			if isSDKTargetGroupRequiresReplacement(sdkTG, resTG, featureGates) {
				unmatchedSDKTGs = append(unmatchedSDKTGs, sdkTG)
				continue
			}
			matchedResAndSDKTGs = append(matchedResAndSDKTGs, resAndSDKTargetGroupPair{
				resTG: resTG,
				sdkTG: sdkTG,
			})
			foundMatch = true
		}
		if !foundMatch {
			unmatchedResTGs = append(unmatchedResTGs, resTG)
		}
	}
	for _, resID := range resTGIDs.Difference(sdkTGIDs).List() {
		unmatchedResTGs = append(unmatchedResTGs, resTGsByID[resID])
	}
	for _, resID := range sdkTGIDs.Difference(resTGIDs).List() {
		unmatchedSDKTGs = append(unmatchedSDKTGs, sdkTGsByID[resID]...)
	}

	return matchedResAndSDKTGs, unmatchedResTGs, unmatchedSDKTGs, nil
}

func mapResTargetGroupByResourceID(resTGs []*elbv2model.TargetGroup) map[string]*elbv2model.TargetGroup {
	resTGsByID := make(map[string]*elbv2model.TargetGroup, len(resTGs))
	for _, resTG := range resTGs {
		resTGsByID[resTG.ID()] = resTG
	}
	return resTGsByID
}

func mapSDKTargetGroupByResourceID(sdkTGs []TargetGroupWithTags, resourceIDTagKey string) (map[string][]TargetGroupWithTags, error) {
	sdkTGsByID := make(map[string][]TargetGroupWithTags, len(sdkTGs))
	for _, sdkTG := range sdkTGs {
		resourceID, ok := sdkTG.Tags[resourceIDTagKey]
		if !ok {
			return nil, errors.Errorf("unexpected targetGroup with no resourceID: %v", awssdk.ToString(sdkTG.TargetGroup.TargetGroupArn))
		}
		sdkTGsByID[resourceID] = append(sdkTGsByID[resourceID], sdkTG)
	}
	return sdkTGsByID, nil
}

// isSDKTargetGroupRequiresReplacement checks whether a sdk TargetGroup requires replacement to fulfill a TargetGroup resource.
func isSDKTargetGroupRequiresReplacement(sdkTG TargetGroupWithTags, resTG *elbv2model.TargetGroup, featureGates config.FeatureGates) bool {
	if string(resTG.Spec.TargetType) != string(sdkTG.TargetGroup.TargetType) {
		return true
	}

	if string(resTG.Spec.Protocol) != string(sdkTG.TargetGroup.Protocol) {
		return true
	}
	if resTG.Spec.ProtocolVersion != nil {
		if string(*resTG.Spec.ProtocolVersion) != awssdk.ToString(sdkTG.TargetGroup.ProtocolVersion) {
			return true
		}
	}

	// Check if TargetControlPort has changed - requires replacement
	if isSDKTargetGroupTargetControlPortDrifted(resTG.Spec, sdkTG) {
		return true
	}

	return isSDKTargetGroupRequiresReplacementDueToNLBHealthCheck(sdkTG, resTG, featureGates)
}

// most of the healthCheck settings for NLB targetGroups cannot be changed for now.
// Only L4 (NLB) target groups require replacement when health check settings change if NLBHealthCheckAdvancedConfig is enabled.
func isSDKTargetGroupRequiresReplacementDueToNLBHealthCheck(sdkTG TargetGroupWithTags, resTG *elbv2model.TargetGroup, featureGates config.FeatureGates) bool {
	if !isL4TargetGroup(resTG.Spec.Protocol) || resTG.Spec.HealthCheckConfig == nil || featureGates.Enabled(config.NLBHealthCheckAdvancedConfig) {
		return false
	}
	sdkObj := sdkTG.TargetGroup
	hcConfig := *resTG.Spec.HealthCheckConfig
	if &hcConfig.Protocol != nil && string(hcConfig.Protocol) != string(sdkObj.HealthCheckProtocol) {
		return true
	}
	if hcConfig.Matcher != nil && (sdkObj.Matcher == nil || awssdk.ToString(hcConfig.Matcher.GRPCCode) != awssdk.ToString(sdkObj.Matcher.GrpcCode) || awssdk.ToString(hcConfig.Matcher.HTTPCode) != awssdk.ToString(sdkObj.Matcher.HttpCode)) {
		return true
	}
	if hcConfig.IntervalSeconds != nil && awssdk.ToInt32(hcConfig.IntervalSeconds) != awssdk.ToInt32(sdkObj.HealthCheckIntervalSeconds) {
		return true
	}
	if hcConfig.TimeoutSeconds != nil && awssdk.ToInt32(hcConfig.TimeoutSeconds) != awssdk.ToInt32(sdkObj.HealthCheckTimeoutSeconds) {
		return true
	}
	return false
}

func isL4TargetGroup(protocol elbv2model.Protocol) bool {
	switch protocol {
	case elbv2model.ProtocolTCP,
		elbv2model.ProtocolUDP,
		elbv2model.ProtocolTLS,
		elbv2model.ProtocolQUIC,
		elbv2model.ProtocolTCP_QUIC,
		elbv2model.ProtocolTCP_UDP:
		return true
	default:
		return false
	}
}

func isSDKTargetGroupTargetControlPortDrifted(tgSpec elbv2model.TargetGroupSpec, sdkTG TargetGroupWithTags) bool {
	desiredPort := tgSpec.TargetControlPort
	currentPort := sdkTG.TargetGroup.TargetControlPort

	if desiredPort == nil && currentPort == nil {
		return false
	}

	if (desiredPort == nil) != (currentPort == nil) {
		return true
	}

	return awssdk.ToInt32(desiredPort) != awssdk.ToInt32(currentPort)
}

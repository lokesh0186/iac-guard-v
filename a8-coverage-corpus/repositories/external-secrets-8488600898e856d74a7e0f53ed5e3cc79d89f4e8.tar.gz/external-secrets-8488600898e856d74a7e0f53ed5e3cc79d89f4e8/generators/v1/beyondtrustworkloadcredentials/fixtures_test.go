/*
Copyright © The ESO Authors

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package beyondtrustworkloadcredentialsdynamic

// Test fixtures containing JSON spec strings for BeyondtrustWorkloadCredentials dynamic secret generator tests.

const (
	// validDynamicSecretSpec is a valid BeyondtrustWorkloadCredentialsDynamicSecret spec with all required fields.
	validDynamicSecretSpec = `apiVersion: generators.external-secrets.io/v1alpha1
kind: BeyondtrustWorkloadCredentialsDynamicSecret
spec:
  provider:
    folderPath: "test/aws-dynamic"
    auth:
      apikey:
        token:
          name: "beyondtrustworkloadcredentials-token"
          key: "token"
    server:
      apiUrl: "https://example.com"
      siteId: "12345678-1234-4234-8234-123456789012"`

	// validDynamicSecretSpecNoFolder is a spec with a secret at root level (no folder prefix).
	validDynamicSecretSpecNoFolder = `apiVersion: generators.external-secrets.io/v1alpha1
kind: BeyondtrustWorkloadCredentialsDynamicSecret
spec:
  provider:
    folderPath: "mysecret"
    auth:
      apikey:
        token:
          name: "beyondtrustworkloadcredentials-token"
          key: "token"
    server:
      apiUrl: "https://example.com"
      siteId: "12345678-1234-4234-8234-123456789012"`

	// specMissingFolderPath has no folderPath field.
	specMissingFolderPath = `apiVersion: generators.external-secrets.io/v1alpha1
kind: BeyondtrustWorkloadCredentialsDynamicSecret
spec:
  provider:
    auth:
      apikey:
        token:
          name: "beyondtrustworkloadcredentials-token"
          key: "token"
    server:
      apiUrl: "https://example.com"
      siteId: "12345678-1234-4234-8234-123456789012"`

	// specMissingAuth has no auth field.
	specMissingAuth = `apiVersion: generators.external-secrets.io/v1alpha1
kind: BeyondtrustWorkloadCredentialsDynamicSecret
spec:
  provider:
    folderPath: "test/dynamic-secret"
    server:
      apiUrl: "https://example.com"
      siteId: "12345678-1234-4234-8234-123456789012"`

	// specSecretNotFound references a non-existent secret.
	specSecretNotFound = `apiVersion: generators.external-secrets.io/v1alpha1
kind: BeyondtrustWorkloadCredentialsDynamicSecret
spec:
  provider:
    folderPath: "test/dynamic-secret"
    auth:
      apikey:
        token:
          name: "nonexistent-secret"
          key: "token"
    server:
      apiUrl: "https://example.com"
      siteId: "12345678-1234-4234-8234-123456789012"`

	// validDynamicSecretSpecWithFolder is used for error and non-string value tests.
	validDynamicSecretSpecWithFolder = `apiVersion: generators.external-secrets.io/v1alpha1
kind: BeyondtrustWorkloadCredentialsDynamicSecret
spec:
  provider:
    folderPath: "test/dynamic-secret"
    auth:
      apikey:
        token:
          name: "beyondtrustworkloadcredentials-token"
          key: "token"
    server:
      apiUrl: "https://example.com"
      siteId: "12345678-1234-4234-8234-123456789012"`

	// specEmptySecretName has a folderPath ending with "/" resulting in empty secret name.
	specEmptySecretName = `apiVersion: generators.external-secrets.io/v1alpha1
kind: BeyondtrustWorkloadCredentialsDynamicSecret
spec:
  provider:
    folderPath: "test/folder/"
    auth:
      apikey:
        token:
          name: "beyondtrustworkloadcredentials-token"
          key: "token"
    server:
      apiUrl: "https://example.com"
      siteId: "12345678-1234-4234-8234-123456789012"`
)

/*
Copyright © The ESO Authors

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package v1

import (
	"reflect"

	"k8s.io/apimachinery/pkg/runtime/schema"
	"sigs.k8s.io/controller-runtime/pkg/scheme"
)

// Package type metadata.
const (
	Group   = "external-secrets.io"
	Version = "v1"
)

var (
	// SchemeGroupVersion is group version used to register these objects.
	SchemeGroupVersion = schema.GroupVersion{Group: Group, Version: Version}

	// SchemeBuilder is used to add go types to the GroupVersionKind scheme.
	SchemeBuilder = &scheme.Builder{GroupVersion: SchemeGroupVersion}

	// AddToScheme adds the types in this group version to the given scheme.
	AddToScheme = SchemeBuilder.AddToScheme
)

// ExternalSecret type metadata.
var (
	ExtSecretKind             = reflect.TypeFor[ExternalSecret]().Name()
	ExtSecretGroupKind        = schema.GroupKind{Group: Group, Kind: ExtSecretKind}.String()
	ExtSecretKindAPIVersion   = ExtSecretKind + "." + SchemeGroupVersion.String()
	ExtSecretGroupVersionKind = SchemeGroupVersion.WithKind(ExtSecretKind)
)

// ClusterExternalSecret type metadata.
var (
	ClusterExtSecretKind             = reflect.TypeFor[ClusterExternalSecret]().Name()
	ClusterExtSecretGroupKind        = schema.GroupKind{Group: Group, Kind: ClusterExtSecretKind}.String()
	ClusterExtSecretKindAPIVersion   = ClusterExtSecretKind + "." + SchemeGroupVersion.String()
	ClusterExtSecretGroupVersionKind = SchemeGroupVersion.WithKind(ClusterExtSecretKind)
)

// SecretStore type metadata.
var (
	SecretStoreKind             = reflect.TypeFor[SecretStore]().Name()
	SecretStoreGroupKind        = schema.GroupKind{Group: Group, Kind: SecretStoreKind}.String()
	SecretStoreKindAPIVersion   = SecretStoreKind + "." + SchemeGroupVersion.String()
	SecretStoreGroupVersionKind = SchemeGroupVersion.WithKind(SecretStoreKind)
)

// ClusterSecretStore type metadata.
var (
	ClusterSecretStoreKind             = reflect.TypeFor[ClusterSecretStore]().Name()
	ClusterSecretStoreGroupKind        = schema.GroupKind{Group: Group, Kind: ClusterSecretStoreKind}.String()
	ClusterSecretStoreKindAPIVersion   = ClusterSecretStoreKind + "." + SchemeGroupVersion.String()
	ClusterSecretStoreGroupVersionKind = SchemeGroupVersion.WithKind(ClusterSecretStoreKind)
)

func init() {
	SchemeBuilder.Register(&ExternalSecret{}, &ExternalSecretList{})
	SchemeBuilder.Register(&ClusterExternalSecret{}, &ClusterExternalSecretList{})
	SchemeBuilder.Register(&SecretStore{}, &SecretStoreList{})
	SchemeBuilder.Register(&ClusterSecretStore{}, &ClusterSecretStoreList{})
}

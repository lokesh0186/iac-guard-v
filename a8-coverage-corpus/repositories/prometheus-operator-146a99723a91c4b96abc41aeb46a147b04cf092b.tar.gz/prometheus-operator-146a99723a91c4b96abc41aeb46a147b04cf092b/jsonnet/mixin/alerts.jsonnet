(
  import 'mixin.libsonnet'
).prometheusAlerts

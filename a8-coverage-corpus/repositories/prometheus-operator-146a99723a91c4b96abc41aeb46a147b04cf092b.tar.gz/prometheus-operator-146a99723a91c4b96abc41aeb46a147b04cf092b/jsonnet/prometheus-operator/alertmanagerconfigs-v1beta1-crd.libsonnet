// Code generated using 'make generate-crds'. DO NOT EDIT.
{ spec+: { versions+: [
  {
    name: 'v1beta1',
    schema: {
      openAPIV3Schema: {
        description: 'The `AlertmanagerConfig` custom resource definition (CRD) defines how `Alertmanager` objects process Prometheus alerts. It allows to specify alert grouping and routing, notification receivers and inhibition rules.\n\n`Alertmanager` objects select `AlertmanagerConfig` objects using label and namespace selectors.',
        properties: {
          apiVersion: {
            description: 'APIVersion defines the versioned schema of this representation of an object.\nServers should convert recognized schemas to the latest internal value, and\nmay reject unrecognized values.\nMore info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#resources',
            type: 'string',
          },
          kind: {
            description: 'Kind is a string value representing the REST resource this object represents.\nServers may infer this from the endpoint the client submits requests to.\nCannot be updated.\nIn CamelCase.\nMore info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#types-kinds',
            type: 'string',
          },
          metadata: {
            type: 'object',
          },
          spec: {
            description: 'spec defines the specification of AlertmanagerConfigSpec',
            properties: {
              inhibitRules: {
                description: "inhibitRules defines the list of inhibition rules. The rules will only apply to alerts matching\nthe resource's namespace.",
                items: {
                  description: 'InhibitRule defines an inhibition rule that allows to mute alerts when other\nalerts are already firing.\nSee https://prometheus.io/docs/alerting/latest/configuration/#inhibit_rule',
                  properties: {
                    equal: {
                      description: 'equal defines labels that must have an equal value in the source and target alert\nfor the inhibition to take effect. This ensures related alerts are properly grouped.',
                      items: {
                        type: 'string',
                      },
                      type: 'array',
                    },
                    sourceMatch: {
                      description: "sourceMatch defines matchers for which one or more alerts have to exist for the inhibition\nto take effect. The operator enforces that the alert matches the resource's namespace.\nThese are the \"trigger\" alerts that cause other alerts to be inhibited.",
                      items: {
                        description: "Matcher defines how to match on alert's labels.",
                        properties: {
                          matchType: {
                            description: 'matchType defines the match operation available with AlertManager >= v0.22.0.\nTakes precedence over Regex (deprecated) if non-empty.\nValid values: "=" (equality), "!=" (inequality), "=~" (regex match), "!~" (regex non-match).',
                            enum: [
                              '!=',
                              '=',
                              '=~',
                              '!~',
                            ],
                            type: 'string',
                          },
                          name: {
                            description: 'name defines the label to match.\nThis specifies which alert label should be evaluated.',
                            minLength: 1,
                            type: 'string',
                          },
                          value: {
                            description: 'value defines the label value to match.\nThis is the expected value for the specified label.',
                            type: 'string',
                          },
                        },
                        required: [
                          'name',
                        ],
                        type: 'object',
                      },
                      type: 'array',
                    },
                    targetMatch: {
                      description: "targetMatch defines matchers that have to be fulfilled in the alerts to be muted.\nThe operator enforces that the alert matches the resource's namespace.\nWhen these conditions are met, matching alerts will be inhibited (silenced).",
                      items: {
                        description: "Matcher defines how to match on alert's labels.",
                        properties: {
                          matchType: {
                            description: 'matchType defines the match operation available with AlertManager >= v0.22.0.\nTakes precedence over Regex (deprecated) if non-empty.\nValid values: "=" (equality), "!=" (inequality), "=~" (regex match), "!~" (regex non-match).',
                            enum: [
                              '!=',
                              '=',
                              '=~',
                              '!~',
                            ],
                            type: 'string',
                          },
                          name: {
                            description: 'name defines the label to match.\nThis specifies which alert label should be evaluated.',
                            minLength: 1,
                            type: 'string',
                          },
                          value: {
                            description: 'value defines the label value to match.\nThis is the expected value for the specified label.',
                            type: 'string',
                          },
                        },
                        required: [
                          'name',
                        ],
                        type: 'object',
                      },
                      type: 'array',
                    },
                  },
                  type: 'object',
                },
                type: 'array',
              },
              receivers: {
                description: 'receivers defines the list of receivers.',
                items: {
                  description: 'Receiver defines one or more notification integrations.',
                  properties: {
                    discordConfigs: {
                      description: 'discordConfigs defines the list of Discord configurations.',
                      items: {
                        description: 'DiscordConfig configures notifications via Discord.\nSee https://prometheus.io/docs/alerting/latest/configuration/#discord_config',
                        properties: {
                          apiURL: {
                            description: "apiURL defines the secret's key that contains the Discord webhook URL.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                            properties: {
                              key: {
                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                type: 'string',
                              },
                              name: {
                                default: '',
                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                type: 'string',
                              },
                              optional: {
                                description: 'Specify whether the Secret or its key must be defined',
                                type: 'boolean',
                              },
                            },
                            required: [
                              'key',
                            ],
                            type: 'object',
                            'x-kubernetes-map-type': 'atomic',
                          },
                          avatarURL: {
                            description: 'avatarURL defines the avatar url of the message sender.',
                            pattern: '^https?://.+$',
                            type: 'string',
                          },
                          content: {
                            description: "content defines the template of the content's body.",
                            minLength: 1,
                            type: 'string',
                          },
                          httpConfig: {
                            description: 'httpConfig defines HTTP client configuration.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          message: {
                            description: "message defines the template of the message's body.",
                            type: 'string',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          title: {
                            description: "title defines the template of the message's title.",
                            type: 'string',
                          },
                          username: {
                            description: 'username defines the username of the message sender.',
                            minLength: 1,
                            type: 'string',
                          },
                        },
                        required: [
                          'apiURL',
                        ],
                        type: 'object',
                      },
                      type: 'array',
                    },
                    emailConfigs: {
                      description: 'emailConfigs defines the list of Email configurations.',
                      items: {
                        description: 'EmailConfig configures notifications via Email.',
                        properties: {
                          authIdentity: {
                            description: 'authIdentity defines the identity to use for SMTP authentication.\nThis is typically used with PLAIN authentication mechanism.',
                            minLength: 1,
                            type: 'string',
                          },
                          authPassword: {
                            description: "authPassword defines the secret's key that contains the password to use for authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                          authSecret: {
                            description: "authSecret defines the secret's key that contains the CRAM-MD5 secret.\nThis is used for CRAM-MD5 authentication mechanism.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                          authUsername: {
                            description: 'authUsername defines the username to use for SMTP authentication.\nThis is used for SMTP AUTH when the server requires authentication.',
                            minLength: 1,
                            type: 'string',
                          },
                          forceImplicitTLS: {
                            description: 'forceImplicitTLS defines whether to force use of implicit TLS (direct TLS connection) for better security.\ntrue: force use of implicit TLS (direct TLS connection on any port)\nfalse: force disable implicit TLS (use explicit TLS/STARTTLS if required)\nnil (default): auto-detect based on port (465=implicit, other=explicit) for backward compatibility\nIt requires Alertmanager >= v0.31.0.',
                            type: 'boolean',
                          },
                          from: {
                            description: 'from defines the sender address for email notifications.\nThis appears as the "From" field in the email header.',
                            minLength: 1,
                            type: 'string',
                          },
                          headers: {
                            description: 'headers defines additional email header key/value pairs.\nThese override any headers previously set by the notification implementation.',
                            items: {
                              description: 'KeyValue defines a (key, value) tuple.',
                              properties: {
                                key: {
                                  description: 'key defines the key of the tuple.\nThis is the identifier or name part of the key-value pair.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                value: {
                                  description: 'value defines the value of the tuple.\nThis is the data or content associated with the key.',
                                  type: 'string',
                                },
                              },
                              required: [
                                'key',
                                'value',
                              ],
                              type: 'object',
                            },
                            type: 'array',
                          },
                          hello: {
                            description: 'hello defines the hostname to identify to the SMTP server.\nThis is used in the SMTP HELO/EHLO command during the connection handshake.',
                            minLength: 1,
                            type: 'string',
                          },
                          html: {
                            description: 'html defines the HTML body of the email notification.\nThis allows for rich formatting in the email content.',
                            type: 'string',
                          },
                          requireTLS: {
                            description: 'requireTLS defines the SMTP TLS requirement.\nNote that Go does not support unencrypted connections to remote SMTP endpoints.',
                            type: 'boolean',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          smarthost: {
                            description: 'smarthost defines the SMTP host and port through which emails are sent.\nFormat should be "hostname:port", e.g. "smtp.example.com:587".',
                            minLength: 1,
                            type: 'string',
                          },
                          text: {
                            description: "text defines the plain text body of the email notification.\nThis provides a fallback for email clients that don't support HTML.",
                            minLength: 1,
                            type: 'string',
                          },
                          threading: {
                            description: 'threading defines the threading configuration for email receiver.\nIt requires Alertmanager >= v0.30.0.',
                            properties: {
                              threadByDate: {
                                description: 'threadByDate defines what granularity of current date to thread by. Accepted values: Daily, None.\n(None means group by alert group key, no date).',
                                enum: [
                                  'Daily',
                                  'None',
                                ],
                                type: 'string',
                              },
                            },
                            required: [
                              'threadByDate',
                            ],
                            type: 'object',
                          },
                          tlsConfig: {
                            description: 'tlsConfig defines the TLS configuration for SMTP connections.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                            properties: {
                              ca: {
                                description: 'ca defines the Certificate authority used when verifying server certificates.',
                                properties: {
                                  configMap: {
                                    description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key to select.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the ConfigMap or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  secret: {
                                    description: 'secret defines the Secret containing data to use for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              cert: {
                                description: 'cert defines the Client certificate to present when doing client-authentication.',
                                properties: {
                                  configMap: {
                                    description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key to select.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the ConfigMap or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  secret: {
                                    description: 'secret defines the Secret containing data to use for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              insecureSkipVerify: {
                                description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                type: 'boolean',
                              },
                              keySecret: {
                                description: 'keySecret defines the Secret containing the client key file for the targets.',
                                properties: {
                                  key: {
                                    description: 'The key of the secret to select from.  Must be a valid secret key.',
                                    type: 'string',
                                  },
                                  name: {
                                    default: '',
                                    description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                    type: 'string',
                                  },
                                  optional: {
                                    description: 'Specify whether the Secret or its key must be defined',
                                    type: 'boolean',
                                  },
                                },
                                required: [
                                  'key',
                                ],
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              maxVersion: {
                                description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                enum: [
                                  'TLS10',
                                  'TLS11',
                                  'TLS12',
                                  'TLS13',
                                ],
                                type: 'string',
                              },
                              minVersion: {
                                description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                enum: [
                                  'TLS10',
                                  'TLS11',
                                  'TLS12',
                                  'TLS13',
                                ],
                                type: 'string',
                              },
                              serverName: {
                                description: 'serverName is used to verify the hostname for the targets.',
                                type: 'string',
                              },
                            },
                            type: 'object',
                          },
                          to: {
                            description: 'to defines the email address to send notifications to.\nThis is the recipient address for alert notifications.',
                            minLength: 1,
                            type: 'string',
                          },
                        },
                        type: 'object',
                      },
                      type: 'array',
                    },
                    msteamsConfigs: {
                      description: 'msteamsConfigs defines the list of MSTeams configurations.\nIt requires Alertmanager >= 0.26.0.',
                      items: {
                        description: 'MSTeamsConfig configures notifications via Microsoft Teams.\nIt requires Alertmanager >= 0.26.0.',
                        properties: {
                          httpConfig: {
                            description: 'httpConfig defines the HTTP client configuration for Teams webhook requests.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          summary: {
                            description: 'summary defines the message summary template for Teams notifications.\nThis provides a brief overview that appears in Teams notification previews.\nIt requires Alertmanager >= 0.27.0.',
                            type: 'string',
                          },
                          text: {
                            description: 'text defines the message body template for Teams notifications.\nThis contains the detailed content of the Teams message.',
                            type: 'string',
                          },
                          title: {
                            description: 'title defines the message title template for Teams notifications.\nThis appears as the main heading of the Teams message card.',
                            type: 'string',
                          },
                          webhookUrl: {
                            description: 'webhookUrl defines the MSTeams webhook URL for sending notifications.\nThis is the incoming webhook URL configured in your Teams channel.',
                            properties: {
                              key: {
                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                type: 'string',
                              },
                              name: {
                                default: '',
                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                type: 'string',
                              },
                              optional: {
                                description: 'Specify whether the Secret or its key must be defined',
                                type: 'boolean',
                              },
                            },
                            required: [
                              'key',
                            ],
                            type: 'object',
                            'x-kubernetes-map-type': 'atomic',
                          },
                        },
                        required: [
                          'webhookUrl',
                        ],
                        type: 'object',
                      },
                      type: 'array',
                    },
                    msteamsv2Configs: {
                      description: 'msteamsv2Configs defines the list of MSTeamsV2 configurations.\nIt requires Alertmanager >= 0.28.0.',
                      items: {
                        description: 'MSTeamsV2Config configures notifications via Microsoft Teams using the new message format with adaptive cards as required by flows.\nSee https://prometheus.io/docs/alerting/latest/configuration/#msteamsv2_config\nIt requires Alertmanager >= 0.28.0.',
                        properties: {
                          httpConfig: {
                            description: 'httpConfig defines the HTTP client configuration for Teams webhook requests.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          text: {
                            description: 'text defines the message body template for adaptive card notifications.\nThis contains the detailed content displayed in the Teams adaptive card format.',
                            minLength: 1,
                            type: 'string',
                          },
                          title: {
                            description: 'title defines the message title template for adaptive card notifications.\nThis appears as the main heading in the Teams adaptive card.',
                            minLength: 1,
                            type: 'string',
                          },
                          webhookURL: {
                            description: 'webhookURL defines the MSTeams incoming webhook URL for adaptive card notifications.\nThis webhook must support the newer adaptive cards format required by Teams flows.',
                            properties: {
                              key: {
                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                type: 'string',
                              },
                              name: {
                                default: '',
                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                type: 'string',
                              },
                              optional: {
                                description: 'Specify whether the Secret or its key must be defined',
                                type: 'boolean',
                              },
                            },
                            required: [
                              'key',
                            ],
                            type: 'object',
                            'x-kubernetes-map-type': 'atomic',
                          },
                        },
                        type: 'object',
                      },
                      type: 'array',
                    },
                    name: {
                      description: 'name defines the name of the receiver. Must be unique across all items from the list.',
                      minLength: 1,
                      type: 'string',
                    },
                    opsgenieConfigs: {
                      description: 'opsgenieConfigs defines the list of OpsGenie configurations.',
                      items: {
                        description: 'OpsGenieConfig configures notifications via OpsGenie.\nSee https://prometheus.io/docs/alerting/latest/configuration/#opsgenie_config',
                        properties: {
                          actions: {
                            description: 'actions defines a comma separated list of actions that will be available for the alert.\nThese appear as action buttons in the OpsGenie interface.',
                            minLength: 1,
                            type: 'string',
                          },
                          apiKey: {
                            description: "apiKey defines the secret's key that contains the OpsGenie API key.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                          apiURL: {
                            description: 'apiURL defines the URL to send OpsGenie API requests to.\nWhen not specified, defaults to the standard OpsGenie API endpoint.',
                            pattern: '^https?://.+$',
                            type: 'string',
                          },
                          description: {
                            description: 'description defines the detailed description of the incident.\nThis provides additional context beyond the message field.',
                            minLength: 1,
                            type: 'string',
                          },
                          details: {
                            description: 'details defines a set of arbitrary key/value pairs that provide further detail about the incident.\nThese appear as additional fields in the OpsGenie alert.',
                            items: {
                              description: 'KeyValue defines a (key, value) tuple.',
                              properties: {
                                key: {
                                  description: 'key defines the key of the tuple.\nThis is the identifier or name part of the key-value pair.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                value: {
                                  description: 'value defines the value of the tuple.\nThis is the data or content associated with the key.',
                                  type: 'string',
                                },
                              },
                              required: [
                                'key',
                                'value',
                              ],
                              type: 'object',
                            },
                            type: 'array',
                          },
                          entity: {
                            description: 'entity defines an optional field that can be used to specify which domain alert is related to.\nThis helps group related alerts together in OpsGenie.',
                            minLength: 1,
                            type: 'string',
                          },
                          httpConfig: {
                            description: 'httpConfig defines the HTTP client configuration for OpsGenie API requests.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          message: {
                            description: 'message defines the alert text limited to 130 characters.\nThis appears as the main alert title in OpsGenie.',
                            minLength: 1,
                            type: 'string',
                          },
                          note: {
                            description: 'note defines an additional alert note.\nThis provides supplementary information about the alert.',
                            minLength: 1,
                            type: 'string',
                          },
                          priority: {
                            description: 'priority defines the priority level of alert.\nPossible values are P1, P2, P3, P4, and P5, where P1 is highest priority.',
                            minLength: 1,
                            type: 'string',
                          },
                          responders: {
                            description: 'responders defines the list of responders responsible for notifications.\nThese determine who gets notified when the alert is created.',
                            items: {
                              description: 'OpsGenieConfigResponder defines a responder to an incident.\nOne of `id`, `name` or `username` has to be defined.',
                              properties: {
                                id: {
                                  description: "id defines the unique identifier of the responder.\nThis corresponds to the responder's ID within OpsGenie.",
                                  minLength: 1,
                                  type: 'string',
                                },
                                name: {
                                  description: 'name defines the display name of the responder.\nThis is used when the responder is identified by name rather than ID.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                type: {
                                  description: 'type defines the type of responder.\nValid values include "user", "team", "schedule", and "escalation".\nThis determines how OpsGenie interprets the other identifier fields.',
                                  enum: [
                                    'team',
                                    'teams',
                                    'user',
                                    'escalation',
                                    'schedule',
                                  ],
                                  minLength: 1,
                                  type: 'string',
                                },
                                username: {
                                  description: 'username defines the username of the responder.\nThis is typically used for user-type responders when identifying by username.',
                                  minLength: 1,
                                  type: 'string',
                                },
                              },
                              required: [
                                'type',
                              ],
                              type: 'object',
                            },
                            type: 'array',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          source: {
                            description: 'source defines the backlink to the sender of the notification.\nThis helps identify where the alert originated from.',
                            minLength: 1,
                            type: 'string',
                          },
                          tags: {
                            description: 'tags defines a comma separated list of tags attached to the notifications.\nThese help categorize and filter alerts within OpsGenie.',
                            minLength: 1,
                            type: 'string',
                          },
                        },
                        type: 'object',
                      },
                      type: 'array',
                    },
                    pagerdutyConfigs: {
                      description: 'pagerdutyConfigs defines the List of PagerDuty configurations.',
                      items: {
                        description: 'PagerDutyConfig configures notifications via PagerDuty.\nSee https://prometheus.io/docs/alerting/latest/configuration/#pagerduty_config',
                        properties: {
                          class: {
                            description: 'class defines the class/type of the event.',
                            minLength: 1,
                            type: 'string',
                          },
                          client: {
                            description: 'client defines the client identification.',
                            minLength: 1,
                            type: 'string',
                          },
                          clientURL: {
                            description: 'clientURL defines the backlink to the sender of notification.',
                            type: 'string',
                          },
                          component: {
                            description: 'component defines the part or component of the affected system that is broken.',
                            minLength: 1,
                            type: 'string',
                          },
                          description: {
                            description: 'description of the incident.',
                            minLength: 1,
                            type: 'string',
                          },
                          details: {
                            description: 'details defines the arbitrary key/value pairs that provide further detail about the incident.',
                            items: {
                              description: 'KeyValue defines a (key, value) tuple.',
                              properties: {
                                key: {
                                  description: 'key defines the key of the tuple.\nThis is the identifier or name part of the key-value pair.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                value: {
                                  description: 'value defines the value of the tuple.\nThis is the data or content associated with the key.',
                                  type: 'string',
                                },
                              },
                              required: [
                                'key',
                                'value',
                              ],
                              type: 'object',
                            },
                            type: 'array',
                            'x-kubernetes-list-type': 'atomic',
                          },
                          group: {
                            description: 'group defines a cluster or grouping of sources.',
                            minLength: 1,
                            type: 'string',
                          },
                          httpConfig: {
                            description: 'httpConfig defines the HTTP client configuration.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          pagerDutyImageConfigs: {
                            description: 'pagerDutyImageConfigs defines a list of image details to attach that provide further detail about an incident.',
                            items: {
                              description: 'PagerDutyImageConfig attaches images to an incident',
                              properties: {
                                alt: {
                                  description: 'alt is the optional alternative text for the image.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                href: {
                                  description: 'href defines the optional URL; makes the image a clickable link.',
                                  type: 'string',
                                },
                                src: {
                                  description: 'src of the image being attached to the incident',
                                  minLength: 1,
                                  type: 'string',
                                },
                              },
                              type: 'object',
                            },
                            type: 'array',
                            'x-kubernetes-list-type': 'atomic',
                          },
                          pagerDutyLinkConfigs: {
                            description: 'pagerDutyLinkConfigs defines a list of link details to attach that provide further detail about an incident.',
                            items: {
                              description: 'PagerDutyLinkConfig attaches text links to an incident',
                              properties: {
                                alt: {
                                  description: "alt defines the text that describes the purpose of the link, and can be used as the link's text.",
                                  minLength: 1,
                                  type: 'string',
                                },
                                href: {
                                  description: 'href defines the URL of the link to be attached',
                                  type: 'string',
                                },
                              },
                              type: 'object',
                            },
                            type: 'array',
                            'x-kubernetes-list-type': 'atomic',
                          },
                          routingKey: {
                            description: "routingKey defines the secret's key that contains the PagerDuty integration key (when using\nEvents API v2). Either this field or `serviceKey` needs to be defined.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          serviceKey: {
                            description: "serviceKey defines the secret's key that contains the PagerDuty service key (when using\nintegration type \"Prometheus\"). Either this field or `routingKey` needs to\nbe defined.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                          severity: {
                            description: 'severity of the incident.',
                            minLength: 1,
                            type: 'string',
                          },
                          source: {
                            description: 'source defines the unique location of the affected system.',
                            minLength: 1,
                            type: 'string',
                          },
                          timeout: {
                            description: 'timeout is the maximum time allowed to invoke the pagerduty\nIt requires Alertmanager >= v0.30.0.',
                            pattern: '^(0|(([0-9]+)y)?(([0-9]+)w)?(([0-9]+)d)?(([0-9]+)h)?(([0-9]+)m)?(([0-9]+)s)?(([0-9]+)ms)?)$',
                            type: 'string',
                          },
                          url: {
                            description: 'url defines the URL to send requests to.',
                            pattern: '^https?://.+$',
                            type: 'string',
                          },
                        },
                        type: 'object',
                      },
                      type: 'array',
                    },
                    pushoverConfigs: {
                      description: 'pushoverConfigs defines the list of Pushover configurations.',
                      items: {
                        description: 'PushoverConfig configures notifications via Pushover.\nSee https://prometheus.io/docs/alerting/latest/configuration/#pushover_config',
                        properties: {
                          device: {
                            description: "device defines the name of a specific device to send the notification to.\nIf not specified, the notification is sent to all user's devices.",
                            minLength: 1,
                            type: 'string',
                          },
                          expire: {
                            description: 'expire defines how long your notification will continue to be retried for,\nunless the user acknowledges the notification. Only applies to priority 2 notifications.',
                            pattern: '^(([0-9]+)y)?(([0-9]+)w)?(([0-9]+)d)?(([0-9]+)h)?(([0-9]+)m)?(([0-9]+)s)?(([0-9]+)ms)?$',
                            type: 'string',
                          },
                          html: {
                            description: 'html defines whether notification message is HTML or plain text.\nWhen true, the message can include HTML formatting tags.\nhtml and monospace formatting are mutually exclusive.',
                            type: 'boolean',
                          },
                          httpConfig: {
                            description: 'httpConfig defines the HTTP client configuration for Pushover API requests.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          message: {
                            description: 'message defines the notification message content.\nThis is the main body text of the Pushover notification.',
                            minLength: 1,
                            type: 'string',
                          },
                          monospace: {
                            description: 'monospace optional HTML/monospace formatting for the message, see https://pushover.net/api#html\nhtml and monospace formatting are mutually exclusive.',
                            type: 'boolean',
                          },
                          priority: {
                            description: 'priority defines the notification priority level.\nSee https://pushover.net/api#priority for valid values and behavior.',
                            minLength: 1,
                            type: 'string',
                          },
                          retry: {
                            description: 'retry defines how often the Pushover servers will send the same notification to the user.\nMust be at least 30 seconds. Only applies to priority 2 notifications.',
                            pattern: '^(([0-9]+)y)?(([0-9]+)w)?(([0-9]+)d)?(([0-9]+)h)?(([0-9]+)m)?(([0-9]+)s)?(([0-9]+)ms)?$',
                            type: 'string',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          sound: {
                            description: "sound defines the name of one of the sounds supported by device clients.\nThis overrides the user's default sound choice for this notification.",
                            minLength: 1,
                            type: 'string',
                          },
                          title: {
                            description: 'title defines the notification title displayed in the Pushover message.\nThis appears as the bold header text in the notification.',
                            minLength: 1,
                            type: 'string',
                          },
                          token: {
                            description: "token defines the secret's key that contains the registered application's API token.\nSee https://pushover.net/apps for application registration.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.\nEither `token` or `tokenFile` is required.",
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                          tokenFile: {
                            description: "tokenFile defines the token file that contains the registered application's API token.\nSee https://pushover.net/apps for application registration.\nEither `token` or `tokenFile` is required.\nIt requires Alertmanager >= v0.26.0.",
                            type: 'string',
                          },
                          ttl: {
                            description: 'ttl defines the time to live for the alert notification.\nThis determines how long the notification remains active before expiring.',
                            pattern: '^(0|(([0-9]+)y)?(([0-9]+)w)?(([0-9]+)d)?(([0-9]+)h)?(([0-9]+)m)?(([0-9]+)s)?(([0-9]+)ms)?)$',
                            type: 'string',
                          },
                          url: {
                            description: 'url defines a supplementary URL shown alongside the message.\nThis creates a clickable link within the Pushover notification.',
                            type: 'string',
                          },
                          urlTitle: {
                            description: 'urlTitle defines a title for the supplementary URL.\nIf not specified, the raw URL is shown instead.',
                            minLength: 1,
                            type: 'string',
                          },
                          userKey: {
                            description: "userKey defines the secret's key that contains the recipient user's user key.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.\nEither `userKey` or `userKeyFile` is required.",
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                          userKeyFile: {
                            description: "userKeyFile defines the user key file that contains the recipient user's user key.\nEither `userKey` or `userKeyFile` is required.\nIt requires Alertmanager >= v0.26.0.",
                            type: 'string',
                          },
                        },
                        type: 'object',
                      },
                      type: 'array',
                    },
                    rocketchatConfigs: {
                      description: 'rocketchatConfigs defines the list of RocketChat configurations.\nIt requires Alertmanager >= 0.28.0.',
                      items: {
                        description: 'RocketChatConfig configures notifications via RocketChat.\nIt requires Alertmanager >= 0.28.0.',
                        properties: {
                          actions: {
                            description: 'actions defines interactive actions to include in the message.\nThese appear as buttons that users can click to trigger responses.',
                            items: {
                              description: 'RocketChatActionConfig defines actions for RocketChat messages.',
                              properties: {
                                msg: {
                                  description: 'msg defines the message to send when the button is clicked.\nThis allows the button to post a predefined message to the channel.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                text: {
                                  description: 'text defines the button text displayed to users.\nThis is the label that appears on the interactive button.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                url: {
                                  description: 'url defines the URL the button links to when clicked.\nThis creates a clickable button that opens the specified URL.',
                                  type: 'string',
                                },
                              },
                              type: 'object',
                            },
                            minItems: 1,
                            type: 'array',
                          },
                          apiURL: {
                            description: 'apiURL defines the API URL for RocketChat.\nDefaults to https://open.rocket.chat/ if not specified.',
                            pattern: '^https?://.+$',
                            type: 'string',
                          },
                          channel: {
                            description: 'channel defines the channel to send alerts to.\nThis can be a channel name (e.g., "#alerts") or a direct message recipient.',
                            minLength: 1,
                            type: 'string',
                          },
                          color: {
                            description: 'color defines the message color displayed in RocketChat.\nThis appears as a colored bar alongside the message.',
                            minLength: 1,
                            type: 'string',
                          },
                          emoji: {
                            description: 'emoji defines the emoji to be displayed as an avatar.\nIf provided, this emoji will be used instead of the default avatar or iconURL.',
                            minLength: 1,
                            type: 'string',
                          },
                          fields: {
                            description: 'fields defines additional fields for the message attachment.\nThese appear as structured key-value pairs within the message.',
                            items: {
                              description: 'RocketChatFieldConfig defines a field for RocketChat messages.',
                              properties: {
                                short: {
                                  description: 'short defines whether this field should be a short field.\nWhen true, the field may be displayed inline with other short fields to save space.',
                                  type: 'boolean',
                                },
                                title: {
                                  description: 'title defines the title of this field.\nThis appears as bold text labeling the field content.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                value: {
                                  description: 'value defines the value of this field, displayed underneath the title.\nThis contains the actual data or content for the field.',
                                  minLength: 1,
                                  type: 'string',
                                },
                              },
                              type: 'object',
                            },
                            minItems: 1,
                            type: 'array',
                          },
                          httpConfig: {
                            description: 'httpConfig defines the HTTP client configuration for RocketChat API requests.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          iconURL: {
                            description: "iconURL defines the icon URL for the message avatar.\nThis displays a custom image as the message sender's avatar.",
                            type: 'string',
                          },
                          imageURL: {
                            description: 'imageURL defines the image URL to display within the message.\nThis embeds an image directly in the message attachment.',
                            type: 'string',
                          },
                          linkNames: {
                            description: 'linkNames defines whether to enable automatic linking of usernames and channels.\nWhen true, @username and #channel references become clickable links.',
                            type: 'boolean',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          shortFields: {
                            description: 'shortFields defines whether to use short fields in the message layout.\nWhen true, fields may be displayed side by side to save space.',
                            type: 'boolean',
                          },
                          text: {
                            description: 'text defines the message text to send.\nThis is optional because attachments can be used instead of or alongside text.',
                            minLength: 1,
                            type: 'string',
                          },
                          thumbURL: {
                            description: 'thumbURL defines the thumbnail URL for the message.\nThis displays a small thumbnail image alongside the message content.',
                            type: 'string',
                          },
                          title: {
                            description: 'title defines the message title displayed prominently in the message.\nThis appears as bold text at the top of the message attachment.',
                            minLength: 1,
                            type: 'string',
                          },
                          titleLink: {
                            description: 'titleLink defines the URL that the title will link to when clicked.\nThis makes the message title clickable in the RocketChat interface.',
                            minLength: 1,
                            type: 'string',
                          },
                          token: {
                            description: 'token defines the sender token for RocketChat authentication.\nThis is the personal access token or bot token used to authenticate API requests.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.',
                            properties: {
                              key: {
                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                type: 'string',
                              },
                              name: {
                                default: '',
                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                type: 'string',
                              },
                              optional: {
                                description: 'Specify whether the Secret or its key must be defined',
                                type: 'boolean',
                              },
                            },
                            required: [
                              'key',
                            ],
                            type: 'object',
                            'x-kubernetes-map-type': 'atomic',
                          },
                          tokenID: {
                            description: 'tokenID defines the sender token ID for RocketChat authentication.\nThis is the user ID associated with the token used for API requests.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.',
                            properties: {
                              key: {
                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                type: 'string',
                              },
                              name: {
                                default: '',
                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                type: 'string',
                              },
                              optional: {
                                description: 'Specify whether the Secret or its key must be defined',
                                type: 'boolean',
                              },
                            },
                            required: [
                              'key',
                            ],
                            type: 'object',
                            'x-kubernetes-map-type': 'atomic',
                          },
                        },
                        required: [
                          'token',
                          'tokenID',
                        ],
                        type: 'object',
                      },
                      type: 'array',
                    },
                    slackConfigs: {
                      description: 'slackConfigs defines the list of Slack configurations.',
                      items: {
                        description: 'SlackConfig configures notifications via Slack.\nSee https://prometheus.io/docs/alerting/latest/configuration/#slack_config',
                        properties: {
                          actions: {
                            description: 'actions defines a list of Slack actions that are sent with each notification.',
                            items: {
                              description: 'SlackAction configures a single Slack action that is sent with each\nnotification.\nSee https://api.slack.com/docs/message-attachments#action_fields and\nhttps://api.slack.com/docs/message-buttons for more information.',
                              properties: {
                                confirm: {
                                  description: 'confirm defines an optional confirmation dialog that appears before the action is executed.\nWhen set, users must confirm their intent before the action proceeds.',
                                  properties: {
                                    dismissText: {
                                      description: 'dismissText defines the label for the cancel button in the dialog.\nWhen not specified, defaults to "Cancel". This button cancels the action.',
                                      minLength: 1,
                                      type: 'string',
                                    },
                                    okText: {
                                      description: 'okText defines the label for the confirmation button in the dialog.\nWhen not specified, defaults to "Okay". This button proceeds with the action.',
                                      minLength: 1,
                                      type: 'string',
                                    },
                                    text: {
                                      description: 'text defines the main message displayed in the confirmation dialog.\nThis should be a clear question or statement asking the user to confirm their action.',
                                      minLength: 1,
                                      type: 'string',
                                    },
                                    title: {
                                      description: 'title defines the title text displayed at the top of the confirmation dialog.\nWhen not specified, a default title will be used.',
                                      minLength: 1,
                                      type: 'string',
                                    },
                                  },
                                  required: [
                                    'text',
                                  ],
                                  type: 'object',
                                },
                                name: {
                                  description: 'name defines a unique identifier for the action within the message.\nThis value is sent back to your application when the action is triggered.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                style: {
                                  description: 'style defines the visual appearance of the action element.\nValid values include "default", "primary" (green), and "danger" (red).',
                                  minLength: 1,
                                  type: 'string',
                                },
                                text: {
                                  description: 'text defines the user-visible label displayed on the action element.\nFor buttons, this is the button text. For select menus, this is the placeholder text.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                type: {
                                  description: 'type defines the type of interactive component.\nCommon values include "button" for clickable buttons and "select" for dropdown menus.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                url: {
                                  description: 'url defines the URL to open when the action is triggered.\nOnly applicable for button-type actions. When set, clicking the button opens this URL.',
                                  type: 'string',
                                },
                                value: {
                                  description: 'value defines the payload sent when the action is triggered.\nThis data is included in the callback sent to your application.',
                                  minLength: 1,
                                  type: 'string',
                                },
                              },
                              required: [
                                'text',
                                'type',
                              ],
                              type: 'object',
                            },
                            minItems: 1,
                            type: 'array',
                            'x-kubernetes-list-type': 'atomic',
                          },
                          apiURL: {
                            description: "apiURL defines the secret's key that contains the Slack webhook URL.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                          callbackId: {
                            description: 'callbackId defines an identifier for the message used in interactive components.',
                            minLength: 1,
                            type: 'string',
                          },
                          channel: {
                            description: 'channel defines the channel or user to send notifications to.',
                            minLength: 1,
                            type: 'string',
                          },
                          color: {
                            description: 'color defines the color of the left border of the Slack message attachment.\nCan be a hex color code (e.g., "#ff0000") or a predefined color name.',
                            minLength: 1,
                            type: 'string',
                          },
                          fallback: {
                            description: "fallback defines a plain-text summary of the attachment for clients that don't support attachments.",
                            minLength: 1,
                            type: 'string',
                          },
                          fields: {
                            description: 'fields defines a list of Slack fields that are sent with each notification.',
                            items: {
                              description: 'SlackField configures a single Slack field that is sent with each notification.\nEach field must contain a title, value, and optionally, a boolean value to indicate if the field\nis short enough to be displayed next to other fields designated as short.\nSee https://api.slack.com/docs/message-attachments#fields for more information.',
                              properties: {
                                short: {
                                  description: 'short determines whether this field can be displayed alongside other short fields.\nWhen true, Slack may display this field side by side with other short fields.\nWhen false or not specified, the field takes the full width of the message.',
                                  type: 'boolean',
                                },
                                title: {
                                  description: 'title defines the label or header text displayed for this field.\nThis appears as bold text above the field value in the Slack message.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                value: {
                                  description: 'value defines the content or data displayed for this field.\nThis appears below the title and can contain plain text or Slack markdown.',
                                  minLength: 1,
                                  type: 'string',
                                },
                              },
                              required: [
                                'title',
                                'value',
                              ],
                              type: 'object',
                            },
                            minItems: 1,
                            type: 'array',
                            'x-kubernetes-list-type': 'atomic',
                          },
                          footer: {
                            description: 'footer defines small text displayed at the bottom of the message attachment.',
                            minLength: 1,
                            type: 'string',
                          },
                          httpConfig: {
                            description: 'httpConfig defines the HTTP client configuration.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          iconEmoji: {
                            description: "iconEmoji defines the emoji to use as the bot's avatar (e.g., \":ghost:\").",
                            minLength: 1,
                            type: 'string',
                          },
                          iconURL: {
                            description: "iconURL defines the URL to an image to use as the bot's avatar.",
                            type: 'string',
                          },
                          imageURL: {
                            description: 'imageURL defines the URL to an image file that will be displayed inside the message attachment.',
                            type: 'string',
                          },
                          linkNames: {
                            description: 'linkNames enables automatic linking of channel names and usernames in the message.\nWhen true, @channel and @username will be converted to clickable links.',
                            type: 'boolean',
                          },
                          messageText: {
                            description: "messageText defines text content of the Slack message.\nIf set, this is sent as the top-level 'text' field in the Slack payload.\nIt requires Alertmanager >= v0.31.0.",
                            minLength: 1,
                            type: 'string',
                          },
                          mrkdwnIn: {
                            description: 'mrkdwnIn defines which fields should be parsed as Slack markdown.\nValid values include "pretext", "text", and "fields".',
                            items: {
                              minLength: 1,
                              type: 'string',
                            },
                            minItems: 1,
                            type: 'array',
                            'x-kubernetes-list-type': 'atomic',
                          },
                          pretext: {
                            description: 'pretext defines optional text that appears above the message attachment block.',
                            minLength: 1,
                            type: 'string',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          shortFields: {
                            description: 'shortFields determines whether fields are displayed in a compact format.\nWhen true, fields are shown side by side when possible.',
                            type: 'boolean',
                          },
                          text: {
                            description: 'text defines the main text content of the Slack message attachment.',
                            minLength: 1,
                            type: 'string',
                          },
                          thumbURL: {
                            description: 'thumbURL defines the URL to an image file that will be displayed as a thumbnail\non the right side of the message attachment.',
                            type: 'string',
                          },
                          timeout: {
                            description: 'timeout defines the maximum time to wait for a webhook request to complete,\nbefore failing the request and allowing it to be retried.\nIt requires Alertmanager >= v0.30.0.',
                            pattern: '^(0|(([0-9]+)y)?(([0-9]+)w)?(([0-9]+)d)?(([0-9]+)h)?(([0-9]+)m)?(([0-9]+)s)?(([0-9]+)ms)?)$',
                            type: 'string',
                          },
                          title: {
                            description: 'title defines the title text displayed in the Slack message attachment.',
                            minLength: 1,
                            type: 'string',
                          },
                          titleLink: {
                            description: 'titleLink defines the URL that the title will link to when clicked.',
                            type: 'string',
                          },
                          updateMessage: {
                            description: 'updateMessage enables updating existing Slack messages instead of creating new ones\nwhen alert state changes. Please note that Webhook URLs do not support updates.\nIt requires Alertmanager >= v0.32.0.',
                            type: 'boolean',
                          },
                          username: {
                            description: 'username defines the slack bot user name.',
                            minLength: 1,
                            type: 'string',
                          },
                        },
                        type: 'object',
                      },
                      type: 'array',
                    },
                    snsConfigs: {
                      description: 'snsConfigs defines the list of SNS configurations',
                      items: {
                        description: 'SNSConfig configures notifications via AWS SNS.\nSee https://prometheus.io/docs/alerting/latest/configuration/#sns_configs',
                        properties: {
                          apiURL: {
                            description: 'apiURL defines the SNS API URL, e.g. https://sns.us-east-2.amazonaws.com.\nIf not specified, the SNS API URL from the SNS SDK will be used.',
                            type: 'string',
                          },
                          attributes: {
                            additionalProperties: {
                              type: 'string',
                            },
                            description: 'attributes defines SNS message attributes as key-value pairs.\nThese provide additional metadata that can be used for message filtering and routing.',
                            type: 'object',
                          },
                          httpConfig: {
                            description: 'httpConfig defines the HTTP client configuration for SNS API requests.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          message: {
                            description: 'message defines the message content of the SNS notification.\nThis is the actual notification text that will be sent to subscribers.',
                            minLength: 1,
                            type: 'string',
                          },
                          phoneNumber: {
                            description: "phoneNumber defines the phone number if message is delivered via SMS in E.164 format.\nIf you don't specify this value, you must specify a value for the TopicARN or TargetARN.",
                            minLength: 1,
                            type: 'string',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          sigv4: {
                            description: "sigv4 configures AWS's Signature Verification 4 signing process to sign requests.\nThis includes AWS credentials and region configuration for authentication.",
                            properties: {
                              accessKey: {
                                description: 'accessKey defines the AWS API key. If not specified, the environment variable\n`AWS_ACCESS_KEY_ID` is used.',
                                properties: {
                                  key: {
                                    description: 'The key of the secret to select from.  Must be a valid secret key.',
                                    type: 'string',
                                  },
                                  name: {
                                    default: '',
                                    description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                    type: 'string',
                                  },
                                  optional: {
                                    description: 'Specify whether the Secret or its key must be defined',
                                    type: 'boolean',
                                  },
                                },
                                required: [
                                  'key',
                                ],
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              externalId: {
                                description: 'externalId defines the external ID used when assuming an AWS role. Can only be used with roleArn.\nIt requires Prometheus >= v3.11.0 or Alertmanager >= v0.33.0. Currently not supported by Thanos.',
                                minLength: 1,
                                type: 'string',
                              },
                              profile: {
                                description: 'profile defines the named AWS profile used to authenticate.',
                                type: 'string',
                              },
                              region: {
                                description: 'region defines the AWS region. If blank, the region from the default credentials chain used.',
                                type: 'string',
                              },
                              roleArn: {
                                description: 'roleArn defines the named AWS profile used to authenticate.',
                                type: 'string',
                              },
                              secretKey: {
                                description: 'secretKey defines the AWS API secret. If not specified, the environment\nvariable `AWS_SECRET_ACCESS_KEY` is used.',
                                properties: {
                                  key: {
                                    description: 'The key of the secret to select from.  Must be a valid secret key.',
                                    type: 'string',
                                  },
                                  name: {
                                    default: '',
                                    description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                    type: 'string',
                                  },
                                  optional: {
                                    description: 'Specify whether the Secret or its key must be defined',
                                    type: 'boolean',
                                  },
                                },
                                required: [
                                  'key',
                                ],
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              useFIPSSTSEndpoint: {
                                description: 'useFIPSSTSEndpoint defines the FIPS mode for the AWS STS endpoint.\nIt requires Prometheus >= v2.54.0.',
                                type: 'boolean',
                              },
                            },
                            type: 'object',
                            'x-kubernetes-validations': [
                              {
                                message: 'externalId can only be used when roleArn is specified',
                                rule: '!has(self.externalId) || has(self.roleArn)',
                              },
                            ],
                          },
                          subject: {
                            description: 'subject defines the subject line when the message is delivered to email endpoints.\nThis field is only used when sending to email subscribers of an SNS topic.',
                            minLength: 1,
                            type: 'string',
                          },
                          targetARN: {
                            description: "targetARN defines the mobile platform endpoint ARN if message is delivered via mobile notifications.\nIf you don't specify this value, you must specify a value for the TopicARN or PhoneNumber.",
                            minLength: 1,
                            type: 'string',
                          },
                          topicARN: {
                            description: "topicARN defines the SNS topic ARN, e.g. arn:aws:sns:us-east-2:698519295917:My-Topic.\nIf you don't specify this value, you must specify a value for the PhoneNumber or TargetARN.",
                            minLength: 1,
                            type: 'string',
                          },
                          useAWSHTTPClient: {
                            description: "useAWSHTTPClient forces the AWS SDK's BuildableClient instead of\nalertmanager's tracing-wrapped HTTP client. Auto-enabled when AWS_CA_BUNDLE\nis set; set explicitly when configuring ca_bundle via shared AWS config.\n\nIt requires Alertmanager >= 0.33.0.",
                            type: 'boolean',
                          },
                        },
                        type: 'object',
                      },
                      type: 'array',
                    },
                    telegramConfigs: {
                      description: 'telegramConfigs defines the list of Telegram configurations.',
                      items: {
                        description: 'TelegramConfig configures notifications via Telegram.\nSee https://prometheus.io/docs/alerting/latest/configuration/#telegram_config',
                        properties: {
                          apiURL: {
                            description: 'apiURL defines the Telegram API URL, e.g. https://api.telegram.org.\nIf not specified, the default Telegram API URL will be used.',
                            pattern: '^https?://.+$',
                            type: 'string',
                          },
                          botToken: {
                            description: 'botToken defines the Telegram bot token. It is mutually exclusive with `botTokenFile`.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.\nEither `botToken` or `botTokenFile` is required.',
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                          botTokenFile: {
                            description: 'botTokenFile defines the file to read the Telegram bot token from.\nIt is mutually exclusive with `botToken`.\nEither `botToken` or `botTokenFile` is required.\nIt requires Alertmanager >= v0.26.0.',
                            type: 'string',
                          },
                          chatID: {
                            description: 'chatID defines the Telegram chat ID where messages will be sent.\nThis can be a user ID, group ID, or channel ID (with @ prefix for public channels).',
                            format: 'int64',
                            type: 'integer',
                          },
                          disableNotifications: {
                            description: 'disableNotifications controls whether Telegram notifications are sent silently.\nWhen true, users will receive the message without notification sounds.',
                            type: 'boolean',
                          },
                          httpConfig: {
                            description: 'httpConfig defines the HTTP client configuration for Telegram API requests.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          message: {
                            description: 'message defines the message template for the Telegram notification.\nThis is the content that will be sent to the specified chat.',
                            type: 'string',
                          },
                          messageThreadID: {
                            description: 'messageThreadID defines the Telegram Group Topic ID for threaded messages.\nThis allows sending messages to specific topics within Telegram groups.\nIt requires Alertmanager >= 0.26.0.',
                            format: 'int64',
                            type: 'integer',
                          },
                          parseMode: {
                            description: 'parseMode defines the parse mode for telegram message formatting.\nValid values are "MarkdownV2", "Markdown", and "HTML".\nThis determines how text formatting is interpreted in the message.',
                            enum: [
                              'MarkdownV2',
                              'Markdown',
                              'HTML',
                            ],
                            type: 'string',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                        },
                        required: [
                          'chatID',
                        ],
                        type: 'object',
                      },
                      type: 'array',
                    },
                    victoropsConfigs: {
                      description: 'victoropsConfigs defines the list of VictorOps configurations.',
                      items: {
                        description: 'VictorOpsConfig configures notifications via VictorOps.\nSee https://prometheus.io/docs/alerting/latest/configuration/#victorops_config',
                        properties: {
                          apiKey: {
                            description: "apiKey defines the secret's key that contains the API key to use when talking to the VictorOps API.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                          apiUrl: {
                            description: 'apiUrl defines the VictorOps API URL.\nWhen not specified, defaults to the standard VictorOps API endpoint.',
                            pattern: '^https?://.+$',
                            type: 'string',
                          },
                          customFields: {
                            description: 'customFields defines additional custom fields for notification.\nThese provide extra metadata that will be included with the VictorOps incident.',
                            items: {
                              description: 'KeyValue defines a (key, value) tuple.',
                              properties: {
                                key: {
                                  description: 'key defines the key of the tuple.\nThis is the identifier or name part of the key-value pair.',
                                  minLength: 1,
                                  type: 'string',
                                },
                                value: {
                                  description: 'value defines the value of the tuple.\nThis is the data or content associated with the key.',
                                  type: 'string',
                                },
                              },
                              required: [
                                'key',
                                'value',
                              ],
                              type: 'object',
                            },
                            type: 'array',
                            'x-kubernetes-list-type': 'atomic',
                          },
                          entityDisplayName: {
                            description: 'entityDisplayName contains a summary of the alerted problem.\nThis appears as the main title or identifier for the incident.',
                            minLength: 1,
                            type: 'string',
                          },
                          httpConfig: {
                            description: "httpConfig defines the HTTP client's configuration for VictorOps API requests.",
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          messageType: {
                            description: 'messageType describes the behavior of the alert.\nValid values are "CRITICAL", "WARNING", and "INFO".',
                            minLength: 1,
                            type: 'string',
                          },
                          monitoringTool: {
                            description: 'monitoringTool defines the monitoring tool the state message is from.\nThis helps identify the source system that generated the alert.',
                            minLength: 1,
                            type: 'string',
                          },
                          routingKey: {
                            description: 'routingKey defines a key used to map the alert to a team.\nThis determines which VictorOps team will receive the alert notification.',
                            minLength: 1,
                            type: 'string',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          stateMessage: {
                            description: 'stateMessage contains a long explanation of the alerted problem.\nThis provides detailed context about the incident.',
                            minLength: 1,
                            type: 'string',
                          },
                        },
                        required: [
                          'routingKey',
                        ],
                        type: 'object',
                      },
                      type: 'array',
                    },
                    webexConfigs: {
                      description: 'webexConfigs defines the list of Webex configurations.',
                      items: {
                        description: 'WebexConfig configures notification via Cisco Webex\nSee https://prometheus.io/docs/alerting/latest/configuration/#webex_config',
                        properties: {
                          apiURL: {
                            description: 'apiURL defines the Webex Teams API URL i.e. https://webexapis.com/v1/messages',
                            pattern: '^https?://.+$',
                            type: 'string',
                          },
                          httpConfig: {
                            description: "httpConfig defines the HTTP client's configuration.\nYou must use this configuration to supply the bot token as part of the HTTP `Authorization` header.",
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          message: {
                            description: 'message defines the message template',
                            type: 'string',
                          },
                          roomID: {
                            description: 'roomID defines the ID of the Webex Teams room where to send the messages.',
                            minLength: 1,
                            type: 'string',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                        },
                        required: [
                          'roomID',
                        ],
                        type: 'object',
                      },
                      type: 'array',
                    },
                    webhookConfigs: {
                      description: 'webhookConfigs defines the List of webhook configurations.',
                      items: {
                        description: 'WebhookConfig configures notifications via a generic receiver supporting the webhook payload.\nSee https://prometheus.io/docs/alerting/latest/configuration/#webhook_config',
                        properties: {
                          httpConfig: {
                            description: 'httpConfig defines the HTTP client configuration for webhook requests.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          maxAlerts: {
                            description: 'maxAlerts defines the maximum number of alerts to be sent per webhook message.\nWhen 0, all alerts are included in the webhook payload.',
                            format: 'int32',
                            minimum: 0,
                            type: 'integer',
                          },
                          payload: {
                            description: 'payload define custom payload to be sent to the webhook endpoint.\nThis is an advanced configuration option that allows you\nto define a custom payload using Go templates.\nIt requires Alertmanager >= v0.32.0.',
                            minLength: 1,
                            type: 'string',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          timeout: {
                            description: 'timeout defines the maximum time to wait for a webhook request to complete,\nbefore failing the request and allowing it to be retried.\nIt requires Alertmanager >= v0.28.0.',
                            pattern: '^(0|(([0-9]+)y)?(([0-9]+)w)?(([0-9]+)d)?(([0-9]+)h)?(([0-9]+)m)?(([0-9]+)s)?(([0-9]+)ms)?)$',
                            type: 'string',
                          },
                          url: {
                            description: 'url defines the URL to send HTTP POST requests to.\nurlSecret takes precedence over url. One of urlSecret and url should be defined.',
                            type: 'string',
                          },
                          urlSecret: {
                            description: "urlSecret defines the secret's key that contains the webhook URL to send HTTP requests to.\nurlSecret takes precedence over url. One of urlSecret and url should be defined.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                        },
                        type: 'object',
                      },
                      type: 'array',
                    },
                    wechatConfigs: {
                      description: 'wechatConfigs defines the list of WeChat configurations.',
                      items: {
                        description: 'WeChatConfig configures notifications via WeChat.\nSee https://prometheus.io/docs/alerting/latest/configuration/#wechat_config',
                        properties: {
                          agentID: {
                            description: 'agentID defines the application agent ID within WeChat Work.\nThis identifies which WeChat Work application will send the notifications.',
                            minLength: 1,
                            type: 'string',
                          },
                          apiSecret: {
                            description: "apiSecret defines the secret's key that contains the WeChat API key.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                            properties: {
                              key: {
                                description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                minLength: 1,
                                type: 'string',
                              },
                              name: {
                                description: "name defines the name of the secret in the object's namespace to select from.",
                                minLength: 1,
                                type: 'string',
                              },
                            },
                            required: [
                              'key',
                              'name',
                            ],
                            type: 'object',
                          },
                          apiURL: {
                            description: 'apiURL defines the WeChat API URL.\nWhen not specified, defaults to the standard WeChat Work API endpoint.',
                            pattern: '^https?://.+$',
                            type: 'string',
                          },
                          corpID: {
                            description: 'corpID defines the corp id for authentication.\nThis is the unique identifier for your WeChat Work organization.',
                            minLength: 1,
                            type: 'string',
                          },
                          httpConfig: {
                            description: 'httpConfig defines the HTTP client configuration for WeChat API requests.',
                            properties: {
                              authorization: {
                                description: 'authorization defines the authorization header configuration for the client.\nThis is mutually exclusive with BasicAuth and is only available starting from Alertmanager v0.22+.',
                                properties: {
                                  credentials: {
                                    description: 'credentials defines a key of a Secret in the namespace that contains the credentials for authentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: {
                                    description: 'type defines the authentication type. The value is case-insensitive.\n\n"Basic" is not a supported value.\n\nDefault: "Bearer"',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                              basicAuth: {
                                description: 'basicAuth defines the basic authentication credentials for the client.\nThis is mutually exclusive with Authorization. If both are defined, BasicAuth takes precedence.',
                                properties: {
                                  password: {
                                    description: 'password defines a key of a Secret containing the password for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  username: {
                                    description: 'username defines a key of a Secret containing the username for\nauthentication.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                },
                                type: 'object',
                              },
                              bearerTokenSecret: {
                                description: "bearerTokenSecret defines the secret's key that contains the bearer token to be used by the client\nfor authentication.\nThe secret needs to be in the same namespace as the AlertmanagerConfig\nobject and accessible by the Prometheus Operator.",
                                properties: {
                                  key: {
                                    description: 'key defines the key of the secret to select from.  Must be a valid secret key.',
                                    minLength: 1,
                                    type: 'string',
                                  },
                                  name: {
                                    description: "name defines the name of the secret in the object's namespace to select from.",
                                    minLength: 1,
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'key',
                                  'name',
                                ],
                                type: 'object',
                              },
                              enableHttp2: {
                                description: 'enableHttp2 can be used to disable HTTP2.',
                                type: 'boolean',
                              },
                              followRedirects: {
                                description: 'followRedirects defines whether HTTP requests follow HTTP 3xx redirects.\nWhen true, the client will automatically follow redirect responses.',
                                type: 'boolean',
                              },
                              noProxy: {
                                description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'string',
                              },
                              oauth2: {
                                description: 'oauth2 defines the OAuth2 client credentials used to fetch a token for the targets.\nThis enables OAuth2 authentication flow for HTTP requests.',
                                properties: {
                                  clientId: {
                                    description: "clientId defines a key of a Secret or ConfigMap containing the\nOAuth2 client's ID.",
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  clientSecret: {
                                    description: "clientSecret defines a key of a Secret containing the OAuth2\nclient's secret.",
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  endpointParams: {
                                    additionalProperties: {
                                      type: 'string',
                                    },
                                    description: 'endpointParams configures the HTTP parameters to append to the token\nURL.',
                                    type: 'object',
                                  },
                                  noProxy: {
                                    description: 'noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names\nthat should be excluded from proxying. IP and domain names can\ncontain port numbers.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'string',
                                  },
                                  proxyConnectHeader: {
                                    additionalProperties: {
                                      items: {
                                        description: 'SecretKeySelector selects a key of a Secret.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      type: 'array',
                                    },
                                    description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  proxyFromEnvironment: {
                                    description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                    type: 'boolean',
                                  },
                                  proxyUrl: {
                                    description: 'proxyUrl defines the HTTP proxy server to use.',
                                    pattern: '^(http|https|socks5)://.+$',
                                    type: 'string',
                                  },
                                  scopes: {
                                    description: 'scopes defines the OAuth2 scopes used for the token request.',
                                    items: {
                                      type: 'string',
                                    },
                                    type: 'array',
                                  },
                                  tlsConfig: {
                                    description: 'tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.\nIt requires Prometheus >= v2.43.0.',
                                    properties: {
                                      ca: {
                                        description: 'ca defines the Certificate authority used when verifying server certificates.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      cert: {
                                        description: 'cert defines the Client certificate to present when doing client-authentication.',
                                        properties: {
                                          configMap: {
                                            description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key to select.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the ConfigMap or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                          secret: {
                                            description: 'secret defines the Secret containing data to use for the targets.',
                                            properties: {
                                              key: {
                                                description: 'The key of the secret to select from.  Must be a valid secret key.',
                                                type: 'string',
                                              },
                                              name: {
                                                default: '',
                                                description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                                type: 'string',
                                              },
                                              optional: {
                                                description: 'Specify whether the Secret or its key must be defined',
                                                type: 'boolean',
                                              },
                                            },
                                            required: [
                                              'key',
                                            ],
                                            type: 'object',
                                            'x-kubernetes-map-type': 'atomic',
                                          },
                                        },
                                        type: 'object',
                                      },
                                      insecureSkipVerify: {
                                        description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                        type: 'boolean',
                                      },
                                      keySecret: {
                                        description: 'keySecret defines the Secret containing the client key file for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      maxVersion: {
                                        description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      minVersion: {
                                        description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                        enum: [
                                          'TLS10',
                                          'TLS11',
                                          'TLS12',
                                          'TLS13',
                                        ],
                                        type: 'string',
                                      },
                                      serverName: {
                                        description: 'serverName is used to verify the hostname for the targets.',
                                        type: 'string',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  tokenUrl: {
                                    description: 'tokenUrl defines the URL to fetch the token from.',
                                    pattern: '^(http|https)://.+$',
                                    type: 'string',
                                  },
                                },
                                required: [
                                  'clientId',
                                  'clientSecret',
                                  'tokenUrl',
                                ],
                                type: 'object',
                              },
                              proxyConnectHeader: {
                                additionalProperties: {
                                  items: {
                                    description: 'SecretKeySelector selects a key of a Secret.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  type: 'array',
                                },
                                description: 'proxyConnectHeader optionally specifies headers to send to\nproxies during CONNECT requests.\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'object',
                                'x-kubernetes-map-type': 'atomic',
                              },
                              proxyFromEnvironment: {
                                description: 'proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).\n\nIt requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.',
                                type: 'boolean',
                              },
                              proxyURL: {
                                description: 'proxyURL defines an optional proxy URL for HTTP requests.\nIf defined, this field takes precedence over `proxyUrl`.',
                                type: 'string',
                              },
                              proxyUrl: {
                                description: 'proxyUrl defines the HTTP proxy server to use.',
                                pattern: '^(http|https|socks5)://.+$',
                                type: 'string',
                              },
                              tlsConfig: {
                                description: 'tlsConfig defines the TLS configuration for the client.\nThis includes settings for certificates, CA validation, and TLS protocol options.',
                                properties: {
                                  ca: {
                                    description: 'ca defines the Certificate authority used when verifying server certificates.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  cert: {
                                    description: 'cert defines the Client certificate to present when doing client-authentication.',
                                    properties: {
                                      configMap: {
                                        description: 'configMap defines the ConfigMap containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key to select.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the ConfigMap or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                      secret: {
                                        description: 'secret defines the Secret containing data to use for the targets.',
                                        properties: {
                                          key: {
                                            description: 'The key of the secret to select from.  Must be a valid secret key.',
                                            type: 'string',
                                          },
                                          name: {
                                            default: '',
                                            description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                            type: 'string',
                                          },
                                          optional: {
                                            description: 'Specify whether the Secret or its key must be defined',
                                            type: 'boolean',
                                          },
                                        },
                                        required: [
                                          'key',
                                        ],
                                        type: 'object',
                                        'x-kubernetes-map-type': 'atomic',
                                      },
                                    },
                                    type: 'object',
                                  },
                                  insecureSkipVerify: {
                                    description: 'insecureSkipVerify defines how to disable target certificate validation.',
                                    type: 'boolean',
                                  },
                                  keySecret: {
                                    description: 'keySecret defines the Secret containing the client key file for the targets.',
                                    properties: {
                                      key: {
                                        description: 'The key of the secret to select from.  Must be a valid secret key.',
                                        type: 'string',
                                      },
                                      name: {
                                        default: '',
                                        description: 'Name of the referent.\nThis field is effectively required, but due to backwards compatibility is\nallowed to be empty. Instances of this type with an empty value here are\nalmost certainly wrong.\nMore info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names',
                                        type: 'string',
                                      },
                                      optional: {
                                        description: 'Specify whether the Secret or its key must be defined',
                                        type: 'boolean',
                                      },
                                    },
                                    required: [
                                      'key',
                                    ],
                                    type: 'object',
                                    'x-kubernetes-map-type': 'atomic',
                                  },
                                  maxVersion: {
                                    description: 'maxVersion defines the maximum acceptable TLS version.\n\nIt requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  minVersion: {
                                    description: 'minVersion defines the minimum acceptable TLS version.\n\nIt requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.',
                                    enum: [
                                      'TLS10',
                                      'TLS11',
                                      'TLS12',
                                      'TLS13',
                                    ],
                                    type: 'string',
                                  },
                                  serverName: {
                                    description: 'serverName is used to verify the hostname for the targets.',
                                    type: 'string',
                                  },
                                },
                                type: 'object',
                              },
                            },
                            type: 'object',
                          },
                          message: {
                            description: 'message defines the API request data as defined by the WeChat API.\nThis contains the actual notification content to be sent.',
                            minLength: 1,
                            type: 'string',
                          },
                          messageType: {
                            description: 'messageType defines the type of message to send.\nValid values include "text", "markdown", and other WeChat Work supported message types.',
                            minLength: 1,
                            type: 'string',
                          },
                          sendResolved: {
                            description: 'sendResolved defines whether or not to notify about resolved alerts.',
                            type: 'boolean',
                          },
                          toParty: {
                            description: "toParty defines the target department(s) to receive the notification.\nCan be a single department ID or multiple department IDs separated by '|'.",
                            minLength: 1,
                            type: 'string',
                          },
                          toTag: {
                            description: "toTag defines the target tag(s) to receive the notification.\nCan be a single tag ID or multiple tag IDs separated by '|'.",
                            minLength: 1,
                            type: 'string',
                          },
                          toUser: {
                            description: "toUser defines the target user(s) to receive the notification.\nCan be a single user ID or multiple user IDs separated by '|'.",
                            minLength: 1,
                            type: 'string',
                          },
                        },
                        type: 'object',
                      },
                      type: 'array',
                    },
                  },
                  required: [
                    'name',
                  ],
                  type: 'object',
                },
                type: 'array',
              },
              route: {
                description: "route defines the Alertmanager route definition for incoming alerts. It will be added to the\ngenerated Alertmanager configuration as a first-level route. The matching behavior of the\nroute depends on the Alertmanager's AlertmanagerConfigMatcherStrategyType.",
                properties: {
                  activeTimeIntervals: {
                    description: 'activeTimeIntervals is a list of TimeInterval names when this route should be active.',
                    items: {
                      type: 'string',
                    },
                    type: 'array',
                  },
                  continue: {
                    description: 'continue defines the boolean indicating whether an alert should continue matching subsequent\nsibling nodes. It will always be overridden to true for the first-level\nroute by the Prometheus operator.',
                    type: 'boolean',
                  },
                  groupBy: {
                    description: 'groupBy defines the list of labels to group by.\nLabels must not be repeated (unique list).\nSpecial label "..." (aggregate by all possible labels), if provided, must be the only element in the list.',
                    items: {
                      type: 'string',
                    },
                    type: 'array',
                  },
                  groupInterval: {
                    description: 'groupInterval defines how long to wait before sending an updated notification.\nMust be greater than 0.\nExample: "5m"',
                    minLength: 1,
                    pattern: '^(0|(([0-9]+)y)?(([0-9]+)w)?(([0-9]+)d)?(([0-9]+)h)?(([0-9]+)m)?(([0-9]+)s)?(([0-9]+)ms)?)$',
                    type: 'string',
                  },
                  groupWait: {
                    description: 'groupWait defines how long to wait before sending the initial notification.\nExample: "30s"',
                    minLength: 1,
                    pattern: '^(0|(([0-9]+)y)?(([0-9]+)w)?(([0-9]+)d)?(([0-9]+)h)?(([0-9]+)m)?(([0-9]+)s)?(([0-9]+)ms)?)$',
                    type: 'string',
                  },
                  matchers: {
                    description: "matchers defines the list of matchers that the alert's labels should match. For the first\nlevel route, the operator removes any existing equality and regexp\nmatcher on the `namespace` label and adds a `namespace: <object namespace>` matcher,\nunless configured otherwise in Alertmanager's AlertmanagerConfigMatcherStrategyType.",
                    items: {
                      description: "Matcher defines how to match on alert's labels.",
                      properties: {
                        matchType: {
                          description: 'matchType defines the match operation available with AlertManager >= v0.22.0.\nTakes precedence over Regex (deprecated) if non-empty.\nValid values: "=" (equality), "!=" (inequality), "=~" (regex match), "!~" (regex non-match).',
                          enum: [
                            '!=',
                            '=',
                            '=~',
                            '!~',
                          ],
                          type: 'string',
                        },
                        name: {
                          description: 'name defines the label to match.\nThis specifies which alert label should be evaluated.',
                          minLength: 1,
                          type: 'string',
                        },
                        value: {
                          description: 'value defines the label value to match.\nThis is the expected value for the specified label.',
                          type: 'string',
                        },
                      },
                      required: [
                        'name',
                      ],
                      type: 'object',
                    },
                    type: 'array',
                  },
                  muteTimeIntervals: {
                    description: 'muteTimeIntervals is a list of MuteTimeInterval names that will mute this route when matched,',
                    items: {
                      type: 'string',
                    },
                    type: 'array',
                  },
                  receiver: {
                    description: 'receiver defines the name of the receiver for this route. If not empty, it should be listed in\nthe `receivers` field.',
                    type: 'string',
                  },
                  repeatInterval: {
                    description: 'repeatInterval defines how long to wait before repeating the last notification.\nMust be greater than 0.\nExample: "4h"',
                    minLength: 1,
                    pattern: '^(0|(([0-9]+)y)?(([0-9]+)w)?(([0-9]+)d)?(([0-9]+)h)?(([0-9]+)m)?(([0-9]+)s)?(([0-9]+)ms)?)$',
                    type: 'string',
                  },
                  routes: {
                    description: 'routes defines the child routes.',
                    items: {
                      'x-kubernetes-preserve-unknown-fields': true,
                    },
                    type: 'array',
                  },
                },
                type: 'object',
              },
              timeIntervals: {
                description: 'timeIntervals defines the list of timeIntervals specifying when the routes should be muted.',
                items: {
                  description: 'TimeInterval specifies the periods in time when notifications will be muted or active.',
                  properties: {
                    name: {
                      description: 'name of the time interval.',
                      type: 'string',
                    },
                    timeIntervals: {
                      description: 'timeIntervals defines a list of TimePeriod.',
                      items: {
                        description: 'TimePeriod describes periods of time.',
                        properties: {
                          daysOfMonth: {
                            description: 'daysOfMonth defines a list of DayOfMonthRange',
                            items: {
                              description: 'DayOfMonthRange is an inclusive range of days of the month beginning at 1',
                              properties: {
                                end: {
                                  description: 'end of the inclusive range',
                                  maximum: 31,
                                  minimum: -31,
                                  type: 'integer',
                                },
                                start: {
                                  description: 'start of the inclusive range',
                                  maximum: 31,
                                  minimum: -31,
                                  type: 'integer',
                                },
                              },
                              type: 'object',
                            },
                            type: 'array',
                          },
                          months: {
                            description: 'months defines a list of MonthRange',
                            items: {
                              description: "MonthRange is an inclusive range of months of the year beginning in January\nMonths can be specified by name (e.g 'January') by numerical month (e.g '1') or as an inclusive range (e.g 'January:March', '1:3', '1:March')",
                              pattern: '^((?i)january|february|march|april|may|june|july|august|september|october|november|december|1[0-2]|[1-9])(?:((:((?i)january|february|march|april|may|june|july|august|september|october|november|december|1[0-2]|[1-9]))$)|$)',
                              type: 'string',
                            },
                            type: 'array',
                          },
                          times: {
                            description: 'times defines a list of TimeRange',
                            items: {
                              description: 'TimeRange defines a start and end time in 24hr format',
                              properties: {
                                endTime: {
                                  description: 'endTime defines the end time in 24hr format.',
                                  pattern: '^((([01][0-9])|(2[0-3])):[0-5][0-9])$|(^24:00$)',
                                  type: 'string',
                                },
                                startTime: {
                                  description: 'startTime defines the start time in 24hr format.',
                                  pattern: '^((([01][0-9])|(2[0-3])):[0-5][0-9])$|(^24:00$)',
                                  type: 'string',
                                },
                              },
                              type: 'object',
                            },
                            type: 'array',
                          },
                          weekdays: {
                            description: 'weekdays defines a list of WeekdayRange',
                            items: {
                              description: "WeekdayRange is an inclusive range of days of the week beginning on Sunday\nDays can be specified by name (e.g 'Sunday') or as an inclusive range (e.g 'Monday:Friday')",
                              pattern: '^((?i)sun|mon|tues|wednes|thurs|fri|satur)day(?:((:(sun|mon|tues|wednes|thurs|fri|satur)day)$)|$)',
                              type: 'string',
                            },
                            type: 'array',
                          },
                          years: {
                            description: 'years defines a list of YearRange',
                            items: {
                              description: 'YearRange is an inclusive range of years',
                              pattern: '^2\\d{3}(?::2\\d{3}|$)',
                              type: 'string',
                            },
                            type: 'array',
                          },
                        },
                        type: 'object',
                      },
                      type: 'array',
                    },
                  },
                  required: [
                    'name',
                  ],
                  type: 'object',
                },
                type: 'array',
              },
            },
            type: 'object',
          },
          status: {
            description: 'status defines the status subresource. It is under active development and is updated only when the\n"StatusForConfigurationResources" feature gate is enabled.\n\nMost recent observed status of the ServiceMonitor. Read-only.\nMore info:\nhttps://github.com/kubernetes/community/blob/master/contributors/devel/sig-architecture/api-conventions.md#spec-and-status',
            properties: {
              bindings: {
                description: 'bindings defines the list of workload resources (Prometheus, PrometheusAgent, ThanosRuler or Alertmanager) which select the configuration resource.',
                items: {
                  description: 'WorkloadBinding is a link between a configuration resource and a workload resource.',
                  properties: {
                    conditions: {
                      description: 'conditions defines the current state of the configuration resource when bound to the referenced Workload object.',
                      items: {
                        description: 'ConfigResourceCondition describes the status of configuration resources linked to Prometheus, PrometheusAgent, Alertmanager or ThanosRuler.',
                        properties: {
                          lastTransitionTime: {
                            description: 'lastTransitionTime defines the time of the last update to the current status property.',
                            format: 'date-time',
                            type: 'string',
                          },
                          message: {
                            description: "message defines the human-readable message indicating details for the condition's last transition.",
                            type: 'string',
                          },
                          observedGeneration: {
                            description: 'observedGeneration defines the .metadata.generation that the\ncondition was set based upon. For instance, if `.metadata.generation` is\ncurrently 12, but the `.status.conditions[].observedGeneration` is 9, the\ncondition is out of date with respect to the current state of the object.',
                            format: 'int64',
                            type: 'integer',
                          },
                          reason: {
                            description: "reason for the condition's last transition.",
                            type: 'string',
                          },
                          status: {
                            description: 'status of the condition.',
                            minLength: 1,
                            type: 'string',
                          },
                          type: {
                            description: 'type of the condition being reported.\nCurrently, only "Accepted" is supported.',
                            enum: [
                              'Accepted',
                            ],
                            minLength: 1,
                            type: 'string',
                          },
                        },
                        required: [
                          'lastTransitionTime',
                          'status',
                          'type',
                        ],
                        type: 'object',
                      },
                      type: 'array',
                      'x-kubernetes-list-map-keys': [
                        'type',
                      ],
                      'x-kubernetes-list-type': 'map',
                    },
                    group: {
                      description: 'group defines the group of the referenced resource.',
                      enum: [
                        'monitoring.coreos.com',
                      ],
                      type: 'string',
                    },
                    name: {
                      description: 'name defines the name of the referenced object.',
                      minLength: 1,
                      type: 'string',
                    },
                    namespace: {
                      description: 'namespace defines the namespace of the referenced object.',
                      minLength: 1,
                      type: 'string',
                    },
                    resource: {
                      description: 'resource defines the type of resource being referenced (e.g. Prometheus, PrometheusAgent, ThanosRuler or Alertmanager).',
                      enum: [
                        'prometheuses',
                        'prometheusagents',
                        'thanosrulers',
                        'alertmanagers',
                      ],
                      type: 'string',
                    },
                  },
                  required: [
                    'group',
                    'name',
                    'namespace',
                    'resource',
                  ],
                  type: 'object',
                },
                type: 'array',
                'x-kubernetes-list-map-keys': [
                  'group',
                  'resource',
                  'name',
                  'namespace',
                ],
                'x-kubernetes-list-type': 'map',
              },
            },
            type: 'object',
          },
        },
        required: [
          'spec',
        ],
        type: 'object',
      },
    },
    served: true,
    storage: false,
    subresources: {
      status: {},
    },
  },
] } }

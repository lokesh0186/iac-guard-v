{{/*
Expand the name of the chart.
*/}}
{{- define "opentelemetry-kube-stack.name" -}}
{{- default .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "opentelemetry-kube-stack.fullname" -}}
{{- if .fullnameOverride }}
{{- .fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}


{{/*
Add the opamp labels if they're enabled
*/}}
{{- define "opentelemetry-kube-stack.collectorOpAMPLabels" -}}
{{- if and .opAMPBridge.enabled .opAMPBridge.addReportingLabel }}
opentelemetry.io/opamp-reporting: "true"
{{- end }}
{{- if and .opAMPBridge.enabled .opAMPBridge.addManagedLabel }}
opentelemetry.io/opamp-managed: "true"
{{- end }}
{{- end }}

{{/*
Allow the release namespace to be overridden
*/}}
{{- define "opentelemetry-kube-stack.namespace" -}}
  {{- if .Values.namespaceOverride -}}
    {{- .Values.namespaceOverride -}}
  {{- else -}}
    {{- .Release.Namespace -}}
  {{- end -}}
{{- end -}}

{{/*
Print a map of key values in a YAML block. This is useful for labels and annotations.
*/}}
{{- define "opentelemetry-kube-stack.renderkv" -}}
{{- with . -}}
{{- range $key, $value := . -}}
{{- printf "\n%s: %s" $key $value }}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Render a deduped list of environment variables and 'extraEnvs'
*/}}
{{- define "opentelemetry-kube-stack.renderenvs" -}}
{{- $envMap := dict }}
{{- $valueFromMap := dict }}
{{- range $item := .extraEnvs }}
{{- if hasKey $item "value" }}
{{- $_ := set $envMap $item.name $item.value }}
{{- else }}
{{- $_ := set $valueFromMap $item.name $item.valueFrom }}
{{- end }}
{{- end }}
{{- range $item := .env }}
{{- if hasKey $item "value" }}
{{- $_ := set $envMap $item.name $item.value }}
{{- else }}
{{- $_ := set $valueFromMap $item.name $item.valueFrom }}
{{- end }}
{{- end }}
{{- range $key, $value := $envMap }}
- name: {{ $key }}
  value: {{ $value | quote }}
{{- end }}
{{- range $key, $value := $valueFromMap }}
- name: {{ $key }}
  valueFrom:
    {{- $value | toYaml | nindent 4 }}
{{- end }}
{{- end }}

{{/*
Create the name of the instrumentation to use
*/}}
{{- define "opentelemetry-kube-stack.instrumentation" -}}
{{- default .Release.Name .Values.instrumentation.name }}
{{- end }}

{{/*
Create the name of the bridge to create
*/}}
{{- define "opentelemetry-opamp-bridge.fullname" -}}
{{- default .Release.Name .opAMPBridge.name }}
{{- end }}

{{/*
Create the name of the clusterRole to use for the opampbridge
*/}}
{{- define "opentelemetry-opamp-bridge.clusterRoleName" -}}
{{- default (printf "%s-bridge" .Release.Name) .Values.opAMPBridge.clusterRole.name }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "opentelemetry-kube-stack.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "opentelemetry-kube-stack.labels" -}}
helm.sh/chart: {{ include "opentelemetry-kube-stack.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
release: {{ .Release.Name | quote }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "opentelemetry-kube-stack.collectorFullname" -}}
{{- if .fullnameOverride }}
{{- .fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else if .collector.fullnameOverride }}
{{- .collector.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $suffix := default .Chart.Name (coalesce .collector.suffix "") }}
{{- if contains $suffix .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $suffix | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create the name of the clusterRole to use
*/}}
{{- define "opentelemetry-kube-stack.clusterRoleName" -}}
{{- default (printf "%s-collector" .Release.Name) .Values.clusterRole.name }}
{{- end }}

{{/*
Create the name of the clusterRoleBinding to use
*/}}
{{- define "opentelemetry-kube-stack.clusterRoleBindingName" -}}
{{- default (include "opentelemetry-kube-stack.fullname" .) .Values.clusterRole.clusterRoleBinding.name }}
{{- end }}

{{/*
Optionally include the RBAC for the k8sCluster receiver
*/}}
{{- define "opentelemetry-kube-stack.k8scluster.rules" -}}
{{- if $.Values.clusterRole.rules }}
{{ toYaml $.Values.clusterRole.rules }}
{{- end }}
{{- $clusterMetricsEnabled := false }}
{{- $eventsEnabled := false }}
{{- $kubernetesObjectsEnabled := false }}
{{- $kubernetesObjectsCoreEnabled := false }}
{{- $kubernetesObjectsRbacEnabled := false }}
{{- $kubernetesObjectsStorageEnabled := false }}
{{- $kubernetesObjectsNetworkingEnabled := false }}
{{- $kubernetesObjectsAutoscalingEnabled := false }}
{{- $kubernetesObjectsAutoscalingVpaEnabled := false }}
{{- $kubernetesObjectsPolicyEnabled := false }}
{{- $kubernetesObjectsApiExtensionsEnabled := false }}
{{- $useLeaderElection := false }}
{{- $k8sApiEnabled := false }}
{{ range $_, $collector := $.Values.collectors -}}
{{- if $.Values.defaultCRConfig.enabled }}
{{- $collector = (mergeOverwrite (deepCopy $.Values.defaultCRConfig) $collector) }}
{{- end }}
{{- $clusterMetricsEnabled = (any $clusterMetricsEnabled (dig "config" "receivers" "k8s_cluster" false $collector)) }}
{{- if (dig "presets" "clusterMetrics" "enabled" false $collector) }}
{{- $clusterMetricsEnabled = true }}
{{- $useLeaderElection = (any $useLeaderElection (not (dig "presets" "clusterMetrics" "disableLeaderElection" false $collector))) }}
{{- end }}
{{- $eventsEnabled = (any $eventsEnabled (dig "config" "receivers" "k8s_cluster" false $collector)) }}
{{- if (dig "presets" "kubernetesEvents" "enabled" false $collector) }}
{{- $eventsEnabled = true }}
{{- $useLeaderElection = (any $useLeaderElection (not (dig "presets" "kubernetesEvents" "disableLeaderElection" false $collector))) }}
{{- end }}
{{- if (dig "presets" "kubernetesObjects" "enabled" false $collector) }}
{{- $kubernetesObjectsEnabled = true }}
{{- $kubernetesObjectsCoreEnabled = (any $kubernetesObjectsCoreEnabled (dig "presets" "kubernetesObjects" "core" "enabled" true $collector)) }}
{{- $kubernetesObjectsRbacEnabled = (any $kubernetesObjectsRbacEnabled (dig "presets" "kubernetesObjects" "rbac" "enabled" true $collector)) }}
{{- $kubernetesObjectsStorageEnabled = (any $kubernetesObjectsStorageEnabled (dig "presets" "kubernetesObjects" "storage" "enabled" true $collector)) }}
{{- $kubernetesObjectsNetworkingEnabled = (any $kubernetesObjectsNetworkingEnabled (dig "presets" "kubernetesObjects" "networking" "enabled" true $collector)) }}
{{- $kubernetesObjectsAutoscalingEnabled = (any $kubernetesObjectsAutoscalingEnabled (dig "presets" "kubernetesObjects" "autoscaling" "enabled" true $collector)) }}
{{- $kubernetesObjectsAutoscalingVpaEnabled = (any $kubernetesObjectsAutoscalingVpaEnabled (dig "presets" "kubernetesObjects" "autoscaling" "vpa" "enabled" false $collector)) }}
{{- $kubernetesObjectsPolicyEnabled = (any $kubernetesObjectsPolicyEnabled (dig "presets" "kubernetesObjects" "policy" "enabled" true $collector)) }}
{{- $kubernetesObjectsApiExtensionsEnabled = (any $kubernetesObjectsApiExtensionsEnabled (dig "presets" "kubernetesObjects" "apiExtensions" "enabled" true $collector)) }}
{{- $useLeaderElection = (any $useLeaderElection (and (eq $collector.mode "daemonset") (not (dig "presets" "kubernetesObjects" "disableLeaderElection" false $collector)))) }}
{{- end }}
{{- if (dig "presets" "resourceDetection" "k8s_api" "enabled" false $collector) }}
{{- $k8sApiEnabled = true }}
{{- end }}
{{- end }}
{{- if $useLeaderElection }}
- verbs:
  - get
  - list
  - watch
  - create
  - update
  - patch
  - delete
  apiGroups:
  - coordination.k8s.io
  resources:
  - leases
{{- end }}
{{- if $clusterMetricsEnabled }}
- apiGroups:
  - ""
  resources:
  - events
  - namespaces
  - namespaces/status
  - nodes
  - nodes/spec
  - pods
  - pods/status
  - replicationcontrollers
  - replicationcontrollers/status
  - resourcequotas
  - services
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - apps
  resources:
  - daemonsets
  - deployments
  - replicasets
  - statefulsets
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - extensions
  resources:
  - daemonsets
  - deployments
  - replicasets
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - batch
  resources:
  - jobs
  - cronjobs
  verbs:
  - get
  - list
  - watch
- apiGroups:
    - autoscaling
  resources:
    - horizontalpodautoscalers
  verbs:
    - get
    - list
    - watch
{{- end }}
{{- if $eventsEnabled }}
- apiGroups: ["events.k8s.io"]
  resources: ["events"]
  verbs: ["watch", "list"]
{{- end }}
{{- if $k8sApiEnabled }}
- apiGroups: [""]
  resources: ["nodes"]
  verbs: ["get", "list"]
- apiGroups: [""]
  resources: ["namespaces"]
  resourceNames: ["kube-system"]
  verbs: ["get"]
{{- end }}
{{- if $kubernetesObjectsEnabled }}
{{- if $kubernetesObjectsCoreEnabled }}
- apiGroups: [""]
  resources: ["namespaces", "pods", "nodes", "services", "serviceaccounts"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["apps"]
  resources: ["deployments", "replicasets", "daemonsets", "statefulsets"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["batch"]
  resources: ["jobs", "cronjobs"]
  verbs: ["get", "list", "watch"]
{{- end }}
{{- if $kubernetesObjectsRbacEnabled }}
- apiGroups: ["rbac.authorization.k8s.io"]
  resources: ["roles", "rolebindings", "clusterroles", "clusterrolebindings"]
  verbs: ["get", "list", "watch"]
{{- end }}
{{- if $kubernetesObjectsStorageEnabled }}
- apiGroups: [""]
  resources: ["persistentvolumes", "persistentvolumeclaims"]
  verbs: ["get", "list", "watch"]
- apiGroups: ["storage.k8s.io"]
  resources: ["storageclasses"]
  verbs: ["get", "list", "watch"]
{{- end }}
{{- if $kubernetesObjectsNetworkingEnabled }}
- apiGroups: ["networking.k8s.io"]
  resources: ["ingresses", "networkpolicies"]
  verbs: ["get", "list", "watch"]
{{- end }}
{{- if $kubernetesObjectsAutoscalingEnabled }}
- apiGroups: ["autoscaling"]
  resources: ["horizontalpodautoscalers"]
  verbs: ["get", "list", "watch"]
{{- if $kubernetesObjectsAutoscalingVpaEnabled }}
- apiGroups: ["autoscaling.k8s.io"]
  resources: ["verticalpodautoscalers"]
  verbs: ["get", "list", "watch"]
{{- end }}
{{- end }}
{{- if $kubernetesObjectsPolicyEnabled }}
- apiGroups: ["policy"]
  resources: ["poddisruptionbudgets"]
  verbs: ["get", "list", "watch"]
{{- end }}
{{- if $kubernetesObjectsApiExtensionsEnabled }}
- apiGroups: ["apiextensions.k8s.io"]
  resources: ["customresourcedefinitions"]
  verbs: ["get", "list", "watch"]
{{- end }}
{{- end }}
{{- end }}

{{/*
List of deprecated Collector component type names that this chart accepts while
users migrate to the current lower_snake_case names.
*/}}
{{- define "opentelemetry-kube-stack.collector.componentRenames" -}}
- old: k8sattributes
  new: k8s_attributes
  section: processors
  pipeline: processors
- old: resourcedetection/env
  new: resource_detection/env
  section: processors
  pipeline: processors
- old: hostmetrics
  new: host_metrics
  section: receivers
  pipeline: receivers
- old: kubeletstats
  new: kubelet_stats
  section: receivers
  pipeline: receivers
- old: filelog
  new: file_log
  section: receivers
  pipeline: receivers
- old: k8sobjects
  new: k8s_objects
  section: receivers
  pipeline: receivers
{{- end }}

{{- define "opentelemetry-kube-stack.collector.componentNames" -}}
{{- $names := dict }}
{{- $renames := include "opentelemetry-kube-stack.collector.componentRenames" . | fromYamlArray }}
{{- range $rename := $renames }}
{{- $name := ternary $rename.new $rename.old $.rewriteDeprecatedComponentNames }}
{{- $_ := set $names $rename.old $name }}
{{- end }}
{{- $names | toYaml }}
{{- end }}

{{- define "opentelemetry-kube-stack.deprecations" -}}
{{- $warnings := list }}
{{- $renames := include "opentelemetry-kube-stack.collector.componentRenames" . | fromYamlArray }}
{{- range $collectorName, $collector := .Values.collectors }}
{{- if $.Values.defaultCRConfig.enabled }}
{{- $collector = (mergeOverwrite (deepCopy $.Values.defaultCRConfig) $collector) }}
{{- end }}
{{- if $collector.enabled }}
{{- $config := deepCopy ($collector.config | default dict) }}
{{- range $rename := $renames }}
{{- $oldName := $rename.old }}
{{- $newName := $rename.new }}
{{- $sectionName := $rename.section }}
{{- $pipelineName := $rename.pipeline }}
{{- $components := get $config $sectionName | default dict }}
{{- if hasKey $components $oldName }}
{{- $warnings = append $warnings (printf "[DEPRECATION] Collector %q: component %q has been renamed to %q. Update your values.yaml. Support for the old name will be removed in a future chart release." $collectorName $oldName $newName) }}
{{- end }}
{{- $pipelines := dig "service" "pipelines" dict $config }}
{{- range $signal, $pipeline := $pipelines }}
{{- if $pipeline }}
{{- $items := get $pipeline $pipelineName | default list }}
{{- if has $oldName $items }}
{{- $warnings = append $warnings (printf "[DEPRECATION] Collector %q: pipeline %q references renamed component %q. Use %q in your values.yaml. Support for the old name will be removed in a future chart release." $collectorName $signal $oldName $newName) }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- join "\n" $warnings }}
{{- end }}

{{/*
Helpers for prometheus servicemonitors
*/}}
{{/* Prometheus specific stuff. */}}
{{/* Allow KubeVersion to be overridden. */}}
{{- define "opentelemetry-kube-stack.kubeVersion" -}}
  {{- default .Capabilities.KubeVersion.Version .Values.kubeVersionOverride -}}
{{- end -}}

{{/* Get value based on current Kubernetes version */}}
{{- define "opentelemetry-kube-stack.kubeVersionDefaultValue" -}}
  {{- $values := index . 0 -}}
  {{- $kubeVersion := index . 1 -}}
  {{- $old := index . 2 -}}
  {{- $new := index . 3 -}}
  {{- $default := index . 4 -}}
  {{- if kindIs "invalid" $default -}}
    {{- if semverCompare $kubeVersion (include "opentelemetry-kube-stack.kubeVersion" $values) -}}
      {{- print $new -}}
    {{- else -}}
      {{- print $old -}}
    {{- end -}}
  {{- else -}}
    {{- print $default }}
  {{- end -}}
{{- end -}}

{{/* Get value for kube-controller-manager depending on insecure scraping availability */}}
{{- define "opentelemetry-kube-stack.kubeControllerManager.insecureScrape" -}}
  {{- $values := index . 0 -}}
  {{- $insecure := index . 1 -}}
  {{- $secure := index . 2 -}}
  {{- $userValue := index . 3 -}}
  {{- include "opentelemetry-kube-stack.kubeVersionDefaultValue" (list $values ">= 1.22-0" $insecure $secure $userValue) -}}
{{- end -}}

{{/* Get value for kube-scheduler depending on insecure scraping availability */}}
{{- define "opentelemetry-kube-stack.kubeScheduler.insecureScrape" -}}
  {{- $values := index . 0 -}}
  {{- $insecure := index . 1 -}}
  {{- $secure := index . 2 -}}
  {{- $userValue := index . 3 -}}
  {{- include "opentelemetry-kube-stack.kubeVersionDefaultValue" (list $values ">= 1.23-0" $insecure $secure $userValue) -}}
{{- end -}}

{{/* Sets default scrape limits for servicemonitor */}}
{{- define "opentelemetry-kube-stack.servicemonitor.scrapeLimits" -}}
{{- with .sampleLimit }}
sampleLimit: {{ . }}
{{- end }}
{{- with .targetLimit }}
targetLimit: {{ . }}
{{- end }}
{{- with .labelLimit }}
labelLimit: {{ . }}
{{- end }}
{{- with .labelNameLengthLimit }}
labelNameLengthLimit: {{ . }}
{{- end }}
{{- with .labelValueLengthLimit }}
labelValueLengthLimit: {{ . }}
{{- end }}
{{- end -}}

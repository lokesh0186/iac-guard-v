/*
Copyright 2025 The Flux authors

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package decryptor

import (
	"k8s.io/apimachinery/pkg/types"

	"github.com/fluxcd/pkg/cache"
)

// Option is a functional option for configuring the Decryptor.
type Option func(o *Decryptor)

// WithRoot sets the root directory for the Decryptor.
func WithRoot(root string) Option {
	return func(o *Decryptor) {
		o.root = root
	}
}

// WithTokenCache sets the token cache for the Decryptor.
func WithTokenCache(tokenCache cache.TokenCache) Option {
	return func(o *Decryptor) {
		o.tokenCache = &tokenCache
	}
}

// WithSOPSAgeSecret sets the SOPSAgeSecret for the Decryptor.
func WithSOPSAgeSecret(name, namespace string) Option {
	return func(o *Decryptor) {
		o.sopsAgeSecret = &types.NamespacedName{
			Name:      name,
			Namespace: namespace,
		}
	}
}

// WithVaultConfigMap sets the ConfigMap (by name and namespace)
// mapping Vault/OpenBao addresses to the Kubernetes auth mount to use for each,
// used to authenticate for SOPS decryption. The ConfigMap also acts as an
// allowlist: only addresses listed in it can be used. When unset, Vault
// Kubernetes auth is disabled.
func WithVaultConfigMap(name, namespace string) Option {
	return func(o *Decryptor) {
		o.vaultConfigMap = &types.NamespacedName{
			Name:      name,
			Namespace: namespace,
		}
	}
}

package commands

import (
	"context"
	"fmt"
	"os"
	"os/signal"

	"github.com/argoproj/pkg/stats"
	"github.com/spf13/cobra"

	"github.com/argoproj/argo-workflows/v4/cmd/argoexec/executor"
	wfv1 "github.com/argoproj/argo-workflows/v4/pkg/apis/workflow/v1alpha1"
	"github.com/argoproj/argo-workflows/v4/util/logging"
	"github.com/argoproj/argo-workflows/v4/workflow/common"
)

func NewArtifactPluginInitCommand() *cobra.Command {
	var artifactPlugin string
	command := cobra.Command{
		Use:   "artifact-plugin-init",
		Short: "Load artifacts from an artifact plugin only, as an init container",
		RunE: func(cmd *cobra.Command, args []string) error {
			ctx := cmd.Context()
			logger := logging.RequireLoggerFromContext(ctx)
			containerName := os.Getenv(common.EnvVarContainerName)
			includeScriptOutput := os.Getenv(common.EnvVarIncludeScriptOutput) == "true"

			name, args := args[0], args[1:]
			logger.WithFields(logging.Fields{"name": name, "args": args}).Debug(ctx, "starting command")

			go func() {
				command, closer, err := startCommand(ctx, name, args, &wfv1.Template{}, containerName, includeScriptOutput)
				if err != nil {
					logger.WithError(err).Error(ctx, "failed to start command")
					return
				}
				defer closer()
				// setup signal handlers
				signals := make(chan os.Signal, 1)
				defer close(signals)
				signal.Notify(signals)
				defer signal.Reset()

				forwardSignals(ctx, signals, command.Process.Pid, false)
			}()
			err := loadArtifactPlugin(ctx, wfv1.ArtifactPluginName(artifactPlugin))
			if err != nil {
				return fmt.Errorf("%w", err)
			}
			return nil
		},
	}
	command.Flags().StringVar(&artifactPlugin, "plugin-name", "", "Artifact plugin name")
	return &command
}

func loadArtifactPlugin(ctx context.Context, pluginName wfv1.ArtifactPluginName) error {
	if err := os.MkdirAll(pluginName.SocketDir(), 0755); err != nil {
		return err
	}
	wfExecutor := executor.Init(ctx, clientConfig, varRunArgo)
	errHandler := wfExecutor.HandleError(ctx)
	defer errHandler()
	defer stats.LogStats()

	err := wfExecutor.LoadArtifactsFromPlugin(ctx, pluginName)
	if err != nil {
		wfExecutor.AddError(ctx, err)
		return err
	}
	return nil
}
